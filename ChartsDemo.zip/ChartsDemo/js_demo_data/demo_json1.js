// entered data from: 
// "available-proteins-ptmvision-210212-Didier-control-t4-merged.json"

let proteinData1 = [
  {
    "id": "A0A098G589",
    "length": 199,
    "modifications": "Carbamidomethyl$Methylamine",
    "modified_positions": 2,
    "name": "Phage repressor",
    "unique_modifications": 2
  },
  {
    "id": "A0A098G593",
    "length": 166,
    "modifications": "Gln->pyro-Glu",
    "modified_positions": 2,
    "name": "Acetyltransferase, GNAT family",
    "unique_modifications": 1
  },
  {
    "id": "A0A098G869",
    "length": 126,
    "modifications": "Acetyl$Malonyl$bemad_st_2h(6)$FormylMet$15N-oxobutanoic$thioacylPA$Carbamidomethyl$Dehydrated",
    "modified_positions": 8,
    "name": "Small ribosomal subunit protein uS12",
    "unique_modifications": 8
  },
  {
    "id": "A0A098G8E7",
    "length": 78,
    "modifications": "Carbamidomethyl$UgiJoullie$phenylsulfonylethyl",
    "modified_positions": 4,
    "name": "Translational regulator CsrA",
    "unique_modifications": 3
  },
  {
    "id": "A0A0A2SQ00",
    "length": 168,
    "modifications": "Oxidation$hex(4)hexnac(1)$Cation:Na$glyoxalAGE$15N-oxobutanoic$Deamidated$Cation:Mg[II]$Thiazolidine$Sulfo$Dehydrated",
    "modified_positions": 10,
    "name": "Small ribosomal subunit protein uS5",
    "unique_modifications": 10
  },
  {
    "id": "A0A0A2ST13",
    "length": 75,
    "modifications": "Delta:H(2)C(3)O(1)$hydroxyisobutyryl$MG-H1$Carbamidomethyl$Didehydro",
    "modified_positions": 6,
    "name": "Small ribosomal subunit protein bS18",
    "unique_modifications": 5
  },
  {
    "id": "A0A0A2ST86",
    "length": 345,
    "modifications": "Nmethylmaleimide$Oxidation$Gly$PS_Hapten$Carbofuran$Tris$BITC$ethylsulfonylethyl$Deamidated$icpl_13c(6)$AEC-MAEC$Carbamidomethyl$Delta:H(6)C(3)O(1)$glycidamide",
    "modified_positions": 13,
    "name": "Cell shape-determining protein MreB",
    "unique_modifications": 14
  },
  {
    "id": "A0A0A2SUE5",
    "length": 78,
    "modifications": "Cytopiloyne",
    "modified_positions": 1,
    "name": "Large ribosomal subunit protein bL28",
    "unique_modifications": 1
  },
  {
    "id": "A0A0A2T5W8",
    "length": 218,
    "modifications": "phosphohexnac$Gly$LG-Hlactam-R$acetyl_2h(3)$Oxidation$Iodoacetanilide:13C(6)$Malonyl$Glu$dhex(4)hexnac(3)kdn(1)$Carbamidomethyl$Thiazolidine$s-glcnac$Biotin-HPDP",
    "modified_positions": 12,
    "name": "Small ribosomal subunit protein uS3",
    "unique_modifications": 13
  },
  {
    "id": "A0A0A2T875",
    "length": 64,
    "modifications": "hex(2)hexa(1)hexnac(1)sulf(1)$hex(1)hexa(1)",
    "modified_positions": 2,
    "name": "Translational regulator CsrA",
    "unique_modifications": 2
  },
  {
    "id": "A0A0C9N1W9",
    "length": 253,
    "modifications": "Oxidation$Cation:Ca[II]$Methyl$Lys->AminoadipicAcid$BEMAD_ST$Cation:K$Carbamidomethyl",
    "modified_positions": 9,
    "name": "imidazole glycerol-phosphate synthase",
    "unique_modifications": 7
  },
  {
    "id": "A0A0C9PGF9",
    "length": 67,
    "modifications": "icpl$Glu->pyro-Glu+Methyl$Unknown:162",
    "modified_positions": 2,
    "name": "Dodecin domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "A0A128JM68",
    "length": 64,
    "modifications": "Carbamidomethyl$Iodoacetanilide",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "A0A128R885",
    "length": 94,
    "modifications": "Oxidation$acetyl_2h(3)$UgiJoullieProGlyProGly$Carbamidomethyl$CresylSaligeninPhosphate",
    "modified_positions": 5,
    "name": "DUF3579 domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "A0A128VVH6",
    "length": 121,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "ProQ-like, activator of ProP osmoprotectant transporter",
    "unique_modifications": 1
  },
  {
    "id": "A0A128XGK4",
    "length": 309,
    "modifications": "Oxidation$Myristoyl+Delta:H(-4)$Deamidated$Biotin:Thermo-21345$Glu$Carbamidomethyl$Decanoyl",
    "modified_positions": 8,
    "name": "Cell division protein FtsX",
    "unique_modifications": 7
  },
  {
    "id": "A0A128YTG3",
    "length": 127,
    "modifications": "Cytopiloyne$Acetylhypusine",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "A0A128ZIR7",
    "length": 62,
    "modifications": "biotinAcrolein298$Cation:Ni[II]$Oxidation$Dioxidation",
    "modified_positions": 4,
    "name": "DUF4169 family protein",
    "unique_modifications": 4
  },
  {
    "id": "A0A129BCU3",
    "length": 284,
    "modifications": "Oxidation$PyruvicAcidIminyl$Carbonyl$sulfanilicacid$Ammonia-loss$galactosyl",
    "modified_positions": 8,
    "name": "RNA polymerase sigma factor RpoH",
    "unique_modifications": 6
  },
  {
    "id": "A0A130C3H7",
    "length": 97,
    "modifications": "Delta:H(2)C(2)$AFB1_Dialdehyde$Oxidation$Gln->pyro-Glu$Acetyl$dhex(1)hex(2)hexnac(2)sulf(1)$Deamidated$Ammonia-loss$Dehydrated",
    "modified_positions": 10,
    "name": "Phasin family protein",
    "unique_modifications": 9
  },
  {
    "id": "A0A131MXS3",
    "length": 98,
    "modifications": "VFQQQTGG$Oxidation",
    "modified_positions": 2,
    "name": "Aspartyl/glutamyl-tRNA(Asn/Gln) amidotransferase subunit C",
    "unique_modifications": 2
  },
  {
    "id": "A0A131N8W7",
    "length": 225,
    "modifications": "Carbamidomethyl$Oxidation$Gln->pyro-Glu",
    "modified_positions": 3,
    "name": "Tol-Pal system protein TolQ",
    "unique_modifications": 3
  },
  {
    "id": "A0A133X5M5",
    "length": 64,
    "modifications": "Biotin:Thermo-21330$Carbamidomethyl$hexnac(1)neuac(1)$bemad_st_2h(6)",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "A0A222P1W0",
    "length": 82,
    "modifications": "Propargylamine$Biotin-PEO-Amine$Cation:Cu[I]$succinyl_13c(4)$benzoyl$succinyl_2h(4)$Methamidophos-S$Didehydro$Cation:Zn[II]",
    "modified_positions": 7,
    "name": "Acyl carrier protein",
    "unique_modifications": 9
  },
  {
    "id": "A0A222P2X3",
    "length": 163,
    "modifications": "Nmethylmaleimide$OxLysBiotinRed$hex$Gly$spermidine$icpl_13c(6)2h(4)$Ammonium$Arg->Npo$BDMAPP$Delta:H(4)C(5)O(1)$icpl_13c(6)$Carbamidomethyl",
    "modified_positions": 12,
    "name": "Transcriptional repressor DicA",
    "unique_modifications": 12
  },
  {
    "id": "A0A222P301",
    "length": 342,
    "modifications": "Cation:Al[III]$Oxidation$Nitrosyl$hexnac(4)$Nitrene",
    "modified_positions": 5,
    "name": "Beta-lactamase HcpD",
    "unique_modifications": 5
  },
  {
    "id": "A0A222P310",
    "length": 430,
    "modifications": "hex(2)neuac(1)$Oxidation$hexnac(1)neuac(1)$Delta:H(4)C(3)$hexnac(1)neugc(1)$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Proline/betaine transporter",
    "unique_modifications": 6
  },
  {
    "id": "A0A222P313",
    "length": 230,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "ATP synthase subunit a",
    "unique_modifications": 1
  },
  {
    "id": "A0A222P331",
    "length": 124,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "A0A222P332",
    "length": 299,
    "modifications": "Oxidation$Propargylamine$Cation:Na$Deamidated$QTGG",
    "modified_positions": 6,
    "name": "Protein LvrA",
    "unique_modifications": 5
  },
  {
    "id": "A0A222P356",
    "length": 66,
    "modifications": "Deoxy$clip_traq_2$Acetylhypusine",
    "modified_positions": 4,
    "name": "Carbon storage regulator",
    "unique_modifications": 3
  },
  {
    "id": "A0A222P368",
    "length": 247,
    "modifications": "MercaptoEthanol$Oxidation$Propionamide$Cresylphosphate$Phosphoadenosine$BDMAPP$O-Isopropylmethylphosphonate$15N-oxobutanoic$Deamidated$Carboxy$Carbamidomethyl$Dehydrated",
    "modified_positions": 23,
    "name": "Acetoacetyl-CoA reductase",
    "unique_modifications": 12
  },
  {
    "id": "A0A222P375",
    "length": 57,
    "modifications": "Amidated",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "A0A2S6F6D0",
    "length": 238,
    "modifications": "Oxidation$Gluratylation$cGMP+RMP-loss$Biotin-phenacyl$Methylamine$hex(1)neugc(1)",
    "modified_positions": 7,
    "name": "RNA polymerase sigma factor FliA",
    "unique_modifications": 6
  },
  {
    "id": "A0A378K3S1",
    "length": 230,
    "modifications": "Cytopiloyne$Carbamidomethyl$Deamidated$Dioxidation",
    "modified_positions": 4,
    "name": "Cytidylate kinase",
    "unique_modifications": 4
  },
  {
    "id": "A0A378K601",
    "length": 316,
    "modifications": "Oxidation$acetyl_2h(3)$thioacylPA$pent(1)hexnac(1)$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "A0A378K631",
    "length": 319,
    "modifications": "Oxidation$GG$Dicarbamidomethyl$Methamidophos-O$CAMthiopropanoyl$Cation:Fe[II]$Carbamidomethyl$Methamidophos-S$glycosyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 11,
    "name": "Glutathione synthetase",
    "unique_modifications": 10
  },
  {
    "id": "A0A378K664",
    "length": 418,
    "modifications": "ident$Delta:H(8)C(6)O(2)$Ammonium$Thiophospho$Delta:H(4)C(3)$Cation:Na$hex(1)hexnac(2)neuac(1)sulf(1)$Carbamidomethyl$Acetyldeoxyhypusine$Piperidine$Oxidation$4-ONE$BITC$dhex(1)hex(1)hexnac(4)$clip_traq_2$hex(1)neuac(1)$SPITC:13C(6)$AEC-MAEC$Delta:H(8)C(6)O(1)$BHTOH",
    "modified_positions": 20,
    "name": "SOS mutagenesis and repair UmuC protein",
    "unique_modifications": 20
  },
  {
    "id": "A0A378K6Y4",
    "length": 853,
    "modifications": "SulfanilicAcid:13C(6)$dhex(2)hex(3)hexa(1)hexnac(1)sulf(1)$Gly$methylsulfonylethyl$Oxidation$dhex(1)hex(4)hexnac(4)$Saligenin$AEBS$Deamidated$PEITC$Carboxymethyl$HexN$Pro->Pyrrolidone$Carbamidomethyl$Thiazolidine$Delta:H(6)C(3)O(1)$glycidamide",
    "modified_positions": 27,
    "name": "Diaminopimelate decarboxylase",
    "unique_modifications": 17
  },
  {
    "id": "A0A378K985",
    "length": 200,
    "modifications": "cGMP+RMP-loss$AMTzHexNAc2",
    "modified_positions": 2,
    "name": "DUF2845 domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "A0A378K9R2",
    "length": 260,
    "modifications": "Ammonium",
    "modified_positions": 1,
    "name": "GNAT family N-acetyltransferase",
    "unique_modifications": 1
  },
  {
    "id": "A0A3A6TZD2",
    "length": 214,
    "modifications": "4-ONE+Delta:H(-2)O(-1)$Met-loss+Acetyl",
    "modified_positions": 2,
    "name": "Alanyl-tRNA editing protein",
    "unique_modifications": 2
  },
  {
    "id": "A0A3A6UQN3",
    "length": 112,
    "modifications": "Oxidation$Delta:H(2)C(3)O(1)",
    "modified_positions": 10,
    "name": "Tryptophan synthase subunit beta like protein",
    "unique_modifications": 2
  },
  {
    "id": "A0A3A6UW83",
    "length": 93,
    "modifications": "Oxidation$Dap-DSP$Cation:Na$Cation:Fe[III]$Cation:Li$Cation:Mg[II]$Phospho",
    "modified_positions": 7,
    "name": "GIY-YIG nuclease family protein",
    "unique_modifications": 7
  },
  {
    "id": "A0A3A6V549",
    "length": 216,
    "modifications": "dhex(1)hex(3)hexnac(1)$hex(2)hexnac(1)pent(1)hexa(1)$Furan$FTC",
    "modified_positions": 3,
    "name": "F-box domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "A0AAN5M018",
    "length": 480,
    "modifications": "Oxidation$hex(2)hexnac(1)$Delta:H(2)C(3)O(1)$Dehydrated$Trimethyl$MG-H1$15N-oxobutanoic$Deamidated$Carboxyethylpyrrole$Pyridylacetyl$Carbamidomethyl$hex(1)hexa(1)hexnac(2)",
    "modified_positions": 16,
    "name": "Outer membrane protein transport protein",
    "unique_modifications": 12
  },
  {
    "id": "A0AAN5PF07",
    "length": 88,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Gly$Propionamide$Dimethyl$Deoxy$Quinone$Carbamidomethyl$methylol$Cation:Ca[II]$Nitrosyl$Methyl+Deamidated$Cation:Fe[III]$neiaa$DAET$Ethyl$GEE$Oxidation$Propargylamine$dichlorination$Malonyl$Acetyl$Cation:K$Hydroxymethyl$Carbofuran$Carboxy$Methylamine$Ser->LacticAcid$Methylthio$Formyl$Pentylamine$Deoxyhypusine$Propionyl$Ethyl+Deamidated$Methyl$Gly-loss+Amide$Delta:H(5)C(2)$Trimethyl$Nitrene",
    "modified_positions": 18,
    "name": "Lipoprotein",
    "unique_modifications": 38
  },
  {
    "id": "A0AAN5PF79",
    "length": 154,
    "modifications": "Glu->pyro-Glu+Methyl$Oxidation$Propargylamine$LG-Hlactam-K$Ethanolyl$CHDH$Crotonaldehyde$Methylamine$PyruvicAcidIminyl$Methylphosphonate$Carbamidomethyl",
    "modified_positions": 14,
    "name": "thioredoxin-dependent peroxiredoxin",
    "unique_modifications": 11
  },
  {
    "id": "A0AAN5PFI7",
    "length": 266,
    "modifications": "4-ONE+Delta:H(-2)O(-1)$Oxidation",
    "modified_positions": 3,
    "name": "Beta-lactamase",
    "unique_modifications": 2
  },
  {
    "id": "A0AAN5PFZ7",
    "length": 164,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "A0AAN5PGD8",
    "length": 117,
    "modifications": "Carbamidomethyl$neugc$Lipoyl$clip_traq_4",
    "modified_positions": 7,
    "name": "Rieske (2Fe-2S) protein",
    "unique_modifications": 4
  },
  {
    "id": "A0AAN5PGG3",
    "length": 441,
    "modifications": "Ethyl$Oxidation$Dimethyl$Phosphoadenosine$Can-FP-biotin$Deamidated$Carbamidomethyl$Thiazolidine$Ammonia-loss",
    "modified_positions": 15,
    "name": "Deoxyguanosinetriphosphate triphosphohydrolase-like protein",
    "unique_modifications": 9
  },
  {
    "id": "A0AAN5PGQ0",
    "length": 516,
    "modifications": "Oxidation$Acetyl$Lysbiotinhydrazide$Glu$Formyl$Carbamidomethyl$Cation:Mg[II]",
    "modified_positions": 12,
    "name": "Alpha-amylase",
    "unique_modifications": 7
  },
  {
    "id": "A0AAN5PHU8",
    "length": 721,
    "modifications": "Gly$Deamidated$Carbamidomethyl$Lys->AminoadipicAcid$GluGlu$Cation:Al[III]$Oxidation$OxArgBiotin$phosphohex$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Pentylamine$Methyl$spermidine$Label:13C(1)2H(3)+Oxidation$Cation:Li$trimethyl_2h(9)$Nmethylmaleimide+water$Met-loss+Acetyl$Methylphosphonate$Argbiotinhydrazide",
    "modified_positions": 25,
    "name": "DNA 3'-5' helicase",
    "unique_modifications": 20
  },
  {
    "id": "A0AAN5PHX7",
    "length": 161,
    "modifications": "Ethanedithiol$Nethylmaleimide+water$glucuronyl",
    "modified_positions": 4,
    "name": "DUF4381 domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "A0AAN5PII5",
    "length": 60,
    "modifications": "Cytopiloyne+water$Delta:H(2)C(3)O(1)",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "A0AAN5PIP9",
    "length": 293,
    "modifications": "Dap-DSP$Oxidation$Amidine$Carboxymethyl$Arg->Orn$Carbamidomethyl$Ammonia-loss$Ethanedithiol",
    "modified_positions": 12,
    "name": "ATP phosphoribosyltransferase",
    "unique_modifications": 8
  },
  {
    "id": "A0AAN5PJ54",
    "length": 98,
    "modifications": "Carbamidomethyl$Deoxy$Oxidation$hex(1)hexa(1)",
    "modified_positions": 4,
    "name": "Transposase",
    "unique_modifications": 4
  },
  {
    "id": "A0AAN5PKB9",
    "length": 139,
    "modifications": "Oxidation",
    "modified_positions": 3,
    "name": "Response regulator",
    "unique_modifications": 1
  },
  {
    "id": "A0AAN5PKN6",
    "length": 350,
    "modifications": "dhex(1)hexnac(3)$Oxidation$Methyl+Deamidated$Hydroxamic_acid$Nethylmaleimide+water$CresylSaligeninPhosphate",
    "modified_positions": 10,
    "name": "Nitronate monooxygenase",
    "unique_modifications": 6
  },
  {
    "id": "A0AAN5PM39",
    "length": 93,
    "modifications": "Ammonium$Carbamidomethyl$Oxidation$methyl_2h(3)",
    "modified_positions": 3,
    "name": "Secreted protein",
    "unique_modifications": 4
  },
  {
    "id": "A0AAN5RTW8",
    "length": 182,
    "modifications": "Oxidation$Propionamide$Ahx2+Hsl$pent(1)hexnac(1)$hex(1)hexnac(1)",
    "modified_positions": 6,
    "name": "Transcription termination/antitermination protein NusG",
    "unique_modifications": 5
  },
  {
    "id": "A0AAN5SZH3",
    "length": 404,
    "modifications": "Oxidation$ethylamino$Gln->pyro-Glu$Delta:H(6)C(6)O(1)$Propiophenone$pentose$bemad_st_2h(6)$4-ONE$NHS-fluorescein$PEITC$Nmethylmaleimide+water$Carbamidomethyl$glycosyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 17,
    "name": "Tryptophan--tRNA ligase",
    "unique_modifications": 14
  },
  {
    "id": "A0AAN5SZW9",
    "length": 289,
    "modifications": "Delta:H(2)C(2)$Gly$Ethanolyl$Deoxy$acetyl_13c(2)$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Peptide methionine sulfoxide reductase MsrA",
    "unique_modifications": 6
  },
  {
    "id": "A0AAN5SZZ3",
    "length": 90,
    "modifications": "Oxidation$BEMAD_ST$Carbamidomethyl$Sulfo$Phospho$clip_traq_3",
    "modified_positions": 8,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "A0AAN5T0T9",
    "length": 321,
    "modifications": "Ethanolamine$benzylguanidine$Propiophenone",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "A0AAN5T175",
    "length": 391,
    "modifications": "SulfanilicAcid:13C(6)$Oxidation$Decarboxylation$O-Dimethylphosphate$cGMP+RMP-loss$qat_2h(3)$Cation:K$Cys->CamSec$Dicarbamidomethyl$Ethylphosphate$thioacylPA$Carbamidomethyl$Delta:H(8)C(6)O(1)$Furan$Carbamyl",
    "modified_positions": 18,
    "name": "ISL3 family transposase",
    "unique_modifications": 15
  },
  {
    "id": "A0AAN5T1Q8",
    "length": 275,
    "modifications": "phosphoRibosyl$Biotin:Thermo-88317",
    "modified_positions": 2,
    "name": "sn-glycerol-3-phosphate transport system permease protein UgpE",
    "unique_modifications": 2
  },
  {
    "id": "A0AAN5T1X2",
    "length": 307,
    "modifications": "Oxidation$Delta:H(4)C(3)O(2)$Methyl$Propionamide$hex(2)hexnac(2)dhex(1)$Malonyl$hex(1)hexnac(1)sulf(1)$Glu$3-deoxyglucosone$hex(3)hexnac(2)$Carbamidomethyl$hex(1)hexnac(2)dhex(2)",
    "modified_positions": 12,
    "name": "MCE family protein",
    "unique_modifications": 12
  },
  {
    "id": "A0AAN5T2X3",
    "length": 306,
    "modifications": "hex(2)hexnac(2)$Cys->Dha",
    "modified_positions": 2,
    "name": "LysR family transcriptional regulator",
    "unique_modifications": 2
  },
  {
    "id": "A0AAP3HCY0",
    "length": 437,
    "modifications": "GlycerylPE$Oxidation$Hydroxamic_acid$Acetyl$AEBS$HCysThiolactone$SPITC$PEITC$hex(1)hexnac(1)dhex(1)me(1)$Cation:Fe[II]$Carbamidomethyl$Biotin$Carbamyl",
    "modified_positions": 18,
    "name": "Sigma-54-dependent response regulator transcription factor FleR",
    "unique_modifications": 13
  },
  {
    "id": "A0AAP3HD07",
    "length": 289,
    "modifications": "Carbamidomethyl$Deamidated$Oxidation$Glu",
    "modified_positions": 5,
    "name": "MinD/ParA family protein",
    "unique_modifications": 4
  },
  {
    "id": "A0AAP3HEA5",
    "length": 212,
    "modifications": "methyl_2h(2)$Carbamidomethyl$Oxidation$deamidated_18o(1)",
    "modified_positions": 7,
    "name": "Uridine kinase",
    "unique_modifications": 4
  },
  {
    "id": "A0AAP3HEJ3",
    "length": 124,
    "modifications": "hex(2)neuac(1)$Oxidation$hex(2)hexnac(1)$hex(3)hexnac(2)phos(1)$hexnac(2)dhex(1)$Propiophenone$Crotonaldehyde$dhex(1)hex(4)hexa(1)$2HPG$QTGG$Butyryl",
    "modified_positions": 12,
    "name": "Group 1 truncated hemoglobin",
    "unique_modifications": 11
  },
  {
    "id": "A0AAP3MBM7",
    "length": 258,
    "modifications": "hex(3)hexnac(1)$Carboxy->Thiocarboxy$Arg->Npo$Deamidated$Carboxymethyl$Carbamidomethyl",
    "modified_positions": 13,
    "name": "Enoyl-CoA hydratase-related protein",
    "unique_modifications": 6
  },
  {
    "id": "A0AAP3MCD4",
    "length": 367,
    "modifications": "Oxidation$Delta:H(6)C(7)O(4)$Hydroxamic_acid$gist-quat_2h(3)$Deoxy$Amino$Deamidated$succinyl_13c(4)$Carbamidomethyl",
    "modified_positions": 16,
    "name": "Ribonucleoside-diphosphate reductase subunit beta",
    "unique_modifications": 9
  },
  {
    "id": "A0AAV2UVV9",
    "length": 199,
    "modifications": "Oxidation$Cation:Ca[II]$ethylamino$Acetyl$Cation:K$Trioxidation$Formyl$Dehydrated",
    "modified_positions": 8,
    "name": "Tfp pilus assembly protein PilO",
    "unique_modifications": 8
  },
  {
    "id": "A0AAV2UWN8",
    "length": 357,
    "modifications": "Oxidation$Gln->pyro-Glu$ZGB$probiotinhydrazide$Hydroxamic_acid$hexnac(1)neuac(1)$Iodoacetanilide:13C(6)$Carbofuran$Amino$Methylamine$CAMthiopropanoyl$Carboxymethyl$AEC-MAEC$Deamidated$Ethanolamine$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 26,
    "name": "Pyruvate dehydrogenase E1 component subunit alpha",
    "unique_modifications": 17
  },
  {
    "id": "A0AAV2UXQ2",
    "length": 755,
    "modifications": "ethylamino$Cation:Na$Deamidated$acetyl_13c(2)$Carbamidomethyl$Pyro-carbamidomethyl$Cation:Ni[II]$glyoxalAGE$dhex(2)hex(4)$Ammonia-loss$gist-quat_2h(9)$Oxidation$BEMAD_ST$Propyl$Dehydrated$Delta:H(2)C(2)$Gln->pyro-Glu$Delta:H(2)C(3)O(1)$Saligenin$Dioxidation",
    "modified_positions": 30,
    "name": "ATPase and specificity subunit of ClpA-ClpP ATP-dependent serine protease, chaperone activity",
    "unique_modifications": 20
  },
  {
    "id": "A0AAV2UXV8",
    "length": 91,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "A0AAX0WT96",
    "length": 163,
    "modifications": "Lysbiotinhydrazide$Delta:H(6)C(3)O(1)",
    "modified_positions": 2,
    "name": "4-diphosphocytidyl-2C-methyl-D-erythritol kinase",
    "unique_modifications": 2
  },
  {
    "id": "A0AAX0WTB2",
    "length": 224,
    "modifications": "MeMePhosphorothioate$icdid$Delta:H(6)C(7)O(4)$LRGG+dimethyl$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Transposase IS701-like DDE domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "A5ICS0",
    "length": 202,
    "modifications": "Oxidation$Delta:H(2)C(3)O(1)$Carboxyethyl$imid_2h(4)$Deamidated$Deoxy$Delta:H(4)C(3)O(1)",
    "modified_positions": 7,
    "name": "Outer-membrane lipoprotein carrier protein",
    "unique_modifications": 7
  },
  {
    "id": "O54589",
    "length": 360,
    "modifications": "Hydroxamic_acid$TMPP-Ac$Oxidation$Ammonia-loss",
    "modified_positions": 6,
    "name": "DotH",
    "unique_modifications": 4
  },
  {
    "id": "P31108",
    "length": 192,
    "modifications": "Oxidation$Gly$Biotin-PEO-Amine$Deamidated$deamidated_18o(1)$Pro->HAVA$LG-anhydrolactam$Carbamidomethyl",
    "modified_positions": 14,
    "name": "Superoxide dismutase [Fe]",
    "unique_modifications": 8
  },
  {
    "id": "Q3V863",
    "length": 575,
    "modifications": "OxProBiotinRed$Oxidation$Methyl$Biotin:Thermo-21330$Aspartylurea$Lys->Allysine$Methylthio$Carbamidomethyl$2-nitrobenzyl",
    "modified_positions": 11,
    "name": "Siderophore biosynthetic protein, iron repressed gene FrgA",
    "unique_modifications": 9
  },
  {
    "id": "Q3V864",
    "length": 249,
    "modifications": "Methamidophos-S",
    "modified_positions": 1,
    "name": "Flagellar biosynthetic protein FliP",
    "unique_modifications": 1
  },
  {
    "id": "Q3V866",
    "length": 256,
    "modifications": "Oxidation$hex(3)hexnac(6)$Diethylphosphothione$Methylphosphonate$CresylSaligeninPhosphate",
    "modified_positions": 5,
    "name": "Flagellar biosynthetic protein FliR",
    "unique_modifications": 5
  },
  {
    "id": "Q3V868",
    "length": 692,
    "modifications": "dhex(1)hex(3)hexa(1)hexnac(2)sulf(1)$Oxidation$Delta:H(2)C(3)O(1)$RNPXL$dhex(2)hex(2)$dhex(3)hex(2)hexnac(2)$O-Isopropylmethylphosphonate$MG-H1$BITC$CAMthiopropanoyl$Glu->pyro-Glu+Methyl:2H(2)13C(1)$hex(1)hexa(1)",
    "modified_positions": 13,
    "name": "Flagellar biosynthesis protein FlhA",
    "unique_modifications": 12
  },
  {
    "id": "Q3V870",
    "length": 248,
    "modifications": "Oxidation$Carboxy$Arg->Orn$neiaa$Carbamidomethyl$dhex(1)hex(1)",
    "modified_positions": 11,
    "name": "Pyridoxine 5'-phosphate synthase",
    "unique_modifications": 6
  },
  {
    "id": "Q48833",
    "length": 89,
    "modifications": "Cation:Al[III]$Oxidation$Gln->pyro-Glu$Cation:Ni[II]$Trioxidation$Deoxy$Deamidated$DNCB_hapten$Carbamidomethyl$Ammonia-loss",
    "modified_positions": 22,
    "name": "Probable monothiol glutaredoxin GrlA",
    "unique_modifications": 10
  },
  {
    "id": "Q5WSJ2",
    "length": 251,
    "modifications": "Glu->pyro-Glu+Methyl$Oxidation$HPG$Thiophospho$Deamidated$Biotin:Thermo-21328$pent(1)hexnac(1)$Quinone$Cytopiloyne+water$Phospho",
    "modified_positions": 13,
    "name": "Band 7 domain-containing protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5WSM8",
    "length": 229,
    "modifications": "hexnac(3)$Oxidation$Propargylamine$Biotin-tyramide$Cation:Mg[II]$glyoxalAGE$Cation:Na$Cation:Li$Cytopiloyne$Carbamidomethyl$OxArgBiotin$Methamidophos-S",
    "modified_positions": 11,
    "name": "ABC transporter domain-containing protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5WSR7",
    "length": 180,
    "modifications": "Oxidation$diart6plex115$icdid_2h(6)$2-dimethylsuccinyl$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Cytochrome c oxidase assembly protein CtaG",
    "unique_modifications": 5
  },
  {
    "id": "Q5WSV4",
    "length": 147,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "HEPN domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5WT42",
    "length": 179,
    "modifications": "AHA-Alkyne$Pyro-carbamidomethyl$Oxidation$Gly$dhex(1)hex(3)hexnac(2)$Propyl$hex(2)hexnac(1)me(1)$AzidoF$unknown_420$Lys->MetOx$Carbamidomethyl$Unknown:420",
    "modified_positions": 20,
    "name": "GTP cyclohydrolase 1",
    "unique_modifications": 12
  },
  {
    "id": "Q5WT83",
    "length": 178,
    "modifications": "Oxidation$Methyl$Carboxy$Octanoyl$Piperidine",
    "modified_positions": 5,
    "name": "Translation initiation factor IF-3",
    "unique_modifications": 5
  },
  {
    "id": "Q5WT84",
    "length": 66,
    "modifications": "Carbamidomethyl$PyMIC$Delta:H(4)C(3)O(1)",
    "modified_positions": 4,
    "name": "Large ribosomal subunit protein bL35",
    "unique_modifications": 3
  },
  {
    "id": "Q5WT88",
    "length": 97,
    "modifications": "Oxidation$Met->AspSA$Methyl$Crotonyl$Formyl$AEC-MAEC$Carbamidomethyl$Thiazolidine$Withaferin",
    "modified_positions": 10,
    "name": "Integration host factor subunit alpha",
    "unique_modifications": 9
  },
  {
    "id": "Q5WT92",
    "length": 205,
    "modifications": "Unknown:216$Oxidation$hexnac(1)dhex(1)$Carbamidomethyl$Unknown:306",
    "modified_positions": 6,
    "name": "Ubiquinol-cytochrome c reductase iron-sulfur subunit",
    "unique_modifications": 5
  },
  {
    "id": "Q5WTA2",
    "length": 64,
    "modifications": "Oxidation$Gly$icdid_2h(6)$Carbamidomethyl$Didehydro",
    "modified_positions": 7,
    "name": "Zinc finger CHCC-type domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5WTF4",
    "length": 219,
    "modifications": "G-H1$Oxidation$Gly$methylsulfonylethyl$hydroxyisobutyryl$Triton$PyridoxalPhosphateH2$dhex(1)hex(2)hexnac(1)$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Legionella transmission activator LetA",
    "unique_modifications": 9
  },
  {
    "id": "Q5WTI6",
    "length": 391,
    "modifications": "Oxidation$ethylamino$Phospho$dileu4plex118",
    "modified_positions": 5,
    "name": "Probable peptidoglycan glycosyltransferase FtsW",
    "unique_modifications": 4
  },
  {
    "id": "Q5WTJ1",
    "length": 412,
    "modifications": "Carbamidomethyl$Deamidated$Formylasparagine",
    "modified_positions": 9,
    "name": "Cell division protein FtsA",
    "unique_modifications": 3
  },
  {
    "id": "Q5WUD5",
    "length": 76,
    "modifications": "Deamidated",
    "modified_positions": 2,
    "name": "Outer membrane protein assembly factor BamC",
    "unique_modifications": 1
  },
  {
    "id": "Q5WV10",
    "length": 231,
    "modifications": "Oxidation$Dansyl$O-pinacolylmethylphosphonate",
    "modified_positions": 7,
    "name": "SPOR domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5WV31",
    "length": 67,
    "modifications": "Carbamidomethyl$Oxidation",
    "modified_positions": 2,
    "name": "DNA-directed RNA polymerase subunit omega",
    "unique_modifications": 2
  },
  {
    "id": "Q5WV32",
    "length": 707,
    "modifications": "Methylphosphonate$HNE+Delta:H(2)$Delta:H(2)C(2)$Oxidation$Gly$pent(2)$Carbofuran$Deamidated$Cys->ethylaminoAla$Bromo$acetyl_13c(2)$Carbamidomethyl$Ethyl$Furan$galactosyl",
    "modified_positions": 22,
    "name": "guanosine-3',5'-bis(diphosphate) 3'-diphosphatase",
    "unique_modifications": 15
  },
  {
    "id": "Q5WVJ3",
    "length": 92,
    "modifications": "ethylamino$icpl_2h(4)$Cation:Na$Deamidated$Pyridylacetyl$QTGG$Biotin$Didehydro$dnic$hex(2)$Phenylisocyanate$ISD_z+2_ion$Ammonia-loss$GluGlu$Oxidation$HNE$NHS-LC-Biotin$15N-oxobutanoic$AzidoF$EQIGG$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Formyl$Cation:Mg[II]$Dehydrated$Delta:H(2)C(2)$Thiazolidine$Dioxidation",
    "modified_positions": 22,
    "name": "HupB DNA binding protein HU-beta",
    "unique_modifications": 27
  },
  {
    "id": "Q5WVL0",
    "length": 301,
    "modifications": "Methamidophos-O$Deoxyhypusine$Propyl$PyruvicAcidIminyl",
    "modified_positions": 4,
    "name": "Glycine--tRNA ligase alpha subunit",
    "unique_modifications": 4
  },
  {
    "id": "Q5WVL6",
    "length": 259,
    "modifications": "Oxidation$Phe->CamCys$EDT-maleimide-PEO-biotin$GG$Malonyl$Dicarbamidomethyl$Carbamidomethyl$Acetylhypusine",
    "modified_positions": 14,
    "name": "29 kDa immunogenic protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5WWN2",
    "length": 124,
    "modifications": "Lys->AminoadipicAcid$Oxidation$maleimide",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5WX44",
    "length": 225,
    "modifications": "hex(1)neuac(1)pent(1)$O-Et-N-diMePhospho$Cresylphosphate$OxArgBiotinRed$HCysThiolactone$ISD_z+2_ion$Methylphosphonate",
    "modified_positions": 7,
    "name": "DNA-binding response regulator",
    "unique_modifications": 7
  },
  {
    "id": "Q5WXB5",
    "length": 81,
    "modifications": "Dethiomethyl$Oxidation$Gly$Amidine$Acetyl$Glu->pyro-Glu$Dehydrated$Carbofuran$Trp->Kynurenin$ISD_z+2_ion$Guanidinyl$Met->Hsl$Deamidated$Carboxymethyl$Carbamidomethyl$Thiazolidine$Dioxidation",
    "modified_positions": 17,
    "name": "Transcription regulator AsnC/Lrp ligand binding domain-containing protein",
    "unique_modifications": 17
  },
  {
    "id": "Q5WXG2",
    "length": 108,
    "modifications": "spermidine",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5WXH8",
    "length": 90,
    "modifications": "Delta:H(2)C(2)$Delta:H(4)C(3)O(2)$Propionamide$Carboxyethyl$Carbonyl$Carbamidomethyl",
    "modified_positions": 7,
    "name": "KaiB domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5WXZ3",
    "length": 112,
    "modifications": "Carboxy$serotonylation",
    "modified_positions": 2,
    "name": "Cell division protein FtsL",
    "unique_modifications": 2
  },
  {
    "id": "Q5WY06",
    "length": 298,
    "modifications": "Oxidation$acetyl_2h(3)$hexnac$HNE-Delta:H(2)O$4-ONE$Cation:Li$Pyridylacetyl$Succinyl",
    "modified_positions": 8,
    "name": "Uncharacterized protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5WYV9",
    "length": 112,
    "modifications": "Oxidation$Gly$Propiophenone$Deoxy$Carbamidomethyl$Unknown:420$benzylguanidine",
    "modified_positions": 8,
    "name": "Nitrogen regulatory protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5WZ85",
    "length": 208,
    "modifications": "Lipoyl$Octanoyl$Methylphosphonate$Carbamidomethyl$methylol",
    "modified_positions": 7,
    "name": "HNH nuclease domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5WZ86",
    "length": 132,
    "modifications": "Glycerophospho$Oxidation$hex(2)hexnac(2)neuac(2)sulf(1)",
    "modified_positions": 3,
    "name": "Type IV secretion protein IcmD",
    "unique_modifications": 3
  },
  {
    "id": "Q5WZ95",
    "length": 376,
    "modifications": "Pyro-carbamidomethyl$Oxidation$Gln->pyro-Glu$Delta:H(2)C(3)O(1)$4-ONE+Delta:H(-2)O(-1)$SMA$Iodoacetanilide$Carbamidomethyl$methylol$Ammonia-loss",
    "modified_positions": 13,
    "name": "DotM C-terminal cytoplasmic domain-containing protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5WZG8",
    "length": 136,
    "modifications": "methyl_2h(2)$Oxidation$Diethylphosphothione$Carbonyl",
    "modified_positions": 4,
    "name": "Ferric uptake regulation protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5WZK0",
    "length": 183,
    "modifications": "AHA-Alkyne$Hydroxyheme$Oxidation$Gly$Ammonium$methyl_2h(3)$Delta:H(4)C(3)$bemad_st_2h(6)$Deamidated$gist-quat_2h(6)$Methylthio$Carbonyl$DNCB_hapten$Carbamidomethyl$Methylpyrroline$Ser->LacticAcid$dnic",
    "modified_positions": 26,
    "name": "Large ribosomal subunit protein uL5",
    "unique_modifications": 17
  },
  {
    "id": "Q5WZK7",
    "length": 111,
    "modifications": "Oxidation$Pro->Pyrrolidinone$FTC$glucosylgalactosyl$Phosphopantetheine$Deamidated$Carboxymethyl$Delta:H(4)C(3)O(1)$DNCB_hapten$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 15,
    "name": "Large ribosomal subunit protein uL22",
    "unique_modifications": 11
  },
  {
    "id": "Q5WZK8",
    "length": 92,
    "modifications": "pent(2)$Oxidation$Dehydrated",
    "modified_positions": 4,
    "name": "Small ribosomal subunit protein uS19",
    "unique_modifications": 3
  },
  {
    "id": "Q5X1H7",
    "length": 338,
    "modifications": "Pyro-carbamidomethyl$Oxidation$Gly$Diisopropylphosphate$diart6plex115$Propiophenone$Ammonia-loss$Arg->GluSA$Deamidated$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 16,
    "name": "Phenylalanine--tRNA ligase alpha subunit",
    "unique_modifications": 11
  },
  {
    "id": "Q5X4B6",
    "length": 150,
    "modifications": "Carbamidomethyl$Isopropylphospho$PET",
    "modified_positions": 3,
    "name": "Regulatory protein RecX",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZR80",
    "length": 81,
    "modifications": "hex(1)hexnac(1)dhex(1)$Oxidation$Methylthio",
    "modified_positions": 2,
    "name": "Putative membrane protein insertion efficiency factor",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZR81",
    "length": 556,
    "modifications": "3-phosphoglyceryl$Oxidation$Glu->pyro-Glu+Methyl$hex(2)pent(2)$Thiophospho$a-type-ion$Deamidated$dhex(1)hex(1)hexnac(1)neuac(1)$dhex(1)hex(1)hexnac(1)neugc(1)",
    "modified_positions": 9,
    "name": "Membrane protein insertase YidC",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZR97",
    "length": 156,
    "modifications": "Nmethylmaleimide$methylsulfonylethyl$Ammonium$Glu->pyro-Glu$methyl_2h(3)$PyridoxalPhosphate$Deamidated$Glu",
    "modified_positions": 8,
    "name": "ATP synthase subunit b",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZRA0",
    "length": 288,
    "modifications": "Oxidation$NDA$Gly$methyl_2h(3)13c(1)$Diethylphosphate$imid_2h(4)$Acetyl$PEITC$Carboxymethyl$Formyl$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 14,
    "name": "ATP synthase gamma chain",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZRA1",
    "length": 458,
    "modifications": "Gly$Phe->CamCys$Ammonium$Glu->pyro-Glu$biotinAcrolein298$Cation:Na$Deamidated$Deoxy$Carbamidomethyl$Didehydro$TAMRA-FP$Biotin-PEO-Amine$methyl_2h(3)$O-Isopropylmethylphosphonate$esp$Carbamyl$Ammonia-loss$pent(2)$Oxidation$Amidine$Acetyl$Cation:Cu[I]$Propyl$Cation:Mg[II]$Dehydrated$Cation:Zn[II]$Gln->pyro-Glu$Trimethyl$TMPP-Ac:13C(9)$deamidated_18o(1)$Methylphosphonate",
    "modified_positions": 58,
    "name": "ATP synthase subunit beta",
    "unique_modifications": 31
  },
  {
    "id": "Q5ZRB7",
    "length": 201,
    "modifications": "Dap-DSP$Gly$Ammonium$Cation:Na$Deoxy$Deamidated$Carbamidomethyl$Delta:H(6)C(3)O(1)$hex$methyl_2h(3)$Met->Hse$Oxidation$Acetyl$Carbofuran$Propyl$AzidoF$Methylamine$Ser->LacticAcid$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Cation:Mg[II]$Didehydroretinylidene$Trimethyl$Carboxymethyl$Amidino",
    "modified_positions": 35,
    "name": "Thioredoxin peroxidase",
    "unique_modifications": 24
  },
  {
    "id": "Q5ZRC1",
    "length": 288,
    "modifications": "hex(1)hexa(1)$TAMRA-FP$Oxidation$Phe->CamCys$diart6plex117$diart6plex115$Propionamide$Carboxyethyl$diart6plex118$imid_2h(4)$Deamidated$diart6plex116/119$diart6plex$Methamidophos-O$Carbamidomethyl$Thiazolidine$Ammonia-loss$Dehydrated",
    "modified_positions": 23,
    "name": "Major outer membrane protein",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZRC2",
    "length": 323,
    "modifications": "hex(1)hexnac(2)sulf(1)$Oxidation$GG$HNE$Dicarbamidomethyl$dhex(1)hexnac(4)",
    "modified_positions": 5,
    "name": "Major outer membrane protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRC7",
    "length": 103,
    "modifications": "Oxidation$Gln->pyro-Glu$HN2_mustard$Delta:H(6)C(7)O(4)$HNE-Delta:H(2)O$bemad_st_2h(6)$PyruvicAcidIminyl$Ammonia-loss$Ethanedithiol",
    "modified_positions": 11,
    "name": "Integration host factor subunit beta",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZRC8",
    "length": 238,
    "modifications": "hex(1)hexnac(1)phos(1)$Oxidation$hex(1)hexnac(1)sulf(1)$Carbamidomethyl$Furan",
    "modified_positions": 8,
    "name": "Histone-lysine N-methyltransferase, H3 lysine-79 specific",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRC9",
    "length": 241,
    "modifications": "dimethyl_2h(4)$Oxidation$Gly$Ethanolyl$Propyl$Glu$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Carbamidomethyl$Farnesyl$dimethyl_2h(6)13c(2)$Ethanedithiol",
    "modified_positions": 12,
    "name": "Uncharacterized protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZRD1",
    "length": 316,
    "modifications": "Dimethylaminoethyl$Pyro-carbamidomethyl$Oxidation$Cation:Ca[II]$Methyl$Propionamide$dhex(1)hex(3)$Propionyl$O-Isopropylmethylphosphonate$Cys->ethylaminoAla$Deamidated$Methamidophos-O$HexN$Carbamidomethyl$Delta:H(4)C(3)O(1)$Deoxyhypusine",
    "modified_positions": 20,
    "name": "Cysteine synthase B",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZRE5",
    "length": 464,
    "modifications": "Delta:H(2)C(2)$Diphthamide$Pyro-carbamidomethyl$Crotonyl$Methyl$Carboxyethyl$GG$Oxidation$Hydroxamic_acid$Iminobiotin$Phosphogluconoylation$SPITC:13C(6)$Carboxymethyl$Carbamidomethyl$Acetylhypusine$Delta:H(6)C(3)O(1)$hex(1)hexa(1)",
    "modified_positions": 19,
    "name": "Fumarate hydratase class II",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZRE6",
    "length": 244,
    "modifications": "Dap-DSP$Acetyl$Crotonaldehyde$Carbamidomethyl$Butyryl",
    "modified_positions": 5,
    "name": "Ribosomal RNA small subunit methyltransferase E",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRE7",
    "length": 108,
    "modifications": "TAMRA-FP$Carbamidomethyl$Dehydrated",
    "modified_positions": 4,
    "name": "Thioredoxin",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRF4",
    "length": 256,
    "modifications": "Nmethylmaleimide$hex(1)hexa(1)$Oxidation$Methyl$hexnac(1)dhex(1)$Carbamidomethyl$GluGlu",
    "modified_positions": 9,
    "name": "Ribosomal RNA small subunit methyltransferase A",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRF6",
    "length": 276,
    "modifications": "Carbamidomethyl",
    "modified_positions": 2,
    "name": "Bis(5'-nucleosyl)-tetraphosphatase, symmetrical",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZRF7",
    "length": 542,
    "modifications": "Biotin:Thermo-21325$Oxidation$Deoxy$Deamidated$Methamidophos-S$hex(3)hexnac(1)hexa(1)",
    "modified_positions": 6,
    "name": "Outer membrane efflux protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRF8",
    "length": 381,
    "modifications": "Unknown:216$Oxidation$Cytopiloyne+water$acetyl_2h(3)$phosphoRibosyl$HN3_mustard$Crotonaldehyde$phosphohex(2)$Glu$Formyl$Delta:H(4)C(3)O(1)$hex(2)sulf(1)$Butyryl",
    "modified_positions": 16,
    "name": "Lipoprotein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZRG1",
    "length": 108,
    "modifications": "Chlorination",
    "modified_positions": 1,
    "name": "Polymerase beta nucleotidyltransferase domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZRG2",
    "length": 139,
    "modifications": "Oxidation$pupylation$gist-quat$dhex(1)hex(2)hexnac(1)$DNCB_hapten$serotonylation",
    "modified_positions": 8,
    "name": "Nucleotidyltransferase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRG3",
    "length": 392,
    "modifications": "GG$Dicarbamidomethyl$Tyr->Dha$dhex(2)hex(2)hexnac(2)kdn(1)$Carboxymethyl$hex(3)hexnac(4)pent(1)",
    "modified_positions": 9,
    "name": "(Serine-type) D-alanyl-D-alanine carboxypeptidase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRG5",
    "length": 348,
    "modifications": "monomethylphosphothione$hexnac(3)$Oxidation$Carbonyl$Carbamidomethyl",
    "modified_positions": 8,
    "name": "FAD/NAD(P)-binding domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRG7",
    "length": 73,
    "modifications": "Oxidation$Ammonia-loss",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRG8",
    "length": 96,
    "modifications": "methylsulfonylethyl$N-dimethylphosphate$GeranylGeranyl$BITC",
    "modified_positions": 4,
    "name": "HTH cro/C1-type domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRH1",
    "length": 423,
    "modifications": "hex$Oxidation$hexnac$gist-quat$lapachenole$Thrbiotinhydrazide$Triton$Didehydro",
    "modified_positions": 9,
    "name": "Serine carboxypeptidase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZRH7",
    "length": 549,
    "modifications": "Oxidation$Gly$Methyl$bisANS-sulfonates$Carbamidomethyl",
    "modified_positions": 6,
    "name": "Probable protein kinase UbiB",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRH9",
    "length": 250,
    "modifications": "galactosyl$hex(1)hexnac(2)sulf(1)$Oxidation$methyl_2h(3)13c(1)$Nitro$Lysbiotinhydrazide$Trimethyl$Glu$Formyl$Carbamidomethyl$hex(4)$Dehydrated",
    "modified_positions": 15,
    "name": "Ubiquinone/menaquinone biosynthesis C-methyltransferase UbiE",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZRI1",
    "length": 201,
    "modifications": "AFB1_Dialdehyde$Oxidation",
    "modified_positions": 2,
    "name": "Transporter, LysE family",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRI2",
    "length": 342,
    "modifications": "Unknown:216$Oxidation$AHA-SS_CAM$Methyl+Deamidated$hydroxyisobutyryl$GG$Carboxy->Thiocarboxy$glucosylgalactosyl$icpl_13c(6)2h(4)$Dicarbamidomethyl$Carboxymethyl$Carbamidomethyl$Thiazolidine$Didehydro$Fluoro",
    "modified_positions": 26,
    "name": "CapM protein, capsular polysaccharide biosynthesis",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZRI4",
    "length": 401,
    "modifications": "Oxidation$ZQG$Tyr->Dha$Deamidated$Carbamidomethyl$NEM:2H(5)+H2O$Delta:H(4)C(3)O(1)",
    "modified_positions": 9,
    "name": "Cytochrome c oxidase subunit 2",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRI8",
    "length": 180,
    "modifications": "Heme$Carbamidomethyl$Deamidated",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRI9",
    "length": 289,
    "modifications": "Oxidation$Gly$Methyl$Delta:H(4)C(3)O(2)$Glu->pyro-Glu$Dehydrated$Hydroxymethyl$Unknown:234$Carbonyl$Cytopiloyne$Carbamidomethyl$Dioxidation",
    "modified_positions": 17,
    "name": "Probable chromosome-partitioning protein ParB",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZRJ1",
    "length": 208,
    "modifications": "Thiazolidine$PyridoxalPhosphateH2$Deamidated",
    "modified_positions": 3,
    "name": "Ribosomal RNA small subunit methyltransferase G",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRJ2",
    "length": 624,
    "modifications": "Oxidation$Gln->pyro-Glu$Diethylphosphate$HNE-Delta:H(2)O$BEMAD_ST$Propyl$Crotonaldehyde$LRGG$Ammonia-loss$PEITC$Pyridylacetyl$Unknown:234$Bromo$DAET$Cytopiloyne$Carbamidomethyl$Butyryl",
    "modified_positions": 18,
    "name": "tRNA uridine 5-carboxymethylaminomethyl modification enzyme MnmG",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZRJ5",
    "length": 228,
    "modifications": "dileu4plex$Oxidation$Ammonium$dileu4plex118$DNCB_hapten$Carbamidomethyl$Delta:H(10)C(8)O(1)",
    "modified_positions": 6,
    "name": "7-cyano-7-deazaguanine synthase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRJ7",
    "length": 245,
    "modifications": "gist-quat_2h(3)$hexnac",
    "modified_positions": 2,
    "name": "Transmembrane protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRJ8",
    "length": 189,
    "modifications": "Oxidation$Gly$QAT$biotinAcrolein298$Dimethyl$NQIGG$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Flavin prenyltransferase UbiX",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRJ9",
    "length": 670,
    "modifications": "Gly$Delta:H(6)C(7)O(4)$Propionamide$Deamidated$Carbamidomethyl$Farnesyl$dimethyl_2h(4)$methyl_2h(3)$murnac$Carbamyl$Cation:Al[III]$Oxidation$Malonyl$SMA$Diethyl$Iodoacetanilide:13C(6)$Nitro$Delta:H(5)C(2)$Label:13C(1)2H(3)+Oxidation$PyruvicAcidIminyl$Delta:H(8)C(6)O(1)",
    "modified_positions": 35,
    "name": "Methionine--tRNA ligase",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZRK0",
    "length": 204,
    "modifications": "Carbamidomethyl$hex(4)$CHDH$hex(1)hexnac(2)sulf(1)",
    "modified_positions": 4,
    "name": "Iron-sulfur cluster binding protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRK1",
    "length": 211,
    "modifications": "Delta:H(2)C(2)$Crotonyl$Oxidation$Methyl$Propionamide$icpl_2h(4)$Gly$Carboxy->Thiocarboxy$Difuran$icdid_2h(6)$Propiophenone$PyridoxalPhosphateH2$Carbamidomethyl$Methylpyrroline$dnic",
    "modified_positions": 16,
    "name": "Endonuclease III",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZRK3",
    "length": 354,
    "modifications": "hexnac(3)$AMTzHexNAc2$C8-QAT$UgiJoullieProGlyProGly$Carbamidomethyl$Ammonia-loss",
    "modified_positions": 7,
    "name": "Magnesium transport protein CorA",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRL0",
    "length": 764,
    "modifications": "hexnac(1)neuac(1)$Cation:Na$3-deoxyglucosone$Cytopiloyne$Carbamidomethyl$CresylSaligeninPhosphate$Cation:Fe[III]$thioacylPA$hex(1)hexnac(1)phos(1)$Oxidation$hex(1)hexnac(1)sulf(1)$AHA-SS$icpl_13c(6)$Cation:Mg[II]$OxProBiotin$GG$FP-Biotin$deamidated_18o(1)$Delta:H(8)C(6)O(1)$PyruvicAcidIminyl$DimethylpyrroleAdduct$Thiazolidine$Phospho",
    "modified_positions": 24,
    "name": "phosphoenolpyruvate--protein phosphotransferase",
    "unique_modifications": 23
  },
  {
    "id": "Q5ZRL1",
    "length": 268,
    "modifications": "Iminobiotin",
    "modified_positions": 1,
    "name": "Probable membrane transporter protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZRL2",
    "length": 256,
    "modifications": "Oxidation$hexnac$deamidated_18o(1)$Met-loss+Acetyl$glucosone",
    "modified_positions": 4,
    "name": "Phosphatidylglycerol--prolipoprotein diacylglyceryl transferase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRL3",
    "length": 264,
    "modifications": "Carbamidomethyl$Argbiotinhydrazide$Propiophenone",
    "modified_positions": 3,
    "name": "Thymidylate synthase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRL4",
    "length": 130,
    "modifications": "Oxidation$murnac$Met->Aha$azole",
    "modified_positions": 6,
    "name": "Thioesterase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRL6",
    "length": 164,
    "modifications": "Decarboxylation$hex(2)hexnac(1)$Pro->Pyrrolidinone$Oxidation",
    "modified_positions": 7,
    "name": "6-carboxy-5,6,7,8-tetrahydropterin synthase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRL9",
    "length": 636,
    "modifications": "Delta:H(2)C(2)$MercaptoEthanol$SulfanilicAcid:13C(6)$Oxidation$pupylation$Delta:H(2)C(3)O(1)$hexnac(1)neuac(1)$Delta:H(5)C(2)$Tris$Label:13C(1)2H(3)+Oxidation$Cation:Na$Deoxy$Carbonyl$DYn-2$Carbamidomethyl$O-pinacolylmethylphosphonate",
    "modified_positions": 19,
    "name": "Coiled-coil containing protein",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZRM5",
    "length": 310,
    "modifications": "Oxidation$ZGB$hexnac(1)dhex(1)$bemad_st_2h(6)$Deamidated$hex(1)hexnac(1)",
    "modified_positions": 8,
    "name": "TPR (Repeat) domain protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRM6",
    "length": 308,
    "modifications": "Oxidation$Dansyl$Saligenin$Malonyl$Thiophospho$HCysThiolactone$Cation:Cu[I]$dimethyl_2h(6)13c(2)$Lys->Allysine",
    "modified_positions": 11,
    "name": "Uncharacterized protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZRN0",
    "length": 71,
    "modifications": "Deamidated$Methamidophos-S$Gln->pyro-Glu$Ammonia-loss",
    "modified_positions": 3,
    "name": "Cold shock transcriptional regulator CspA",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRN3",
    "length": 320,
    "modifications": "Oxidation$Deamidated$UgiJoullieProGly$Thiazolidine$Didehydro$trimethyl_13c(3)2h(9)",
    "modified_positions": 7,
    "name": "Putative auto-transporter adhesin head GIN domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRP6",
    "length": 789,
    "modifications": "ethylamino$Gly$icpl_2h(4)$Hydroxamic_acid$hep$Glu->pyro-Glu$Deamidated$Carbamidomethyl$glucosone$Delta:H(6)C(3)O(1)$Delta:H(4)C(6)$dnic$OxProBiotinRed$icpl_13c(6)2h(4)$Methylpyrroline$dhex(1)hex(1)$Ammonia-loss$Cation:Al[III]$Oxidation$Acetyl$Propyl$MicrocinC7$Dehydrated$Delta:H(2)C(3)O(1)$Diethyl$Trimethyl$PyridoxalPhosphateH2$Carboxymethyl$Unknown:234$deamidated_18o(1)$glycosyl",
    "modified_positions": 32,
    "name": "Transcription accessory protein",
    "unique_modifications": 31
  },
  {
    "id": "Q5ZRP7",
    "length": 126,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Oxidation$Carboxy$Delta:H(4)C(2)$Ethyl",
    "modified_positions": 6,
    "name": "Acyl-CoA thioester hydrolase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRQ5",
    "length": 68,
    "modifications": "Oxidation$imid_2h(4)$15N-oxobutanoic$Deamidated$Dehydrated",
    "modified_positions": 7,
    "name": "Cold shock protein CspE",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRQ6",
    "length": 555,
    "modifications": "Oxidation$Delta:H(4)C(3)O(2)$Methyl$diart6plex117$hydroxyisobutyryl$diart6plex115$diart6plex118$ZQG$Crotonaldehyde$Methylamine$diart6plex116/119$diart6plex$PyruvicAcidIminyl$Carbamidomethyl$hexnac(1)kdn(2)$hexnac(2)dhex(2)",
    "modified_positions": 19,
    "name": "DNA repair protein RecN",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZRQ8",
    "length": 608,
    "modifications": "hex(1)hexa(1)$Oxidation$Dap-DSP$Amidine$Octanoyl$hexnac(1)neugc(2)$Phosphoadenosine$Cation:Na$Dioxidation$spermine$Carbamidomethyl$Delta:H(6)C(3)O(1)$Unknown:162$GluGlu",
    "modified_positions": 29,
    "name": "Large ribosomal subunit assembly factor BipA",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZRR0",
    "length": 336,
    "modifications": "Oxidation$Decarboxylation$Crotonyl$dhex(1)hexnac(5)$Acetyl$Hydroxymethyl$dhex(1)hex(2)hexnac(1)$AzidoF$Carbamidomethyl$EDT-iodoacetyl-PEO-biotin$GluGlu",
    "modified_positions": 12,
    "name": "Aldo/keto reductase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZRR2",
    "length": 165,
    "modifications": "Homocysteic_acid$Oxidation$Chlorination$Deamidated$Carbamidomethyl$Fluoro",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRR7",
    "length": 286,
    "modifications": "Ethyl+Deamidated$hex(5)$Oxidation$Diethyl$Delta:H(4)C(3)O(1)$Propionyl$clip_traq_3",
    "modified_positions": 8,
    "name": "VipE",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRT0",
    "length": 658,
    "modifications": "Oxidation$Crotonyl$Thiazolidine$Met-loss+Acetyl$Carbamidomethyl$Decanoyl$hex(1)hexnac(1)dhex(1)me(2)$hex(1)hexnac(1)$Delta:H(4)C(6)",
    "modified_positions": 12,
    "name": "O-acetyltransferase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZRT1",
    "length": 206,
    "modifications": "Cation:Ni[II]$Oxidation$PyMIC$Delta:H(4)C(3)O(1)$Propionyl",
    "modified_positions": 7,
    "name": "Ribosomal RNA large subunit methyltransferase E",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRT3",
    "length": 291,
    "modifications": "Oxidation$icpl_2h(4)$Cation:Na$FMNH$Carbamidomethyl$hex(3)$hexnac(2)$Unknown:210$dnic",
    "modified_positions": 12,
    "name": "Dihydropteroate synthase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZRT6",
    "length": 249,
    "modifications": "Carbamidomethyl$Glycerophospho$Oxidation",
    "modified_positions": 6,
    "name": "Triosephosphate isomerase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRT9",
    "length": 158,
    "modifications": "Cation:Al[III]$Oxidation$Gly$GG$Diethyl$Dicarbamidomethyl$Unknown:250$Delta:H(6)C(3)O(1)$Carboxymethyl$methyl_2h(2)$Carbamidomethyl$Didehydro",
    "modified_positions": 15,
    "name": "NADH-quinone oxidoreductase subunit B",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZRU0",
    "length": 227,
    "modifications": "CIGG$Oxidation$Glu->pyro-Glu$Pro->pyro-Glu$15N-oxobutanoic$Carbonyl$Cytopiloyne$Carbamidomethyl$Dehydrated",
    "modified_positions": 16,
    "name": "NADH-quinone oxidoreductase subunit C",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZRU6",
    "length": 166,
    "modifications": "Menadione-HQ$Oxidation$gist-quat$Carbamidomethyl$sulfanilicacid$maleimide",
    "modified_positions": 12,
    "name": "NADH-quinone oxidoreductase subunit I",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRU7",
    "length": 219,
    "modifications": "Oxidation$Diisopropylphosphate$Dehydrated",
    "modified_positions": 3,
    "name": "NADH-quinone oxidoreductase subunit J",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRV3",
    "length": 492,
    "modifications": "Ammonium$dhex(2)hex(2)$Phosphoadenosine$Arg->Npo$Cation:Na$Deamidated$Deoxy$Carbamidomethyl$Oxidation$Pyridylethyl$Guanidinyl$Lys->MetOx$Ser->LacticAcid$Formyl$Glu->pyro-Glu+Methyl:2H(2)13C(1)$AHA-SS_CAM$PyridoxalPhosphateH2$PhosphoCytidine$Dioxidation",
    "modified_positions": 36,
    "name": "Transcription termination/antitermination protein NusA",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZRV5",
    "length": 123,
    "modifications": "Gly$hex(1)hexnac(2)dhex(1)$GG$Cation:Fe[III]$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Ribosome-binding factor A",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRV6",
    "length": 303,
    "modifications": "Oxidation$propionyl_13c(3)$phosphoRibosyl$clip_traq_4$Myristoyl+Delta:H(-4)$MesitylOxide$Cation:Fe[II]$AEC-MAEC$Carbamidomethyl",
    "modified_positions": 15,
    "name": "tRNA pseudouridine synthase B",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZRV7",
    "length": 91,
    "modifications": "hexnac(1)neuac(1)$hex(2)hexnac(3)$Ammonia-loss$Lys->MetOx",
    "modified_positions": 5,
    "name": "Small ribosomal subunit protein uS15",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRV8",
    "length": 729,
    "modifications": "hep$Glu->pyro-Glu$Dicarbamidomethyl$Deamidated$Deoxy$Arg->Orn$Carbamidomethyl$Palmitoyl$hex(1)hexnac(1)neuac(1)$Oxidation$Amidine$Acetyl$AzidoF$Formyl$Biotin:Thermo-33033$Lys->Allysine$Propionyl$Dehydrated$Delta:H(2)C(3)O(1)$GG$2HPG$hex(1)hexa(1)hexnac(1)$Thiazolidine$Dioxidation",
    "modified_positions": 49,
    "name": "Polyribonucleotide nucleotidyltransferase",
    "unique_modifications": 24
  },
  {
    "id": "Q5ZRW1",
    "length": 113,
    "modifications": "dhex(1)hex(5)$acetyl_2h(3)",
    "modified_positions": 2,
    "name": "HIT family hydrolase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRW4",
    "length": 238,
    "modifications": "Gly$LG-anhyropyrrole$Myristoyl+Delta:H(-4)$Carbamidomethyl$Ethyl$hex(2)pent(2)me(1)",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRW9",
    "length": 286,
    "modifications": "Propargylamine$Cysteinyl$NHS-LC-Biotin$Carbonyl$Thiazolidine",
    "modified_positions": 6,
    "name": "DUF547 domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRX1",
    "length": 112,
    "modifications": "Gly-loss+Amide$Deoxy$Oxidation$Deamidated",
    "modified_positions": 10,
    "name": "Nucleoid-associated protein lpg2755",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRX7",
    "length": 389,
    "modifications": "hex(1)hexnac(2)sulf(1)$Oxidation$Nitro$Diethylphosphate$Biotin-PEO-Amine$clip_traq_4$Deoxy$Formyl$Ethanedithiol",
    "modified_positions": 10,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZRY0",
    "length": 187,
    "modifications": "Oxidation$Gln->pyro-Glu$Nitrosyl$Deoxy$Deamidated$deamidated_18o(1)$Ammonia-loss",
    "modified_positions": 11,
    "name": "Oligoribonuclease",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRY7",
    "length": 429,
    "modifications": "Oxidation$icdid$Delta:H(2)C(3)O(1)$phosphoRibosyl$Trimethyl$BHT$murnac$PyruvicAcidIminyl$UgiJoullieProGlyProGly",
    "modified_positions": 15,
    "name": "histidine kinase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZRY9",
    "length": 341,
    "modifications": "Gly$Deamidated$SMA$pent(1)hexnac(1)$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 15,
    "name": "(Two component) response regulator",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRZ0",
    "length": 416,
    "modifications": "phosphohexnac$Propionamide$bemad_c_2h(6)$GluGluGluGlu$PyruvicAcidIminyl$Crotonaldehyde$SMA$Butyryl$Carbonyl$esp$Carbamidomethyl$Nitrene$Delta:H(6)C(3)O(1)",
    "modified_positions": 10,
    "name": "Aminotransferase class II",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZRZ4",
    "length": 164,
    "modifications": "hex(1)hexnac(2)dhex(2)sulf(1)$Deamidated$dhex(2)hex(4)",
    "modified_positions": 3,
    "name": "Peptidyl-prolyl cis-trans isomerase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRZ5",
    "length": 209,
    "modifications": "DeStreak$Oxidation$ethylamino",
    "modified_positions": 4,
    "name": "Inner membrane protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZS03",
    "length": 161,
    "modifications": "Carbamidomethyl$Isopropylphospho$Oxidation$Dioxidation",
    "modified_positions": 4,
    "name": "HTH cro/C1-type domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZS04",
    "length": 95,
    "modifications": "PyridoxalPhosphate",
    "modified_positions": 1,
    "name": "UPF0235 protein lpg2716",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZS07",
    "length": 119,
    "modifications": "Carbamidomethyl$4-ONE+Delta:H(-2)O(-1)$TNBS$Carbamyl",
    "modified_positions": 4,
    "name": "Large ribosomal subunit protein bL20",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZS12",
    "length": 144,
    "modifications": "hex(1)hexnac(1)dhex(1)$Oxidation$Propionamide$Carboxyethyl$Dimethylphosphothione$BHT$Retinylidene",
    "modified_positions": 9,
    "name": "Large ribosomal subunit protein uL13",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZS13",
    "length": 143,
    "modifications": "Oxidation$Gly$hex(2)hexnac(2)dhex(1)$Carbofuran$FP-Biotin$Deamidated$AEC-MAEC$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Small ribosomal subunit protein uS9",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZS16",
    "length": 246,
    "modifications": "Amidated$Carboxy$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 3,
    "name": "Ubiquinol-cytochrome c reductase, cytochrome c1",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZS19",
    "length": 493,
    "modifications": "Delta:H(2)C(2)$Met->Hse$Oxidation$ethylamino$Diethylphosphate$Myristoyl+Delta:H(-4)$Delta:H(4)C(2)$Formyl$Carbamidomethyl$Ethyl$Sulfide$Dioxidation",
    "modified_positions": 17,
    "name": "Bifunctional NAD(P)H-hydrate repair enzyme",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZS20",
    "length": 160,
    "modifications": "Ammonium$Malonyl$methyl_2h(3)$Delta:H(2)C(3)$esp$PyruvicAcidIminyl$Carbamidomethyl$hex(1)hexa(1)",
    "modified_positions": 7,
    "name": "tRNA threonylcarbamoyladenosine biosynthesis protein TsaE",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZS23",
    "length": 313,
    "modifications": "Oxidation$Carbonyl$Carbamidomethyl$Carbamyl$Dehydrated",
    "modified_positions": 5,
    "name": "tRNA dimethylallyltransferase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZS28",
    "length": 847,
    "modifications": "Oxidation$GG$hexnac(1)dhex(1)$Dicarbamidomethyl$clip_traq_4$Biotin:Thermo-21328$QTGG$DNCB_hapten$Carbamyl$Unknown:162",
    "modified_positions": 9,
    "name": "Cation transporting ATPase PacS",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZS30",
    "length": 466,
    "modifications": "Gly$pyrophospho$Deamidated$Pyridylacetyl$Quinone$Carbamidomethyl$Didehydro$Phenylisocyanate$pent(1)hexnac(1)$Pro->HAVA$Ethanolamine$Ammonia-loss$Carbamyl$MercaptoEthanol$Oxidation$propionyl_13c(3)$Carbofuran$bemad_st_2h(6)$Methylamine$Ser->LacticAcid$Gln->pyro-Glu$deamidated_18o(1)$AEC-MAEC$Delta:H(8)C(6)O(1)$Thiazolidine",
    "modified_positions": 28,
    "name": "IcmX (IcmY)",
    "unique_modifications": 25
  },
  {
    "id": "Q5ZS31",
    "length": 151,
    "modifications": "Oxidation$ethylamino$Dimethylphosphothione$Formyl$Ethyl",
    "modified_positions": 6,
    "name": "Type 4 adapter protein IcmW",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZS32",
    "length": 151,
    "modifications": "betaFNA",
    "modified_positions": 1,
    "name": "IcmV",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZS37",
    "length": 235,
    "modifications": "PyruvicAcidIminyl",
    "modified_positions": 1,
    "name": "Hypothetical with two candidate membrane-spanning segments",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZS54",
    "length": 238,
    "modifications": "Gln->pyro-Glu$azole$15N-oxobutanoic$Nitrene$Ammonia-loss",
    "modified_positions": 4,
    "name": "Dienelactone hydrolase family protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZS57",
    "length": 252,
    "modifications": "monomethylphosphothione$G-H1$Oxidation$Cation:Ni[II]$Nitro$OxLysBiotin$Carbamidomethyl$Arg2PG",
    "modified_positions": 12,
    "name": "Pantothenate synthetase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZS59",
    "length": 220,
    "modifications": "Hydroxyheme$Unknown:306$Oxidation",
    "modified_positions": 3,
    "name": "Transmembrane protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZS61",
    "length": 75,
    "modifications": "Oxidation$probiotinhydrazide$Carboxy->Thiocarboxy$Carbamidomethyl$GEE",
    "modified_positions": 6,
    "name": "Ferrous iron transporter A",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZS63",
    "length": 322,
    "modifications": "Gly$dhex$Iminobiotin$Deamidated$Carbamidomethyl",
    "modified_positions": 12,
    "name": "Octaprenyl diphosphate synthase IspB",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZS64",
    "length": 371,
    "modifications": "HNE+Delta:H(2)$Oxidation$hex(2)hexnac(2)neuac(1)sulf(1)",
    "modified_positions": 3,
    "name": "Sensory box protein, EAL domain, GGDEF domain, signal transduction protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZS68",
    "length": 103,
    "modifications": "Oxidation$Gly$maleimide3$deamidated_18o(1)$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Large ribosomal subunit protein bL21",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZS71",
    "length": 365,
    "modifications": "Carbamidomethyl$murnac",
    "modified_positions": 4,
    "name": "Competence damage inducible protein CinA",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZS72",
    "length": 272,
    "modifications": "Oxidation$Gly$Carbofuran$Deamidated$Deoxy$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 19,
    "name": "Phenylalanine-4-hydroxylase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZS74",
    "length": 618,
    "modifications": "Cys->PyruvicAcid$hex(3)hexnac(2)neuac(2)$Ethyl+Deamidated$icdid$Nitrosyl$phosphohexnac$O-Dimethylphosphate$Cation:Li$Methylamine$Delta:H(4)C(5)O(1)$CAMthiopropanoyl$pent(1)hexnac(1)$Quinone$Ethylphosphate$Carbamidomethyl$Nitrene$s-glcnac",
    "modified_positions": 21,
    "name": "UvrABC system protein C",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZS77",
    "length": 835,
    "modifications": "HN2_mustard$Gly$Dimethyl$dhex(2)hex(2)$Met->Hsl$Carbamidomethyl$Cytopiloyne+water$Didehydro$hex(2)pent(2)me(1)$Dethiomethyl$Carbonyl$DMPO$Oxidation$bemad_st_2h(6)$15N-oxobutanoic$Lys->Allysine$Haloxon$hex(2)neuac(1)$hex(2)hexnac(2)$Methyl$glycidamide",
    "modified_positions": 24,
    "name": "Sensory box/GGDEF family protein",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZS78",
    "length": 240,
    "modifications": "HNE+Delta:H(2)$Oxidation$acetyl_2h(3)$icpl_13c(6)2h(4)$AEBS$bemad_st_2h(6)$neuac$Carbamidomethyl$Thiazolidine$EDT-iodoacetyl-PEO-biotin",
    "modified_positions": 11,
    "name": "Enhanced entry protein EnhA",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZS79",
    "length": 188,
    "modifications": "Carbamidomethyl$Oxidation$Ethanolyl$HCysThiolactone",
    "modified_positions": 7,
    "name": "Enhanced entry protein EnhB",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZS82",
    "length": 403,
    "modifications": "Oxidation$Methyl+Deamidated$Saligenin$biotinAcrolein298$Cation:Na$SPITC$PyruvicAcidIminyl$Carbamidomethyl$Unknown:420$Dioxidation",
    "modified_positions": 19,
    "name": "Uncharacterized protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZS83",
    "length": 88,
    "modifications": "Oxidation$Methylthio",
    "modified_positions": 4,
    "name": "Small ribosomal subunit protein bS20",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZS85",
    "length": 454,
    "modifications": "Dimethylaminoethyl$Gly$Propionamide$Ammonium$Delta:H(4)C(3)$Delta:H(4)C(5)O(1)$Deoxy$Deamidated$Carbamidomethyl$Unknown:306$Delta:H(6)C(3)O(1)$Methyl+Deamidated$methyl_2h(3)$ISD_z+2_ion$Oxidation$Propargylamine$Amino$Gln->pyro-Glu$Cresylphosphate$UgiJoullieProGlyProGly",
    "modified_positions": 33,
    "name": "Leucine aminopeptidase",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZS87",
    "length": 144,
    "modifications": "maleimide$Carbamidomethyl$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Ethanedithiol",
    "modified_positions": 5,
    "name": "DNA polymerase III, chi subunit",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZS92",
    "length": 393,
    "modifications": "HN2_mustard$hep$Lys->MetOx$Carbamidomethyl$DMPO$Didehydro$Dioxidation",
    "modified_positions": 10,
    "name": "NAD(P)/FAD-dependent oxidoreductase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZS94",
    "length": 1067,
    "modifications": "icpl_2h(4)$Ammonium$glucuronyl$hex(1)pent(1)$dhex(2)hex(2)$dhex(1)hex(1)hexnac(3)$clip_traq_4$Deoxy$Diethylphosphothione$Succinyl$Carbamidomethyl$hex(1)hexnac(2)dhex(2)$dnic$Unknown:216$dhex(3)hex(1)hexnac(2)kdn(1)$icpl$AEBS$BMP-piperidinol$HydroxymethylOP$murnac$Carbonyl$Methylpyrroline$Ammonia-loss$hex(1)neuac(1)pent(1)$hex(1)hexnac(1)dhex(1)$Oxidation$MercaptoEthanol$Fluorescein-tyramine$acetyl_2h(3)$Dansyl$Propyl$BITC$Carboxy$SMA$a-type-ion$hex(1)pent(2)me(1)$Dehydrated$Gln->pyro-Glu$AEC-MAEC$Decanoyl",
    "modified_positions": 50,
    "name": "Carbamoyl phosphate synthase large chain",
    "unique_modifications": 40
  },
  {
    "id": "Q5ZS95",
    "length": 160,
    "modifications": "Oxidation$NDA$O-Methylphosphate$Pentylamine$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Transcription elongation factor GreA",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZS97",
    "length": 353,
    "modifications": "Trimethyl$BEMAD_ST$O-pinacolylmethylphosphonate",
    "modified_positions": 4,
    "name": "Cysteine protease",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSA0",
    "length": 259,
    "modifications": "Oxidation$Gln->pyro-Glu$Gly$AHA-SS_CAM$Carbamidomethyl$Biotin$Delta:H(6)C(3)O(1)$Sulfide",
    "modified_positions": 10,
    "name": "Cell division protein ZipA",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZSA3",
    "length": 447,
    "modifications": "Oxidation$Gly$dhex(2)hex(2)$Deamidated$Deoxy$Methylamine$Carbamidomethyl",
    "modified_positions": 11,
    "name": "UDP-N-acetylmuramoylalanine--D-glutamate ligase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZSA5",
    "length": 469,
    "modifications": "clip_traq_3$hex$3-phosphoglyceryl$Oxidation$Cation:Ni[II]$His+O(2)$Propionamide$TAMRA-FP$Aspartylurea$Arg->Npo$Crotonaldehyde$deamidated_18o(1)$Carbamidomethyl$GEE$Fluoro",
    "modified_positions": 19,
    "name": "UDP-N-acetylmuramate--L-alanine ligase",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZSA7",
    "length": 364,
    "modifications": "GluGlu$Oxidation$Gly$Gln->pyro-Glu$Delta:H(4)C(3)O(2)$hex(1)hexnac(2)dhex(2)sulf(1)$hex(1)pent(1)$NHS-LC-Biotin$dhex(2)hex(4)$Deamidated$Carbamidomethyl$clip_traq_3",
    "modified_positions": 19,
    "name": "D-alanine--D-alanine ligase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZSB0",
    "length": 398,
    "modifications": "Sulfo-NHS-LC-LC-Biotin$ethylamino$Arg->Npo$Deamidated$Carbamidomethyl$Unknown:210$Cation:Ca[II]$Ethanolamine$Carbamyl$Oxidation$neugc$Acetyl$Cation:K$Formyl$Delta:H(2)C(2)$Ethyl+Deamidated$Gln->pyro-Glu$Cation:Li$Iodoacetanilide",
    "modified_positions": 24,
    "name": "Cell division protein FtsZ",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZSB7",
    "length": 140,
    "modifications": "Oxidation$Ammonium$methyl_2h(3)$deamidated_18o(1)$Carbamidomethyl$Carbamyl",
    "modified_positions": 8,
    "name": "Conserved domain protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSB8",
    "length": 146,
    "modifications": "PhosphoCytidine",
    "modified_positions": 1,
    "name": "YdbS-like PH domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSB9",
    "length": 657,
    "modifications": "hex(2)neuac(1)$Oxidation$Dehydrated$Cation:Na$betaFNA$UgiJoullieProGlyProGly$Succinyl$Ser->LacticAcid$Methylthio$Carbamidomethyl$Cation:Mg[II]$2-nitrobenzyl$serotonylation$Dehydro$GluGlu",
    "modified_positions": 16,
    "name": "Acyltransferase",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZSC5",
    "length": 314,
    "modifications": "15N-oxobutanoic$Carbamidomethyl$Oxidation$Nitro",
    "modified_positions": 7,
    "name": "Methionyl-tRNA formyltransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSD1",
    "length": 385,
    "modifications": "Oxidation$Propiophenone$pentose$Methylpyrroline$Carbamyl$Dehydrated",
    "modified_positions": 7,
    "name": "Acid sphingomyelinase-like phosphodiesterase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSE0",
    "length": 137,
    "modifications": "Carbamidomethyl$Oxidation$2-nitrobenzyl$dhex(1)hex(3)hexnac(2)",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSE1",
    "length": 84,
    "modifications": "Oxidation$Methamidophos-S",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSE3",
    "length": 125,
    "modifications": "Oxidation$neugc$HNE$Ammonium$Hydroxamic_acid$O-Isopropylmethylphosphonate$murnac",
    "modified_positions": 12,
    "name": "Hypothetical, uroporphyrin-III C-methyltransferase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZSE4",
    "length": 78,
    "modifications": "Cation:Cu[I]$Cation:Zn[II]",
    "modified_positions": 2,
    "name": "DUF1653 domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSF0",
    "length": 202,
    "modifications": "Carbamidomethyl$Delta:H(4)C(3)",
    "modified_positions": 3,
    "name": "ISI400 transposase B",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSF4",
    "length": 68,
    "modifications": "PyridoxalPhosphate",
    "modified_positions": 1,
    "name": "Prophage regulatory protein-like",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSF7",
    "length": 195,
    "modifications": "HNE+Delta:H(2)$Oxidation$HN2_mustard$NDA$Label:2H(4)+GG$HCysThiolactone$NEMsulfurWater$thioacylPA$Biotin:Thermo-21328$Formyl$Carbonyl$Carbamidomethyl$hex(3)",
    "modified_positions": 10,
    "name": "Transcriptional regulator",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZSH1",
    "length": 469,
    "modifications": "Amidated$Oxidation$Lysbiotinhydrazide$SPITC$Carbamidomethyl$Argbiotinhydrazide$Deoxyhypusine$Dioxidation",
    "modified_positions": 11,
    "name": "Dot/Icm secretion system substrate",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZSH3",
    "length": 457,
    "modifications": "Decarboxylation$Oxidation$Pro->Pyrrolidinone$Difuran$Tris$OxLysBiotin$Carbonyl$Methylthio$Carbamidomethyl$Ethyl$hex(1)hexnac(1)$Fluoro",
    "modified_positions": 19,
    "name": "peptidoglycan lytic exotransglycosylase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZSH7",
    "length": 127,
    "modifications": "Carbamidomethyl$Oxidation",
    "modified_positions": 2,
    "name": "Large-conductance mechanosensitive channel",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSI1",
    "length": 318,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Ferredoxin reductase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSI4",
    "length": 298,
    "modifications": "AFB1_Dialdehyde$GluGluGluGlu",
    "modified_positions": 4,
    "name": "Tellurite resistance protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSI7",
    "length": 347,
    "modifications": "ident$Oxidation$cGMP+RMP-loss$Dimethylphosphothione$SPITC$Carbamidomethyl$Met->Hpg$Ethanedithiol",
    "modified_positions": 9,
    "name": "Phospho-2-dehydro-3-deoxyheptonate aldolase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZSJ1",
    "length": 455,
    "modifications": "Oxidation$Gly$Phosphopropargyl$neugc$ISD_z+2_ion$Deoxy$Phosphogluconoylation$Delta:H(2)C(3)$Ser->LacticAcid$Deamidated$deamidated_18o(1)$Carbamidomethyl$Dehydrated",
    "modified_positions": 23,
    "name": "Macrodomain effector MavL domain-containing protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZSJ3",
    "length": 287,
    "modifications": "DNCB_hapten$Oxidation$glucuronyl",
    "modified_positions": 3,
    "name": "Transcriptional regulator, LuxR family",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSK8",
    "length": 397,
    "modifications": "Cation:Al[III]$Oxidation$Gly$Gln->pyro-Glu$Dansyl$hexnac$azole$Aspartylurea$hex(1)pent(1)$Cation:Na$propyl_2h(6)$Deoxy$Carbamidomethyl$Dehydrated",
    "modified_positions": 20,
    "name": "SdeD",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZSL0",
    "length": 231,
    "modifications": "succinyl_2h(4)$Oxidation$Crotonyl",
    "modified_positions": 4,
    "name": "Pyrroloquinoline quinone (Coenzyme PQQ) biosynthesis protein C",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSL2",
    "length": 295,
    "modifications": "methylsulfonylethyl$Oxidation$Decarboxylation$Tris$Cation:Li$UgiJoullieProGlyProGly$Carbamidomethyl",
    "modified_positions": 11,
    "name": "Ankyrin repeat protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZSL4",
    "length": 106,
    "modifications": "hex(1)hexnac(2)$hex(1)hexnac(1)dhex(1)$AROD$Formyl$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZSL9",
    "length": 310,
    "modifications": "Oxidation$ethylamino$Diethylphosphate$Carboxy->Thiocarboxy$Carbamidomethyl$Dioxidation",
    "modified_positions": 12,
    "name": "DUF5636 domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSM4",
    "length": 164,
    "modifications": "neiaa_2h(5)$Oxidation$hex(1)pent(3)",
    "modified_positions": 5,
    "name": "Small heat shock protein HspC2",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSN1",
    "length": 462,
    "modifications": "hex(1)hexa(1)$Delta:H(2)C(2)$dimethyl_2h(4)$Glu->pyro-Glu+Methyl$Decarboxylation$Oxidation$hex(2)$Carboxyethyl$cGMP+RMP-loss$pupylation$Pyridylethyl$Gly$Oxidation+NEM$Deamidated$Carbamidomethyl$NBS$Dioxidation",
    "modified_positions": 25,
    "name": "phosphomannomutase",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZSN7",
    "length": 270,
    "modifications": "Carbamidomethyl$Ethylphosphate$Ethanedithiol",
    "modified_positions": 3,
    "name": "Cellobiose phosphorylase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSP2",
    "length": 252,
    "modifications": "Propiophenone$Delta:H(6)C(3)O(1)$Deamidated$Carbamidomethyl$benzylguanidine$gist-quat_2h(9)",
    "modified_positions": 6,
    "name": "Hydrogenase maturation factor HypB",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSP5",
    "length": 368,
    "modifications": "cGMP$Oxidation$hexnac$HNE-Delta:H(2)O$Cation:Na$Unknown:234$Carbamidomethyl$methylol",
    "modified_positions": 12,
    "name": "Hydrogenase maturation factor",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZSP8",
    "length": 281,
    "modifications": "Menadione-HQ$Propionamide$Carboxyethyl$Iodoacetanilide:13C(6)$DNCB_hapten",
    "modified_positions": 4,
    "name": "Hydrogenase/sulfur reductase gamma subunit",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZSP9",
    "length": 261,
    "modifications": "Deamidated$MercaptoEthanol",
    "modified_positions": 2,
    "name": "Sulfhydrogenase delta subunit",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSQ1",
    "length": 159,
    "modifications": "BEMAD_ST",
    "modified_positions": 1,
    "name": "Hydrogenase expression/formation protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSQ4",
    "length": 239,
    "modifications": "Acetyl$Nitrene$Oxidation$Dioxidation",
    "modified_positions": 7,
    "name": "Peptide aspartate b-dioxygenase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSQ5",
    "length": 310,
    "modifications": "Carbamidomethyl$EQIGG$glycosyl$Dimethylphosphothione",
    "modified_positions": 8,
    "name": "Exported protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSQ7",
    "length": 127,
    "modifications": "bemad_st_2h(6)$Formyl",
    "modified_positions": 2,
    "name": "Nuclear transport factor 2 family protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSR1",
    "length": 471,
    "modifications": "monomethylphosphothione$pent(2)$Oxidation$Gly$hydroxyisobutyryl$azole$Glu->pyro-Glu$15N-oxobutanoic$Deoxy$HydroxymethylOP$GEE$Nethylmaleimide+water$Ethylphosphate$Carbamidomethyl$Met->Hpg$Dehydrated",
    "modified_positions": 22,
    "name": "Ankyrin repeat-containing protein",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZSR2",
    "length": 209,
    "modifications": "Oxidation$Gln->pyro-Glu$PET$pupylation$GG$Diethyl$Dicarbamidomethyl$Isopropylphospho$GGQ$Methamidophos-S$GPIanchor",
    "modified_positions": 11,
    "name": "Uncharacterized protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZSS3",
    "length": 185,
    "modifications": "Carbamidomethyl$Cation:Ca[II]$Cation:K",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSS4",
    "length": 136,
    "modifications": "Unknown:216$Carbamidomethyl$Gly$FP-Biotin",
    "modified_positions": 7,
    "name": "PhnB protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSS5",
    "length": 157,
    "modifications": "Oxidation$O-Et-N-diMePhospho$Glu->pyro-Glu$Carbamidomethyl$Methamidophos-S$Dehydrated",
    "modified_positions": 9,
    "name": "DNA binding protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZST4",
    "length": 219,
    "modifications": "Delta:H(2)C(2)",
    "modified_positions": 1,
    "name": "Alkaline phosphatase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZST9",
    "length": 403,
    "modifications": "Oxidation$Decarboxylation$GG$Diethyl$icpl$phosphoRibosyl$Dicarbamidomethyl$nic$Carbamidomethyl$GEE$hex(1)hexnac(2)neuac(2)sulf(1)",
    "modified_positions": 12,
    "name": "Malonate decarboxylase acyl carrier protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZSU6",
    "length": 183,
    "modifications": "Nitro$Oxidation$clip_traq_4",
    "modified_positions": 3,
    "name": "N-acetyltransferase domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSV0",
    "length": 368,
    "modifications": "Oxidation$Methyl$Acetyl$Trimethyl$Isopropylphospho$Carbamidomethyl$Didehydro",
    "modified_positions": 10,
    "name": "Ankyrin repeat family protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZSV2",
    "length": 97,
    "modifications": "Carbamidomethyl",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSV8",
    "length": 219,
    "modifications": "3-phosphoglyceryl$Oxidation$NHS-LC-Biotin$PEO-Iodoacetyl-LC-Biotin$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Transglutaminase-like domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZSW6",
    "length": 354,
    "modifications": "Dansyl$hex(5)hexnac(1)$Carbamidomethyl$succinyl_2h(4)$Ammonia-loss",
    "modified_positions": 6,
    "name": "Leucine-rich repeat-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZSX0",
    "length": 356,
    "modifications": "Oxidation$HNE$Ethanolyl$HCysThiolactone$Carbamidomethyl$EHD-diphenylpentanone",
    "modified_positions": 8,
    "name": "Transcriptional regulator",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSX4",
    "length": 294,
    "modifications": "Dimethyl$CHDH$Delta:H(4)C(2)$deamidated_18o(1)$Ethyl$methylol$Delta:H(4)C(3)O(1)",
    "modified_positions": 5,
    "name": "Leucine-rich repeat-containing protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZSX5",
    "length": 434,
    "modifications": "Gly$SPITC$hex(5)hexnac(1)$Formyl$Carbamidomethyl$Ethyl$CresylSaligeninPhosphate",
    "modified_positions": 6,
    "name": "SdbC",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZSX7",
    "length": 721,
    "modifications": "Glycerophospho$Carbamidomethyl$Decarboxylation$methyl_2h(3)13c(1)$methyl_2h(3)$O-Isopropylmethylphosphonate$Carbonyl$Ammonia-loss$pent(2)$Oxidation$Trp->Oxolactone$Propargylamine$Amidine$Acetyl$PS_Hapten$ethylsulfonylethyl$Formyl$Nmethylmaleimide$Unknown:248$hexnac",
    "modified_positions": 23,
    "name": "Catalase-peroxidase 1",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZSX9",
    "length": 308,
    "modifications": "Lys->CamCys$AEBS",
    "modified_positions": 2,
    "name": "Plasminogen activator",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSY4",
    "length": 484,
    "modifications": "Ethyl$Delta:H(4)C(3)",
    "modified_positions": 2,
    "name": "Symporter",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSZ0",
    "length": 305,
    "modifications": "Oxidation$PET$Crotonaldehyde$CAMthiopropanoyl$Nethylmaleimide+water",
    "modified_positions": 5,
    "name": "Transcriptional regulator, LysR family",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZSZ1",
    "length": 157,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Gln->pyro-Glu$Oxidation$acetyl_2h(3)$Carboxy$Delta:O(4)",
    "modified_positions": 12,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSZ5",
    "length": 204,
    "modifications": "hep$Carbamidomethyl$O-Et-N-diMePhospho",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSZ6",
    "length": 312,
    "modifications": "Delta:H(2)C(2)$Aspartylurea$HN3_mustard$Lys->Allysine",
    "modified_positions": 4,
    "name": "HipA-like C-terminal domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSZ8",
    "length": 75,
    "modifications": "Acetyl$CresylSaligeninPhosphate$SPITC",
    "modified_positions": 4,
    "name": "HTH cro/C1-type domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZT00",
    "length": 583,
    "modifications": "Oxidation$Methyl$Delta:H(2)C(3)O(1)$probiotinhydrazide$Delta:H(2)C(3)$Carbamidomethyl$CresylSaligeninPhosphate$Dioxidation",
    "modified_positions": 10,
    "name": "Inner membrane protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZT02",
    "length": 121,
    "modifications": "Carbamidomethyl$Oxidation$acetyl_2h(3)",
    "modified_positions": 4,
    "name": "BRCT domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZT06",
    "length": 147,
    "modifications": "SulfanilicAcid:13C(6)$Oxidation$hexnac$icpl_2h(4)$Acetyldeoxyhypusine$Trimethyl$Deoxy$methyl_2h(3)+acetyl_2h(3)$DimethylpyrroleAdduct$Carbamidomethyl$dnic",
    "modified_positions": 13,
    "name": "GatB/YqeY domain-containing protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZT07",
    "length": 79,
    "modifications": "ZQG$MicrocinC7$neiaa",
    "modified_positions": 3,
    "name": "Small ribosomal subunit protein bS21",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZT11",
    "length": 375,
    "modifications": "Iodoacetanilide:13C(6)$Oxidation$hex(2)$Unknown:234",
    "modified_positions": 11,
    "name": "Heme chaperone HemW",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZT13",
    "length": 330,
    "modifications": "Gly$Ammonium$Deamidated$Carbamidomethyl$Delta:H(4)C(3)O(1)$Delta:H(6)C(3)O(1)$methyl_2h(3)$Met->Hpg$Ammonia-loss$Sulfide$Oxidation$gist-quat$HNE$Carbofuran$Propionyl$Dehydrated$Gln->pyro-Glu$SPITC:13C(6)$Carboxymethyl$Dioxidation",
    "modified_positions": 32,
    "name": "Malate dehydrogenase",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZT14",
    "length": 306,
    "modifications": "DNCB_hapten$HNE-BAHAH$Oxidation$PyruvicAcidIminyl",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZT27",
    "length": 158,
    "modifications": "G-H1$Oxidation$pupylation$Acetyldeoxyhypusine$4-ONE$Delta:H(4)C(3)$clip_traq_4$Deoxy$murnac$UgiJoullieProGly$Carbamidomethyl$maleimide$hexnac(5)$glycidamide",
    "modified_positions": 19,
    "name": "RNA polymerase-binding transcription factor DksA",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZT28",
    "length": 287,
    "modifications": "OxProBiotinRed$Diisopropylphosphate$CAMthiopropanoyl$Carbamidomethyl$Furan$Fluoro",
    "modified_positions": 7,
    "name": "Release factor glutamine methyltransferase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZT30",
    "length": 424,
    "modifications": "Glu->pyro-Glu+Methyl$Oxidation$Cation:Cu[I]$dhex(1)hexnac(4)$Carbamidomethyl$Biotin:Thermo-88310$Deoxyhypusine",
    "modified_positions": 10,
    "name": "Glutamyl-tRNA reductase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZT36",
    "length": 76,
    "modifications": "hex(1)pent(2)me(1)",
    "modified_positions": 1,
    "name": "Exodeoxyribonuclease 7 small subunit",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZT48",
    "length": 386,
    "modifications": "Unknown:216$Oxidation$methyl_2h(3)13c(1)$dhex(1)hex(1)hexnac(3)sulf(1)$Carbamidomethyl",
    "modified_positions": 6,
    "name": "Transmembrane protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZT49",
    "length": 260,
    "modifications": "ethylamino$Phosphopropargyl$Trimethyl$Propyl$Deamidated$Formyl$Carbamidomethyl$Thiazolidine$Unknown:306",
    "modified_positions": 11,
    "name": "3-hydroxybutyrate dehydrogenase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZT51",
    "length": 290,
    "modifications": "Oxidation$Amidine$2HPG$Formyl$Carbamidomethyl",
    "modified_positions": 15,
    "name": "4-hydroxy-tetrahydrodipicolinate synthase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZT53",
    "length": 100,
    "modifications": "Oxidation$Crotonyl$Acetyl$dhex(3)hex(2)hexnac(2)$Crotonaldehyde$IED-Biotin$Amidino",
    "modified_positions": 7,
    "name": "Secreted protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZT58",
    "length": 84,
    "modifications": "Oxidation$ethylamino$DimethylamineGMBS$Carbamidomethyl$Unknown:306",
    "modified_positions": 5,
    "name": "Glutaredoxin",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZT59",
    "length": 139,
    "modifications": "Oxidation$Tris$Deamidated$Pentylamine$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Rhodanese domain protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZT61",
    "length": 310,
    "modifications": "CarbamidomethylDTT$bemad_st_2h(6)$Cation:Li$methyl_2h(3)+acetyl_2h(3)$Diethylphosphothione$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Ribosomal protein uL3 glutamine methyltransferase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZT62",
    "length": 352,
    "modifications": "QEQTGG$BHTOH",
    "modified_positions": 2,
    "name": "Chorismate synthase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZT63",
    "length": 340,
    "modifications": "OxProBiotin$Oxidation$Gly$Diethyl$Carbamidomethyl$Delta:H(4)C(3)O(1)",
    "modified_positions": 8,
    "name": "Aspartate-semialdehyde dehydrogenase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZT65",
    "length": 467,
    "modifications": "Delta:H(2)C(2)$Oxidation$Methamidophos-O$neiaa$Ethanolamine$Carbamidomethyl$Thiazolidine$Dioxidation",
    "modified_positions": 12,
    "name": "Ankyrin repeat domain protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZT75",
    "length": 206,
    "modifications": "hex(2)pent(2)$O-pinacolylmethylphosphonate",
    "modified_positions": 3,
    "name": "FMN-dependent NADH:quinone oxidoreductase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZT83",
    "length": 332,
    "modifications": "dimethyl_2h(4)$Oxidation$Gly$AccQTag$Carboxy$Deamidated$SMA$deamidated_18o(1)$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Deoxy$Carbamidomethyl$Thiazolidine",
    "modified_positions": 22,
    "name": "Fumarylacetoacetate hydrolase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZT84",
    "length": 348,
    "modifications": "Oxidation$Delta:H(8)C(6)O(2)$BITC$Carbamidomethyl$igbp_13c(2)$Delta:H(6)C(3)O(1)$Biotin-HPDP",
    "modified_positions": 9,
    "name": "4-hydroxyphenylpyruvate dioxygenase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZT85",
    "length": 218,
    "modifications": "Carbamidomethyl$Deoxy$Oxidation$maleimide",
    "modified_positions": 11,
    "name": "O-methyltransferase, SAM-dependent",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZT86",
    "length": 357,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Ammonium$Lysbiotinhydrazide$Iminobiotin$Cys->CamSec$Deamidated$Deoxy$dhex(1)hex(3)hexnac(6)$Carbamidomethyl$methyl_2h(3)$Ammonia-loss$Oxidation$dichlorination$Acetyl$Trioxidation$Ser->LacticAcid$hexnac(4)$Delta:H(2)C(2)$3-phosphoglyceryl$Gln->pyro-Glu",
    "modified_positions": 27,
    "name": "Glu/Leu/Phe/Val dehydrogenase",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZT89",
    "length": 437,
    "modifications": "Nmethylmaleimide$SulfanilicAcid:13C(6)$Oxidation$Crotonaldehyde$icpl_13c(6)$Butyryl",
    "modified_positions": 6,
    "name": "sn-glycerol-3-phosphate-binding periplasmic protein UgpB",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZT91",
    "length": 216,
    "modifications": "gist-quat$Carbamidomethyl$Octanoyl",
    "modified_positions": 3,
    "name": "DUF5638 domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZT92",
    "length": 280,
    "modifications": "Cation:Al[III]$Oxidation$Delta:H(8)C(6)O(2)$Phosphoadenosine$Didehydro",
    "modified_positions": 8,
    "name": "Oxidoreductase (NAD-dependent epimerase/dehydratase)",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZT95",
    "length": 412,
    "modifications": "dhex(1)hex(3)$Delta:H(2)C(5)$Oxidation$Delta:H(8)C(6)O(2)$Dimethylphosphothione$Delta:H(2)C(3)$Deamidated$thioacylPA$Methylphosphonate$hex(1)pent(2)$Deoxyhypusine",
    "modified_positions": 13,
    "name": "Prolidase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZT97",
    "length": 187,
    "modifications": "Nmethylmaleimide",
    "modified_positions": 1,
    "name": "Acyltransferase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTA1",
    "length": 468,
    "modifications": "Oxidation$Methyl$Delta:H(6)C(6)O(1)$imid_2h(4)$hexnac(1)neuac(1)$Delta:H(5)C(2)$Dimethyl$Carbofuran$Deamidated$hex(1)neugc(1)$Carbamidomethyl$Methamidophos-S",
    "modified_positions": 16,
    "name": "Phosphate acetyl/butyryltransferase family protein includes: (Dehydratase mit MaoC domain",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZTA4",
    "length": 96,
    "modifications": "hexnac(2)sulf(1)",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTA5",
    "length": 216,
    "modifications": "Carbamidomethyl$Gly",
    "modified_positions": 9,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTA7",
    "length": 83,
    "modifications": "Oxidation$Gly$Amidine$O-Dimethylphosphate$icpl_13c(6)2h(4)$Acetyl$Trimethyl$Hydroxytrimethyl$Propyl$Ethylphosphate$NIPCAM$Deoxy$HydroxymethylOP$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 12,
    "name": "Silver efflux pump",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZTA9",
    "length": 262,
    "modifications": "Cation:Li$CAMthiopropanoyl$Nethylmaleimide+water$Carbamidomethyl$Nitrene",
    "modified_positions": 6,
    "name": "Putative DNA-binding domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTB0",
    "length": 457,
    "modifications": "Oxidation$methyl_2h(3)13c(1)$Biotin$bemad_st_2h(6)$Deamidated$hexnac(2)neugc(1)$Glu->pyro-Glu+Methyl:2H(2)13C(1)$succinyl_13c(4)$benzoyl$Delta:H(8)C(6)O(1)$glycosyl",
    "modified_positions": 13,
    "name": "Glutamine synthetase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZTB2",
    "length": 386,
    "modifications": "cGMP$Decarboxylation$Oxidation$Methyl$Diisopropylphosphate$Pro->pyro-Glu$Deamidated$NO_SMX_SEMD$Carbonyl$Carbamidomethyl$a-type-ion$Delta:H(10)C(8)O(1)",
    "modified_positions": 21,
    "name": "Alcohol dehydrogenase, iron containing",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZTB3",
    "length": 232,
    "modifications": "Acetyl$4-ONE$neiaa",
    "modified_positions": 3,
    "name": "Glutamine amidotransferase, class I",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTB6",
    "length": 169,
    "modifications": "phosphohexnac",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTB7",
    "length": 430,
    "modifications": "Menadione-HQ$hex(1)hexnac(1)neugc(2)$Tris$Oxidation",
    "modified_positions": 10,
    "name": "C4-dicarboxylate transport protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTD1",
    "length": 250,
    "modifications": "Lys->CamCys$Delta:H(8)C(6)O(2)$Decarboxylation$Oxidation$Pro->Pyrrolidinone$VFQQQTGG$UgiJoullieProGly$Thiazolidine$sulfanilicacid$GPIanchor",
    "modified_positions": 11,
    "name": "3-oxoacyl reductase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZTD6",
    "length": 563,
    "modifications": "PET$4-ONE+Delta:H(-2)O(-1)$pyrophospho$Dicarbamidomethyl$Unknown:250$Carbamidomethyl$HN3_mustard$Propiophenone$pentose$Delta:H(2)C(3)$Oxidation$Pyridylethyl$ethylsulfonylethyl$Methylthio$clip_traq_2$Methamidophos-S$maleimide$GG$Cation:Li",
    "modified_positions": 26,
    "name": "Isovaleryl CoA dehydrogenase",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZTD9",
    "length": 407,
    "modifications": "Oxidation$Delta:H(6)C(7)O(4)$Propargylamine$Thiophospho$Biotin:Thermo-21328$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZTE1",
    "length": 239,
    "modifications": "Oxidation$PS_Hapten$O-Isopropylmethylphosphonate$ethylsulfonylethyl$hex(3)hexnac(1)pent(1)",
    "modified_positions": 4,
    "name": "2,3,4,5-tetrahydropyridine-2,6-carboxylate N-succinyltransferase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTE6",
    "length": 590,
    "modifications": "methylsulfonylethyl$Oxidation$Diisopropylphosphate$Delta:H(2)C(3)O(1)$Methyl+Deamidated$Nitrosyl$Saligenin$Hydroxamic_acid$Unknown:210$Isopropylphospho$Carboxyethylpyrrole$Cation:Fe[II]$UgiJoullieProGly$DMPO$Carbamyl",
    "modified_positions": 17,
    "name": "Purine NTPase, putative",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZTE8",
    "length": 307,
    "modifications": "Oxidation$Gly$Nitro$Dimethylphosphothione$Cation:Li$Carbamidomethyl$dimethyl_2h(6)13c(2)$a-type-ion",
    "modified_positions": 10,
    "name": "Nucleoside-diphosphate sugar epimerase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTF1",
    "length": 134,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "YjbQ family protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTG2",
    "length": 178,
    "modifications": "dileu4plex$Oxidation$hep$Tyr->Dha$dileu4plex117$Deoxy$dileu4plex118$Formyl",
    "modified_positions": 9,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTG6",
    "length": 323,
    "modifications": "Oxidation$Carboxy->Thiocarboxy$Acetyl$thioacylPA$Diethylphosphothione$Ser->LacticAcid$GGQ$Carbonyl$UgiJoullieProGlyProGly$Met->Hpg",
    "modified_positions": 20,
    "name": "Ornithine cyclodeaminase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZTG8",
    "length": 208,
    "modifications": "Oxidation$Gly$Methyl$acetyl_2h(3)$Hydroxamic_acid$Deamidated$Deoxy$Carboxymethyl$Carbamidomethyl",
    "modified_positions": 21,
    "name": "(Beta)-carbonic anhydrase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZTH2",
    "length": 620,
    "modifications": "Ammonium$Pyridylacetyl$dileu4plex118$Carbamidomethyl$dileu4plex115$Unknown:216$DAET$dileu4plex$Oxidation$Acetyl$Propyl$BITC$NIPCAM$Ser->LacticAcid$maleimide$Diethyl$GG$Trimethyl$dileu4plex117$glycidamide",
    "modified_positions": 26,
    "name": "IcmL-like",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZTH5",
    "length": 133,
    "modifications": "Deamidated",
    "modified_positions": 1,
    "name": "Acetyltransferase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTH8",
    "length": 468,
    "modifications": "Delta:H(2)C(2)$Oxidation$Acetyl$4-ONE+Delta:H(-2)O(-1)$PyridoxalPhosphate$neuac$Guanidinyl$Arg2PG$dimethyl_2h(4)13c(2)$murnac$Formyl$Carbamidomethyl$dimethyl_2h(6)$O-pinacolylmethylphosphonate",
    "modified_positions": 14,
    "name": "IS4 family transposase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZTJ0",
    "length": 336,
    "modifications": "Oxidation$HN2_mustard$PET$hex(1)pent(1)$Propyl$gist-quat_2h(3)$Carbamidomethyl$sulfanilicacid$Didehydro",
    "modified_positions": 10,
    "name": "N-acetyltransferase domain-containing protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZTJ2",
    "length": 124,
    "modifications": "Oxidation",
    "modified_positions": 3,
    "name": "VOC domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTJ3",
    "length": 257,
    "modifications": "hex(1)hexnac(1)dhex(1)$Oxidation$neugc$PyruvicAcidIminyl$Carbamidomethyl",
    "modified_positions": 6,
    "name": "Acetyltransferase, GNAT family",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTK1",
    "length": 482,
    "modifications": "Oxidation$O-Dimethylphosphate$TNBS$Carbofuran$Methamidophos-O$Ethylphosphate$Carbamidomethyl$clip_traq_3",
    "modified_positions": 11,
    "name": "Uncharacterized protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTL2",
    "length": 119,
    "modifications": "OxLysBiotinRed$Oxidation$Methyl$Diethylphosphate$Ethanedithiol$ethylsulfonylethyl$Carboxyethylpyrrole$Lys->AminoadipicAcid$glycidamide",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZTM4",
    "length": 538,
    "modifications": "Unknown:216$Oxidation$Deamidated$thioacylPA$SPITC:13C(6)$Ser->LacticAcid$Thiazolidine",
    "modified_positions": 8,
    "name": "Calmodulin-dependent protein kinase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZTN0",
    "length": 180,
    "modifications": "SMA$Menadione$AccQTag",
    "modified_positions": 3,
    "name": "Ankyrin 3",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTN5",
    "length": 625,
    "modifications": "Oxidation$Cation:Ca[II]$Ammonium$Cation:K$methyl_2h(3)$methyl_2h(2)",
    "modified_positions": 11,
    "name": "Probable potassium transport system protein Kup 2",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZTN8",
    "length": 303,
    "modifications": "Phosphoguanosine$Succinyl",
    "modified_positions": 3,
    "name": "Cobalt zinc cadmium cation transporter",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTP1",
    "length": 472,
    "modifications": "Glu->pyro-Glu$SPITC$Methamidophos-O$Carbamidomethyl$hex(1)hexa(1)$Palmitoyl$HN3_mustard$DNPS$Ub-Br2$hex(1)neuac(1)pent(1)$Oxidation$Propyl$Carboxy$2-monomethylsuccinyl$Ser->LacticAcid$icpl_13c(6)$Methamidophos-S$Dehydrated$Nmethylmaleimide$Menadione-HQ$Unknown:234",
    "modified_positions": 23,
    "name": "Transposase, IS4 family, Tn5",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZTP7",
    "length": 127,
    "modifications": "methyl_2h(2)$Delta:H(5)C(2)$dhex(1)hex(2)hexa(1)",
    "modified_positions": 3,
    "name": "Transposase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTQ6",
    "length": 165,
    "modifications": "Diethylphosphate$glucuronyl",
    "modified_positions": 2,
    "name": "Transmembrane protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTQ7",
    "length": 58,
    "modifications": "3-phosphoglyceryl",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTS0",
    "length": 187,
    "modifications": "pent(2)$PEITC$Oxidation$BITC",
    "modified_positions": 6,
    "name": "Putative conjugative transfer protein TraE",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTS3",
    "length": 116,
    "modifications": "dimethyl_2h(4)$Oxidation$hexnac$FMNC$EGCG1",
    "modified_positions": 7,
    "name": "Conjugative transfer: assembly",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTS5",
    "length": 202,
    "modifications": "Carbamidomethyl$LG-anhyropyrrole$deamidated_18o(1)",
    "modified_positions": 3,
    "name": "TraW",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTS6",
    "length": 331,
    "modifications": "Carbamidomethyl$Isopropylphospho$Oxidation",
    "modified_positions": 7,
    "name": "TraU",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTS8",
    "length": 603,
    "modifications": "Biotin:Thermo-21901+2H2O$Phycocyanobilin$Gly$glucuronyl$Dicarbamidomethyl$Carbamidomethyl$Delta:H(6)C(3)O(1)$CAF$probiotinhydrazide$SulfurDioxide$Dimethylphosphothione$MesitylOxide$Sulfide$hex(1)hexnac(1)dhex(1)$Oxidation$Dansyl$Carbofuran$bisANS-sulfonates$hex(1)hexnac(2)$hex(2)hexnac(1)$Unknown:248$GG$Iodoacetanilide:13C(6)$dhex(1)hex(2)$hex(1)pent(2)me(1)",
    "modified_positions": 26,
    "name": "TraN",
    "unique_modifications": 25
  },
  {
    "id": "Q5ZTT1",
    "length": 461,
    "modifications": "Oxidation$diart6plex117$diart6plex115$Dap-DSP$diart6plex118$N-dimethylphosphate$Propiophenone$pentose$diart6plex116/119$diart6plex$pent(1)hexnac(1)$Biotin:Thermo-21345$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 10,
    "name": "TraH",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZTT3",
    "length": 630,
    "modifications": "sulfo+amino$Oxidation$Propionamide$Diethylphosphate$dileu4plex118$PhosphoCytidine$Methylthio$Carbamidomethyl$EDT-iodoacetyl-PEO-biotin",
    "modified_positions": 11,
    "name": "TraD",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZTT5",
    "length": 363,
    "modifications": "NDA$AccQTag$Dimethylphosphothione$Propiophenone$Sulfo",
    "modified_positions": 7,
    "name": "DUF4917 domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTT6",
    "length": 278,
    "modifications": "3-phosphoglyceryl$Oxidation$AEBS$PyridoxalPhosphateH2$CAMthiopropanoyl$Nethylmaleimide+water$Formyl$Carbamidomethyl",
    "modified_positions": 10,
    "name": "Site-specific DNA-methyltransferase (adenine-specific)",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTU3",
    "length": 125,
    "modifications": "Oxidation$SPITC:13C(6)$Octanoyl",
    "modified_positions": 3,
    "name": "MazG (Nucleoside triphosphate pyrophosphohydrolase)",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTU6",
    "length": 280,
    "modifications": "Dioxidation$galactosyl",
    "modified_positions": 2,
    "name": "D-xylose reductase III",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTV4",
    "length": 334,
    "modifications": "Menadione-HQ$MesitylOxide$PyridoxalPhosphate$CresylSaligeninPhosphate",
    "modified_positions": 4,
    "name": "Prophage dlp12 integrase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTV5",
    "length": 292,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Mevalonate kinase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTV6",
    "length": 432,
    "modifications": "monomethylphosphothione$Oxidation$NDA$Methyl+Deamidated$dhex$cGMP+RMP-loss$Diethylphosphate$Iminobiotin$bemad_st_2h(6)$Pro->pyro-Glu$15N-oxobutanoic$Carbonyl$Delta:H(6)C(3)O(1)$Dehydrated",
    "modified_positions": 15,
    "name": "3-hydroxy-3-methylglutaryl coenzyme A reductase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZTV9",
    "length": 99,
    "modifications": "Oxidation$pyrophospho$3-deoxyglucosone$Thiazolidine$Fluoro",
    "modified_positions": 6,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTW1",
    "length": 374,
    "modifications": "hex(1)hexnac(1)phos(1)$Oxidation$Delta:H(2)C(3)O(1)$dhex(2)hex(2)hexnac(4)$hex(1)pent(1)$hex(1)hexnac(1)sulf(1)$hex(1)hexnac(2)$Carbamidomethyl",
    "modified_positions": 10,
    "name": "ABC transporter, permease",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTW2",
    "length": 245,
    "modifications": "Oxidation$PET$hex(1)pent(1)$GluGluGluGlu$Methylamine$Isopropylphospho$3-deoxyglucosone$Argbiotinhydrazide$hex(1)hexa(1)",
    "modified_positions": 12,
    "name": "ABC transporter, ATP binding protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZTW5",
    "length": 176,
    "modifications": "Oxidation$Ethyl+Deamidated$Cation:Ca[II]$Propionamide$Carboxyethyl$Cation:K$Carbamidomethyl$Phospho$GPIanchor",
    "modified_positions": 9,
    "name": "Peptidoglycan-associated lipoprotein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZTW6",
    "length": 322,
    "modifications": "Gly-loss+Amide$Delta:H(8)C(6)O(2)$Gln->pyro-Glu$Formyl",
    "modified_positions": 7,
    "name": "Cell division coordinator CpoB",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTW7",
    "length": 217,
    "modifications": "Oxidation$phosphohex(2)$thioacylPA$methyl_2h(2)$Carbamidomethyl$hex(2)sulf(1)$sulfanilicacid$dimethyl_2h(6)13c(2)$Haloxon",
    "modified_positions": 12,
    "name": "7-carboxy-7-deazaguanine synthase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZTX2",
    "length": 200,
    "modifications": "Gly$Cy3b-maleimide$hep$Didehydro$Carbofuran$Deamidated$Iodoacetanilide$Carboxymethyl$AEC-MAEC$Carbamidomethyl$maleimide",
    "modified_positions": 15,
    "name": "Nucleoside triphosphate pyrophosphatase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZTX9",
    "length": 112,
    "modifications": "QEQTGG",
    "modified_positions": 1,
    "name": "7,8-dihydroneopterin aldolase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTY1",
    "length": 445,
    "modifications": "Oxidation$Decarboxylation$Pro->Pyrrolidinone$Gly$Diethyl$hex(1)neuac(1)$Saligenin$Phosphoadenosine$Deamidated$BMP-piperidinol$Carboxymethyl$AEC-MAEC$Carbamidomethyl$Delta:H(6)C(3)O(1)$Dioxidation",
    "modified_positions": 14,
    "name": "Phospho-2-dehydro-3-deoxyheptonate aldolase",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZTY6",
    "length": 382,
    "modifications": "Oxidation$Gly$propionyl_13c(3)$methyl+acetyl_2h(3)$Hydroxytrimethyl$Iodoacetanilide:13C(6)$Diethylphosphate$Malonyl$Gln->pyro-Glu$Carbamyl$Deamidated$Deoxy$Ser->LacticAcid$Nethylmaleimide+water$Carbamidomethyl$Ammonia-loss$Deoxyhypusine$Dioxidation",
    "modified_positions": 24,
    "name": "S-adenosylmethionine synthase",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZTY7",
    "length": 441,
    "modifications": "Oxidation$Gln->pyro-Glu$Delta:H(4)C(3)O(2)$Cation:Cu[I]$Glu->pyro-Glu+Methyl:2H(2)13C(1)$AEC-MAEC$deamidated_18o(1)$Iodo$Carbamidomethyl$Thiazolidine$Cytopiloyne+water$Carbamyl$EHD-diphenylpentanone$Cation:Zn[II]",
    "modified_positions": 22,
    "name": "Adenosylhomocysteinase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZTY9",
    "length": 562,
    "modifications": "Oxidation$RNPXL$Decanoyl$Iodoacetanilide$PhosphoCytidine$hexnac(4)$Carbamidomethyl$Thiazolidine",
    "modified_positions": 8,
    "name": "Serine metalloprotease",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTZ0",
    "length": 93,
    "modifications": "hex(2)pent(2)$Oxidation$Crotonyl$dhex(1)hex(4)hexnac(3)",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTZ2",
    "length": 191,
    "modifications": "Difuran$Oxidation$Unknown:234",
    "modified_positions": 3,
    "name": "Hypothetical, YGGT family protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTZ4",
    "length": 231,
    "modifications": "MeMePhosphorothioate$O-Dimethylphosphate$Ethylphosphate$3-deoxyglucosone$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Pyridoxal phosphate homeostasis protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTZ5",
    "length": 344,
    "modifications": "Homocysteic_acid$ethylamino$Delta:H(6)C(7)O(4)$phosphoRibosyl$Phosphoadenosine$Deamidated$Carbamidomethyl$hex$GluGluGlu$HydroxymethylOP$Biotin-PEG-PRA$AFB1_Dialdehyde$Oxidation$NHS-LC-Biotin$Ser->LacticAcid$Thiophos-S-S-biotin$O-pinacolylmethylphosphonate$Cresylphosphate$HexN",
    "modified_positions": 22,
    "name": "Twitching motility protein PilT",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZTZ6",
    "length": 235,
    "modifications": "Oxidation$Gly$propionyl_13c(3)$Tris$Delta:H(4)C(3)$Deamidated$Methamidophos-O$Cation:Fe[II]$Carbamidomethyl$Unknown:306$sulfanilicacid$Propionyl$galactosyl",
    "modified_positions": 19,
    "name": "Ribonuclease PH",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZTZ7",
    "length": 288,
    "modifications": "Diphthamide$Oxidation$Sulfo-NHS-LC-LC-Biotin$Methyl+Deamidated$Propargylamine$Acetyldeoxyhypusine$OxArgBiotinRed$Glu$AHA-SS$Carbonyl$Carbamidomethyl$Ammonia-loss",
    "modified_positions": 15,
    "name": "Stress-induced protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZU00",
    "length": 128,
    "modifications": "Oxidation$Methyl$hex(1)pent(3)me(1)$Deamidated$Carbamidomethyl$Thiazolidine",
    "modified_positions": 11,
    "name": "Endoribonuclease L-PSP",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZU04",
    "length": 337,
    "modifications": "Oxidation$dhex$hex(1)hexnac(2)dhex(1)$Cresylphosphate$RNPXL$Carbamidomethyl$Dioxidation",
    "modified_positions": 6,
    "name": "S-adenosylmethionine:tRNA ribosyltransferase-isomerase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZU07",
    "length": 618,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Oxidation$Gln->pyro-Glu$Hydroxamic_acid$hep$Cation:Ag$dhex(3)hex(1)hexnac(3)kdn(1)$O-Isopropylmethylphosphonate$Deamidated$Methylthio$Ammonia-loss$Sulfide",
    "modified_positions": 17,
    "name": "Protein translocase subunit SecD",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZU09",
    "length": 113,
    "modifications": "Carbamidomethyl",
    "modified_positions": 3,
    "name": "Putative pterin-4-alpha-carbinolamine dehydratase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZU10",
    "length": 369,
    "modifications": "Oxidation$dhex(2)hex(2)hexa(1)$Biotin-tyramide$Nitro$Carboxy->Thiocarboxy$Gly-loss+Amide$hexnac(1)neuac(1)$dhex(1)hex(2)hexa(1)hexnac(1)$clip_traq_4$Cation:Fe[III]$Carbamidomethyl$clip_traq_2",
    "modified_positions": 14,
    "name": "Histidinol-phosphate aminotransferase 2",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZU12",
    "length": 268,
    "modifications": "Carbamidomethyl$Oxidation",
    "modified_positions": 2,
    "name": "Tfp pilus assembly protein PilW",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZU14",
    "length": 397,
    "modifications": "Lys->CamCys$hexnac$GG$Diethylphosphothione$deamidated_18o(1)$Methylphosphonate$Carbamidomethyl$Thiazolidine$Furan$Unknown:162$CresylSaligeninPhosphate",
    "modified_positions": 10,
    "name": "Membrane-bound lytic murein transglycosylase A",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZU29",
    "length": 455,
    "modifications": "Oxidation$Methyl$Acetyl$RNPXL$Dimethyl$clip_traq_4$Delta:H(4)C(2)$hexnac(1)neugc(1)$Ethyl",
    "modified_positions": 12,
    "name": "DUF5624 domain-containing protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZU34",
    "length": 297,
    "modifications": "TAMRA-FP$Oxidation$diart6plex117$diart6plex115$diart6plex118$Hydroxymethyl$Deamidated$diart6plex116/119$diart6plex$Carbamidomethyl$Ammonia-loss$ub-amide",
    "modified_positions": 10,
    "name": "Major outer membrane protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZU35",
    "length": 80,
    "modifications": "Oxidation$Met->AspSA$Carboxymethyl$Met-loss+Acetyl$Carbamidomethyl",
    "modified_positions": 4,
    "name": "XRE family transcriptional regulator",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZU37",
    "length": 139,
    "modifications": "Carbamidomethyl$Deamidated$Carboxymethyl",
    "modified_positions": 6,
    "name": "Organic hydroperoxide resistance protein OsmC, predicted redox protein, regulator of sulfide bond formation",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZU38",
    "length": 207,
    "modifications": "Oxidation$LG-Hlactam-R",
    "modified_positions": 2,
    "name": "Glutathione S-transferase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZU44",
    "length": 436,
    "modifications": "Oxidation$Iminobiotin$BADGE$hex(4)hexnac(2)$maleimide",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZU52",
    "length": 367,
    "modifications": "Oxidation$hex(2)hexnac(1)$icdid_2h(6)$FP-Biotin$bemad_st_2h(6)$HydroxymethylOP$Lipoyl$deamidated_18o(1)$Carbamidomethyl$Thiazolidine",
    "modified_positions": 7,
    "name": "Dipeptide epimerase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZU56",
    "length": 269,
    "modifications": "HN3_mustard$clip_traq_4",
    "modified_positions": 2,
    "name": "3',5'-cyclic nucleotide phosphodiesterase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZU58",
    "length": 374,
    "modifications": "CIGG$dimethyl_2h(4)$Decarboxylation$Pro->Pyrrolidinone$Methyl$icpl_2h(4)$Methylpyrroline$Thiazolidine$Nitrene$Ammonia-loss$dnic",
    "modified_positions": 11,
    "name": "Guanine nucleotide exchange protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZU63",
    "length": 327,
    "modifications": "Carbamidomethyl$Oxidation$hexnac(2)$Carboxymethyl",
    "modified_positions": 4,
    "name": "3',5'-cyclic nucleotide phosphodiesterase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZU69",
    "length": 438,
    "modifications": "Oxidation$Diethylphosphate$Iminobiotin$HCysThiolactone$BDMAPP$gist-quat_2h(3)",
    "modified_positions": 7,
    "name": "Polyketide synthase, type I",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZU75",
    "length": 204,
    "modifications": "Biotin:Thermo-21325$hex(2)hexnac(3)neuac(1)sulf(1)$clip_traq_3",
    "modified_positions": 3,
    "name": "Leucine-rich repeat-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZU77",
    "length": 247,
    "modifications": "AHA-SS_CAM$Oxidation$neugc$Biotin-tyramide$AHA-SS$Cytopiloyne$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZU78",
    "length": 383,
    "modifications": "Dimethylphosphothione$Cation:Na$AEC-MAEC$clip_traq_4",
    "modified_positions": 6,
    "name": "Serine kinase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZU80",
    "length": 89,
    "modifications": "HCysThiolactone$TNBS$Iodoacetanilide$Ser->LacticAcid$HexN",
    "modified_positions": 5,
    "name": "Probable Fe(2+)-trafficking protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZU82",
    "length": 881,
    "modifications": "Cation:Al[III]$Oxidation$Delta:H(2)C(5)$acetyl_2h(3)$Biotin-PEO-Amine$Diethylphosphate$Malonyl$Dimethylphosphothione$CHDH$Trioxidation$Guanidinyl$Can-FP-biotin$Cation:Fe[II]$Methylthio$Carbamidomethyl$clip_traq_2",
    "modified_positions": 22,
    "name": "Coiled-coil protein",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZU87",
    "length": 59,
    "modifications": "Oxidation$Gly$Ethylphosphate$Deamidated$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Methyltransferase activator Trm112 homolog",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZU88",
    "length": 250,
    "modifications": "Myristoyl$Methyl$acetyl_2h(3)$Methylamine$icpl_13c(6)$Ethanolamine$Carbamidomethyl$Unknown:210",
    "modified_positions": 15,
    "name": "3-deoxy-manno-octulosonate cytidylyltransferase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZU97",
    "length": 420,
    "modifications": "acetyl_13c(2)$Deamidated$hex(1)hexnac(1)neuac(1)ac(1)",
    "modified_positions": 6,
    "name": "D-alanyl-D-alanine carboxypeptidase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZUA1",
    "length": 177,
    "modifications": "acetyl_2h(3)$DeStreak$hex(1)pent(1)$Delta:H(5)C(2)$Puromycin$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Transporting ATPase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZUA5",
    "length": 108,
    "modifications": "Tyr->Dha$Carbamidomethyl$Oxidation",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZUB1",
    "length": 159,
    "modifications": "Oxidation$propionyl_13c(3)$methyl+acetyl_2h(3)$dileu4plex118$AEC-MAEC$UgiJoullieProGlyProGly$Carbamidomethyl",
    "modified_positions": 11,
    "name": "YchJ-like middle NTF2-like domain-containing protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZUC1",
    "length": 91,
    "modifications": "Oxidation$Cys->Dha$LRGG+methyl$Octanoyl$Delta:H(4)C(3)$Haloxon$neiaa$Carbamidomethyl$Carbamyl$Propionyl",
    "modified_positions": 10,
    "name": "Acylphosphatase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUC5",
    "length": 146,
    "modifications": "Gly$Delta:H(2)C(5)$Glu->pyro-Glu$Delta:H(4)C(5)O(1)$Deamidated$Carboxymethyl$Carbamidomethyl$Dehydrated",
    "modified_positions": 13,
    "name": "Lactoylglutathione lyase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZUC8",
    "length": 177,
    "modifications": "Oxidation$bemad_st_2h(6)",
    "modified_positions": 2,
    "name": "SPOR domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUD5",
    "length": 224,
    "modifications": "Oxidation$Gln->pyro-Glu$Delta:H(4)C(3)O(2)$Gly$Gly-loss+Amide$Dicarbamidomethyl$Trioxidation$Deamidated$Carbamidomethyl$Fluoro",
    "modified_positions": 13,
    "name": "Ribonuclease 3",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUD9",
    "length": 214,
    "modifications": "Oxidation$Carboxyethylpyrrole$Diethylphosphothione$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 14,
    "name": "ATP-dependent Clp protease proteolytic subunit",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUE0",
    "length": 424,
    "modifications": "Gly$Ammonium$lapachenole$LG-Hlactam-K$Deamidated$Carbamidomethyl$Didehydro$Pyro-carbamidomethyl$NDA$methyl_2h(3)$2-succinyl$Biotin:Thermo-21328$Oxidation$NQIGG$hex(3)$Tween80$Gln->pyro-Glu$Diethyl$Iodoacetanilide:13C(6)$dhex(1)hex(2)$Carboxymethyl",
    "modified_positions": 27,
    "name": "ATP-dependent Clp protease ATP-binding subunit ClpX",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZUE1",
    "length": 816,
    "modifications": "Gly$azole$Ammonium$Thiazolidine$NHS-fluorescein$Deamidated$Deoxy$Carbamidomethyl$Delta:H(6)C(3)O(1)$NDA$Biotin-PEO-Amine$AEBS$methyl_2h(3)$Ethanolamine$Ammonia-loss$Oxidation$propionyl_13c(3)$PEITC$Amino$clip_traq_2$Lys->Allysine$GPIanchor$Gln->pyro-Glu$ZGB$Methyl$TNBS$phosphohex(2)$TMPP-Ac:13C(9)$Carboxymethyl$OxArgBiotin$Dioxidation",
    "modified_positions": 52,
    "name": "Lon protease",
    "unique_modifications": 31
  },
  {
    "id": "Q5ZUE3",
    "length": 624,
    "modifications": "Nmethylmaleimide$AHA-SS_CAM$Gln->pyro-Glu$Oxidation$Delta:H(2)C(3)O(1)$spermidine$Propargylamine$Cresylphosphate$Deamidated$Glu$Quinone$Pro->Pyrrolidone",
    "modified_positions": 17,
    "name": "Periplasmic chaperone PpiD",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZUE7",
    "length": 220,
    "modifications": "Unknown:216$Met->Hse$Decarboxylation$Gln->pyro-Glu$Gluratylation$acetyl_2h(3)$GG$hexnac(1)neuac(1)$Glu->pyro-Glu$Biotin-phenacyl$Dicarbamidomethyl$Dehydrated",
    "modified_positions": 16,
    "name": "Dot/Icm T4SS effector",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZUE8",
    "length": 116,
    "modifications": "hex(3)hexnac(1)$Sulfo-NHS-LC-LC-Biotin$Methyl$Oxidation$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Rhodanese domain protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUF1",
    "length": 431,
    "modifications": "Methyl$Hydroxamic_acid$HNE$dhex(2)hex(2)$hex(1)hexnac(1)neugc(1)$Cation:Li$CresylSaligeninPhosphate",
    "modified_positions": 7,
    "name": "Glutamate-cysteine ligase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZUF4",
    "length": 145,
    "modifications": "Glu->pyro-Glu$Oxidation$Carbamyl",
    "modified_positions": 4,
    "name": "D-aminoacyl-tRNA deacylase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZUF9",
    "length": 688,
    "modifications": "Cation:Al[III]$hex(1)hexnac(1)neuac(1)$Gly$NDA$Oxidation$Amidine$Delta:H(10)C(8)O(1)$Phosphoadenosine$Deamidated$Ser->LacticAcid$maleimide$Carbamidomethyl$Phosphoguanosine$EHD-diphenylpentanone$Haloxon$Ethanedithiol",
    "modified_positions": 20,
    "name": "Glycine--tRNA ligase beta subunit",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZUG0",
    "length": 176,
    "modifications": "Amidated$Carbamidomethyl$Ethyl+Deamidated$SPITC",
    "modified_positions": 4,
    "name": "D,D-heptose 1,7-bisphosphate phosphatase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUG1",
    "length": 243,
    "modifications": "Unknown:216$Oxidation$Label:2H(4)+GG$methyl_2h(3)$Hydroxymethyl$CHDH$Lys->MetOx",
    "modified_positions": 7,
    "name": "Ribosomal RNA small subunit methyltransferase J",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZUG6",
    "length": 138,
    "modifications": "Oxidation$Methyl$neiaa_2h(5)$Thrbiotinhydrazide$Delta:H(4)C(3)$Carbamidomethyl",
    "modified_positions": 7,
    "name": "VirK protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZUG8",
    "length": 302,
    "modifications": "Delta:H(2)C(2)$pent(2)$Oxidation$Ammonia-loss$Carbamidomethyl$serotonylation",
    "modified_positions": 9,
    "name": "hydroxymethylglutaryl-CoA lyase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZUH1",
    "length": 535,
    "modifications": "Oxidation$Phenylisocyanate$dhex(1)hex(3)hexnac(1)sulf(1)$hex(1)pent(3)me(1)$Deamidated$Pyridylacetyl$Deoxy$Succinyl$Carbamidomethyl$Biotin:Thermo-88310",
    "modified_positions": 15,
    "name": "Propionyl CoA carboxylase beta subunit",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUH3",
    "length": 394,
    "modifications": "Dethiomethyl$Met->Hse$Oxidation$Decarboxylation$Pro->Pyrrolidinone$acetyl_2h(3)$ethylamino$Menadione$bemad_st_2h(6)$Deamidated$Met->Hsl$Methamidophos-O$Deoxy$Ethanolamine$Carbamidomethyl$Carbamyl",
    "modified_positions": 22,
    "name": "Acyl CoA C-acetyltransferase",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZUH7",
    "length": 333,
    "modifications": "Decarboxylation$Oxidation$Diethylphosphate$O-Isopropylmethylphosphonate$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Dihydroorotate dehydrogenase (quinone)",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUH9",
    "length": 588,
    "modifications": "Oxidation$NDA$Saligenin$Malonyl$Trioxidation$Deamidated$Thiazolidine$Nitrene$Dioxidation",
    "modified_positions": 11,
    "name": "ATP-dependent lipid A-core flippase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZUI0",
    "length": 323,
    "modifications": "hex$GlycerylPE$Oxidation$Thiadiazole$Iodoacetanilide$CAMthiopropanoyl$Methylthio$Ethanolamine$Carbamidomethyl",
    "modified_positions": 11,
    "name": "Tetraacyldisaccharide 4'-kinase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZUI3",
    "length": 296,
    "modifications": "Oxidation$Nitro$NHS-fluorescein$Succinyl$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Hydrogen peroxide-inducible genes activator OxyR",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUI5",
    "length": 357,
    "modifications": "hex$Oxidation$Gly$3sulfo$hex(2)hexnac(2)neugc(1)$Carboxyethylpyrrole$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 10,
    "name": "Iron-sulfur cluster carrier protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZUJ0",
    "length": 331,
    "modifications": "GlycerylPE$Oxidation$ethylamino$Delta:H(4)C(3)O(2)$AEBS$Deoxy$Arg->Orn$Carbamidomethyl",
    "modified_positions": 17,
    "name": "Delta-aminolevulinic acid dehydratase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZUJ2",
    "length": 562,
    "modifications": "hex$Oxidation$Methyl$Carboxyethyl$methyl_2h(3)13c(1)$glucuronyl$Thiazolidine$bemad_st_2h(6)$dimethyl_2h(4)13c(2)$Ser->LacticAcid$dimethyl_2h(6)",
    "modified_positions": 13,
    "name": "Translocation and assembly module subunit TamA",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZUJ4",
    "length": 164,
    "modifications": "hex(1)hexnac(1)phos(1)$hex(1)hexnac(1)sulf(1)$Iodoacetanilide$Carbamidomethyl$Propionyl",
    "modified_positions": 6,
    "name": "Hypothetical 17.2kDa protein, CinA-related competence damage protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUJ7",
    "length": 348,
    "modifications": "Delta:H(2)C(2)$Oxidation$Methyl$Acetyl$methyl_2h(3)$Propyl$Cation:Li$Deamidated$Glycerophospho$Lipoyl$AEC-MAEC$acetyl_13c(2)$Carbamidomethyl$Biotin",
    "modified_positions": 28,
    "name": "Protein RecA",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZUK1",
    "length": 426,
    "modifications": "Menadione-HQ$Oxidation$Delta:H(2)C(5)$DimethylpyrroleAdduct$HN3_mustard$Iminobiotin$Propyl$Biotin:Thermo-21328$Carbamidomethyl$GluGlu",
    "modified_positions": 11,
    "name": "Coiled-coil protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUK7",
    "length": 109,
    "modifications": "Carbamidomethyl$SulfanilicAcid:13C(6)$dhex(1)hex(3)$Gly",
    "modified_positions": 2,
    "name": "Flagellar motor switch protein FliN",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUL7",
    "length": 161,
    "modifications": "Unknown:162",
    "modified_positions": 2,
    "name": "Transmembrane protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZUM0",
    "length": 316,
    "modifications": "Dimethylaminoethyl$Oxidation$Trp->Kynurenin$dileu4plex117$Ser->LacticAcid$Carbamidomethyl$dileu4plex115",
    "modified_positions": 8,
    "name": "Eukaryotic small stress protein PASS1",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZUM1",
    "length": 258,
    "modifications": "Carbamidomethyl$Label:13C(1)2H(3)+Oxidation$Oxidation$glyoxalAGE",
    "modified_positions": 3,
    "name": "Phosphodiester glycosidase domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUM3",
    "length": 73,
    "modifications": "Oxidation$Phenylisocyanate$Crotonaldehyde$Pyridylacetyl$MesitylOxide",
    "modified_positions": 5,
    "name": "Translation initiation factor IF-1",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUM4",
    "length": 123,
    "modifications": "Carbamidomethyl$Pyro-carbamidomethyl$methyl_2h(3)13c(1)",
    "modified_positions": 4,
    "name": "Rhodanese domain protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZUN0",
    "length": 343,
    "modifications": "Carbamidomethyl$Deamidated$Hydroxymethyl$Carbofuran",
    "modified_positions": 5,
    "name": "histidine kinase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUP0",
    "length": 455,
    "modifications": "Oxidation$Phosphopropargyl$BITC$Deamidated$2HPG$Succinyl$dhex(2)hexnac(2)kdn(1)$Carbamidomethyl$Didehydro$Dehydrated",
    "modified_positions": 10,
    "name": "UDP-N-acetylmuramate--L-alanyl-gamma-D-glutamyl-meso-2,6-diaminoheptandioate ligase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUP2",
    "length": 436,
    "modifications": "Dicarbamidomethyl$Cation:Na$Carbamidomethyl$Biotin$hex(1)hexa(1)$Cys->Dha$AccQTag$Dimethylphosphothione$Propiophenone$Oxidation$dhex(1)hex(5)$Malonyl$Amino$NQIGG$Cation:Mg[II]$Menadione$hex(3)$Gln->pyro-Glu$GG$Tris$Pro->Pyrrolidone$Dioxidation",
    "modified_positions": 23,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZUP5",
    "length": 261,
    "modifications": "icpl_13c(6)2h(4)$AEBS$hex(2)hexnac(1)sulf(1)$Methylthio",
    "modified_positions": 5,
    "name": "Inositol-1-monophosphatase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUP6",
    "length": 257,
    "modifications": "Oxidation$acetyl_2h(3)$BITC$igbp$Ammonia-loss",
    "modified_positions": 9,
    "name": "tRNA (cytidine/uridine-2'-O-)-methyltransferase TrmJ",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUP8",
    "length": 127,
    "modifications": "maleimide$Arg->Orn",
    "modified_positions": 3,
    "name": "NifU family iron binding protein, [Fe-S] cluster formation/repair protein IscU, HesB",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUQ0",
    "length": 95,
    "modifications": "Oxidation$hep$Acetyl$Deamidated$AEC-MAEC$Carbonyl$Carbamyl$Propionyl",
    "modified_positions": 9,
    "name": "Putative Fis-like DNA-binding protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZUQ2",
    "length": 262,
    "modifications": "Thiazolidine$s-glcnac",
    "modified_positions": 4,
    "name": "FecR protein domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUQ6",
    "length": 477,
    "modifications": "Oxidation$Methyl+Deamidated$LRGG+dimethyl$Dimethyl$Cation:Fe[III]$Cation:Na$Delta:H(4)C(2)$Carbamidomethyl$Ethyl$Propionyl",
    "modified_positions": 10,
    "name": "Aspartyl/glutamyl-tRNA(Asn/Gln) amidotransferase subunit B",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUQ7",
    "length": 483,
    "modifications": "Didehydroretinylidene$Oxidation$Gly$icdid$Propargylamine$HNE-Delta:H(2)O$Carbamidomethyl$Delta:H(10)C(8)O(1)",
    "modified_positions": 8,
    "name": "Glutamyl-tRNA(Gln) amidotransferase subunit A",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZUR2",
    "length": 292,
    "modifications": "Nitro$Diethyl",
    "modified_positions": 3,
    "name": "sn-glycerol-3-phosphate transport system permease protein UgpA",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUR4",
    "length": 363,
    "modifications": "Oxidation$Delta:H(6)C(6)O(1)$clip_traq_4$15N-oxobutanoic$hex(1)neugc(1)$pent(1)hexnac(1)$Carbamidomethyl$Sulfo$Phospho",
    "modified_positions": 12,
    "name": "sn-glycerol-3-phosphate transport, ATP binding protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZUR5",
    "length": 305,
    "modifications": "AEBS$Formyl",
    "modified_positions": 3,
    "name": "DUF1189 domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUR6",
    "length": 261,
    "modifications": "Oxidation$Dap-DSP$HPG$Biotin$Delta:H(4)C(3)$Formyl$Thiazolidine$Propionyl$glycidamide",
    "modified_positions": 10,
    "name": "Hydrolase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZUR8",
    "length": 276,
    "modifications": "Oxidation$Dap-DSP$Phosphoadenosine$Arg->Npo$Ammonia-loss$Cation:Li$Deamidated$Carbamidomethyl$Sulfo$Phospho",
    "modified_positions": 13,
    "name": "Septum site-determining protein MinD",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUR9",
    "length": 490,
    "modifications": "Oxidation$Pyridylethyl$Gly$Propionamide$Aspartylurea$Carboxy->Thiocarboxy$Cation:Ag$Ethanolyl$gist-quat_2h(6)$Carbamidomethyl$Cation:Mg[II]$hex(1)hexnac(1)dhex(1)me(2)$Delta:H(6)C(3)O(1)$Fluoro",
    "modified_positions": 23,
    "name": "Inosine-5'-monophosphate dehydrogenase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZUS2",
    "length": 861,
    "modifications": "hexnac(2)sulf(1)$G-H1$Oxidation$O-Et-N-diMePhospho$Methyl$acetyl_2h(3)$spermidine$O-Methylphosphate$Deoxy$Methamidophos-O$Glu->pyro-Glu+Methyl:2H(2)13C(1)$hexnac(1)neugc(1)$Carbamidomethyl$2-nitrobenzyl",
    "modified_positions": 23,
    "name": "Bifunctional uridylyltransferase/uridylyl-removing enzyme",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZUS3",
    "length": 254,
    "modifications": "Oxidation$Cresylphosphate$bemad_st_2h(6)$icpl_13c(6)$Formyl$Carbamidomethyl$Thiazolidine$tmab_2h(9)",
    "modified_positions": 13,
    "name": "Methionine aminopeptidase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZUS8",
    "length": 254,
    "modifications": "Gly$Delta:H(6)C(7)O(4)$phosphoRibosyl$Glu->pyro-Glu$Deamidated$Methamidophos-O$3-deoxyglucosone$Carbamidomethyl$Fluoro$Pyro-carbamidomethyl$ISD_z+2_ion$Phosphogluconoylation$MesitylOxide$Carbamyl$Oxidation$Acetyl$Formylasparagine$Carbofuran$UgiJoullieProGly$OxProBiotin$hex(2)hexnac(1)$Chlorination$Thiazolidine",
    "modified_positions": 33,
    "name": "Small ribosomal subunit protein uS2",
    "unique_modifications": 23
  },
  {
    "id": "Q5ZUS9",
    "length": 292,
    "modifications": "Met->Hse$Oxidation$Gluratylation$Nitrosyl$Diisopropylphosphate$pupylation$AHA-SS_CAM$Gly$Glu->pyro-Glu$Cation:Ag$Dehydrated$Deamidated$3-deoxyglucosone$AHA-SS$Carbamidomethyl$Unknown:306$GluGlu",
    "modified_positions": 24,
    "name": "Elongation factor Ts",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZUT0",
    "length": 247,
    "modifications": "CarboxymethylDMAP$Oxidation$icpl_2h(4)$Cresylphosphate$Thiophospho$Trimethyl$Propyl$Carbamidomethyl$Carbamyl$O-pinacolylmethylphosphonate",
    "modified_positions": 17,
    "name": "Uridylate kinase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUT1",
    "length": 185,
    "modifications": "His+O(2)$hex$cGMP$Oxidation$Propionamide$gist-quat$imid_2h(4)$Dihydroxyimidazolidine$Methylamine$Diethylphosphothione$icpl_13c(6)$Dioxidation",
    "modified_positions": 15,
    "name": "Ribosome-recycling factor",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZUT4",
    "length": 448,
    "modifications": "Acetyl$Delta:H(5)C(2)$Dimethyl$Carbamidomethyl$GEE",
    "modified_positions": 4,
    "name": "N-succinylarginine dihydrolase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUT7",
    "length": 407,
    "modifications": "propionyl_13c(3)$Deamidated$Carboxymethyl$Carbonyl$Carbamidomethyl$Sulfide",
    "modified_positions": 10,
    "name": "Carboxypeptidase G2",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZUU1",
    "length": 560,
    "modifications": "Oxidation$propionyl_13c(3)$Methyl$hexnac$gist-quat$Iodoacetanilide:13C(6)$PS_Hapten$clip_traq_4$glyoxalAGE$AEC-MAEC$PyruvicAcidIminyl$Biotin$Deoxyhypusine$Haloxon",
    "modified_positions": 19,
    "name": "Kinectin 1 (Kinesin receptor)",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZUU2",
    "length": 239,
    "modifications": "Oxidation$Gly$glucosylgalactosyl$Tris$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Uracil-DNA glycosylase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUU3",
    "length": 230,
    "modifications": "Oxidation$PS_Hapten$exactagamine$Cation:Na$ethylsulfonylethyl$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Carbamidomethyl$Cation:Mg[II]$Unknown:210",
    "modified_positions": 12,
    "name": "Ubiquinone biosynthesis O-methyltransferase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZUV5",
    "length": 400,
    "modifications": "Oxidation$Glu->pyro-Glu+Methyl$Diethylphosphate$RNPXL$Dehydrated",
    "modified_positions": 6,
    "name": "Ras-GEF domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUW0",
    "length": 283,
    "modifications": "methyl_2h(3)$O-Methylphosphate$Methylamine$Pro->Pyrrolidone$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Oxidoreductase, short chain dehydrogenase/reductase family",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUW9",
    "length": 439,
    "modifications": "Menadione-HQ$Oxidation$Gly$Propionamide$Acetyl$Isopropylphospho$Carbamidomethyl$Methamidophos-S$Met->Hpg$Propionyl",
    "modified_positions": 9,
    "name": "Phosphoribosylamine--glycine ligase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUX0",
    "length": 192,
    "modifications": "Carbamidomethyl$Oxidation$Dimethyl$sulfanilicacid",
    "modified_positions": 4,
    "name": "Phosphoribosylglycinamide formyltransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUX5",
    "length": 463,
    "modifications": "Oxidation$Phe->CamCys$hex(2)hexnac(1)sulf(1)$Gluratylation$LG-Hlactam-R$hexnac(1)dhex(1)$Glycerophospho$Formyl",
    "modified_positions": 10,
    "name": "IgA Peptidase M64",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZUY0",
    "length": 198,
    "modifications": "Dimethylphosphothione$Fluoro",
    "modified_positions": 3,
    "name": "Putative transport protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUY7",
    "length": 557,
    "modifications": "methylol$Oxidation",
    "modified_positions": 2,
    "name": "Neutral metalloproteinase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUZ0",
    "length": 334,
    "modifications": "Carbamidomethyl$Oxidation",
    "modified_positions": 3,
    "name": "Myo-inositol-2-dehydrogenase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUZ1",
    "length": 628,
    "modifications": "dimethyl_2h(4)$Oxidation$Phosphopropargyl$Biotin:Thermo-88317$PET$Carboxy->Thiocarboxy$Lysbiotinhydrazide$Propionyl$Cation:K$Trimethyl$OxLysBiotin$Ub-VME$Carbamidomethyl$Didehydro$CresylSaligeninPhosphate$Dioxidation",
    "modified_positions": 21,
    "name": "IolC/IolB transferase kinase protein",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZUZ4",
    "length": 85,
    "modifications": "Carbamidomethyl$BMP-piperidinol",
    "modified_positions": 3,
    "name": "Signal peptide protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUZ7",
    "length": 191,
    "modifications": "Unknown:216$Acetyl",
    "modified_positions": 4,
    "name": "Lipid/polyisoprenoid-binding YceI-like domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZV03",
    "length": 438,
    "modifications": "Palmitoyl$Oxidation$hex(1)hexnac(2)dhex(1)$hexnac$Carboxymethyl:13C(2)$Diethyl$Dimethyl$Cation:Li$Delta:H(4)C(2)$Met-loss+Acetyl$Carbamidomethyl$Ethyl$CresylSaligeninPhosphate",
    "modified_positions": 16,
    "name": "Uncharacterized protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZV05",
    "length": 296,
    "modifications": "Unknown:216$SulfanilicAcid:13C(6)$Diethyl$Carbamidomethyl$glucosone",
    "modified_positions": 5,
    "name": "Polysaccharide deacetylase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZV06",
    "length": 282,
    "modifications": "Oxidation$Methyl$methyl+acetyl_2h(3)$Hydroxamic_acid$biotinAcrolein298$Cation:Na$Amino$Carbonyl$Carbamidomethyl$Thiazolidine",
    "modified_positions": 19,
    "name": "Acetyltransferase, GNAT family",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZV13",
    "length": 278,
    "modifications": "propionamide_2h(3)$Oxidation$GluGluGluGlu",
    "modified_positions": 3,
    "name": "Zn-dependent hydrolase GumP",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZV19",
    "length": 338,
    "modifications": "NHS-fluorescein$2-nitrobenzyl",
    "modified_positions": 2,
    "name": "tRNA pseudouridine synthase D",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZV21",
    "length": 439,
    "modifications": "Oxidation$dhex$hydroxyisobutyryl$Ammonia-loss$Carbamyl",
    "modified_positions": 8,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZV30",
    "length": 250,
    "modifications": "methyl_2h(2)$hex$UgiJoullieProGly",
    "modified_positions": 5,
    "name": "Transcriptional regulator SkgA, mercury resistance",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZV33",
    "length": 417,
    "modifications": "NDA$hex(2)$Diisopropylphosphate$Delta:H(2)C(5)$Thrbiotinhydrazide$Deoxy$Pyridylacetyl$Lys->AminoadipicAcid$Carbamidomethyl$trimethyl_13c(3)2h(9)",
    "modified_positions": 11,
    "name": "Gamma-glutamyl phosphate reductase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZV38",
    "length": 225,
    "modifications": "Oxidation$Trp->Oxolactone$Methyl$Pro->pyro-Glu$Carbonyl$acetyl_13c(2)$Carbamidomethyl",
    "modified_positions": 9,
    "name": "RES domain-containing protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZV43",
    "length": 439,
    "modifications": "Gly$ethylamino$Hydroxamic_acid$Glu->pyro-Glu$Delta:H(4)C(3)$Deamidated$Deoxy$Carbamidomethyl$Delta:H(6)C(3)O(1)$Pyro-carbamidomethyl$phosphohexnac$Delta:S(-1)Se(1)$Carboxy->Thiocarboxy$methyl_2h(3)$Methylpyrroline$Ammonia-loss$Carbamyl$propionamide_2h(3)$Oxidation$4-ONE$Carbofuran$15N-oxobutanoic$Trioxidation$Menadione$Dehydrated$Gln->pyro-Glu$Cyano$Iodoacetanilide:13C(6)$Cresylphosphate$Carboxymethyl$Dioxidation",
    "modified_positions": 59,
    "name": "Thiolase",
    "unique_modifications": 31
  },
  {
    "id": "Q5ZV47",
    "length": 65,
    "modifications": "CIGG$Methamidophos-O$Bromo",
    "modified_positions": 4,
    "name": "Carbon storage regulator CsrA",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZV48",
    "length": 112,
    "modifications": "Unknown:216$Oxidation$Gln->pyro-Glu$Propargylamine$Ammonium$Acetyl$Dimethylphosphothione$methyl_2h(3)$Propyl$NIPCAM$Deamidated$Carboxymethyl$Carbamidomethyl$Amidino$Delta:H(6)C(3)O(1)",
    "modified_positions": 17,
    "name": "Small ribosomal subunit protein bS6",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZV51",
    "length": 149,
    "modifications": "Oxidation$dhex(2)hex(1)hexnac(1)kdn(1)$dhex(2)hex(2)hexnac(1)$PhosphoCytidine$glucosone$hex(3)hexnac(1)hexa(1)",
    "modified_positions": 6,
    "name": "Large ribosomal subunit protein bL9",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZV63",
    "length": 187,
    "modifications": "15N-oxobutanoic$Formyl$Oxidation$OxLysBiotin",
    "modified_positions": 5,
    "name": "RNA polymerase sigma E factor RpoE",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZV65",
    "length": 131,
    "modifications": "BHT",
    "modified_positions": 1,
    "name": "Esterase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZV80",
    "length": 370,
    "modifications": "Delta:H(2)C(2)$Oxidation$dhex(1)hex(1)hexnac(3)$Crotonaldehyde$Deamidated$Lipoyl$Butyryl$PhosphoCytidine$Carbamidomethyl$Carbamyl",
    "modified_positions": 16,
    "name": "Dihydrolipoamide acetyltransferase component of pyruvate dehydrogenase complex",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZV81",
    "length": 324,
    "modifications": "Delta:H(2)C(2)$Oxidation$Gln->pyro-Glu$Gly$Delta:H(2)C(3)O(1)$Thrbiotinhydrazide$MG-H1$BITC$Can-FP-biotin$Carbonyl$Carbamidomethyl$Dioxidation",
    "modified_positions": 19,
    "name": "2-oxoisovalerate dehydrogenase subunit beta",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZV88",
    "length": 242,
    "modifications": "hexnac$Glycerophospho$Oxidation$Cation:Zn[II]",
    "modified_positions": 5,
    "name": "UDP-2,3-diacylglucosamine hydrolase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZV91",
    "length": 294,
    "modifications": "Delta:H(2)C(3)O(1)$Amidine$hep$dhex(1)hex(2)$thioacylPA$Carboxymethyl$Carbamidomethyl",
    "modified_positions": 11,
    "name": "Type 4 apparatus protein DotZ",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZV92",
    "length": 141,
    "modifications": "Delta:H(2)C(2)$pent(2)$Oxidation$Cation:Ca[II]$Glu->pyro-Glu$Cation:K$Dimethyl$Delta:H(4)C(2)$UgiJoullieProGly$Ethyl",
    "modified_positions": 14,
    "name": "Nucleoside diphosphate kinase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZV94",
    "length": 260,
    "modifications": "Deamidated$Pyridylacetyl$Formyl$Carbamidomethyl$maleimide",
    "modified_positions": 6,
    "name": "Fimbrial biogenesis and twitching motility protein PilF",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZV97",
    "length": 224,
    "modifications": "GluGlu$Deoxy$Oxidation$Deamidated",
    "modified_positions": 7,
    "name": "Ancillary SecYEG translocon subunit",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZV99",
    "length": 462,
    "modifications": "OxProBiotin$murnac$Cytopiloyne$Carbamyl$Propionyl",
    "modified_positions": 6,
    "name": "GTPase Der",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVA0",
    "length": 140,
    "modifications": "15N-oxobutanoic$Glu->pyro-Glu",
    "modified_positions": 2,
    "name": "Universal stress protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVA6",
    "length": 429,
    "modifications": "Oxidation$Pro->Pyrrolidinone$acetyl_2h(3)$dhex$Delta:H(5)C(2)$hexnac(2)$Dioxidation",
    "modified_positions": 11,
    "name": "Glutamate-1-semialdehyde 2,1-aminomutase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVB0",
    "length": 372,
    "modifications": "Oxidation$Gly$Diethylphosphate$Cation:K$Carbofuran$Dihydroxyimidazolidine$Glu->pyro-Glu+Methyl:2H(2)13C(1)$3-deoxyglucosone$Carbamidomethyl$Dioxidation",
    "modified_positions": 20,
    "name": "Citrate synthase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVB2",
    "length": 271,
    "modifications": "Gly$Didehydro$Delta:H(6)C(3)O(1)$Deamidated$dhex(1)hex(4)$Pro->HAVA$Carbamidomethyl$Unknown:210$MicrocinC7$Fluoro",
    "modified_positions": 13,
    "name": "Putative phosphoenolpyruvate synthase regulatory protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVB4",
    "length": 197,
    "modifications": "hexnac(3)$Decarboxylation$Gln->pyro-Glu$Methyl$Oxidation$Deamidated$Methylphosphonate$Carbamidomethyl",
    "modified_positions": 11,
    "name": "Sel1 repeat family protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVB7",
    "length": 406,
    "modifications": "Nmethylmaleimide$Lys->CamCys$Oxidation$hep$Lysbiotinhydrazide$hex(1)hexnac(1)$dhex(1)hex(1)hexnac(2)neuac(1)",
    "modified_positions": 7,
    "name": "(Type IV) pilus assembly protein PilC",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVC1",
    "length": 189,
    "modifications": "Lys->CamCys$Carbamidomethyl$Deamidated",
    "modified_positions": 3,
    "name": "Purine/pyrimidine phosphoribosyltransferase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVE8",
    "length": 340,
    "modifications": "dhex(3)hex(3)hexnac(1)$Oxidation$Propiophenone$CHDH",
    "modified_positions": 4,
    "name": "Spectinomycin phosphotransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVF5",
    "length": 133,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Integral membrane protein (PIN domain superfamily)",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVF6",
    "length": 269,
    "modifications": "Oxidation$Cation:Ca[II]$Methyl$hexnac$pent(1)hexnac(1)$OxLysBiotin$Carbamidomethyl$Dioxidation",
    "modified_positions": 17,
    "name": "LepB protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVF7",
    "length": 529,
    "modifications": "Amidated$Oxidation$dhex(1)hex(2)$Deoxy$Carbamidomethyl$glucosone$glycidamide",
    "modified_positions": 7,
    "name": "Serine/threonine-protein kinase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVF9",
    "length": 346,
    "modifications": "Cation:Al[III]$Oxidation$dhex$Diethyl$Saligenin$Propiophenone$Tyr->Dha$Ethanolamine$Carbamidomethyl$sulfanilicacid",
    "modified_positions": 10,
    "name": "Uncharacterized protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVG1",
    "length": 982,
    "modifications": "Oxidation$O-Et-N-diMePhospho$Phosphopropargyl$Malonyl$Carbamyl$MicrocinC7",
    "modified_positions": 7,
    "name": "Potassium efflux system KefA",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVG3",
    "length": 209,
    "modifications": "glucosone$sulfo+amino$Formyl",
    "modified_positions": 3,
    "name": "Transmembrane protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVG4",
    "length": 104,
    "modifications": "Gly$GG$hep$Acetyldeoxyhypusine$Dicarbamidomethyl$Deamidated$Carbamidomethyl$Unknown:306",
    "modified_positions": 11,
    "name": "Putative regulatory protein FmdB zinc ribbon domain-containing protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVG6",
    "length": 239,
    "modifications": "Unknown:216$Cation:Al[III]$Delta:H(2)C(3)O(1)$Delta:H(4)C(3)$Methylthio$EDT-iodoacetyl-PEO-biotin",
    "modified_positions": 6,
    "name": "Pimeloyl-[acyl-carrier protein] methyl ester esterase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVG7",
    "length": 381,
    "modifications": "Unknown:216$hex$Propargylamine$hex(1)neuac(1)$MM-diphenylpentanone$UgiJoullieProGlyProGly$Carbamidomethyl$O-pinacolylmethylphosphonate",
    "modified_positions": 7,
    "name": "8-amino-7-oxononanoate synthase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVH3",
    "length": 201,
    "modifications": "O-Dimethylphosphate$Ethylphosphate$Methylamine$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 3,
    "name": "Dephospho-CoA kinase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVH9",
    "length": 579,
    "modifications": "Oxidation$Delta:H(4)C(3)O(2)$Delta:H(6)C(7)O(4)$Biotin-tyramide$azole$PS_Hapten$BEMAD_ST$Thiazolidine$neuac$O-Isopropylmethylphosphonate$QQQTGG$ethylsulfonylethyl$Biotin:Thermo-21328$Cytopiloyne$Carbamidomethyl$Argbiotinhydrazide$Delta:H(4)C(3)O(1)",
    "modified_positions": 20,
    "name": "Single-stranded-DNA-specific exonuclease RecJ",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZVI1",
    "length": 397,
    "modifications": "MercaptoEthanol$Oxidation$Dap-DSP$Ammonium$Carboxy->Thiocarboxy$methyl_2h(3)$Delta:H(4)C(3)$Deamidated$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 22,
    "name": "Aminotransferase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVI3",
    "length": 734,
    "modifications": "Delta:H(2)C(2)$hex$Oxidation$Methyl$Carboxyethyl$Met->Aha$hep$AEBS$hex(2)hexnac(1)me(1)$Trioxidation$Cation:Li$Pyridylacetyl$Biotin:Thermo-21345$CAMthiopropanoyl$Carbamidomethyl$Thiazolidine$succinyl_2h(4)$Delta:H(4)C(6)",
    "modified_positions": 21,
    "name": "GTP pyrophosphokinase",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZVI7",
    "length": 172,
    "modifications": "Ethanolamine$Delta:H(8)C(6)O(2)$Propargylamine$PyridoxalPhosphateH2",
    "modified_positions": 6,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVJ3",
    "length": 248,
    "modifications": "Dap-DSP$Oxidation$Biotin:Thermo-21330$neuac$AEC-MAEC$Dioxidation",
    "modified_positions": 8,
    "name": "Pseudouridine synthase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVK0",
    "length": 158,
    "modifications": "DNCB_hapten$Malonyl",
    "modified_positions": 1,
    "name": "Endoribonuclease YbeY",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVK1",
    "length": 296,
    "modifications": "OxLysBiotinRed$Oxidation$hex(1)hexnac(1)neuac(1)$Iodoacetanilide:13C(6)$LG-pyrrole$Acetyldeoxyhypusine$Acetyl$dhex(2)hex(2)$4-ONE+Delta:H(-2)O(-1)$PyridoxalPhosphateH2$Cation:Fe[III]$Guanidinyl$Deamidated$dimethyl_2h(4)13c(2)$Carboxymethyl$Iodoacetanilide$Carbamidomethyl$dimethyl_2h(6)",
    "modified_positions": 19,
    "name": "Magnesium and cobalt efflux protein CorC",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZVK2",
    "length": 226,
    "modifications": "Carbamidomethyl$Deamidated$Carboxy$maleimide",
    "modified_positions": 5,
    "name": "Transcriptional regulatory protein CpxR",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVK5",
    "length": 131,
    "modifications": "Oxidation$HN2_mustard$HNE$bemad_st_2h(6)$Deoxy$methyl_2h(3)+acetyl_2h(3)$Carbamidomethyl",
    "modified_positions": 12,
    "name": "Cytidine deaminase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVK9",
    "length": 132,
    "modifications": "Oxidation$Carboxy->Thiocarboxy$Ethanolyl$Deoxy$maleimide",
    "modified_positions": 6,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVL3",
    "length": 259,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Short chain dehydrogenase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVL5",
    "length": 229,
    "modifications": "Oxidation$NDA$ethylamino$Diethylphosphate$Delta:H(2)C(3)$Carbamidomethyl$Delta:H(10)C(8)O(1)",
    "modified_positions": 5,
    "name": "Orotidine 5'-phosphate decarboxylase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVL6",
    "length": 371,
    "modifications": "Dethiomethyl$Oxidation$Tyr->Dha$hex(1)hexnac(1)neugc(1)$Delta:H(2)C(3)$Met->Hsl$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 8,
    "name": "Aminotransferase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVM1",
    "length": 433,
    "modifications": "SulfanilicAcid:13C(6)$Oxidation$Delta:H(2)C(5)$hex(2)$HNE-Delta:H(2)O$Glu$Carbamidomethyl$dhex(1)hex(1)",
    "modified_positions": 10,
    "name": "3-phosphoshikimate 1-carboxyvinyltransferase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVM4",
    "length": 293,
    "modifications": "Phe->CamCys$FMNH$Isopropylphospho$Carboxymethyl$Unknown:210",
    "modified_positions": 5,
    "name": "Purine nucleoside phosphorylase II",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVM5",
    "length": 423,
    "modifications": "Nmethylmaleimide$Oxidation$Gly$Biotin-tyramide$Trimethyl$4-ONE$Deoxy$Deamidated$UgiJoullieProGly$Carbamidomethyl$NA-LNO2",
    "modified_positions": 28,
    "name": "Citrate synthase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZVN7",
    "length": 366,
    "modifications": "Carbamidomethyl$Acetylhypusine",
    "modified_positions": 2,
    "name": "Anhydro-N-acetylmuramic acid kinase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVP1",
    "length": 212,
    "modifications": "Oxidation$O-Et-N-diMePhospho$Pro->pyro-Glu$Carbonyl$Methylphosphonate$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Thymidylate kinase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVP3",
    "length": 412,
    "modifications": "Oxidation$Gln->pyro-Glu$Methyl$Deamidated$Deoxy$Carbamidomethyl$Ammonia-loss",
    "modified_positions": 13,
    "name": "3-oxoacyl-[acyl-carrier-protein] synthase 2",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVP6",
    "length": 315,
    "modifications": "GlycerylPE$Oxidation$Gly$Crotonyl$hex(4)hexnac(1)$hex(1)hexnac(1)dhex(1)$Malonyl$BDMAPP$dhex(1)hex(3)hexnac(3)neuac(2)$Deamidated$Deoxy$Carbamidomethyl$Dioxidation",
    "modified_positions": 29,
    "name": "Malonyl CoA-acyl carrier protein transacylase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZVP8",
    "length": 342,
    "modifications": "Delta:H(6)C(7)O(4)$Glycerophospho$Deamidated$Delta:H(4)C(2)$UgiJoullieProGly$OxLysBiotin$Carbamidomethyl$Ethyl$maleimide",
    "modified_positions": 8,
    "name": "Phosphate acyltransferase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZVQ2",
    "length": 130,
    "modifications": "Hydroxamic_acid$Deamidated$Methyl$Carbonyl",
    "modified_positions": 3,
    "name": "Iron-sulfur cluster insertion protein ErpA",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVQ8",
    "length": 269,
    "modifications": "hex(2)neuac(1)$Oxidation$Gly$Gluratylation$Methyl$Cation:Ag$Deamidated$Carbamidomethyl$Thiazolidine$Dehydrated",
    "modified_positions": 25,
    "name": "Dehydrogenase, short chain (Dhs-6C)",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVR3",
    "length": 112,
    "modifications": "Biotin:Thermo-33033-H",
    "modified_positions": 1,
    "name": "Ribosomal silencing factor RsfS",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVR4",
    "length": 156,
    "modifications": "Palmitoyl$Oxidation$LRGG$DimethylamineGMBS$Carbamidomethyl$Unknown:210",
    "modified_positions": 7,
    "name": "Ribosomal RNA large subunit methyltransferase H",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVR6",
    "length": 372,
    "modifications": "Oxidation$Phosphopantetheine$pentose$Propiophenone$Deamidated$Carbamidomethyl$Unknown:420",
    "modified_positions": 9,
    "name": "Peptidoglycan glycosyltransferase MrdB",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVR7",
    "length": 191,
    "modifications": "Oxidation$Delta:S(-1)Se(1)$Cation:Na$Pyridylacetyl$Lys->MetOx$DMPO$Ammonia-loss",
    "modified_positions": 12,
    "name": "Ribonuclease HII",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVR8",
    "length": 320,
    "modifications": "Lys->CamCys$Oxidation$methyl+acetyl_2h(3)$Hydroxytrimethyl$Hydroxymethyl$TNBS$phenylsulfonylethyl$Delta:H(4)C(5)O(1)$Cation:Li$Formyl$Carbamidomethyl$glucosone$methylol$glycosyl$hex(1)pent(2)$Sulfide$Dioxidation",
    "modified_positions": 16,
    "name": "Oxidoreductase",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZVR9",
    "length": 384,
    "modifications": "Oxidation$hex(4)hexnac(1)$Cation:Cu[I]$Lys->AminoadipicAcid$Carbamidomethyl",
    "modified_positions": 6,
    "name": "Lipid-A-disaccharide synthase 1",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVS0",
    "length": 98,
    "modifications": "Oxidation$Gln->pyro-Glu$Methyl+Deamidated$bacillosamine$pupylation$Hydroxamic_acid$hexnac(1)neuac(1)$Iminobiotin$neuac$Deamidated$Deoxy$Amino$Thiophos-S-S-biotin",
    "modified_positions": 20,
    "name": "Putative Fis-like DNA-binding protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZVS1",
    "length": 623,
    "modifications": "Oxidation$Gln->pyro-Glu$Decarboxylation$Andro-H2O$Met->AspSA$Delta:H(2)C(3)O(1)$Glu->pyro-Glu$HNE-Delta:H(2)O$HCysThiolactone$Deamidated$methyl_2h(3)+acetyl_2h(3)$Deoxy$Met-loss+Acetyl$Carbonyl$Carbamidomethyl$Thiazolidine$methylol",
    "modified_positions": 24,
    "name": "Chaperone protein HtpG",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZVS4",
    "length": 257,
    "modifications": "Lys->CamCys$Oxidation$propionyl_13c(3)$hex(3)hexnac(6)$Met->Aha$methyl+acetyl_2h(3)$Hydroxytrimethyl$dhex(1)hex(2)hexnac(4)sulf(2)$esp$Thiazolidine",
    "modified_positions": 10,
    "name": "UPF0246 protein lpg1366",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVS5",
    "length": 186,
    "modifications": "Oxidation$Delta:H(6)C(3)O(1)$clip_traq_4",
    "modified_positions": 3,
    "name": "DUF4124 domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVS7",
    "length": 399,
    "modifications": "Dethiomethyl$hex$GlycerylPE$Oxidation$Gly$bemad_st_2h(6)$hex(1)hexnac(1)neugc(1)$Met->Hsl$Carbamidomethyl$O-pinacolylmethylphosphonate",
    "modified_positions": 9,
    "name": "General secretion pathway protein F",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVT1",
    "length": 205,
    "modifications": "dhex(1)hex(2)hexa(1)hexnac(2)$Carbamidomethyl$CarbamidomethylDTT$neugc$Thiazolidine$hex(1)hexnac(2)$Delta:H(8)C(6)O(1)$hex(1)pent(2)",
    "modified_positions": 4,
    "name": "Type II secretion system protein J",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVT3",
    "length": 792,
    "modifications": "Oxidation$sulfanilicacid$icpl_2h(4)$Iodoacetanilide:13C(6)$dnic$Biotin-PEO-Amine$dhex(2)hex(2)$Delta:H(4)C(3)$phosphohex$Methylpyrroline$dimethyl_2h(6)13c(2)$hexnac(2)$Fluoro",
    "modified_positions": 12,
    "name": "Inner membrane protein PLUS sensory box protein LssE",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZVT4",
    "length": 376,
    "modifications": "Phosphogluconoylation$Oxidation$Unknown:162$Delta:H(8)C(6)O(1)",
    "modified_positions": 8,
    "name": "TPR repeat protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVT6",
    "length": 391,
    "modifications": "Ethanolamine$Carboxy$4-ONE+Delta:H(-2)O(-1)",
    "modified_positions": 3,
    "name": "SGNH/GDSL hydrolase family protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVT7",
    "length": 394,
    "modifications": "Oxidation$Gln->pyro-Glu$methyl_2h(3)13c(1)$glucuronyl$cGMP+RMP-loss$Methylamine$PyruvicAcidIminyl$Carbamidomethyl$Furan$Didehydro",
    "modified_positions": 20,
    "name": "acetyl-CoA C-acyltransferase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVU2",
    "length": 823,
    "modifications": "Gly$Glu->pyro-Glu$Deamidated$Deoxy$Succinyl$Carbamidomethyl$Delta:H(6)C(3)O(1)$Gluratylation$MesitylOxide$Met->Hpg$Oxidation$Propargylamine$Amidine$NHS-LC-Biotin$15N-oxobutanoic$Dehydrated$pupylation$OxProBiotin$hexnac$Gly-loss+Amide$Carboxymethyl$Bromo",
    "modified_positions": 39,
    "name": "Leucine--tRNA ligase",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZVU5",
    "length": 211,
    "modifications": "Lys->AminoadipicAcid$Oxidation$dhex$GG",
    "modified_positions": 6,
    "name": "Probable nicotinate-nucleotide adenylyltransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVU9",
    "length": 294,
    "modifications": "Pyro-carbamidomethyl$Glu->pyro-Glu+Methyl$Gly$Oxidation$Decarboxylation$Carbofuran$QQQTGG$Deamidated$Biotin:Thermo-33033-H$Carbamidomethyl$Ub-Br2$Ammonia-loss",
    "modified_positions": 19,
    "name": "Acetyl-coenzyme A carboxylase carboxyl transferase subunit beta",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZVV0",
    "length": 475,
    "modifications": "Oxidation$Gly$hex(4)hexa(1)hexnac(1)$acetyl_2h(3)$Ammonium$methyl_2h(3)$Deoxy$Ser->LacticAcid$AEC-MAEC$Carbonyl$methyl_2h(2)$Carbamidomethyl$Cation:Mg[II]$Nitrene$Didehydro$Dehydrated",
    "modified_positions": 22,
    "name": "Flagellin",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZVV2",
    "length": 541,
    "modifications": "Delta:H(6)C(6)O(1)$Hydroxamic_acid$hep$Cation:Na",
    "modified_positions": 4,
    "name": "Flagellar hook-associated protein 2",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVV4",
    "length": 248,
    "modifications": "Nmethylmaleimide$Malonyl$Dihydroxyimidazolidine$esp$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Enhanced entry protein EnhA",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVV5",
    "length": 432,
    "modifications": "Carbamidomethyl$bemad_st_2h(6)",
    "modified_positions": 2,
    "name": "Lysosomal dipeptide transporter MFSD1",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVV7",
    "length": 321,
    "modifications": "Oxidation$Met->Aha$dhex$IBTP$Formyl$Carbamidomethyl$Didehydro$Unknown:162",
    "modified_positions": 10,
    "name": "Pseudouridine synthase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVV8",
    "length": 241,
    "modifications": "Oxidation$Gly$Methyl$Thiadiazole$Carbamidomethyl$Lys->Allysine$Delta:H(6)C(3)O(1)",
    "modified_positions": 10,
    "name": "Purine nucleoside phosphorylase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVW2",
    "length": 104,
    "modifications": "hex$Oxidation$Formyl$Maleimide-PEO2-Biotin$O-pinacolylmethylphosphonate",
    "modified_positions": 7,
    "name": "DUF4286 domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVW3",
    "length": 361,
    "modifications": "Crotonyl$hex(2)hexnac(1)$HNE$Bromo$Formyl$hex(1)hexnac(1)dhex(1)me(1)",
    "modified_positions": 7,
    "name": "LbtU family siderophore porin",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVW9",
    "length": 494,
    "modifications": "GlycerylPE$Oxidation$Met->AspSA$Phosphopropargyl$hex(1)pent(1)$HCysThiolactone$O-Isopropylmethylphosphonate$Tyr->Dha$Deamidated$Deoxy$deamidated_18o(1)$pent(1)hexnac(1)$Carboxymethyl$Methylthio$Carbamidomethyl$GEE",
    "modified_positions": 24,
    "name": "Type II secretion system protein E",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZVX1",
    "length": 295,
    "modifications": "Myristoleyl$Oxidation$ethylamino$Decarboxylation$GGQ$Ethanedithiol",
    "modified_positions": 10,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVX3",
    "length": 249,
    "modifications": "OxProBiotinRed$Oxidation$Brij35$deamidated_18o(1)$Cytopiloyne$GEE$methylol",
    "modified_positions": 10,
    "name": "Transposase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVY2",
    "length": 551,
    "modifications": "hex(1)hexnac(1)dhex(1)$Oxidation$Gly$acetyl_2h(3)$Propargylamine$Carbofuran$hex(1)hexnac(1)neugc(1)$Chlorination$AEC-MAEC$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 22,
    "name": "Glutamine--tRNA ligase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZVY3",
    "length": 272,
    "modifications": "dimethyl_2h(4)$Oxidation$Cation:Na$Carbamidomethyl$a-type-ion",
    "modified_positions": 9,
    "name": "Tryptophan synthase alpha chain",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVY4",
    "length": 399,
    "modifications": "Decarboxylation$Glu->pyro-Glu+Methyl$Oxidation$icpl_2h(4)$Iodoacetanilide:13C(6)$hydroxyisobutyryl$Deamidated$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Nethylmaleimide+water$Carbamidomethyl$Methylpyrroline$MicrocinC7$dnic",
    "modified_positions": 12,
    "name": "Tryptophan synthase beta chain",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZVY7",
    "length": 432,
    "modifications": "OxLysBiotinRed$Myristoleyl$hep$Ser->LacticAcid$Carbamidomethyl",
    "modified_positions": 6,
    "name": "Oxidoreductase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVZ1",
    "length": 284,
    "modifications": "Oxidation$Decarboxylation$methyl_2h(3)$Deoxy$Deamidated$Carbamidomethyl",
    "modified_positions": 17,
    "name": "Bifunctional protein FolD",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVZ3",
    "length": 254,
    "modifications": "OxProBiotinRed$Oxidation$Ammonium$OxArgBiotinRed$UgiJoullieProGlyProGly$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Hydroxyacylglutathione hydrolase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVZ4",
    "length": 479,
    "modifications": "Methyl$Label:2H(4)+GG$Cresylphosphate$Succinyl$Carbonyl",
    "modified_positions": 8,
    "name": "Membrane bound lytic murein transglycosylase D",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVZ8",
    "length": 528,
    "modifications": "Oxidation$Pyridylethyl$lapachenole$Aspartylurea$GluGluGluGlu$Delta:H(5)C(2)$Dimethyl$AEBS$Deoxy$Formyl$Carbamidomethyl$Ethyl",
    "modified_positions": 18,
    "name": "Peptidase C58 YopT-type domain-containing protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZW00",
    "length": 199,
    "modifications": "Oxidation$Deoxy$Lys->MetOx$Carbamidomethyl$Ammonia-loss$Sulfide",
    "modified_positions": 7,
    "name": "Holliday junction branch migration complex subunit RuvA",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZW07",
    "length": 127,
    "modifications": "Oxidation$Ethyl+Deamidated$Methyl$Hydroxymethyl$Amino$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Carbamidomethyl$methylol",
    "modified_positions": 9,
    "name": "Secreted endonuclease",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZW09",
    "length": 123,
    "modifications": "Cresylphosphate$Oxidation",
    "modified_positions": 3,
    "name": "Proteinase inhibitor I42 chagasin domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZW60",
    "length": 598,
    "modifications": "hex(1)neuac(1)pent(1)$hex$methylsulfonylethyl$Oxidation$Gluratylation$GG$Dicarbamidomethyl$NEM:2H(5)$methyl_2h(3)+acetyl_2h(3)$methylol$maleimide$CresylSaligeninPhosphate$Dioxidation",
    "modified_positions": 19,
    "name": "PNPLA domain-containing protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZW66",
    "length": 261,
    "modifications": "Biotin-PEO-Amine$SMA$Oxidation",
    "modified_positions": 3,
    "name": "Flagellar basal-body rod protein FlgG",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZW67",
    "length": 248,
    "modifications": "CIGG$Lys->CamCys$Oxidation$HNE$hex(1)hexnac(1)dhex(1)me(1)$dimethyl_2h(6)13c(2)$Sulfo$Phospho$Sulfide",
    "modified_positions": 12,
    "name": "Flagellar basal-body rod protein FlgF",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZW71",
    "length": 130,
    "modifications": "Oxidation$AzidoF$Delta:H(4)C(2)$acetyl_13c(2)$Ethyl$Dioxidation",
    "modified_positions": 5,
    "name": "Flagellar basal body rod protein FlgB",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZW72",
    "length": 311,
    "modifications": "Propiophenone$15N-oxobutanoic$Carbamidomethyl$benzylguanidine$sulfanilicacid",
    "modified_positions": 6,
    "name": "Oxygen-dependent coproporphyrinogen-III oxidase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZW81",
    "length": 190,
    "modifications": "Oxidation$LRGG+dimethyl$Thiophospho$4-ONE$bemad_st_2h(6)$Ethanolamine$Carbamidomethyl$hex(1)hexnac(2)dhex(2)$Sulfo$Phospho$Dehydrated",
    "modified_positions": 12,
    "name": "Sigma 54 modulation protein YhbH",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZW83",
    "length": 210,
    "modifications": "Oxidation$Methyl$Ammonium$hex(2)hexnac(1)neugc(2)$methyl_2h(3)$Cation:K$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Orotate phosphoribosyltransferase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZW90",
    "length": 199,
    "modifications": "Oxidation$Cation:Na$Isopropylphospho$Cation:Mg[II]$hex(1)hexnac(1)",
    "modified_positions": 5,
    "name": "Imidazole glycerol phosphate synthase subunit HisH 2",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZW91",
    "length": 239,
    "modifications": "Oxidation$GG$HNE$N-dimethylphosphate$Dicarbamidomethyl$ISD_z+2_ion$Carbamidomethyl$Propionyl",
    "modified_positions": 8,
    "name": "1-(5-phosphoribosyl)-5-[(5-phosphoribosylamino)methylideneamino] imidazole-4-carboxamide isomerase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZW93",
    "length": 207,
    "modifications": "Oxidation$Carbofuran$Deoxy$Deamidated$Carboxymethyl$Carbamidomethyl$methylol$Delta:H(6)C(3)O(1)",
    "modified_positions": 11,
    "name": "Histidine biosynthesis bifunctional protein HisIE",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZWA1",
    "length": 795,
    "modifications": "hex(1)hexnac(1)neuac(2)ac(1)$Methyl$hexnac(1)dhex(1)$Hydroxymethyl$sulfanilicacid$Ammonia-loss$Dioxidation",
    "modified_positions": 9,
    "name": "Outer membrane protein RomA",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZWA5",
    "length": 155,
    "modifications": "Carbamidomethyl$Deoxy$Oxidation$Ammonia-loss",
    "modified_positions": 5,
    "name": "6,7-dimethyl-8-ribityllumazine synthase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZWA7",
    "length": 204,
    "modifications": "Propargylamine$Oxidation$ZQG$BEMAD_ST",
    "modified_positions": 5,
    "name": "Riboflavin synthase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZWA8",
    "length": 357,
    "modifications": "Oxidation$hexnac(1)dhex(1)$Deamidated$EQIGG$hexnac(4)$Carbamidomethyl$Thiazolidine$Met->Hpg$GPIanchor",
    "modified_positions": 13,
    "name": "Riboflavin biosynthesis protein RibD",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZWB1",
    "length": 442,
    "modifications": "His+O(2)$hex$Oxidation$Cation:Ni[II]$Propionamide$OxArgBiotinRed$clip_traq_4$Carboxyethylpyrrole$Carbamidomethyl$Arg2PG$hexnac(2)",
    "modified_positions": 17,
    "name": "Two component response regulator PilR",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZWB8",
    "length": 161,
    "modifications": "Oxidation$Gln->pyro-Glu$methyl_2h(3)13c(1)$cGMP+RMP-loss$bemad_st_2h(6)$dimethyl_2h(4)13c(2)$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Carbamidomethyl$Carbamyl",
    "modified_positions": 10,
    "name": "Nucleotide-binding protein lpg1167",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZWC1",
    "length": 384,
    "modifications": "Delta:H(2)C(2)$Oxidation$Propionyl$Acetyl$pyrophospho$Pro->Pyrrolidone$Carbamidomethyl$hex(1)hexnac(2)dhex(2)$Carbamyl$CresylSaligeninPhosphate$ub-amide",
    "modified_positions": 14,
    "name": "Acetylornithine deacetylase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZWC3",
    "length": 243,
    "modifications": "Oxidation$Methyl$Methyl+Deamidated$Hydroxamic_acid$Pro->pyro-Glu$Deoxy$Carbonyl",
    "modified_positions": 19,
    "name": "OmpA-like transmembrane domain protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZWC5",
    "length": 81,
    "modifications": "Carbamidomethyl$Didehydro$AEC-MAEC",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWC7",
    "length": 256,
    "modifications": "Oxidation$Decarboxylation$Diisopropylphosphate$acetyl_2h(3)$Pro->Pyrrolidinone$Isopropylphospho$Ser->LacticAcid$Delta:H(4)C(6)",
    "modified_positions": 12,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZWC9",
    "length": 398,
    "modifications": "hex(2)$Gly$Propargylamine$Diethyl$Acetyldeoxyhypusine$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Aminopeptidase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZWD3",
    "length": 318,
    "modifications": "Oxidation$Propionamide$Biotin:Thermo-21330$Lysbiotinhydrazide$glyoxalAGE$Glu$serotonylation$Ammonia-loss",
    "modified_positions": 9,
    "name": "Uncharacterized protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZWE3",
    "length": 76,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "GIY-YIG domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWE4",
    "length": 364,
    "modifications": "Oxidation$AHA-SS_CAM$methyl_2h(3)13c(1)$icpl_2h(4)$ISD_z+2_ion$Carboxy$Carbamidomethyl$Methylpyrroline$Carbamyl$dnic",
    "modified_positions": 9,
    "name": "Spermidine/putrescine import ATP-binding protein PotA",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZWE5",
    "length": 274,
    "modifications": "Methylthio",
    "modified_positions": 2,
    "name": "Spermidine/putrescine ABC transporter permease protein PotB",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWE7",
    "length": 340,
    "modifications": "Oxidation$Delta:H(2)C(3)O(1)$pyrophospho$Carbamidomethyl$Nitrene",
    "modified_positions": 6,
    "name": "Putrescine-binding periplasmic protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZWE8",
    "length": 322,
    "modifications": "Oxidation$bacillosamine$hep$hexnac(1)neugc(2)$Pro->pyro-Glu$glyoxalAGE$Pyridylacetyl",
    "modified_positions": 11,
    "name": "Serine protease Lpg1137",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZWE9",
    "length": 300,
    "modifications": "hex$Oxidation$Dansyl$Deoxy$Deamidated$SMA",
    "modified_positions": 12,
    "name": "DUF4349 domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZWF0",
    "length": 203,
    "modifications": "Lys->CamCys$MercaptoEthanol$Oxidation$betaFNA$Chlorination$Iodoacetanilide$QTGG$Carbamidomethyl$Thiazolidine",
    "modified_positions": 11,
    "name": "Bacterial regulatory proteins, TetR family",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZWF5",
    "length": 483,
    "modifications": "Oxidation$Ethyl+Deamidated$Met->Aha$Methyl+Deamidated$EDT-maleimide-PEO-biotin$Hydroxamic_acid$Saligenin$Aspartylurea$Ammonium$methyl_2h(3)$Cytopiloyne$Carbamidomethyl$Fluoro",
    "modified_positions": 22,
    "name": "Adenylate cyclase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZWF7",
    "length": 154,
    "modifications": "AMTzHexNAc2",
    "modified_positions": 1,
    "name": "Cytidine/deoxycytidylate deaminase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWG3",
    "length": 442,
    "modifications": "OxProBiotinRed$Oxidation$Sulfo-NHS-LC-LC-Biotin$Pro->Pyrrolidinone$hexnac(1)neuac(1)$Delta:H(4)C(3)$Tyr->Dha$Glycerophospho$Carbamidomethyl$Methylpyrroline",
    "modified_positions": 12,
    "name": "Membrane bound lytic murein transglycosylase D",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZWH3",
    "length": 127,
    "modifications": "Carbamidomethyl$Oxidation$DMPO",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWH4",
    "length": 212,
    "modifications": "Methyl+Deamidated$Hydroxamic_acid$AEC-MAEC$Thiophos-S-S-biotin$Lys->Allysine",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZWH5",
    "length": 231,
    "modifications": "DNCB_hapten$Oxidation$Cytopiloyne+water",
    "modified_positions": 3,
    "name": "Transglutaminase-like domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWH6",
    "length": 686,
    "modifications": "Carbamidomethyl$3-phosphoglyceryl$Oxidation$O-Et-N-diMePhospho$neugc$acetyl_2h(3)$hep$Lys->AminoadipicAcid$FP-Biotin$Unknown:250$Cation:Cu[I]$Ethylphosphate$Biotin$sulfanilicacid$Cation:Zn[II]",
    "modified_positions": 14,
    "name": "Uncharacterized protein",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZWI1",
    "length": 330,
    "modifications": "DimethylamineGMBS$Carbamidomethyl$Unknown:162",
    "modified_positions": 5,
    "name": "Aminoglycoside phosphotransferase domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWI6",
    "length": 152,
    "modifications": "Succinyl$4-ONE$NQIGG",
    "modified_positions": 3,
    "name": "Transmembrane protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWI8",
    "length": 595,
    "modifications": "Palmitoyl$Oxidation$Unknown:248$AccQTag$Diethylphosphate$Delta:H(4)C(3)$MesitylOxide$Octanoyl$Thiazolidine$Cytopiloyne+water$AHA-Alkyne-KDDDD",
    "modified_positions": 10,
    "name": "Polyhydroxyalkanoic synthase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZWJ8",
    "length": 535,
    "modifications": "Oxidation$ZQG$hexnac(1)neugc(2)$Formylasparagine$Carbonyl$Carbamidomethyl$Thiazolidine$Propionyl$hex(1)hexa(1)hexnac(2)",
    "modified_positions": 14,
    "name": "Probable lipid II flippase MurJ",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZWK1",
    "length": 343,
    "modifications": "Oxidation$Acetyl$biotinAcrolein298$Formyl$hex(1)hexnac(1)dhex(1)me(2)$Lys->Allysine$Dioxidation",
    "modified_positions": 15,
    "name": "DUF1016 domain-containing protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZWK2",
    "length": 227,
    "modifications": "NDA$bemad_st_2h(6)$SPITC:13C(6)$Methylthio$Delta:H(4)C(6)",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZWL1",
    "length": 394,
    "modifications": "Deamidated$SMA$MTSL$Carbamidomethyl$clip_traq_3$clip_traq_2$hex(3)",
    "modified_positions": 10,
    "name": "GIY-YIG nuclease family protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZWL8",
    "length": 85,
    "modifications": "Menadione-HQ$Oxidation",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWM9",
    "length": 180,
    "modifications": "Pro->Pyrrolidone$Oxidation$Ub-Br2$BHTOH",
    "modified_positions": 4,
    "name": "Guanylate cyclase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZWN0",
    "length": 146,
    "modifications": "Iodoacetanilide:13C(6)$Oxidation",
    "modified_positions": 2,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWQ1",
    "length": 175,
    "modifications": "Phosphogluconoylation$Oxidation",
    "modified_positions": 2,
    "name": "DUF2231 domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWQ6",
    "length": 1071,
    "modifications": "Oxidation$neugc$phosphoRibosyl$Nitro$Ammonium$methyl_2h(3)$trimethyl_2h(9)$Carbonyl$Carbamidomethyl$Fluoro",
    "modified_positions": 18,
    "name": "Chemiosmotic efflux system protein A-like protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZWQ7",
    "length": 322,
    "modifications": "Lipoyl$Methyl$Palmitoleyl",
    "modified_positions": 3,
    "name": "Chemiosmotic efflux system C protein B",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWQ9",
    "length": 124,
    "modifications": "Arg->Orn$4AcAllylGal$acetyl_13c(2)$Carbamidomethyl$Arg->GluSA",
    "modified_positions": 3,
    "name": "Putative outer membrane lipoprotein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZWR1",
    "length": 736,
    "modifications": "Cation:Al[III]$Oxidation$Delta:H(10)C(8)O(1)$Methyl$acetyl_2h(3)$PEITC$Methamidophos-O$clip_traq_2$EHD-diphenylpentanone$Dioxidation",
    "modified_positions": 17,
    "name": "Copper-exporting P-type ATPase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZWR2",
    "length": 303,
    "modifications": "hexnac(1)dhex(2)$Biotin-PEG-PRA",
    "modified_positions": 3,
    "name": "Ribose-phosphate pyrophosphokinase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWR6",
    "length": 377,
    "modifications": "Biotin:Thermo-21345$Met->Hse$Oxidation$Biotin-PEG-PRA",
    "modified_positions": 4,
    "name": "Chemiosmotic efflux system B protein B",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZWT7",
    "length": 210,
    "modifications": "Methamidophos-O$Cys->Dha",
    "modified_positions": 2,
    "name": "TIGR03747 family integrating conjugative element membrane protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWT8",
    "length": 108,
    "modifications": "O-Dimethylphosphate$Ethylphosphate",
    "modified_positions": 1,
    "name": "Conjugal transfer protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWU4",
    "length": 419,
    "modifications": "Unknown:216$Oxidation$AccQTag$IodoU-AMP$Formyl$succinyl_13c(4)$benzoyl$succinyl_2h(4)",
    "modified_positions": 17,
    "name": "Exported membrane protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZWU7",
    "length": 324,
    "modifications": "phosphohex",
    "modified_positions": 1,
    "name": "TIGR03756 family integrating conjugative element protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWU8",
    "length": 455,
    "modifications": "Carbamidomethyl$Met->Hse$Oxidation$Delta:H(2)C(5)$Decarboxylation$Malonyl$Acetyl$Acetyldeoxyhypusine$methyl_2h(3)+acetyl_2h(3)$Decanoyl$Arg->GluSA",
    "modified_positions": 15,
    "name": "Membrane protein, Tfp pilus assembly, pilus retraction ATPase PilT",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZWV8",
    "length": 140,
    "modifications": "Nmethylmaleimide$SMA",
    "modified_positions": 2,
    "name": "Single-stranded DNA-binding protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWV9",
    "length": 168,
    "modifications": "icdid_2h(6)",
    "modified_positions": 1,
    "name": "Antirestriction protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWW5",
    "length": 246,
    "modifications": "Oxidation$C8-QAT$Deoxy$succinyl_13c(4)$benzoyl$Carbamidomethyl$NBS",
    "modified_positions": 8,
    "name": "Uncharacterized protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZWX9",
    "length": 420,
    "modifications": "phosphohex(2)$MesitylOxide$Quinone$methylol$Haloxon",
    "modified_positions": 5,
    "name": "Transmembrane protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZWY1",
    "length": 555,
    "modifications": "Dethiomethyl$Oxidation$Gly$Cation:Na$AzidoF$Deoxy$Met->Hsl$Deamidated$Carboxymethyl$esp$Carbamidomethyl$Delta:H(6)C(3)O(1)$tmab_2h(9)",
    "modified_positions": 18,
    "name": "AMP-binding protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZWY3",
    "length": 480,
    "modifications": "Oxidation$ISD_z+2_ion$Deoxy$Unknown:210$Glu$Carboxymethyl$Carbamidomethyl$hex(3)$hex(3)hexnac(4)neuac(1)$Carbamyl",
    "modified_positions": 15,
    "name": "TldD protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZWY4",
    "length": 268,
    "modifications": "hex(2)hexnac(5)$phosphohexnac$Oxidation$Propargylamine$Delta:H(4)C(3)$Carboxymethyl$Carbamidomethyl$Methamidophos-S$s-glcnac",
    "modified_positions": 10,
    "name": "Nitrilase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZWY5",
    "length": 224,
    "modifications": "Isopropylphospho$Delta:H(8)C(6)O(2)$hex(5)hexnac(2)",
    "modified_positions": 3,
    "name": "Carrier/transport protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWY7",
    "length": 605,
    "modifications": "Unknown:216$Oxidation$PhosphoUridine$neugc$Gly$Biotin:Thermo-21330$neuac$Methamidophos-O$Carbamidomethyl$Delta:H(4)C(3)O(1)$hex(3)",
    "modified_positions": 17,
    "name": "2-oxoglutarate ferredoxin oxidoreductase alpha subunit",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZWZ0",
    "length": 229,
    "modifications": "Lys->CamCys$Oxidation$NDA$Trioxidation$PropylNAGthiazoline$GGQ$Carbamidomethyl$Maleimide-PEO2-Biotin$hex(1)hexnac(1)$Dioxidation",
    "modified_positions": 9,
    "name": "DNA repair protein RecO",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZWZ4",
    "length": 187,
    "modifications": "Carbamidomethyl$Gln->pyro-Glu$probiotinhydrazide",
    "modified_positions": 3,
    "name": "2-dehydro-3-deoxy-phosphogluconate aldolase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWZ7",
    "length": 328,
    "modifications": "Oxidation$Diisopropylphosphate$Myristoyl+Delta:H(-4)$Succinyl$glycosyl$Phospho$BHTOH",
    "modified_positions": 8,
    "name": "Riboflavin biosynthesis protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZWZ8",
    "length": 143,
    "modifications": "dileu4plex$Decarboxylation$Oxidation$HNE-Delta:H(2)O$4-ONE$dileu4plex117$CAMthiopropanoyl$dileu4plex118$Carbamidomethyl$Methylpyrroline$tmab_2h(9)$dileu4plex115",
    "modified_positions": 10,
    "name": "Universal stress protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZWZ9",
    "length": 483,
    "modifications": "methylsulfonylethyl$Oxidation$Ethyl+Deamidated$Cation:Ni[II]$azole$HNE$Biotin-phenacyl$icpl$Carbamidomethyl$succinyl_2h(4)$benzylguanidine$Ammonia-loss",
    "modified_positions": 16,
    "name": "DamX-related protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZX00",
    "length": 369,
    "modifications": "CIGG$Pyro-carbamidomethyl$Oxidation$hex(1)neuac(1)$AEBS$O-Isopropylmethylphosphonate$neuac$AzidoF$Deoxy$UgiJoullieProGly$Carbamidomethyl$Unknown:306$Ammonia-loss",
    "modified_positions": 14,
    "name": "3-dehydroquinate synthase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZX01",
    "length": 175,
    "modifications": "Cation:Al[III]$Oxidation$Delta:H(8)C(6)O(2)$Propionamide$Iodoacetanilide:13C(6)$Phosphoadenosine$Deamidated",
    "modified_positions": 7,
    "name": "Shikimate kinase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZX05",
    "length": 182,
    "modifications": "MesitylOxide$Oxidation$neugc$Carbonyl",
    "modified_positions": 8,
    "name": "Type IV pilus biogenesis protein PilN",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZX06",
    "length": 354,
    "modifications": "Oxidation$Lys->AminoadipicAcid$HPG$Deamidated$Deoxy$Arg->Orn$Carbamidomethyl$clip_traq_3",
    "modified_positions": 9,
    "name": "Type IV pilus biogenesis protein PilM",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZX07",
    "length": 336,
    "modifications": "Cys->PyruvicAcid$Oxidation$Gly$Gln->pyro-Glu$Diethyl$hep$DeStreak$Dimethylphosphothione$dhex(1)hex(2)$Carboxy$Methylthio$Carbamidomethyl$Acetylhypusine",
    "modified_positions": 22,
    "name": "Uncharacterized protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZX08",
    "length": 794,
    "modifications": "hex(1)hexa(1)$Oxidation$Decarboxylation$Pro->Pyrrolidinone$AccQTag$glucuronyl$Gly$Cation:Na$Deamidated$Unknown:210$Octanoyl$Carbamidomethyl$Menadione$Ethanedithiol",
    "modified_positions": 24,
    "name": "Penicillin-binding protein 1A",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZX10",
    "length": 312,
    "modifications": "Lys->CamCys$Oxidation$PET$Pro->Pyrrolidinone$GG$eqat_2h(5)$Hydroxamic_acid$Acetyl$Iminobiotin$Dicarbamidomethyl$Deamidated$Carbonyl$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 14,
    "name": "Electron transfer flavoprotein subunit alpha",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZX11",
    "length": 249,
    "modifications": "Oxidation$Gln->pyro-Glu$Delta:H(5)C(2)$bemad_st_2h(6)$15N-oxobutanoic$Deoxy$a-type-ion$Ammonia-loss",
    "modified_positions": 12,
    "name": "Electron transfer flavoprotein subunit beta",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZX12",
    "length": 414,
    "modifications": "Delta:H(2)C(2)$Lys->CamCys$Decarboxylation$Gly$Cation:Ni[II]$Phenylisocyanate$icpl$Acetyldeoxyhypusine$Biotin-PEO-Amine$Pyridylacetyl$Isopropylphospho$Carbamidomethyl",
    "modified_positions": 13,
    "name": "J domain-containing protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZX15",
    "length": 350,
    "modifications": "Oxidation$Pyridylethyl$Amidine$HN3_mustard$Deoxy$Carbamidomethyl$NA-LNO2$Furan",
    "modified_positions": 9,
    "name": "Erythronate-4-phosphate dehydrogenase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZX16",
    "length": 483,
    "modifications": "monomethylphosphothione$Dap-DSP$Oxidation$ZQG$dhex$Met->AspSA$Tris$Delta:H(4)C(5)O(1)$Deamidated$Met-loss+Acetyl$Carbamidomethyl$Sulfo$Phospho",
    "modified_positions": 19,
    "name": "UDP-N-acetylmuramoyl-L-alanyl-D-glutamate--2,6-diaminopimelate ligase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZX20",
    "length": 152,
    "modifications": "icpl$AEBS$hex(1)pent(1)$Trp->Kynurenin$Pro->Pyrrolidone$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Transcriptional regulator MraZ",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZX22",
    "length": 256,
    "modifications": "Gly$Gln->pyro-Glu$icpl_13c(6)2h(4)$PyridoxalPhosphate$Deamidated$CAMthiopropanoyl$Carbamidomethyl",
    "modified_positions": 9,
    "name": "Type III pantothenate kinase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZX24",
    "length": 135,
    "modifications": "Lys->CamCys$Decarboxylation$Sulfide$Oxidation",
    "modified_positions": 4,
    "name": "Cytochrome c5",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZX25",
    "length": 233,
    "modifications": "CIGG$Nitro$Ethanolyl$Hydroxymethyl$TMPP-Ac$SMA$MTSL$acetyl_13c(2)$Carbamidomethyl$methylol",
    "modified_positions": 11,
    "name": "Flagella basal body P-ring formation protein FlgA",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZX27",
    "length": 165,
    "modifications": "Deamidated$Carbamidomethyl$Malonyl$spermine",
    "modified_positions": 4,
    "name": "Flagellar biosynthesis/type III secretory pathway chaperone",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZX32",
    "length": 218,
    "modifications": "Pyro-carbamidomethyl$Oxidation$Gly$GG$glucuronyl$Dicarbamidomethyl$Deamidated$Deoxy$Carbamidomethyl",
    "modified_positions": 11,
    "name": "Uncharacterized protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZX44",
    "length": 297,
    "modifications": "Oxidation$Biotin-PEO-Amine$Dimethylphosphothione$Crotonaldehyde$Carbamidomethyl$Butyryl$clip_traq_3",
    "modified_positions": 8,
    "name": "1-acyl-sn-glycerol-3-phosphate acyltransferase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZX47",
    "length": 426,
    "modifications": "Oxidation$Biotin:Thermo-33033-H",
    "modified_positions": 2,
    "name": "Sodium:dicarboxylate symporter",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZX48",
    "length": 358,
    "modifications": "glucosone$3sulfo$Oxidation$HexN",
    "modified_positions": 5,
    "name": "beta-N-acetylhexosaminidase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZX56",
    "length": 377,
    "modifications": "Oxidation$Gly$Biotin-PEO-Amine$Deamidated$deamidated_18o(1)$hex(3)hexnac(2)$AEC-MAEC$Carbamidomethyl$EHD-diphenylpentanone$glycidamide",
    "modified_positions": 15,
    "name": "NAD(P) transhydrogenase subunit alpha part 1",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZX60",
    "length": 526,
    "modifications": "Oxidation$methyl_2h(3)13c(1)$Propargylamine$Propionamide$hex(1)neuac(1)$hexnac(1)neuac(1)$Delta:H(5)C(2)$15N-oxobutanoic$hex(1)neugc(1)$icpl_13c(6)$Carbamidomethyl$Dehydrated",
    "modified_positions": 17,
    "name": "Peptide chain release factor 3",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZX66",
    "length": 183,
    "modifications": "Oxidation$hex(3)hexnac(2)$Cation:Fe[III]",
    "modified_positions": 3,
    "name": "Putative 3-methyladenine DNA glycosylase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZX69",
    "length": 133,
    "modifications": "Oxidation$Propargylamine$icpl$propyl_2h(6)$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Cytochrome c-type biogenesis protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZX71",
    "length": 650,
    "modifications": "Oxidation$NDA$Met->Aha$Biotin-tyramide",
    "modified_positions": 9,
    "name": "Cytochrome c-type biogenesis protein CcmF",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZX72",
    "length": 143,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Carbamyl",
    "modified_positions": 1,
    "name": "Cytochrome c-type biogenesis protein CcmE",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZX75",
    "length": 226,
    "modifications": "hex(1)hexnac(1)neugc(1)",
    "modified_positions": 1,
    "name": "Heme exporter protein B",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZX78",
    "length": 93,
    "modifications": "CIGG$Oxidation$Diethyl$imid_2h(4)$Methylamine$Deoxy",
    "modified_positions": 6,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZX79",
    "length": 471,
    "modifications": "Oxidation$neugc$hex(2)hexnac(2)$IBTP$Delta:H(6)C(7)O(4)$Biotin:Thermo-21330$Pro->HAVA$Deoxy$HexN$Carbamidomethyl$Delta:H(6)C(3)O(1)$Dioxidation",
    "modified_positions": 18,
    "name": "Transcriptional regulator FleQ",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZX81",
    "length": 338,
    "modifications": "Menadione-HQ$Ethyl+Deamidated$Furan$hex(6)hexnac(5)",
    "modified_positions": 4,
    "name": "Membrane fusion protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZX83",
    "length": 225,
    "modifications": "Gly-loss+Amide$Delta:H(5)C(2)$O-Et-N-diMePhospho$Ethyl+Deamidated",
    "modified_positions": 4,
    "name": "ABC transporter, ATP binding protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZX84",
    "length": 252,
    "modifications": "Carbamidomethyl$hex(1)hexnac(1)neuac(1)",
    "modified_positions": 3,
    "name": "GTP cyclohydrolase 1 type 2 homolog",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZX87",
    "length": 93,
    "modifications": "CarboxymethylDMAP$Carbamidomethyl$Gly$Pyridylethyl$succinyl_13c(4)$benzoyl$succinyl_2h(4)$O-pinacolylmethylphosphonate",
    "modified_positions": 6,
    "name": "STAS domain-containing protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZX90",
    "length": 260,
    "modifications": "Diethylphosphate$Oxidation$phosphohex",
    "modified_positions": 3,
    "name": "Intermembrane phospholipid transport system permease protein MlaE",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZX91",
    "length": 265,
    "modifications": "Oxidation$Propiophenone$Deamidated$QTGG$Formyl$Carbamidomethyl$Thiazolidine",
    "modified_positions": 14,
    "name": "Toluene tolerance ABC transporter, ATP binding protein Ttg2A",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZX92",
    "length": 320,
    "modifications": "GluGluGlu$Cation:Ni[II]$Oxidation$Deamidated$SMA$Carbamidomethyl",
    "modified_positions": 10,
    "name": "Arabinose 5-phosphate isomerase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXA2",
    "length": 241,
    "modifications": "MercaptoEthanol$Oxidation$Gln->pyro-Glu$icpl_2h(4)$dnic$bemad_st_2h(6)$15N-oxobutanoic$Deamidated$Dehydrated",
    "modified_positions": 9,
    "name": "Thioesterase domain-containing protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZXB1",
    "length": 259,
    "modifications": "Oxidation$OxProBiotin$Carboxyethyl$Carboxy$gist-quat_2h(6)$benzylguanidine$CresylSaligeninPhosphate",
    "modified_positions": 10,
    "name": "Lipopolysaccharide biosynthesis glycosyltransferase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXB7",
    "length": 232,
    "modifications": "Oxidation$methyl_2h(3)$Phospho$Propionamide",
    "modified_positions": 5,
    "name": "Protein tyrosine phosphatase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXC3",
    "length": 471,
    "modifications": "Pyro-carbamidomethyl$Oxidation$Gln->pyro-Glu$Menadione-HQ$Amidine$FP-Biotin$Cation:Na$Deamidated$Deoxy$Lys->AminoadipicAcid$Carbamidomethyl$Lys->Allysine$Didehydro$Dehydro$hex(3)",
    "modified_positions": 24,
    "name": "Succinyl-diaminopimelate desuccinylase",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZXC5",
    "length": 280,
    "modifications": "Unknown:216$Oxidation$neugc$hex(1)hexnac(2)dhex(1)$dhex(2)hex(4)$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Probable nicotinate-nucleotide pyrophosphorylase [carboxylating]",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXC7",
    "length": 795,
    "modifications": "Gly$Dicarbamidomethyl$Deamidated$Deoxy$Carbamidomethyl$hex(1)pent(3)$pent(1)hexnac(1)$Sulfo$galactosyl$Oxidation$Phenylisocyanate:2H(5)$bacillosamine$Lys->CamCys$GG$FMNH$Unknown:234$Carboxymethyl$Thiazolidine$Phospho",
    "modified_positions": 35,
    "name": "Phosphoenolpyruvate synthase",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZXC8",
    "length": 332,
    "modifications": "Delta:H(6)C(7)O(4)$Diethylphosphate$Tyr->Dha$AzidoF$Deoxy$Carbamidomethyl$hexnac(1)kdn(2)",
    "modified_positions": 12,
    "name": "Choloylglycine hydrolase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXD1",
    "length": 456,
    "modifications": "Unknown:216$Ethyl$Homocysteic_acid$Oxidation$Methyl$FTC$ISD_z+2_ion$Deamidated$Dioxidation$Isopropylphospho$esp$Carbonyl$Fluoro$Thiazolidine$Sulfide$hexnac(2)dhex(2)",
    "modified_positions": 25,
    "name": "Adenylosuccinate lyase",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZXD2",
    "length": 549,
    "modifications": "Nmethylmaleimide$Unknown:216$Glu->pyro-Glu+Methyl$Oxidation$Amidine$Saligenin$N-dimethylphosphate$Hydroxymethyl$Delta:H(4)C(3)$O-Isopropylmethylphosphonate$Unknown:234$icpl_13c(6)$dhex(1)hex(1)hexnac(2)sulf(1)$dhex(1)hex(4)$Carbamidomethyl$Methylthio$clip_traq_2",
    "modified_positions": 19,
    "name": "L-aspartate oxidase",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZXE4",
    "length": 178,
    "modifications": "Carbamidomethyl$Oxidation$Biotin:Thermo-88317",
    "modified_positions": 4,
    "name": "Transposase IS200-like domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXE6",
    "length": 317,
    "modifications": "Pyro-carbamidomethyl$Oxidation$Gln->pyro-Glu$Methyl$Phosphopropargyl$GlycerylPE$Propiophenone$Carbamidomethyl$Ammonia-loss",
    "modified_positions": 11,
    "name": "Acetyl-coenzyme A carboxylase carboxyl transferase subunit alpha",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZXE7",
    "length": 245,
    "modifications": "Oxidation$GG$Biotin-PEO-Amine$Dicarbamidomethyl$Deamidated$Deoxy$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Phosphopantetheine-protein transferase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXE8",
    "length": 331,
    "modifications": "Pyro-carbamidomethyl$Oxidation$PET$Carboxy->Thiocarboxy$Cys->SecNEM:2H(5)$Cresylphosphate$Delta:H(4)C(3)$15N-oxobutanoic$Carbamidomethyl$NBS$Ammonia-loss$Dehydrated",
    "modified_positions": 13,
    "name": "Bifunctional ligase/repressor BirA",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZXF2",
    "length": 339,
    "modifications": "Carbamidomethyl$Oxidation$Gluratylation",
    "modified_positions": 3,
    "name": "Glycosyltransferase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXG2",
    "length": 239,
    "modifications": "LRGG+dimethyl$Carbamidomethyl$methylol$Didehydro$CresylSaligeninPhosphate",
    "modified_positions": 11,
    "name": "Methyltransferase type 12 domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXG5",
    "length": 372,
    "modifications": "acetyl_2h(3)$GG$hex(2)hexnac(1)me(1)$hex(1)hexa(1)hexnac(1)$Carbamidomethyl",
    "modified_positions": 9,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXG7",
    "length": 174,
    "modifications": "Thiazolidine$Decanoyl$Delta:H(4)C(3)",
    "modified_positions": 4,
    "name": "Right handed beta helix domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXH0",
    "length": 318,
    "modifications": "Oxidation$O-Dimethylphosphate$Succinyl$Ethylphosphate$Unknown:162",
    "modified_positions": 5,
    "name": "NAD dependent epimerase/dehydratase, UDP-glucose-4-epimerase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXH3",
    "length": 359,
    "modifications": "Lys->CamCys$Palmitoyl$Oxidation$Trioxidation$Iodoacetanilide$Carbamidomethyl$Methylpyrroline$dnic",
    "modified_positions": 10,
    "name": "dTDP-glucose 4,6-dehydratase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZXH4",
    "length": 294,
    "modifications": "Oxidation$Diisopropylphosphate$dhex(2)hex(1)hexnac(4)sulf(1)$Acetyl$Cation:Fe[III]$dhex(1)hex(4)hexnac(3)$3-deoxyglucosone$dhex(2)hex(4)hexnac(2)$Carbamidomethyl$hexnac(2)$Delta:H(4)C(3)O(1)$Propionyl",
    "modified_positions": 12,
    "name": "dTDP-4-dehydrorhamnose reductase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZXI0",
    "length": 232,
    "modifications": "Carbamidomethyl$TMPP-Ac:13C(9)$Carboxymethyl$acetyl_2h(3)",
    "modified_positions": 4,
    "name": "CMP-N,N'-diacetyllegionaminic acid synthase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXI1",
    "length": 213,
    "modifications": "Oxidation$ethylamino$dhex(1)hex(1)hexnac(3)$Deamidated$dimethyl_2h(4)13c(2)$Carboxymethyl$Pro->HAVA$Carbamidomethyl$Thiazolidine$Delta:H(6)C(3)O(1)",
    "modified_positions": 21,
    "name": "Imidazole glycerol phosphate synthase subunit HisH 1",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZXJ1",
    "length": 149,
    "modifications": "Unknown:216$Carbamidomethyl$Oxidation$Lys->MetOx",
    "modified_positions": 4,
    "name": "17kDa common antigen",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXJ2",
    "length": 357,
    "modifications": "Delta:H(2)C(2)$hex(1)hexa(1)$Met->Hse$Oxidation$Myristoyl$Methyl$Delta:H(6)C(7)O(4)$acetyl_2h(3)$Diethylphosphate$4-ONE+Delta:H(-2)O(-1)$betaFNA$Amino$Methamidophos-O$Ser->LacticAcid$Carbonyl$Dipyrrolylmethanemethyl$Carbamidomethyl$glycidamide",
    "modified_positions": 20,
    "name": "Alanine racemase",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZXJ7",
    "length": 536,
    "modifications": "Oxidation$Saligenin$PS_Hapten$4-ONE$hex(1)pent(3)me(1)$TMPP-Ac$Carboxy$Carboxymethyl$Carbamidomethyl$Ammonia-loss",
    "modified_positions": 24,
    "name": "Glutamine-dependent NAD(+) synthetase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZXK6",
    "length": 417,
    "modifications": "pent(2)$Oxidation$imid_2h(4)$Acetyl$Crotonaldehyde$Delta:H(4)C(5)O(1)$HydroxymethylOP$Nethylmaleimide+water$Butyryl$Carbamidomethyl$EDT-iodoacetyl-PEO-biotin$Carbamyl$Sulfide$Dioxidation",
    "modified_positions": 16,
    "name": "Serine hydroxymethyltransferase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZXK8",
    "length": 145,
    "modifications": "Saligenin$methylsulfonylethyl",
    "modified_positions": 2,
    "name": "Hypothetical, His rich",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXL0",
    "length": 420,
    "modifications": "Ethyl+Deamidated$Oxidation$ZQG$Ammonium$methyl_2h(3)$Deamidated$Carbamidomethyl",
    "modified_positions": 7,
    "name": "RND efflux membrane fusion protein, acriflavin resistance protein E",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXL5",
    "length": 337,
    "modifications": "OxLysBiotinRed$Oxidation$hydroxyisobutyryl$Dimethylphosphothione$Succinyl$PyruvicAcidIminyl$Cytopiloyne+water$hex(1)pent(2)",
    "modified_positions": 11,
    "name": "Uncharacterized protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZXL6",
    "length": 223,
    "modifications": "Oxidation$Crotonyl$Carbamidomethyl$clip_traq_2$hex(1)hexnac(1)$EHD-diphenylpentanone",
    "modified_positions": 7,
    "name": "Two component response regulator",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXL9",
    "length": 231,
    "modifications": "Oxidation$Delta:H(8)C(6)O(2)$Decarboxylation$Delta:H(2)C(3)O(1)$Methyl$Deamidated",
    "modified_positions": 6,
    "name": "Endo-1,4-beta-xylanase-like",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXM3",
    "length": 320,
    "modifications": "hex(1)hexnac(3)neuac(1)$Oxidation",
    "modified_positions": 5,
    "name": "IcmL-like",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXM6",
    "length": 145,
    "modifications": "Carbamidomethyl$Myristoyl$O-Et-N-diMePhospho",
    "modified_positions": 3,
    "name": "Predicted transporter component",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXM7",
    "length": 203,
    "modifications": "Oxidation$Gly$Diethyl$hep$Glu->pyro-Glu$Deamidated$Carbamidomethyl$Thiazolidine",
    "modified_positions": 13,
    "name": "Enhanced entry protein EnhA",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZXM8",
    "length": 557,
    "modifications": "Delta:H(6)C(6)O(1)$Diethylphosphate$Deamidated$glycidamide$Carbamidomethyl$sulfanilicacid$NDA$unknown_420$MesitylOxide$Biotin:Thermo-33033-H$DAET$GEE$Carbamyl$Oxidation$betaFNA$Formyl$CIGG$Methyl$Delta:H(2)C(3)O(1)$hydroxyisobutyryl$Dioxidation",
    "modified_positions": 27,
    "name": "Energy-dependent translational throttle protein EttA",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZXM9",
    "length": 340,
    "modifications": "Oxidation$azole$Gly-loss+Amide$hexnac(1)neuac(1)$AEBS$Ammonium$Carbamidomethyl",
    "modified_positions": 9,
    "name": "L-threonine 3-dehydrogenase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXN2",
    "length": 455,
    "modifications": "OxLysBiotinRed$dhex(1)hex(2)$Deamidated$clip_traq_3",
    "modified_positions": 4,
    "name": "Outer membrane protein TolC",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXN3",
    "length": 283,
    "modifications": "Oxidation$propionyl_13c(3)$Pentylamine$OxArgBiotinRed$Cation:Li$Deamidated$dileu4plex118$Piperidine$Carbamidomethyl$Farnesyl$Delta:H(6)C(3)O(1)$Delta:H(4)C(6)",
    "modified_positions": 16,
    "name": "tRNA-cytidine(32) 2-sulfurtransferase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZXP4",
    "length": 96,
    "modifications": "Delta:H(2)C(2)$Oxidation$Gly$Amidine$Ammonium$Carboxy->Thiocarboxy$Glu->pyro-Glu$Trimethyl$Carbofuran$ISD_z+2_ion$Myristoyl+Delta:H(-4)$Deamidated$Cation:Li$Carbamidomethyl$Delta:H(6)C(3)O(1)$Dehydrated",
    "modified_positions": 20,
    "name": "Co-chaperonin GroES",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZXQ0",
    "length": 190,
    "modifications": "LG-lactam-R$Diethyl",
    "modified_positions": 2,
    "name": "Lipoprotein, putative",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXQ9",
    "length": 254,
    "modifications": "Oxidation$ethylamino$Gly$pupylation$Amidine$Glu->pyro-Glu$Carbofuran$AzidoF$Deamidated$Carboxyethylpyrrole$Formyl$Carbamidomethyl$Thiazolidine$Dehydrated",
    "modified_positions": 20,
    "name": "Acetoacetate decarboxylase ADC",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZXR9",
    "length": 479,
    "modifications": "Carbamidomethyl$Pyro-carbamidomethyl$Oxidation$hex(1)hexnac(1)neuac(2)ac(1)$Propionamide$cGMP+RMP-loss$O-Dimethylphosphate$Malonyl$Dimethyl$15N-oxobutanoic$Deoxy$PyruvicAcidIminyl$Ethylphosphate$Ethyl$hex(1)hexnac(1)dhex(1)me(2)$Ammonia-loss$Dehydrated",
    "modified_positions": 16,
    "name": "Multidrug efflux MFS outer membrane protein (RND family)",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZXS1",
    "length": 373,
    "modifications": "hex(2)hexnac(1)me(1)$UgiJoullieProGlyProGly$methyl_2h(3)13c(1)",
    "modified_positions": 4,
    "name": "ABC transporter permease protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXS5",
    "length": 396,
    "modifications": "hexnac(1)dhex(2)$Carbamidomethyl$Oxidation",
    "modified_positions": 5,
    "name": "Tryptophan/tyrosine permease",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXS9",
    "length": 430,
    "modifications": "Carbamidomethyl$hex(1)hexnac(1)kdn(1)sulf(1)$Oxidation$Deamidated",
    "modified_positions": 7,
    "name": "Lysosomal dipeptide transporter MFSD1",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXT0",
    "length": 411,
    "modifications": "CIGG$diart6plex117$diart6plex115$Oxidation$Palmitoleyl$hexnac$Gly$diart6plex118$HN3_mustard$Deamidated$diart6plex116/119$diart6plex$Carbamidomethyl$Thiazolidine$Lys->Allysine$Hydroxyfarnesyl",
    "modified_positions": 17,
    "name": "NADP-dependent malic enzyme",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZXT1",
    "length": 75,
    "modifications": "Carbamidomethyl$Didehydro$Delta:H(6)C(3)O(1)",
    "modified_positions": 7,
    "name": "Large ribosomal subunit protein bL31",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXU0",
    "length": 441,
    "modifications": "OxLysBiotinRed$Arg->Npo$Deoxy$Deamidated$Carbamidomethyl$Nitrosyl$icpl_13c(6)2h(4)$Biotin-PEO-Amine$Carbonyl$Cation:Al[III]$Oxidation$bemad_st_2h(6)$AzidoF$serotonylation$hex(3)$Menadione-HQ$pupylation$AHA-SS_CAM$Methyl$Arg2PG",
    "modified_positions": 22,
    "name": "ATP-dependent protease ATPase subunit HslU",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZXU1",
    "length": 182,
    "modifications": "Oxidation$pentose$Propiophenone$QQQTGG$Deamidated$clip_traq_3",
    "modified_positions": 6,
    "name": "ATP-dependent protease subunit HslV",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXU3",
    "length": 427,
    "modifications": "Unknown:216$Decarboxylation",
    "modified_positions": 3,
    "name": "Lysosomal dipeptide transporter MFSD1",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXU5",
    "length": 209,
    "modifications": "Piperidine$Oxidation",
    "modified_positions": 2,
    "name": "Thymidine kinase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXU6",
    "length": 493,
    "modifications": "monomethylphosphothione$SulfanilicAcid:13C(6)$Thrbiotinhydrazide$OxLysBiotin$Carbamidomethyl$GEE$a-type-ion",
    "modified_positions": 9,
    "name": "Melitin resistance protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXV1",
    "length": 355,
    "modifications": "Oxidation$Pro->Pyrrolidinone$BITC$Carbamidomethyl$serotonylation",
    "modified_positions": 9,
    "name": "Type IV fimbrial biogenesis PilW related protein, transmembrane",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXW3",
    "length": 190,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "3-methyladenine DNA glycosylase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXX5",
    "length": 149,
    "modifications": "Cys->PyruvicAcid$Pyro-carbamidomethyl$Oxidation$Cyano$Carbamidomethyl$Ammonia-loss",
    "modified_positions": 5,
    "name": "Nitrogen fixation protein (Fe-S cluster formation) NifU",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXX6",
    "length": 414,
    "modifications": "Carbamidomethyl$Cys->ethylaminoAla$Oxidation",
    "modified_positions": 4,
    "name": "Cysteine desulfurase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXX7",
    "length": 428,
    "modifications": "Oxidation$Delta:H(8)C(6)O(2)$Gluratylation$GG$Ammonium$methyl_2h(3)$Dicarbamidomethyl$GGQ",
    "modified_positions": 16,
    "name": "ABC transporter, permease component",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZXX8",
    "length": 250,
    "modifications": "FTC$Propionamide$Hydroxamic_acid$hex(2)pent(2)$Deamidated$Carbamidomethyl$OxProBiotinRed$dhex(3)hexnac(3)kdn(1)$hex(1)hexnac(1)dhex(1)$Oxidation$Acetyl$bemad_st_2h(6)$PEITC$hex(1)hexnac(1)$clip_traq_3$Methyl$Delta:H(2)C(3)O(1)$cGMP+RMP-loss$Tris",
    "modified_positions": 23,
    "name": "ATP transporter, ABC binding component, ATP-binding protein",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZXY0",
    "length": 153,
    "modifications": "MercaptoEthanol$Oxidation$Propionamide$BITC$Carbonyl",
    "modified_positions": 7,
    "name": "Rrf2 family protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXY2",
    "length": 139,
    "modifications": "ident$Oxidation$FTC$SPITC$Label:13C(1)2H(3)+Oxidation$Carbamidomethyl",
    "modified_positions": 5,
    "name": "DUF1499 domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXY5",
    "length": 271,
    "modifications": "Ethyl$Oxidation$hex(2)hexnac(2)dhex(1)$Diisopropylphosphate$acetyl_2h(3)$Thiophospho$Thiazolidine$Propiophenone$Dimethyl$OxArgBiotin$Methylthio$Formyl$Decanoyl$methylol$hex(1)pent(2)$hex(1)hexa(1)",
    "modified_positions": 16,
    "name": "Aminodeoxychorismate lyase",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZXZ1",
    "length": 128,
    "modifications": "Delta:H(4)C(3)",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXZ2",
    "length": 297,
    "modifications": "hex(1)hexnac(1)dhex(1)$Delta:H(2)C(5)$hexnac(1)dhex(1)$Propyl$Carboxymethyl$Octanoyl$Carbamidomethyl$Dehydrated",
    "modified_positions": 9,
    "name": "Aspartate carbamoyltransferase catalytic subunit",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZXZ5",
    "length": 254,
    "modifications": "neugc",
    "modified_positions": 4,
    "name": "Type II/III secretion system protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZY00",
    "length": 326,
    "modifications": "Oxidation$dhex(1)hex(3)$Methyl$GG$Cresylphosphate$Biotin-PEO-Amine$Dicarbamidomethyl$CHDH$Formyl$Carbamidomethyl$Acetylhypusine$glycidamide",
    "modified_positions": 11,
    "name": "Adenosine deaminase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZY09",
    "length": 177,
    "modifications": "hex(1)pent(2)me(1)$Oxidation$dhex",
    "modified_positions": 4,
    "name": "Spore maturation protein B",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZY11",
    "length": 356,
    "modifications": "Formyl$Delta:H(4)C(3)O(2)$bacillosamine",
    "modified_positions": 3,
    "name": "DUF1460 domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZY13",
    "length": 132,
    "modifications": "Met->Hse$Ethyl+Deamidated$neugc$Ethyl$methylol",
    "modified_positions": 8,
    "name": "PHA accumulation regulator DNA-binding N-terminal domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZY14",
    "length": 248,
    "modifications": "dhex(1)hex(3)hexnac(1)$Oxidation$pupylation$Gln->pyro-Glu$bacillosamine$icpl_2h(4)$Propyl$dhex(2)hex(2)hexnac(1)$Retinylidene$dnic",
    "modified_positions": 11,
    "name": "Acetyoacetyl CoA reductase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZY18",
    "length": 274,
    "modifications": "Oxidation$AMTzHexNAc2$hex(1)hexnac(2)dhex(1)$Ammonium$Trimethyl$methyl_2h(3)$O-Methylphosphate$Propyl$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Formamidopyrimidine-DNA glycosylase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZY19",
    "length": 206,
    "modifications": "Diphthamide$Oxidation$BMP-piperidinol$Carbamidomethyl$Delta:H(8)C(6)O(1)",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZY20",
    "length": 355,
    "modifications": "Oxidation$dhex(2)hex(2)hexa(1)$hep$Propiophenone$dhex(1)hex(2)hexa(1)hexnac(1)$Amino$PyruvicAcidIminyl$Carbamidomethyl$GEE$O-pinacolylmethylphosphonate",
    "modified_positions": 15,
    "name": "DNA polymerase IV",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZY27",
    "length": 199,
    "modifications": "Oxidation$Methyl$hexnac$Delta:H(5)C(2)$Dioxidation",
    "modified_positions": 5,
    "name": "Outer-membrane lipoprotein LolB",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZY30",
    "length": 315,
    "modifications": "Oxidation$hex(2)$Gly$Delta:H(2)C(3)$CAMthiopropanoyl$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 12,
    "name": "Ribose-phosphate pyrophosphokinase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZY33",
    "length": 427,
    "modifications": "Carbamidomethyl$Oxidation$Dioxidation",
    "modified_positions": 3,
    "name": "Lysosomal dipeptide transporter MFSD1",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZY34",
    "length": 129,
    "modifications": "Hydroxamic_acid$Iodoacetanilide$Methyl+Deamidated",
    "modified_positions": 3,
    "name": "SseB protein N-terminal domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZY37",
    "length": 215,
    "modifications": "methyl_2h(3)13c(1)$Lysbiotinhydrazide$Deamidated$Pro->HAVA$acetyl_13c(2)",
    "modified_positions": 6,
    "name": "Pyridoxine/pyridoxamine 5'-phosphate oxidase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZY40",
    "length": 409,
    "modifications": "Delta:H(2)C(2)$G-H1$Oxidation$hexnac$HNE$hex(1)hexnac(1)neuac(1)sulf(1)$dhex(1)hex(2)hexa(1)hexnac(1)$Trp->Kynurenin$Deamidated$Methamidophos-O$Delta:H(2)C(3)$Methylthio$Ethanolamine$Carbamidomethyl$Sulfide$Dioxidation",
    "modified_positions": 28,
    "name": "Dihydrolipoyllysine-residue succinyltransferase component of 2-oxoglutarate dehydrogenase complex",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZY42",
    "length": 240,
    "modifications": "Menadione-HQ$Oxidation$Gly$Met->Aha$Delta:H(2)C(3)O(1)$Pentylamine$Diisopropylphosphate$HN3_mustard$sulfo+amino$MG-H1$Cation:Li$Deamidated$dimethyl_2h(4)13c(2)$Carboxymethyl$AEC-MAEC$Methylphosphonate$Carbamidomethyl$dimethyl_2h(6)",
    "modified_positions": 27,
    "name": "Succinate dehydrogenase iron-sulfur subunit",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZY43",
    "length": 589,
    "modifications": "Dap-DSP$Gly$hex(1)hexnac(2)dhex(1)$Ammonium$RNPXL$Deoxy$Deamidated$Carbamidomethyl$dimethyl_2h(6)$Didehydro$Delta:H(6)C(3)O(1)$Delta:H(4)C(3)O(1)$Fluoro$sulfo+amino$Biotin:Thermo-21330$methyl_2h(3)$MesitylOxide$Biotin:Thermo-33033-H$Carbamyl$Oxidation$neugc$Ethanolyl$Hydroxymethyl$Glu->pyro-Glu+Methyl:2H(2)13C(1)$MicrocinC7$pupylation$diart6plex117$Methyl$Myristoyl+Delta:H(-4)$dimethyl_2h(4)13c(2)$diart6plex$EDT-iodoacetyl-PEO-biotin",
    "modified_positions": 60,
    "name": "Succinate dehydrogenase flavoprotein subunit",
    "unique_modifications": 32
  },
  {
    "id": "Q5ZY48",
    "length": 208,
    "modifications": "hex(1)hexnac(2)neuac(1)sulf(1)$Oxidation$Gly$EDT-maleimide-PEO-biotin$Quinone$Carbamidomethyl$Methylpyrroline$2-nitrobenzyl",
    "modified_positions": 8,
    "name": "Type 4 adapter protein LvgA",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZY49",
    "length": 187,
    "modifications": "Oxidation$Methyl+Deamidated$Ammonium$methyl_2h(3)$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Aminoglycoside N (6')-acetyltransferase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZY50",
    "length": 155,
    "modifications": "EDT-iodoacetyl-PEO-biotin$Oxidation$4-ONE$hex(1)neuac(1)",
    "modified_positions": 4,
    "name": "Acetyltransferase, GNAT family",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZY51",
    "length": 202,
    "modifications": "monomethylphosphothione$Pro->Pyrrolidinone$PET$DimethylamineGMBS$EHD-diphenylpentanone$Propionyl",
    "modified_positions": 4,
    "name": "Uridine kinase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZY54",
    "length": 282,
    "modifications": "Oxidation$Ammonium$Carbofuran$Deamidated$Carboxymethyl$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 6,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZY55",
    "length": 276,
    "modifications": "Deamidated$Oxidation$Pro->pyro-Glu$Carbonyl",
    "modified_positions": 5,
    "name": "Aldo/keto reductases",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZY57",
    "length": 310,
    "modifications": "Oxidation$Gluratylation$GG$Dicarbamidomethyl$QQQTGG$MesitylOxide",
    "modified_positions": 6,
    "name": "Phytanoyl-CoA dioxygenase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZY61",
    "length": 256,
    "modifications": "Oxidation$Diisopropylphosphate$dhex$hexnac$Carbamidomethyl$Decanoyl$clip_traq_3",
    "modified_positions": 8,
    "name": "Acyl-[acyl-carrier-protein]--UDP-N-acetylglucosamine O-acyltransferase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZY62",
    "length": 150,
    "modifications": "Delta:H(2)C(2)$Oxidation$Pro->Pyrrolidinone$Formyl$Thiazolidine",
    "modified_positions": 6,
    "name": "3-hydroxyacyl-[acyl-carrier-protein] dehydratase FabZ",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZY64",
    "length": 339,
    "modifications": "maleimide3$LG-anhydrolactam$Carbamidomethyl$Cation:Ni[II]",
    "modified_positions": 4,
    "name": "UDP-3-O-(3-hydroxymyristoyl) glucosamine N-acyltransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZY65",
    "length": 166,
    "modifications": "Delta:H(2)C(2)$Oxidation$Gln->pyro-Glu$Methyl+Deamidated$Hydroxamic_acid$BITC$Deoxy$Lys->AminoadipicAcid$clip_traq_3$Ammonia-loss$Dehydrated",
    "modified_positions": 16,
    "name": "Outer membrane protein OmpH",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZY70",
    "length": 423,
    "modifications": "Oxidation$Cation:Li$Deamidated$ethylsulfonylethyl$Ser->LacticAcid$2-nitrobenzyl$Carbamyl",
    "modified_positions": 14,
    "name": "Phosphatidylcholine hydrolyzing phospholipase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZY77",
    "length": 411,
    "modifications": "Delta:H(2)C(2)$AHA-SS_CAM$Oxidation",
    "modified_positions": 3,
    "name": "Argininosuccinate lyase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZY82",
    "length": 104,
    "modifications": "Oxidation$Diisopropylphosphate",
    "modified_positions": 2,
    "name": "Arginine repressor",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZY85",
    "length": 191,
    "modifications": "Oxidation$Carboxymethyl$spermine",
    "modified_positions": 2,
    "name": "Cupin",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZY86",
    "length": 431,
    "modifications": "Pyro-carbamidomethyl$hex(3)hexnac(1)$Gly$Oxidation$Delta:H(2)C(3)O(1)$O-Dimethylphosphate$Hydroxamic_acid$Ammonium$methyl_2h(3)$Myristoyl+Delta:H(-4)$Ethylphosphate$AEC-MAEC$Carbamidomethyl$Unknown:306$galactosyl",
    "modified_positions": 17,
    "name": "Adenylosuccinate synthetase",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZY89",
    "length": 495,
    "modifications": "Nmethylmaleimide$GluGluGlu$Oxidation$SulfanilicAcid:13C(6)$methyl_2h(3)13c(1)$Propionamide$Hydroxycinnamyl$icpl_13c(6)2h(4)$dhex(1)hex(2)hexa(1)$Dihydroxyimidazolidine$Glu$Nmethylmaleimide+water$Iodoacetanilide$Unknown:234$Cytopiloyne$Carbamidomethyl",
    "modified_positions": 23,
    "name": "Ankyrin repeat-containing protein",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZY97",
    "length": 89,
    "modifications": "Cation:Mg[II]$Oxidation$Cation:Na",
    "modified_positions": 4,
    "name": "Sugar transport PTS system phosphocarrier HPr protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYA2",
    "length": 336,
    "modifications": "methylsulfonylethyl$Oxidation$Gly$Dehydrated$GluGluGluGlu$LG-anhyropyrrole$Deoxy$Deamidated$Diethylphosphothione$Nethylmaleimide+water$Quinone$Carbamidomethyl$Thiazolidine$methylol$hexnac(2)$Sulfide$Dioxidation",
    "modified_positions": 36,
    "name": "Probable fructose-bisphosphate aldolase class 1",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZYA8",
    "length": 145,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Deamidated$Methylthio$UgiJoullieProGly$Carbamidomethyl",
    "modified_positions": 6,
    "name": "3-dehydroquinate dehydratase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYA9",
    "length": 160,
    "modifications": "Oxidation$Diethyl$Cation:Li$2-monomethylsuccinyl$esp$Methamidophos-S$Hypusine$Propionyl",
    "modified_positions": 12,
    "name": "Biotin carboxyl carrier protein of acetyl-CoA carboxylase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYB1",
    "length": 289,
    "modifications": "Oxidation$Gly$PET$glucuronyl$NEM:2H(5)$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Ribosomal protein L11 methyltransferase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYB2",
    "length": 529,
    "modifications": "G-H1$Oxidation$Gly$PhosphoCytidine$Deoxy$Lipoyl$MesitylOxide$PyruvicAcidIminyl$Carbamidomethyl",
    "modified_positions": 16,
    "name": "Bifunctional purine biosynthesis protein PurH",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYB3",
    "length": 261,
    "modifications": "Carbamidomethyl$hex(1)pent(2)me(1)$Cresylphosphate",
    "modified_positions": 6,
    "name": "IcmH (DotU)",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYB5",
    "length": 418,
    "modifications": "Chlorination",
    "modified_positions": 1,
    "name": "TphA (ProP)",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYB9",
    "length": 194,
    "modifications": "Oxidation$Delta:H(2)C(3)$Carboxymethyl$Delta:H(6)C(3)O(1)$EHD-diphenylpentanone",
    "modified_positions": 4,
    "name": "IcmC (DotE)",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYC0",
    "length": 269,
    "modifications": "Oxidation$Decarboxylation$Phosphopropargyl$Gln->pyro-Glu$Deoxy$Deamidated$Glu$Ser->LacticAcid$deamidated_18o(1)$DAET$Ammonia-loss$Unknown:162$O-pinacolylmethylphosphonate",
    "modified_positions": 14,
    "name": "IcmG (DotF)",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZYC1",
    "length": 1048,
    "modifications": "Gly$HN2_mustard$icdid_2h(6)$Deoxy$Deamidated$CAMthiopropanoyl$acetyl_13c(2)$Carbamidomethyl$Unknown:306$methylol$Delta:H(6)C(3)O(1)$Decarboxylation$Diisopropylphosphate$HNE-Delta:H(2)O$Isopropylphospho$Lipoyl$dhex(1)hex(1)hexnac(2)sulf(1)$neiaa$dhex(1)hex(1)$Ammonia-loss$Cation:Al[III]$monomethylphosphothione$Acetyl$4-ONE$Carbofuran$BITC$15N-oxobutanoic$Lys->MetOx$LG-anhydrolactam$Methamidophos-S$maleimide$Nmethylmaleimide$GG$Gly-loss+Amide$hexnac$Pro->Pyrrolidone",
    "modified_positions": 53,
    "name": "IcmE (DotG)",
    "unique_modifications": 36
  },
  {
    "id": "Q5ZYC3",
    "length": 212,
    "modifications": "Oxidation$Methyl$Trimethyl$Propyl$Deamidated$dhex(1)hex(1)",
    "modified_positions": 8,
    "name": "IcmL (DotI)",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYC5",
    "length": 189,
    "modifications": "Carbamidomethyl$Arg->Npo$LG-lactam-R",
    "modified_positions": 3,
    "name": "LphA (DotK)",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYD0",
    "length": 114,
    "modifications": "Oxidation$Propionamide$GG$gist-quat$Delta:H(2)C(3)O(1)$Deoxy$Deamidated$PyruvicAcidIminyl$Carbamidomethyl$Unknown:162$glycidamide",
    "modified_positions": 15,
    "name": "Type 4 adapter protein IcmS",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZYD1",
    "length": 86,
    "modifications": "O-Et-N-diMePhospho",
    "modified_positions": 1,
    "name": "IcmT",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYD7",
    "length": 203,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Oxidation$cGMP+RMP-loss$Carboxy$Ser->LacticAcid$Carbamidomethyl",
    "modified_positions": 5,
    "name": "SAM-dependent methyltransferase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYD9",
    "length": 126,
    "modifications": "acetyl_13c(2)$Carbamidomethyl$Carboxy$Ethanolyl",
    "modified_positions": 5,
    "name": "HTH hxlR-type domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZYE3",
    "length": 450,
    "modifications": "Propiophenone$dimethyl_2h(4)13c(2)$Lys->MetOx$dimethyl_2h(6)$dhex(2)hex(1)hexnac(2)kdn(1)",
    "modified_positions": 5,
    "name": "Outer membrane efflux protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYE6",
    "length": 77,
    "modifications": "Deamidated$Ammonia-loss",
    "modified_positions": 1,
    "name": "Cold shock protein CspD",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYF3",
    "length": 335,
    "modifications": "Carbamidomethyl$Arg->GluSA",
    "modified_positions": 2,
    "name": "Glucokinase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYF7",
    "length": 81,
    "modifications": "Argbiotinhydrazide",
    "modified_positions": 1,
    "name": "HTH cro/C1-type domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYF8",
    "length": 302,
    "modifications": "Oxidation$Delta:H(4)C(3)O(2)$Unknown:248$Biotin-tyramide$GG$Trimethyl$Methylamine$Succinyl$pent(1)hexnac(1)$AEC-MAEC$Lys->Allysine$Menadione$Delta:H(4)C(6)$Dioxidation",
    "modified_positions": 13,
    "name": "Probable alpha-L-glutamate ligase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZYG3",
    "length": 242,
    "modifications": "Oxidation$Phe->CamCys$neugc$glucuronyl$dhex(1)hex(2)hexnac(2)neugc(1)$DNCB_hapten",
    "modified_positions": 8,
    "name": "SURF1-like protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYG4",
    "length": 182,
    "modifications": "Carbamidomethyl$Oxidation",
    "modified_positions": 6,
    "name": "Inner (Transmembrane) protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYG6",
    "length": 113,
    "modifications": "SulfanilicAcid:13C(6)$Oxidation$Myristoleyl$Gln->pyro-Glu$Pyro-carbamidomethyl$Glu->pyro-Glu$GluGluGluGlu$CAMthiopropanoyl$Carbamidomethyl",
    "modified_positions": 14,
    "name": "Carboxymuconolactone decarboxylase-like domain-containing protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYG7",
    "length": 196,
    "modifications": "Oxidation$Crotonyl$hex(1)neuac(1)$hydroxyisobutyryl$Malonyl$Carbamidomethyl$Thiazolidine",
    "modified_positions": 8,
    "name": "Coiled-coil protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZYH0",
    "length": 567,
    "modifications": "Oxidation$GG$hex(1)hexnac(1)neuac(1)neugc(1)$icpl$Dicarbamidomethyl$maleimide$Carbamidomethyl$Cation:Mg[II]$hexnac(2)$Delta:H(4)C(3)O(1)$Propionyl$Dioxidation",
    "modified_positions": 18,
    "name": "Putative ankyrin-repeat containing protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZYH2",
    "length": 458,
    "modifications": "hex(1)neuac(1)pent(1)$G-H1$Oxidation$Methyl$Acetyl$Cation:Li$Deamidated$gist-quat_2h(9)$EQIGG$spermine$gist-quat_2h(6)$PyruvicAcidIminyl$clip_traq_3$Delta:H(6)C(3)O(1)$Carbamyl",
    "modified_positions": 23,
    "name": "Signal recognition particle protein",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZYH3",
    "length": 86,
    "modifications": "Dansyl$Dap-DSP$Oxidation$Amidine",
    "modified_positions": 4,
    "name": "Small ribosomal subunit protein bS16",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZYH5",
    "length": 169,
    "modifications": "Methamidophos-O$Oxidation$Amidine",
    "modified_positions": 5,
    "name": "Ribosome maturation factor RimM",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYH6",
    "length": 250,
    "modifications": "Cation:Al[III]$Oxidation$Dimethylphosphothione$SMA$Carbamidomethyl",
    "modified_positions": 8,
    "name": "tRNA (guanine-N(1)-)-methyltransferase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYH7",
    "length": 121,
    "modifications": "Oxidation$Dehydrated$Glu->pyro-Glu$dileu4plex117$trimethyl_2h(9)$benzoyl$succinyl_2h(4)$dileu4plex115",
    "modified_positions": 9,
    "name": "Large ribosomal subunit protein bL19",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYH8",
    "length": 151,
    "modifications": "Ethyl$pupylation$BHT$Delta:H(4)C(2)",
    "modified_positions": 4,
    "name": "Methylated DNA protein cysteine S-methyltransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZYI0",
    "length": 235,
    "modifications": "Oxidation$Tyr->Dha$DNPS$Carbamidomethyl$glycosyl$clip_traq_3",
    "modified_positions": 6,
    "name": "Zinc metalloprotease",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYI4",
    "length": 304,
    "modifications": "dhex(1)hexnac(3)$Oxidation$Gly$Propiophenone$Octanoyl$Carbamidomethyl$Thiazolidine",
    "modified_positions": 7,
    "name": "ABC transporter, ATP binding component",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZYI6",
    "length": 339,
    "modifications": "Oxidation$NDA$Dansyl$acetyl_2h(3)$Hydroxamic_acid$hep$gist-quat_2h(3)$Cation:Li$Carboxymethyl$Carbamidomethyl$serotonylation",
    "modified_positions": 16,
    "name": "Heat shock protein HtpX",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZYJ1",
    "length": 157,
    "modifications": "Trioxidation$Carbamidomethyl$Delta:H(2)C(3)O(1)",
    "modified_positions": 3,
    "name": "DUF4442 domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYJ3",
    "length": 484,
    "modifications": "dileu4plex$Oxidation$Gly$Methyl$Propionamide$GG$Iodoacetanilide:13C(6)$Dicarbamidomethyl$BDMAPP$dileu4plex117$Carboxy$Glu$dileu4plex118$dileu4plex115$Carbamidomethyl$succinyl_2h(4)$Ammonia-loss$hex(1)hexa(1)",
    "modified_positions": 17,
    "name": "Ribosomal protein S6 modification protein",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZYJ7",
    "length": 199,
    "modifications": "icpl_13c(6)2h(4)$HN3_mustard$Oxidation",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYK2",
    "length": 144,
    "modifications": "Oxidation$Gly$hexnac$Deamidated$Delta:H(2)C(3)$Carboxymethyl$AEC-MAEC$Ethanolamine$Carbamidomethyl$Unknown:306$Carbamyl",
    "modified_positions": 22,
    "name": "Oligoketide cyclase/lipid transporter protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZYK6",
    "length": 277,
    "modifications": "Unknown:248$EDT-maleimide-PEO-biotin$GG$Tris$Dicarbamidomethyl$Glu->pyro-Glu+Methyl:2H(2)13C(1)$DYn-2$Carbamidomethyl$Delta:H(4)C(3)O(1)",
    "modified_positions": 8,
    "name": "Diaminopimelate epimerase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYL0",
    "length": 425,
    "modifications": "Oxidation$Phe->CamCys$Gln->pyro-Glu$Oxidation+NEM$neuac$Deamidated$Met-loss+Acetyl$clip_traq_2$Nethylmaleimide$Ethanedithiol",
    "modified_positions": 15,
    "name": "3-oxoacyl-(Acyl carrier protein) synthase II, N-terminal",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZYL1",
    "length": 430,
    "modifications": "OxProBiotin$Pyridylethyl$Gln->pyro-Glu$Oxidation$Dimethylphosphothione$15N-oxobutanoic$Carbamidomethyl$a-type-ion",
    "modified_positions": 10,
    "name": "3-oxoacyl-[acyl-carrier-protein] synthase 2",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYL3",
    "length": 137,
    "modifications": "Gly$Trioxidation$Carboxy$GGQ$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Acyl carrier protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYL4",
    "length": 252,
    "modifications": "hex(1)hexnac(1)phos(1)$Menadione-HQ$Oxidation$Gly$Delta:H(-4)O(3)$AccQTag$GG$icpl_13c(6)2h(4)$Carboxy$Deoxy$Ser->LacticAcid$PyruvicAcidIminyl$Carbamidomethyl$Menadione",
    "modified_positions": 17,
    "name": "Glucose-1-dehydrogenase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZYL7",
    "length": 127,
    "modifications": "Oxidation$Gly$GG$HNE$Propiophenone$Dicarbamidomethyl$QEQTGG$Carbamidomethyl$Thiazolidine$hex(1)hexnac(1)$Didehydro$Biotin-PEG-PRA",
    "modified_positions": 15,
    "name": "Large ribosomal subunit protein bL17",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZYL8",
    "length": 330,
    "modifications": "Gly$FTC$phosphoRibosyl$Dipyridyl$clip_traq_4$Deamidated$hex(1)hexnac(1)neuac(2)ac(2)$Met->Hsl$Carbamidomethyl$Biotin$Dethiomethyl$Can-FP-biotin$Isopropylphospho$Phosphogluconoylation$hex(1)hexnac(2)pent(1)$gist-quat_2h(9)$Oxidation$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Gln->pyro-Glu",
    "modified_positions": 22,
    "name": "DNA-directed RNA polymerase subunit alpha",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZYL9",
    "length": 206,
    "modifications": "Diethylphosphate$Cation:Na$Deamidated$Carbamidomethyl$FMN$FMNC$Sulfo$Oxidation$Dansyl$acetyl_2h(3)$gist-quat$bemad_st_2h(6)$BITC$SMA$Cation:Mg[II]$Ethyl+Deamidated$Phospho$tmab_2h(9)$Dioxidation",
    "modified_positions": 18,
    "name": "Small ribosomal subunit protein uS4",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZYM0",
    "length": 132,
    "modifications": "Oxidation$Gln->pyro-Glu$dhex$Deamidated$Carboxymethyl$AEC-MAEC$Carbamidomethyl$Ammonia-loss",
    "modified_positions": 9,
    "name": "Small ribosomal subunit protein uS11",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYM5",
    "length": 61,
    "modifications": "HydroxymethylOP$Deamidated",
    "modified_positions": 2,
    "name": "Large ribosomal subunit protein uL30",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYM8",
    "length": 179,
    "modifications": "cGMP$Oxidation$Gln->pyro-Glu$Formyl$Cytopiloyne$O-pinacolylmethylphosphonate",
    "modified_positions": 9,
    "name": "Large ribosomal subunit protein uL6",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYM9",
    "length": 131,
    "modifications": "Oxidation$Gluratylation$Deoxy$Deamidated$Carbamidomethyl$Thiazolidine",
    "modified_positions": 9,
    "name": "Small ribosomal subunit protein uS8",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYN0",
    "length": 100,
    "modifications": "Oxidation$Cys->Oxoalanine$Pro->Pyrrolidinone$TMPP-Ac$Deamidated$Biotin:Thermo-21345$Carbamidomethyl$Furan",
    "modified_positions": 10,
    "name": "Small ribosomal subunit protein uS14",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYN3",
    "length": 121,
    "modifications": "pent(2)$Oxidation$hex(5)$SPITC:13C(6)$deamidated_18o(1)$Thiazolidine$glycosyl$GPIanchor",
    "modified_positions": 10,
    "name": "Large ribosomal subunit protein uL14",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYN4",
    "length": 84,
    "modifications": "Carbamidomethyl$Oxidation$Didehydro$Octanoyl",
    "modified_positions": 10,
    "name": "Small ribosomal subunit protein uS17",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZYN5",
    "length": 64,
    "modifications": "Oxidation$hex(2)$FTC$Glu->pyro-Glu$Tris$Lys->AminoadipicAcid$Lys->Allysine$Dehydrated",
    "modified_positions": 7,
    "name": "Large ribosomal subunit protein uL29",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYN6",
    "length": 137,
    "modifications": "Unknown:216$Trp->Hydroxykynurenin$Oxidation$Cresylphosphate$Glu->pyro-Glu$Carbamyl",
    "modified_positions": 12,
    "name": "Large ribosomal subunit protein uL16",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYP0",
    "length": 275,
    "modifications": "Oxidation$Cys->Oxoalanine$Diisopropylphosphate$Methyl$Tris$PEITC$Methamidophos-O$Deamidated$AEC-MAEC$Carbamidomethyl",
    "modified_positions": 17,
    "name": "Large ribosomal subunit protein uL2",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZYP1",
    "length": 98,
    "modifications": "dhex(2)hex(2)$Carboxymethyl",
    "modified_positions": 2,
    "name": "Large ribosomal subunit protein uL23",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYP5",
    "length": 396,
    "modifications": "Gly$icpl_2h(4)$Ammonium$Hydroxamic_acid$Cation:Na$dhex(2)hex(1)hexnac(3)$Deoxy$Deamidated$Quinone$methyl_2h(2)$Carbamidomethyl$Biotin$Delta:H(4)C(3)O(1)$Didehydro$Fluoro$dnic$Cation:Ca[II]$methyl_2h(3)13c(1)$Cys->Dha$Biotin:Thermo-21330$Carboxy->Thiocarboxy$N-dimethylphosphate$methyl_2h(3)$MTSL$Pro->HAVA$Ethanolamine$Carbonyl$Methylpyrroline$Sulfo$Ammonia-loss$Carbamyl$DMPO$dhex(1)hex(2)hexa(1)hexnac(2)$Sulfide$Oxidation$dhex(1)hex(2)hexnac(3)$gist-quat$HNE$Malonyl$Cation:K$Propyl$15N-oxobutanoic$Trioxidation$phosphohex$SMA$Ser->LacticAcid$hex(6)phos(1)$Cation:Mg[II]$hex(1)hexnac(1)$Dehydrated$CarbamidomethylDTT$Gln->pyro-Glu$Methyl$Trimethyl$Cation:Li$deamidated_18o(1)$Thiazolidine$Nitrene$Phospho$Dioxidation",
    "modified_positions": 86,
    "name": "Elongation factor Tu",
    "unique_modifications": 60
  },
  {
    "id": "Q5ZYP7",
    "length": 175,
    "modifications": "Gly$Delta:H(6)C(7)O(4)$Hydroxamic_acid$Diethylphosphate$hep$3-deoxyglucosone$Lys->AminoadipicAcid$Carbamidomethyl$Unknown:306$Fluoro$Cation:Ca[II]$Methyl+Deamidated$AccQTag$Acetyldeoxyhypusine$methyl_2h(3)$Oxidation$Cation:K$PEITC$Menadione$Dehydrated$Thiazolidine",
    "modified_positions": 25,
    "name": "Small ribosomal subunit protein uS7",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZYQ1",
    "length": 126,
    "modifications": "Biotin:Thermo-88310",
    "modified_positions": 1,
    "name": "Large ribosomal subunit protein bL12",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYQ2",
    "length": 177,
    "modifications": "Oxidation$bemad_st_2h(6)$Deamidated$Cation:Fe[II]$Ethyl",
    "modified_positions": 7,
    "name": "Large ribosomal subunit protein uL10",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYQ4",
    "length": 144,
    "modifications": "dhex(1)hexnac(3)$Oxidation$Deoxy$Iodoacetanilide$GluGlu",
    "modified_positions": 6,
    "name": "Large ribosomal subunit protein uL11",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYR2",
    "length": 163,
    "modifications": "methylsulfonylethyl$Oxidation$Crotonyl$Saligenin$Lysbiotinhydrazide$AEBS$LG-anhyropyrrole$Carbamidomethyl$Cytopiloyne+water$EHD-diphenylpentanone",
    "modified_positions": 10,
    "name": "Dihydrofolate reductase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZYR4",
    "length": 839,
    "modifications": "Oxidation$Phosphopropargyl$HNE-Delta:H(2)O$BDMAPP$Carbonyl$clip_traq_2",
    "modified_positions": 12,
    "name": "LPS-assembly protein LptD",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYR6",
    "length": 220,
    "modifications": "HNE+Delta:H(2)$Oxidation$Dap-DSP",
    "modified_positions": 6,
    "name": "Mannose-1-phosphate guanyltransferase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYR7",
    "length": 230,
    "modifications": "Oxidation$Gln->pyro-Glu$Methyl$Hydroxamic_acid$Deoxy$Deamidated$Carbamidomethyl$Unknown:306",
    "modified_positions": 8,
    "name": "Type 4 apparatus protein DotY",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYS1",
    "length": 401,
    "modifications": "SulfanilicAcid:13C(6)$hex(1)hexnac(2)dhex(1)$Saligenin$Acetyldeoxyhypusine$hep$Propiophenone$Arg->Npo",
    "modified_positions": 7,
    "name": "Lipoprotein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZYS4",
    "length": 189,
    "modifications": "Gly$probiotinhydrazide$hexnac$Thiophospho$dhex(1)hex(1)hexnac(1)kdn(1)$Deamidated$dileu4plex115$Carbamidomethyl$GluGlu",
    "modified_positions": 14,
    "name": "Elongation factor P",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYS8",
    "length": 403,
    "modifications": "hex(1)hexa(1)$Oxidation$Biotin-tyramide$Iminobiotin$propyl_2h(6)$MesitylOxide$Carboxymethyl$Carbamidomethyl$Delta:H(6)C(3)O(1)$BHTOH",
    "modified_positions": 16,
    "name": "Formate dehydrogenase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZYS9",
    "length": 258,
    "modifications": "DNCB_hapten$Formyl$methyl_2h(2)$Carbamidomethyl$Thiazolidine",
    "modified_positions": 6,
    "name": "Methyltransferase domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYT4",
    "length": 740,
    "modifications": "Oxidation$methyl_2h(3)13c(1)$icpl_2h(4)$Cation:Na$15N-oxobutanoic$Deoxy$Carbamidomethyl$Sulfo$dnic",
    "modified_positions": 15,
    "name": "Sensory box protein, GGDEF family protein, LssE",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYT5",
    "length": 499,
    "modifications": "Palmitoyl$Oxidation$Saligenin$AEBS$BADGE$TNBS$Propiophenone$benzylguanidine",
    "modified_positions": 10,
    "name": "Ras GEF",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYT7",
    "length": 287,
    "modifications": "Oxidation$Phosphopropargyl$Difuran$Trimethyl$Deamidated$Unknown:234$Carbamidomethyl$Ammonia-loss",
    "modified_positions": 14,
    "name": "Transcriptional regulator, LysR family",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYU3",
    "length": 198,
    "modifications": "Oxidation$Met->Aha$galactosyl",
    "modified_positions": 3,
    "name": "5'-deoxynucleotidase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYU9",
    "length": 212,
    "modifications": "Oxidation$GG$Dicarbamidomethyl$Ser->LacticAcid$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Type-4 uracil-DNA glycosylase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYV1",
    "length": 132,
    "modifications": "hex(1)hexnac(1)dhex(1)me(1)",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYV3",
    "length": 647,
    "modifications": "Nmethylmaleimide$Unknown:216$Oxidation$Gly$Diisopropylphosphate$acetyl_2h(3)$hydroxyisobutyryl$Nitro$icpl_13c(6)2h(4)$3-deoxyglucosone$Nethylmaleimide+water$Carbamidomethyl",
    "modified_positions": 15,
    "name": "Uncharacterized protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZYV4",
    "length": 330,
    "modifications": "Delta:H(2)C(2)$Oxidation$dhex(2)hex(3)hexnac(1)sulf(1)$dimethyl_2h(6)$dimethyl_2h(4)13c(2)$Arg->Orn$Thiazolidine$Carbamyl$Delta:H(10)C(8)O(1)",
    "modified_positions": 10,
    "name": "Multidrug resistance secretion protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYV6",
    "length": 448,
    "modifications": "GPIanchor$BHT$Delta:H(6)C(3)O(1)$azole",
    "modified_positions": 4,
    "name": "Outer membrane channel protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZYW1",
    "length": 414,
    "modifications": "hex$hex(1)hexnac(1)dhex(1)$Oxidation$Gly$Methyl$O-Dimethylphosphate$Ethanolyl$Ethylphosphate$Ethanolamine$Carbamidomethyl",
    "modified_positions": 10,
    "name": "DEAD-box ATP-dependent RNA helicase RhpA",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZYW4",
    "length": 317,
    "modifications": "Lys->CamCys$HCysThiolactone$Ethanolyl$clip_traq_4$Carbamidomethyl$clip_traq_3",
    "modified_positions": 6,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYW8",
    "length": 199,
    "modifications": "Unknown:216$Ethyl+Deamidated$Oxidation$Nitrosyl$glucosone$Deamidated$Deoxy$DNCB_hapten$UgiJoullieProGlyProGly$Carbamidomethyl$Ammonia-loss$Dehydrated",
    "modified_positions": 15,
    "name": "Short chain dehydrogenase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZYW9",
    "length": 295,
    "modifications": "Oxidation$Methyl$Thiophospho$Carbonyl$Didehydro$hex(1)hexa(1)",
    "modified_positions": 6,
    "name": "D-3-phosphoglycerate dehydrogenase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYX1",
    "length": 259,
    "modifications": "Retinylidene$Carbamidomethyl$Dimethylphosphothione$PET",
    "modified_positions": 5,
    "name": "DNA repair protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZYX4",
    "length": 264,
    "modifications": "Oxidation$PET$Diethyl$Diethylphosphate$O-Isopropylmethylphosphonate$Cation:Li$Unknown:234$CresylSaligeninPhosphate",
    "modified_positions": 11,
    "name": "Lipolytic enzyme",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYY2",
    "length": 277,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Heme oxygenase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYY4",
    "length": 368,
    "modifications": "Oxidation$hex(4)hexa(1)hexnac(1)$AccQTag$Cresylphosphate$Cation:Ag$Biotin:Thermo-21345$3-deoxyglucosone$Carbamidomethyl",
    "modified_positions": 10,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYY5",
    "length": 465,
    "modifications": "Oxidation$dhex(1)hex(2)hexnac(2)neugc(1)$Lipoyl$3-deoxyglucosone$Carbamidomethyl$Delta:H(8)C(6)O(1)$Fluoro",
    "modified_positions": 10,
    "name": "Multidrug efflux protein, outer membrane component",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZYZ3",
    "length": 166,
    "modifications": "Oxidation$Delta:H(2)C(5)",
    "modified_positions": 3,
    "name": "N5-carboxyaminoimidazole ribonucleotide mutase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYZ6",
    "length": 294,
    "modifications": "Oxidation$HN2_mustard$Decarboxylation$glucuronyl$IodoU-AMP$Hydroxymethyl$Cation:Fe[III]$MDCC$Isopropylphospho$Carbamidomethyl$CresylSaligeninPhosphate",
    "modified_positions": 14,
    "name": "Transcriptional regulator, LysR family",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZZ05",
    "length": 137,
    "modifications": "Oxidation",
    "modified_positions": 2,
    "name": "Membrane protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZ06",
    "length": 512,
    "modifications": "Unknown:216$MercaptoEthanol$Oxidation$Decarboxylation$hexnac$Iodoacetanilide:13C(6)$Dimethylphosphothione$dhex(1)hex(2)$Trioxidation$Carbamidomethyl$glycosyl$hex(3)",
    "modified_positions": 14,
    "name": "Cryptochrome/photolyase family protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZZ07",
    "length": 232,
    "modifications": "Oxidation$Pro->Pyrrolidinone$biotinAcrolein298$LG-anhyropyrrole$Deamidated$LG-anhydrolactam$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 9,
    "name": "2-deoxy-D-gluconate-3-dehydrogenase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZZ08",
    "length": 595,
    "modifications": "Nmethylmaleimide$Oxidation$Dimethylphosphothione$Deoxy$Delta:H(2)C(3)$Methylphosphonate$Carbamidomethyl$GEE$hexnac(2)$Phospho",
    "modified_positions": 12,
    "name": "DhaL domain-containing protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZZ15",
    "length": 424,
    "modifications": "hex$Oxidation$diart6plex115$diart6plex117$glucosylgalactosyl$Propiophenone$NHS-LC-Biotin$diart6plex$UgiJoullieProGly$DimethylpyrroleAdduct$Carbamidomethyl$hexnac(2)$Fluoro",
    "modified_positions": 15,
    "name": "Coiled-coil protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZZ16",
    "length": 334,
    "modifications": "OxLysBiotinRed$Delta:H(4)C(2)O(-1)S(1)$Methyl+Deamidated$Hydroxamic_acid$BHT$Dioxidation",
    "modified_positions": 11,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZZ17",
    "length": 749,
    "modifications": "hep$Deamidated$methylol$Phosphogluconoylation$Lipoyl$Oxidation$Carboxyethyl$PyridoxalPhosphate$Propyl$Ser->LacticAcid$dhex(1)hex(1)hexnac(1)neugc(1)$O-pinacolylmethylphosphonate$Lys->CamCys$CarboxymethylDMAP$Gln->pyro-Glu$Delta:H(-4)O(3)$Trimethyl$Tris$Carboxymethyl$Pro->Pyrrolidone",
    "modified_positions": 32,
    "name": "Catalase-peroxidase 2",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZZ26",
    "length": 246,
    "modifications": "Oxidation$Glu->pyro-Glu+Methyl$PET$Ammonium$bemad_c_2h(6)$Succinyl$deamidated_18o(1)$Carbonyl$Ethanolamine$Carbamidomethyl$Thiazolidine$Carbamyl$galactosyl",
    "modified_positions": 10,
    "name": "ABC sugar transporter, ATP binding protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZZ27",
    "length": 294,
    "modifications": "Menadione-HQ$Oxidation$Delta:H(4)C(2)O(-1)S(1)$Ethanolyl$Biotin:Thermo-21345$esp$DimethylpyrroleAdduct$Methamidophos-S",
    "modified_positions": 7,
    "name": "ABC sugar transporter, periplasmic sugar binding protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZZ29",
    "length": 150,
    "modifications": "Oxidation$Nitrosyl$Methyl$Amino$Lys->AminoadipicAcid$methylol",
    "modified_positions": 8,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZZ31",
    "length": 280,
    "modifications": "Oxidation$Dimethylphosphothione$Trioxidation$glycosyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 6,
    "name": "Protease HtpX",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZZ35",
    "length": 480,
    "modifications": "Oxidation$Decarboxylation$Ethanolyl$LG-lactam-K$glucosone$DMPO",
    "modified_positions": 5,
    "name": "FAD monooxygenase, PheA/TfdB family",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZZ38",
    "length": 286,
    "modifications": "Oxidation$hydroxyisobutyryl$Hydroxamic_acid$Malonyl$NHS-fluorescein$Methylphosphonate$Carbamidomethyl",
    "modified_positions": 6,
    "name": "Transcriptional regulator, LysR",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZZ40",
    "length": 188,
    "modifications": "maleimide$Carboxy$deamidated_18o(1)",
    "modified_positions": 3,
    "name": "FBOX-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZ44",
    "length": 136,
    "modifications": "Oxidation$Unknown:248$Iodoacetanilide:13C(6)$Malonyl$BITC",
    "modified_positions": 5,
    "name": "Peptide chain release factor",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZZ45",
    "length": 294,
    "modifications": "TMPP-Ac$Propionamide",
    "modified_positions": 2,
    "name": "DUF808 domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZ49",
    "length": 93,
    "modifications": "dimethyl_2h(4)13c(2)$dimethyl_2h(6)$Delta:H(4)C(3)O(2)",
    "modified_positions": 2,
    "name": "SapA-like",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZ50",
    "length": 153,
    "modifications": "G-H1$Oxidation$hexnac$Unknown:234$HexN$Carbamidomethyl$CresylSaligeninPhosphate",
    "modified_positions": 8,
    "name": "Secondary thiamine-phosphate synthase enzyme",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZZ51",
    "length": 325,
    "modifications": "Oxidation$NDA$GG$Methylphosphonate$Carbamidomethyl$hex(1)pent(2)me(1)",
    "modified_positions": 8,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZZ53",
    "length": 70,
    "modifications": "icpl",
    "modified_positions": 1,
    "name": "ParD-like antitoxin of type II toxin-antitoxin system",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZ59",
    "length": 171,
    "modifications": "Ethanolamine",
    "modified_positions": 1,
    "name": "N-acetyltransferase domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZ62",
    "length": 446,
    "modifications": "Delta:H(2)C(2)$Oxidation$AMTzHexNAc2$hexnac$Biotin-phenacyl$Diethylphosphate$Formyl$CresylSaligeninPhosphate",
    "modified_positions": 12,
    "name": "Uncharacterized protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZZ74",
    "length": 396,
    "modifications": "AHA-SS_CAM$Oxidation$Decarboxylation$Trimethyl$Carbofuran$Propyl$AEC-MAEC$Carbamidomethyl$hex(1)hexa(1)",
    "modified_positions": 15,
    "name": "Phosphoglycerate kinase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZZ75",
    "length": 474,
    "modifications": "Carbamidomethyl$Met->Hse$Oxidation$Delta:H(2)C(3)O(1)$Propionamide$MG-H1$BITC$Methamidophos-O$Ethylphosphate$hex(1)pent(2)me(1)$Haloxon",
    "modified_positions": 14,
    "name": "Pyruvate kinase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZZ78",
    "length": 230,
    "modifications": "Oxidation$Dansyl$Saligenin$HPG$Carboxyethylpyrrole$Isopropylphospho",
    "modified_positions": 6,
    "name": "Activator of ProP osmoprotectant transporter",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZZ80",
    "length": 243,
    "modifications": "Oxidation$Dimethyl$hex(1)pent(3)$Deoxy$dhex(2)hex(2)hexnac(1)$Delta:H(4)C(2)$deamidated_18o(1)$pent(1)hexnac(1)$Carbamidomethyl$Ethyl$QTGG$Dioxidation",
    "modified_positions": 15,
    "name": "4-hydroxy-tetrahydrodipicolinate reductase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZZ86",
    "length": 200,
    "modifications": "methylsulfonylethyl$Biotin:Thermo-88317$Cresylphosphate$Acetyl$Dipyridyl$Isopropylphospho$Lys->MetOx$Ser->LacticAcid$2HPG$Carbamidomethyl$methylol$Fluoro",
    "modified_positions": 10,
    "name": "Probable GTP-binding protein EngB",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZZ89",
    "length": 432,
    "modifications": "pent(2)$Oxidation$Cation:Ca[II]$Dap-DSP$Ammonium$Biotin-PEO-Amine$Cation:K$Phosphoadenosine$methyl_2h(3)$Cation:Li$HydroxymethylOP$Deamidated$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Pro->Pyrrolidone",
    "modified_positions": 25,
    "name": "ABC transporter, ATP binding protein",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZZ91",
    "length": 176,
    "modifications": "Cation:Al[III]$Oxidation$Gly$Lysbiotinhydrazide$Deamidated$Carbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 9,
    "name": "IcmL-like",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZZ93",
    "length": 360,
    "modifications": "His+O(2)$dimethyl_2h(4)$Oxidation$Met->AspSA$Methyl+Deamidated$Hydroxamic_acid$Cation:Na$Deamidated$Amino$Carboxy$Carbamidomethyl$Cation:Mg[II]$DMPO",
    "modified_positions": 22,
    "name": "Aminomethyltransferase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZZ96",
    "length": 102,
    "modifications": "Methamidophos-O$Bromo$Haloxon",
    "modified_positions": 3,
    "name": "YCII-related domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZ97",
    "length": 484,
    "modifications": "Gly$QAT$Triton$Dicarbamidomethyl$Delta:H(4)C(5)O(1)$Carbamidomethyl$Fluoro$Biotin-PEO-Amine$gist-quat_2h(3)$Oxidation$propionyl_13c(3)$Dansyl$Amidine$NHS-LC-Biotin$Ub-VME$Menadione$methyl+acetyl_2h(3)$GG$EDT-iodoacetyl-PEO-biotin",
    "modified_positions": 26,
    "name": "Probable glycine dehydrogenase (decarboxylating) subunit 2",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZZ98",
    "length": 414,
    "modifications": "hex(1)neuac(1)pent(1)$Oxidation$dhex(1)hex(3)hexnac(2)$Delta:H(2)C(3)O(1)$bemad_st_2h(6)$Dihydroxyimidazolidine$Tyr->Dha$Delta:H(2)C(3)$Cytopiloyne$Ethyl$Met->Hpg",
    "modified_positions": 13,
    "name": "HDOD domain-containing protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZZA1",
    "length": 600,
    "modifications": "dhex(1)hex(2)hexa(1)hexnac(2)$dimethyl_2h(4)$Oxidation$Gln->pyro-Glu$hep$Carbonyl$Carboxymethyl$icpl_13c(6)$PyruvicAcidIminyl$Carbamidomethyl$trimethyl_13c(3)2h(9)$Dioxidation",
    "modified_positions": 18,
    "name": "2-oxoacid dehydrogenase acyltransferase catalytic domain-containing protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZZA2",
    "length": 89,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Transcriptional regulator",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZA6",
    "length": 198,
    "modifications": "DAET$Oxidation$Nitrosyl",
    "modified_positions": 4,
    "name": "Cytochrome oxidase-like",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZB0",
    "length": 260,
    "modifications": "Oxidation$Iminobiotin$LG-Hlactam-R$bacillosamine",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZB3",
    "length": 150,
    "modifications": "Biotin",
    "modified_positions": 1,
    "name": "Two component sensor and regulator, histidine kinase response regulator",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZC4",
    "length": 196,
    "modifications": "Oxidation$Deamidated$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Carbamidomethyl$clip_traq_2$methylol$Delta:H(4)C(3)O(1)",
    "modified_positions": 7,
    "name": "DUF4254 domain-containing protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZZC7",
    "length": 507,
    "modifications": "Cation:Al[III]$Delta:H(2)C(2)$Oxidation$Gln->pyro-Glu$Methyl$Pro->Pyrrolidinone$Hydroxamic_acid$Ammonia-loss$Deamidated$Nmethylmaleimide+water$Arg->GluSA",
    "modified_positions": 14,
    "name": "Membrane-associated HD superfamily hydrolase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZZC8",
    "length": 315,
    "modifications": "dimethyl_2h(4)$DAET$Carbamidomethyl$Ethanolyl",
    "modified_positions": 4,
    "name": "Glutathione synthase/ribosomal protein S6 modification enzyme",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZD1",
    "length": 255,
    "modifications": "Myristoyl+Delta:H(-4)$OxProBiotin",
    "modified_positions": 3,
    "name": "Dot/Icm T4SS effector",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZD3",
    "length": 400,
    "modifications": "Oxidation$NDA$Methyl$ZGB$GG$Gly$Dicarbamidomethyl$neuac$Cation:Na$Glu$spermine$Carbamidomethyl$Dioxidation",
    "modified_positions": 19,
    "name": "2-octaprenyl-6-methoxyphenol hydroxylase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZZD7",
    "length": 523,
    "modifications": "Pyro-carbamidomethyl$Oxidation$Gln->pyro-Glu$Methyl$Amidine$Deoxy$Methylamine$Delta:H(2)C(3)$hexnac(1)neugc(1)$Carbamidomethyl$clip_traq_2",
    "modified_positions": 13,
    "name": "Glutamate synthase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZZE1",
    "length": 392,
    "modifications": "OxLysBiotinRed$Oxidation$Methyl$Hydroxamic_acid$HN3_mustard$Acetyl$Propiophenone$Deamidated$SMA$murnac$Carbamidomethyl$Delta:H(8)C(6)O(1)$CresylSaligeninPhosphate",
    "modified_positions": 27,
    "name": "Aminotransferase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZZE7",
    "length": 395,
    "modifications": "Oxidation$Gly$Tween20$PS_Hapten$O-Isopropylmethylphosphonate$Phosphogluconoylation$ethylsulfonylethyl$Carbamidomethyl$Thiazolidine$Unknown:306$Menadione$Propionyl",
    "modified_positions": 13,
    "name": "Phospho-2-dehydro-3-deoxyheptonate aldolase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZZE9",
    "length": 392,
    "modifications": "dhex(2)hex(3)hexnac(1)sulf(1)$Ammonia-loss$dhex(2)hex(2)hexnac(2)sulf(1)",
    "modified_positions": 2,
    "name": "Multidrug resistance protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZF2",
    "length": 247,
    "modifications": "DNCB_hapten$Glu$GluGlu",
    "modified_positions": 3,
    "name": "Methylamine utilization protein MauE",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZF7",
    "length": 244,
    "modifications": "Acetyl$Oxidation$methyl_2h(3)$Formyl",
    "modified_positions": 6,
    "name": "Transferase enzyme",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZF8",
    "length": 297,
    "modifications": "methylsulfonylethyl$Oxidation$hep$AEBS$Ethanolyl$Dimethyl$Trioxidation$Carboxy$neiaa$Ethyl",
    "modified_positions": 10,
    "name": "2-methylisocitrate lyase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZZG2",
    "length": 292,
    "modifications": "Trimethyl$Didehydro",
    "modified_positions": 2,
    "name": "Acetyltransferase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZG8",
    "length": 233,
    "modifications": "hex(2)pent(2)$Cation:K$Carbonyl",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZH0",
    "length": 331,
    "modifications": "Oxidation$Carboxy$Carbamidomethyl$glucosone$Unknown:162",
    "modified_positions": 7,
    "name": "Integral membrane protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZZH6",
    "length": 253,
    "modifications": "Lys->CamCys$PEITC",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZH8",
    "length": 397,
    "modifications": "Ammonium$Guanidinyl$Biotin:Thermo-21328$Carbamidomethyl$GEE$Ahx2+Hsl",
    "modified_positions": 6,
    "name": "Leucine aminopeptidase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZZI2",
    "length": 213,
    "modifications": "Carbamidomethyl",
    "modified_positions": 3,
    "name": "3-demethoxyubiquinol 3-hydroxylase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZI4",
    "length": 463,
    "modifications": "Thrbiotinhydrazide$Propargylamine",
    "modified_positions": 2,
    "name": "Amino acid permease",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZJ2",
    "length": 461,
    "modifications": "SulfanilicAcid:13C(6)$Oxidation$hex(2)$Nitrosyl$Glu->pyro-Glu$BisANS$dhex(1)hex(4)$dhex(1)hex(1)hexnac(2)sulf(1)$hexnac(2)$Ammonia-loss",
    "modified_positions": 14,
    "name": "Outer membrane efflux protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZZK1",
    "length": 85,
    "modifications": "HCysThiolactone$Deamidated$succinyl_13c(4)$benzoyl$succinyl_2h(4)",
    "modified_positions": 5,
    "name": "RNA-binding protein Hfq",
    "unique_modifications": 5
  },
  {
    "id": "Q7WTV4",
    "length": 455,
    "modifications": "diart6plex115$ZQG$hexnac(1)neugc(1)$Carbamidomethyl$Cation:Fe[III]$hex(4)hexnac(3)pent(1)$diart6plex116/119$GluGlu$Oxidation$Fluorescein-tyramine$Propargylamine$Amidine$BITC$icpl_13c(6)$Nmethylmaleimide$pupylation$diart6plex117$Saligenin$diart6plex",
    "modified_positions": 13,
    "name": "histidine kinase",
    "unique_modifications": 19
  },
  {
    "id": "Q8RNM5",
    "length": 469,
    "modifications": "Oxidation$Met->AspSA$Methyl$Pro->Pyrrolidinone$Delta:H(5)C(2)$UgiJoullieProGly$Methamidophos-S$Pro->Pyrrolidone$Thiazolidine$Unknown:306$Ammonia-loss$Dioxidation",
    "modified_positions": 14,
    "name": "Zn metalloprotein",
    "unique_modifications": 12
  },
  {
    "id": "Q9S4T0",
    "length": 416,
    "modifications": "Oxidation$Gly$Decarboxylation$hexnac$Delta:H(4)C(3)$Deamidated$Formyl$Carbamidomethyl$Arg->GluSA$Fluoro",
    "modified_positions": 18,
    "name": "Homogentisate 1,2-dioxygenase",
    "unique_modifications": 10
  },
  {
    "id": "Q9S4T1",
    "length": 341,
    "modifications": "hex(1)hexa(1)$SulfanilicAcid:13C(6)$Decarboxylation$Oxidation$G-H1$OxProBiotin$Gln->pyro-Glu$Methylamine$Deamidated$Glu$Dioxidation",
    "modified_positions": 17,
    "name": "RNA polymerase sigma factor RpoS",
    "unique_modifications": 11
  },
  {
    "id": "Q9S4T3",
    "length": 251,
    "modifications": "Acetyl$Methylthio",
    "modified_positions": 3,
    "name": "5'-nucleotidase SurE",
    "unique_modifications": 2
  },
  {
    "id": "A0A0A2SMI1",
    "length": 93,
    "modifications": "HPG$Oxidation",
    "modified_positions": 2,
    "name": "Putative Fis-like DNA-binding protein",
    "unique_modifications": 2
  },
  {
    "id": "A0A0A2SNW4",
    "length": 105,
    "modifications": "Delta:H(6)C(6)O(1)$Amidine$azole",
    "modified_positions": 3,
    "name": "Small ribosomal subunit protein uS10",
    "unique_modifications": 3
  },
  {
    "id": "A0A129B6Z6",
    "length": 88,
    "modifications": "Ethanolyl",
    "modified_positions": 1,
    "name": "Flagellar biosynthetic protein FlhB",
    "unique_modifications": 1
  },
  {
    "id": "A0A222P2X8",
    "length": 73,
    "modifications": "Deamidated$Decarboxylation",
    "modified_positions": 2,
    "name": "Cold shock protein CapB",
    "unique_modifications": 2
  },
  {
    "id": "A0A222P2Z3",
    "length": 136,
    "modifications": "Deamidated",
    "modified_positions": 1,
    "name": "F0F1 ATP synthase subunit epsilon",
    "unique_modifications": 1
  },
  {
    "id": "A0A378KDY1",
    "length": 332,
    "modifications": "Carbamidomethyl$Gly",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "A0AAN2RRN1",
    "length": 107,
    "modifications": "Oxidation$Delta:H(4)C(3)",
    "modified_positions": 3,
    "name": "Protein-export membrane protein SecG",
    "unique_modifications": 2
  },
  {
    "id": "A0AAN5PHP6",
    "length": 77,
    "modifications": "AFB1_Dialdehyde$sulfanilicacid",
    "modified_positions": 2,
    "name": "Acyl carrier protein",
    "unique_modifications": 2
  },
  {
    "id": "A0AAN5PHX0",
    "length": 58,
    "modifications": "DNCB_hapten",
    "modified_positions": 1,
    "name": "Dodecin domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "A0AAN5Q4D1",
    "length": 79,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "CHASE3 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "A0AAN5T2B5",
    "length": 65,
    "modifications": "Oxidation$Unknown:234",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "A0AAP3HCA8",
    "length": 227,
    "modifications": "Oxidation$Iodoacetanilide$Delta:H(4)C(3)",
    "modified_positions": 3,
    "name": "LuxR family transcriptional regulator RegK3",
    "unique_modifications": 3
  },
  {
    "id": "A0AAV2UWY0",
    "length": 404,
    "modifications": "icpl_13c(6)2h(4)$Oxidation$Glu",
    "modified_positions": 4,
    "name": "Integral membrane protein",
    "unique_modifications": 3
  },
  {
    "id": "A0AAX2IXW3",
    "length": 56,
    "modifications": "Carbamidomethyl$Oxidation$Sulfo-NHS-LC-LC-Biotin",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5WSZ3",
    "length": 49,
    "modifications": "Ub-Br2",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5WYY5",
    "length": 76,
    "modifications": "Lysbiotinhydrazide$GGQ",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5WZ42",
    "length": 98,
    "modifications": "Phospho",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZR89",
    "length": 118,
    "modifications": "Dehydrated$Unknown:250",
    "modified_positions": 3,
    "name": "UPF0102 protein lpg2994",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRQ9",
    "length": 270,
    "modifications": "Carbamidomethyl",
    "modified_positions": 2,
    "name": "NAD(P)H-hydrate epimerase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZRZ7",
    "length": 99,
    "modifications": "15N-oxobutanoic$Glu->pyro-Glu$Dehydrated",
    "modified_positions": 3,
    "name": "Transcriptional regulator",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZS45",
    "length": 163,
    "modifications": "Acetyl",
    "modified_positions": 1,
    "name": "DotD",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZS69",
    "length": 92,
    "modifications": "Deamidated",
    "modified_positions": 1,
    "name": "Large ribosomal subunit protein bL27",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZS91",
    "length": 250,
    "modifications": "CIGG$Propargylamine",
    "modified_positions": 2,
    "name": "Membrane protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSE7",
    "length": 186,
    "modifications": "Decarboxylation$icpl_2h(4)$gist-quat_2h(6)$Methylpyrroline$dnic",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZSF3",
    "length": 132,
    "modifications": "Oxidation$Diisopropylphosphate$Ethanedithiol",
    "modified_positions": 4,
    "name": "LvrA",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSF5",
    "length": 225,
    "modifications": "Oxidation$Methyl",
    "modified_positions": 3,
    "name": "Phage repressor",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSG6",
    "length": 281,
    "modifications": "Oxidation$MTSL$Biotin-PEG-PRA",
    "modified_positions": 4,
    "name": "DUF2306 domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSH8",
    "length": 135,
    "modifications": "Carbamidomethyl",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSP1",
    "length": 113,
    "modifications": "Carbamidomethyl$Acetyl$Sulfo-NHS-LC-LC-Biotin",
    "modified_positions": 4,
    "name": "Hydrogenase maturation factor HypA",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSR4",
    "length": 149,
    "modifications": "Propargylamine",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSW4",
    "length": 306,
    "modifications": "hex$Oxidation$PyruvicAcidIminyl",
    "modified_positions": 5,
    "name": "Regulatory protein (LysR transcriptional regulator)",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSY9",
    "length": 75,
    "modifications": "Piperidine$Oxidation",
    "modified_positions": 2,
    "name": "HTH cro/C1-type domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZT23",
    "length": 257,
    "modifications": "Pentylamine$Oxidation$glycosyl$Carbamyl",
    "modified_positions": 3,
    "name": "ATPases involved in biogenesis of archaeal flagella",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZT47",
    "length": 301,
    "modifications": "Carbamidomethyl$Oxidation$HN2_mustard$GPIanchor",
    "modified_positions": 4,
    "name": "Chemotaxis (Motility protein A) transmembrane",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZT88",
    "length": 239,
    "modifications": "15N-oxobutanoic$Carbamidomethyl$Gly",
    "modified_positions": 4,
    "name": "Glycerophosphoryl diester esterase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZT99",
    "length": 296,
    "modifications": "Oxidation$Glu->pyro-Glu$15N-oxobutanoic$Didehydro$Dehydrated",
    "modified_positions": 7,
    "name": "Curved DNA binding protein DnaJ",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTA3",
    "length": 103,
    "modifications": "Glu->pyro-Glu$Deamidated$Glu->pyro-Glu+Methyl:2H(2)13C(1)$PyruvicAcidIminyl$Dehydrated",
    "modified_positions": 5,
    "name": "Periplasmic, osmotically inducible protein Y-like",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTC4",
    "length": 128,
    "modifications": "Carbamidomethyl$Diisopropylphosphate",
    "modified_positions": 3,
    "name": "Transmembrane protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTD4",
    "length": 353,
    "modifications": "Oxidation$hexnac(1)dhex(1)$Ammonium$Can-FP-biotin$deamidated_18o(1)$Quinone",
    "modified_positions": 7,
    "name": "3-oxoacyl-(Acyl carrier protein) synthase III",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZTN3",
    "length": 220,
    "modifications": "hep",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTN6",
    "length": 153,
    "modifications": "Oxidation$Carbonyl",
    "modified_positions": 2,
    "name": "Cyclic nucleotide-binding domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTQ3",
    "length": 97,
    "modifications": "dhex(1)hexnac(3)",
    "modified_positions": 1,
    "name": "DUF2282 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTR6",
    "length": 294,
    "modifications": "methylsulfonylethyl$Oxidation$Acetyl$methyl_2h(2)$Carbamidomethyl$Phospho",
    "modified_positions": 8,
    "name": "LvrA",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZTW4",
    "length": 200,
    "modifications": "Gly$Carbofuran$PEITC$Carbamidomethyl$hex(1)hexnac(3)neugc(1)$Delta:H(6)C(3)O(1)$Deoxyhypusine",
    "modified_positions": 7,
    "name": "Conserved domain protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZU01",
    "length": 163,
    "modifications": "Didehydro",
    "modified_positions": 1,
    "name": "Aspartyl protease",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZU17",
    "length": 216,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Lysoplasmalogenase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZU21",
    "length": 155,
    "modifications": "Oxidation$Dimethyl$phenylsulfonylethyl$Delta:H(4)C(2)$neiaa$Carbamidomethyl$Ethyl",
    "modified_positions": 10,
    "name": "Phosphohistidine phosphatase SixA",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZU24",
    "length": 245,
    "modifications": "ethylamino$LG-Hlactam-R$Dicarbamidomethyl$GG",
    "modified_positions": 4,
    "name": "Hydantoin racemase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZU36",
    "length": 125,
    "modifications": "N-dimethylphosphate",
    "modified_positions": 1,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZUB6",
    "length": 100,
    "modifications": "Carbamidomethyl$Gly",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUI4",
    "length": 184,
    "modifications": "CresylSaligeninPhosphate$azole",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUL2",
    "length": 257,
    "modifications": "Formyl",
    "modified_positions": 1,
    "name": "Flagellar motor protein MotA",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZUX2",
    "length": 296,
    "modifications": "MercaptoEthanol$Oxidation$icdid$Carboxyethyl$Lys->MetOx$SPITC:13C(6)$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZV02",
    "length": 185,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "GDT1 family protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZV07",
    "length": 179,
    "modifications": "Diethylphosphate$NQIGG",
    "modified_positions": 2,
    "name": "Dienelactone hydrolase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZV11",
    "length": 327,
    "modifications": "Cytopiloyne$Carbamidomethyl$Oxidation",
    "modified_positions": 4,
    "name": "Chalcone and stilbene synthases",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZV55",
    "length": 162,
    "modifications": "Carbamidomethyl$Deoxy$Oxidation",
    "modified_positions": 10,
    "name": "Enhanced entry protein EnhB",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVC0",
    "length": 108,
    "modifications": "HMVK$hydroxyisobutyryl",
    "modified_positions": 2,
    "name": "DUF1820 domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVI0",
    "length": 269,
    "modifications": "galactosyl",
    "modified_positions": 1,
    "name": "Cofactor-independent phosphoglycerate mutase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVJ5",
    "length": 263,
    "modifications": "UgiJoullieProGly",
    "modified_positions": 1,
    "name": "Segregation and condensation protein A",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVK7",
    "length": 254,
    "modifications": "Carbamidomethyl$Unknown:234$Carbonyl",
    "modified_positions": 4,
    "name": "Deoxyribose-phosphate aldolase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVP2",
    "length": 332,
    "modifications": "Saligenin$methylsulfonylethyl$Ethanedithiol",
    "modified_positions": 3,
    "name": "Endolytic murein transglycosylase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVQ0",
    "length": 142,
    "modifications": "Carbamidomethyl$Methyl$Propionamide",
    "modified_positions": 2,
    "name": "Metal-binding protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVS8",
    "length": 140,
    "modifications": "Deamidated$Gln->pyro-Glu",
    "modified_positions": 3,
    "name": "Type II secretion system core protein G",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVW5",
    "length": 386,
    "modifications": "Oxidation",
    "modified_positions": 2,
    "name": "Drug resistance transporter, Bcr/CflA",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVX2",
    "length": 340,
    "modifications": "Crotonyl",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVX9",
    "length": 104,
    "modifications": "HN3_mustard",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZW78",
    "length": 262,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "PhzF family phenazine biosynthesis protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWG7",
    "length": 371,
    "modifications": "Ammonium$methyl_2h(3)",
    "modified_positions": 1,
    "name": "Serine-type D-Ala-D-Ala carboxypeptidase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWI2",
    "length": 403,
    "modifications": "Oxidation$Phe->CamCys",
    "modified_positions": 2,
    "name": "Alpha/beta hydrolase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWI5",
    "length": 200,
    "modifications": "HexN",
    "modified_positions": 1,
    "name": "Proton transporter",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWJ4",
    "length": 147,
    "modifications": "CAF$Methamidophos-O$Oxidation",
    "modified_positions": 5,
    "name": "N-acetyltransferase domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWQ5",
    "length": 150,
    "modifications": "glucuronyl$Oxidation$EDT-iodoacetyl-PEO-biotin$Delta:H(10)C(8)O(1)",
    "modified_positions": 4,
    "name": "Transporter",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZX50",
    "length": 148,
    "modifications": "Delta:H(2)C(3)O(1)",
    "modified_positions": 1,
    "name": "Periplasmic protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZX86",
    "length": 81,
    "modifications": "4-ONE+Delta:H(-2)O(-1)$Oxidation",
    "modified_positions": 2,
    "name": "Hypothetical BolA like protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXA8",
    "length": 199,
    "modifications": "Oxidation$O-Methylphosphate",
    "modified_positions": 2,
    "name": "Rhomboid family protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXI8",
    "length": 98,
    "modifications": "Oxidation",
    "modified_positions": 2,
    "name": "Glutamate synthetase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXM1",
    "length": 269,
    "modifications": "Deamidated$Oxidation",
    "modified_positions": 2,
    "name": "Sepiapterin reductase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXR2",
    "length": 84,
    "modifications": "Acetyldeoxyhypusine",
    "modified_positions": 1,
    "name": "Hypothetical exported protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXR4",
    "length": 289,
    "modifications": "Cation:Al[III]$Carbamidomethyl$Oxidation$Delta:H(2)C(5)",
    "modified_positions": 4,
    "name": "DUF692 domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXR5",
    "length": 259,
    "modifications": "Phosphogluconoylation$Myristoyl$Unknown:210$Unknown:250",
    "modified_positions": 3,
    "name": "Putative DNA-binding domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXT8",
    "length": 412,
    "modifications": "Lipoyl$Succinyl",
    "modified_positions": 2,
    "name": "UPF0761 membrane protein lpg0643",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXV8",
    "length": 130,
    "modifications": "Ethyl$Oxidation$Dimethyl",
    "modified_positions": 4,
    "name": "Integral membrane protein (PIN domain superfamily)",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXW7",
    "length": 134,
    "modifications": "Oxidation$Ammonium$hep$methyl_2h(3)$Cation:Li$methyl_2h(2)",
    "modified_positions": 15,
    "name": "DUF4332 domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXZ8",
    "length": 159,
    "modifications": "neuac",
    "modified_positions": 2,
    "name": "Swiss Army Knife 2H phosphoesterase domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZY17",
    "length": 395,
    "modifications": "Dap-DSP$Oxidation$NHS-LC-Biotin$Cation:Na$hex(1)pent(2)me(1)",
    "modified_positions": 6,
    "name": "Stearoyl-CoA-9-desaturase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYF2",
    "length": 220,
    "modifications": "Carbamidomethyl$dhex(1)hex(1)",
    "modified_positions": 2,
    "name": "2-dehydro-3-deoxy-phosphogluconate aldolase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYG0",
    "length": 294,
    "modifications": "Carbamidomethyl$Diisopropylphosphate$Diethyl",
    "modified_positions": 3,
    "name": "Protoheme IX farnesyltransferase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYI7",
    "length": 193,
    "modifications": "Deamidated$Oxidation",
    "modified_positions": 2,
    "name": "LemA protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYJ8",
    "length": 128,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYQ6",
    "length": 123,
    "modifications": "Oxidation$dhex(2)hex(1)hexnac(2)kdn(1)",
    "modified_positions": 4,
    "name": "Protein translocase subunit SecE",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYS3",
    "length": 326,
    "modifications": "Hydroxyheme",
    "modified_positions": 1,
    "name": "L-lysine 2,3-aminomutase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYW3",
    "length": 113,
    "modifications": "Carbamidomethyl$Methylamine$Succinyl",
    "modified_positions": 4,
    "name": "Arsenate reductase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYY6",
    "length": 328,
    "modifications": "Cation:Al[III]$clip_traq_3",
    "modified_positions": 2,
    "name": "RND efflux membrane fusion protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZ39",
    "length": 241,
    "modifications": "Oxidation$Propargylamine",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZ87",
    "length": 200,
    "modifications": "DYn-2$Carbamidomethyl$Dehydrated",
    "modified_positions": 5,
    "name": "Cytochrome c4",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZD5",
    "length": 193,
    "modifications": "Oxidation$Arg->GluSA",
    "modified_positions": 3,
    "name": "YecA family protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZH5",
    "length": 118,
    "modifications": "dhex",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZI5",
    "length": 190,
    "modifications": "Decarboxylation",
    "modified_positions": 1,
    "name": "Lipid A acyltransferase PagP",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZI7",
    "length": 180,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Transmembrane protein",
    "unique_modifications": 1
  },
  {
    "id": "A0A222P351",
    "length": 137,
    "modifications": "4-ONE+Delta:H(-2)O(-1)",
    "modified_positions": 1,
    "name": "Integrating conjugative element protein PilL, PFGI-1 class",
    "unique_modifications": 1
  },
  {
    "id": "A0A2S6F0M8",
    "length": 63,
    "modifications": "hexnac(1)dhex(1)$Carbamidomethyl",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZR94",
    "length": 131,
    "modifications": "Oxidation$Oxidation+NEM$Delta:S(-1)Se(1)",
    "modified_positions": 2,
    "name": "ATP synthase protein I",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRA4",
    "length": 284,
    "modifications": "Carbamidomethyl$Deamidated$Oxidation",
    "modified_positions": 3,
    "name": "DUF2520 domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRS5",
    "length": 500,
    "modifications": "OxLysBiotinRed",
    "modified_positions": 1,
    "name": "Peptide transport protein, POT family",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZRS9",
    "length": 184,
    "modifications": "Oxidation$HN2_mustard",
    "modified_positions": 2,
    "name": "CDP-diacylglycerol--glycerol-3-phosphate 3-phosphatidyltransferase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRU8",
    "length": 101,
    "modifications": "Biotin$Oxidation",
    "modified_positions": 2,
    "name": "NADH-quinone oxidoreductase subunit K",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZS76",
    "length": 219,
    "modifications": "Ethanolamine$Oxidation$propionyl_13c(3)",
    "modified_positions": 3,
    "name": "Outer membrane protein beta-barrel domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZS86",
    "length": 105,
    "modifications": "Carbamidomethyl",
    "modified_positions": 2,
    "name": "DUF1840 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZS93",
    "length": 90,
    "modifications": "Carbamidomethyl$Trp->Kynurenin",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSH2",
    "length": 96,
    "modifications": "Thiazolidine",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSI6",
    "length": 194,
    "modifications": "Carbamidomethyl$hexnac(2)neugc(1)$Diisopropylphosphate",
    "modified_positions": 2,
    "name": "prephenate dehydratase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSR7",
    "length": 242,
    "modifications": "dhex(1)hex(3)hexnac(5)",
    "modified_positions": 1,
    "name": "Integral membrane protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSW1",
    "length": 133,
    "modifications": "Diethylphosphate",
    "modified_positions": 1,
    "name": "Mutator MutT protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZT26",
    "length": 277,
    "modifications": "Carbamidomethyl$glucuronyl",
    "modified_positions": 2,
    "name": "Alpha/beta hydrolase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZT31",
    "length": 92,
    "modifications": "Methyl",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTJ6",
    "length": 170,
    "modifications": "Tween20$Oxidation",
    "modified_positions": 2,
    "name": "Outer membrane protein beta-barrel domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTP0",
    "length": 69,
    "modifications": "Formyl",
    "modified_positions": 4,
    "name": "Cold shock DNA binding domain protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTQ8",
    "length": 48,
    "modifications": "Propargylamine$O-Isopropylmethylphosphonate",
    "modified_positions": 3,
    "name": "Core-binding (CB) domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTV0",
    "length": 401,
    "modifications": "Carbamidomethyl$Oxidation$neuac",
    "modified_positions": 3,
    "name": "Major facilitator family transporter",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZU32",
    "length": 286,
    "modifications": "Carbamidomethyl$QTGG",
    "modified_positions": 3,
    "name": "UVB-resistance protein UVR8",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZU73",
    "length": 93,
    "modifications": "Hydroxamic_acid$Carbamidomethyl$acetyl_2h(3)",
    "modified_positions": 3,
    "name": "HTH cro/C1-type domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZU84",
    "length": 111,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Ferredoxin",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZU91",
    "length": 105,
    "modifications": "PET",
    "modified_positions": 1,
    "name": "Possible regulator of murein genes BolA",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZUI9",
    "length": 130,
    "modifications": "hexnac(1)neuac(1)",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZUT2",
    "length": 121,
    "modifications": "Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 2,
    "name": "Cytochrome c domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZUY1",
    "length": 372,
    "modifications": "Diisopropylphosphate",
    "modified_positions": 1,
    "name": "Heparan-alpha-glucosaminide N-acetyltransferase catalytic domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZV53",
    "length": 185,
    "modifications": "betaFNA",
    "modified_positions": 1,
    "name": "Hypothetical thiol-disulfide isomerase and thioredoxins family",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVG5",
    "length": 212,
    "modifications": "Cation:Al[III]$Oxidation$Gln->pyro-Glu$Carbamidomethyl$Ammonia-loss",
    "modified_positions": 5,
    "name": "ATP-dependent dethiobiotin synthetase BioD",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVN9",
    "length": 113,
    "modifications": "Diisopropylphosphate",
    "modified_positions": 1,
    "name": "Type 4 fimbrial biogenesis protein PilZ",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZW80",
    "length": 151,
    "modifications": "Cation:Mg[II]$dimethyl_2h(6)13c(2)$Oxidation",
    "modified_positions": 5,
    "name": "YbaK/aminoacyl-tRNA synthetase-associated domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWP6",
    "length": 98,
    "modifications": "Gly-loss+Amide$Oxidation",
    "modified_positions": 2,
    "name": "DUF2933 domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWW3",
    "length": 381,
    "modifications": "Cation:Al[III]$Carbamidomethyl$neiaa_2h(5)",
    "modified_positions": 5,
    "name": "Ecto-ATP diphosphohydrolase II",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZX26",
    "length": 106,
    "modifications": "Hydroxamic_acid",
    "modified_positions": 1,
    "name": "Negative regulator of flagellin synthesis",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZX37",
    "length": 125,
    "modifications": "Carbamidomethyl$Oxidation$Bromo",
    "modified_positions": 3,
    "name": "Sel-1 protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZX61",
    "length": 288,
    "modifications": "HNE$Delta:H(2)C(3)$Oxidation",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZX70",
    "length": 177,
    "modifications": "Carbamidomethyl$Formylasparagine",
    "modified_positions": 3,
    "name": "Thiol:disulfide interchange protein DsbE",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXB0",
    "length": 416,
    "modifications": "Carbamidomethyl$hex(2)neuac(1)$Oxidation$Ub-fluorescein",
    "modified_positions": 4,
    "name": "O-antigen biosynthesis protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXG9",
    "length": 334,
    "modifications": "hexnac(2)",
    "modified_positions": 1,
    "name": "O-antigen initiating glycosyl transferase group 4-UDP-N-acetylmuramyl pentapeptide phosphotransferase/(N-acetylgalactosaminyl transferase TrsF)",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXK7",
    "length": 103,
    "modifications": "Met->Hse$Oxidation$Methamidophos-S",
    "modified_positions": 3,
    "name": "Hypothetical periplasmic or secreted lipoprotein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXQ4",
    "length": 88,
    "modifications": "dhex(1)hex(4)hexnac(2)$Oxidation",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXR7",
    "length": 217,
    "modifications": "Aspartylurea",
    "modified_positions": 1,
    "name": "Ribulose-phosphate 3-epimerase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXZ9",
    "length": 61,
    "modifications": "Lipoyl",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYC9",
    "length": 120,
    "modifications": "Pyridylacetyl$acetyl_2h(3)$Phenylisocyanate",
    "modified_positions": 3,
    "name": "IcmR",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYH9",
    "length": 287,
    "modifications": "Thiazolidine$neiaa_2h(5)",
    "modified_positions": 2,
    "name": "Lpg0393 helical bundle domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYK8",
    "length": 101,
    "modifications": "hex$Carbamidomethyl$Oxidation",
    "modified_positions": 4,
    "name": "PilZ domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYN2",
    "length": 109,
    "modifications": "Delta:H(8)C(6)O(2)",
    "modified_positions": 1,
    "name": "Large ribosomal subunit protein uL24",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYR3",
    "length": 429,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Chaperone SurA",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYU8",
    "length": 424,
    "modifications": "dhex(1)hex(1)hexnac(1)kdn(1)$deamidated_18o(1)",
    "modified_positions": 4,
    "name": "MFS transporter family protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYZ4",
    "length": 359,
    "modifications": "Carbamidomethyl$Deoxy$Phospho",
    "modified_positions": 3,
    "name": "N5-carboxyaminoimidazole ribonucleotide synthase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZ36",
    "length": 278,
    "modifications": "hex(1)hexnac(2)sulf(1)$Isopropylphospho",
    "modified_positions": 2,
    "name": "Pyoverdine biosynthesis protein PvcB",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZ52",
    "length": 159,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZA7",
    "length": 191,
    "modifications": "Carbamidomethyl$Thiophospho",
    "modified_positions": 2,
    "name": "Peptide methionine sulfoxide reductase MsrA",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZB4",
    "length": 113,
    "modifications": "NHS-fluorescein",
    "modified_positions": 1,
    "name": "Alkylphosphonate uptake protein PhnA",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZD6",
    "length": 104,
    "modifications": "Carbamidomethyl$Biotin$Methamidophos-O$Ethanedithiol",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZH4",
    "length": 240,
    "modifications": "Unknown:234",
    "modified_positions": 1,
    "name": "DUF2490 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZI6",
    "length": 141,
    "modifications": "acetyl_13c(2)$Delta:H(2)C(3)$Oxidation$Ethanolyl",
    "modified_positions": 4,
    "name": "Hemin binding protein Hbp",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZJ9",
    "length": 156,
    "modifications": "Ethyl",
    "modified_positions": 1,
    "name": "Thiol-disulfide oxidoreductase ResA",
    "unique_modifications": 1
  }
];