// entered data from: 
// "available-proteins-ptmvision-210212-Didier-copper-t4-merged.json"

let proteinData2 = [
  {
    "id": "A0A098G589",
    "length": 199,
    "modifications": "Carbamidomethyl$sulfanilicacid$Delta:H(6)C(3)O(1)$Carboxymethyl",
    "modified_positions": 3,
    "name": "Phage repressor",
    "unique_modifications": 4
  },
  {
    "id": "A0A098G593",
    "length": 166,
    "modifications": "hex$Gln->pyro-Glu",
    "modified_positions": 3,
    "name": "Acetyltransferase, GNAT family",
    "unique_modifications": 2
  },
  {
    "id": "A0A098G705",
    "length": 100,
    "modifications": "Label:2H(4)+GG$Oxidation$Glu->pyro-Glu+Methyl$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Putative F fimbriae pilin protein (TraA)",
    "unique_modifications": 4
  },
  {
    "id": "A0A098G869",
    "length": 126,
    "modifications": "NDA$bemad_st_2h(6)$thioacylPA$Dehydrated$Carbamidomethyl$Deamidated$Can-FP-biotin$FormylMet$Pro->Pyrrolidone",
    "modified_positions": 9,
    "name": "Small ribosomal subunit protein uS12",
    "unique_modifications": 9
  },
  {
    "id": "A0A098G8E7",
    "length": 78,
    "modifications": "Glu$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Translational regulator CsrA",
    "unique_modifications": 2
  },
  {
    "id": "A0A0A2SMI1",
    "length": 93,
    "modifications": "Oxidation$glucosone",
    "modified_positions": 4,
    "name": "Putative Fis-like DNA-binding protein",
    "unique_modifications": 2
  },
  {
    "id": "A0A0A2SNW4",
    "length": 105,
    "modifications": "Propionamide$thioacylPA$galactosyl",
    "modified_positions": 2,
    "name": "Small ribosomal subunit protein uS10",
    "unique_modifications": 3
  },
  {
    "id": "A0A0A2SQ00",
    "length": 168,
    "modifications": "Oxidation$Dehydrated$hex(4)hexnac(1)$Thiazolidine",
    "modified_positions": 10,
    "name": "Small ribosomal subunit protein uS5",
    "unique_modifications": 4
  },
  {
    "id": "A0A0A2ST13",
    "length": 75,
    "modifications": "Carboxymethyl:13C(2)$gist-quat$Lys->CamCys$Carbamidomethyl$glycidamide$glyoxalAGE$Myristoleyl",
    "modified_positions": 7,
    "name": "Small ribosomal subunit protein bS18",
    "unique_modifications": 7
  },
  {
    "id": "A0A0A2ST86",
    "length": 345,
    "modifications": "Deoxy$methyl_2h(2)$Hydroxamic_acid$Carbamidomethyl$dhex(2)hex(1)hexnac(1)kdn(1)$CarbamidomethylDTT$Malonyl$OxProBiotinRed$Oxidation$Carbofuran$Dimethylaminoethyl$clip_traq_4$Didehydro$Gly$Delta:H(6)C(3)O(1)",
    "modified_positions": 16,
    "name": "Cell shape-determining protein MreB",
    "unique_modifications": 15
  },
  {
    "id": "A0A0A2T5W8",
    "length": 218,
    "modifications": "dimethyl_2h(4)13c(2)$Dehydrated$Methamidophos-O$Delta:H(6)C(6)O(1)$trimethyl_2h(9)$3-deoxyglucosone$Oxidation$unknown_420$dimethyl_2h(6)$Malonyl$Carboxymethyl",
    "modified_positions": 11,
    "name": "Small ribosomal subunit protein uS3",
    "unique_modifications": 11
  },
  {
    "id": "A0A0A2T875",
    "length": 64,
    "modifications": "hex(1)neugc(1)$hex(2)hexa(1)hexnac(1)sulf(1)",
    "modified_positions": 1,
    "name": "Translational regulator CsrA",
    "unique_modifications": 2
  },
  {
    "id": "A0A0C9N1W9",
    "length": 253,
    "modifications": "Diisopropylphosphate$Carbamidomethyl$Ethyl+Deamidated$Cytopiloyne+water$PyridoxalPhosphateH2$Oxidation$Didehydro",
    "modified_positions": 11,
    "name": "imidazole glycerol-phosphate synthase",
    "unique_modifications": 7
  },
  {
    "id": "A0A0C9PGF9",
    "length": 67,
    "modifications": "icpl$Unknown:162$Nitrene$QTGG$AEBS$EDT-iodoacetyl-PEO-biotin$Oxidation",
    "modified_positions": 9,
    "name": "Dodecin domain-containing protein",
    "unique_modifications": 7
  },
  {
    "id": "A0A128JM68",
    "length": 64,
    "modifications": "Acetyl$Iodoacetanilide$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "A0A128VVH6",
    "length": 121,
    "modifications": "Gly$Carbamidomethyl",
    "modified_positions": 3,
    "name": "ProQ-like, activator of ProP osmoprotectant transporter",
    "unique_modifications": 2
  },
  {
    "id": "A0A128XGK4",
    "length": 309,
    "modifications": "Carbamidomethyl$Decanoyl$Deamidated$Oxidation$hex(3)$Myristoyl$Dioxidation",
    "modified_positions": 9,
    "name": "Cell division protein FtsX",
    "unique_modifications": 7
  },
  {
    "id": "A0A129B6Z6",
    "length": 88,
    "modifications": "Arg->Orn$methylol$Hydroxymethyl$DNCB_hapten",
    "modified_positions": 4,
    "name": "Flagellar biosynthetic protein FlhB",
    "unique_modifications": 4
  },
  {
    "id": "A0A129BCU3",
    "length": 284,
    "modifications": "Trimethyl$Unknown:210$galactosyl$Oxidation$Propyl",
    "modified_positions": 8,
    "name": "RNA polymerase sigma factor RpoH",
    "unique_modifications": 5
  },
  {
    "id": "A0A130C3H7",
    "length": 97,
    "modifications": "AFB1_Dialdehyde$Delta:H(2)C(2)$Lys->MetOx$Deamidated$Oxidation$dhex(1)hex(2)hexnac(2)sulf(1)",
    "modified_positions": 8,
    "name": "Phasin family protein",
    "unique_modifications": 6
  },
  {
    "id": "A0A131MXS3",
    "length": 98,
    "modifications": "Oxidation$VFQQQTGG$GluGlu",
    "modified_positions": 4,
    "name": "Aspartyl/glutamyl-tRNA(Asn/Gln) amidotransferase subunit C",
    "unique_modifications": 3
  },
  {
    "id": "A0A131N8W7",
    "length": 225,
    "modifications": "Oxidation$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Tol-Pal system protein TolQ",
    "unique_modifications": 2
  },
  {
    "id": "A0A133X5M5",
    "length": 64,
    "modifications": "NIPCAM$Carbamidomethyl$hexnac(1)dhex(2)$hexnac(1)neuac(1)$Oxidation$hex(1)hexnac(1)dhex(1)$Thiophos-S-S-biotin$hexnac(1)neugc(1)",
    "modified_positions": 8,
    "name": "Uncharacterized protein",
    "unique_modifications": 8
  },
  {
    "id": "A0A222P1W0",
    "length": 82,
    "modifications": "benzoyl$succinyl_2h(4)$succinyl_13c(4)",
    "modified_positions": 1,
    "name": "Acyl carrier protein",
    "unique_modifications": 3
  },
  {
    "id": "A0A222P2X3",
    "length": 163,
    "modifications": "bemad_st_2h(6)$Carbamidomethyl$UgiJoullieProGlyProGly$ISD_z+2_ion$GluGluGlu$OxLysBiotin$icpl_13c(6)2h(4)$Sulfo$O-Methylphosphate$Phospho$Gly",
    "modified_positions": 17,
    "name": "Transcriptional repressor DicA",
    "unique_modifications": 11
  },
  {
    "id": "A0A222P2X8",
    "length": 73,
    "modifications": "hex(2)hexnac(1)$Deamidated",
    "modified_positions": 2,
    "name": "Cold shock protein CapB",
    "unique_modifications": 2
  },
  {
    "id": "A0A222P301",
    "length": 342,
    "modifications": "sulfanilicacid$Nitrene$UgiJoullieProGlyProGly$biotinAcrolein298$HydroxymethylOP$Cation:Al[III]$Oxidation$Gly-loss+Amide$Nitrosyl",
    "modified_positions": 10,
    "name": "Beta-lactamase HcpD",
    "unique_modifications": 9
  },
  {
    "id": "A0A222P313",
    "length": 230,
    "modifications": "Oxidation$imid_2h(4)",
    "modified_positions": 2,
    "name": "ATP synthase subunit a",
    "unique_modifications": 2
  },
  {
    "id": "A0A222P328",
    "length": 195,
    "modifications": "cGMP+RMP-loss",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "A0A222P331",
    "length": 124,
    "modifications": "Oxidation$Propionamide$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "A0A222P332",
    "length": 299,
    "modifications": "Oxidation$ISD_z+2_ion",
    "modified_positions": 2,
    "name": "Protein LvrA",
    "unique_modifications": 2
  },
  {
    "id": "A0A222P351",
    "length": 137,
    "modifications": "dimethyl_2h(6)13c(2)$Methyl",
    "modified_positions": 3,
    "name": "Integrating conjugative element protein PilL, PFGI-1 class",
    "unique_modifications": 2
  },
  {
    "id": "A0A222P356",
    "length": 66,
    "modifications": "Dap-DSP$Deoxy$glucuronyl",
    "modified_positions": 3,
    "name": "Carbon storage regulator",
    "unique_modifications": 3
  },
  {
    "id": "A0A222P368",
    "length": 247,
    "modifications": "Carbamyl$Delta:H(4)C(2)O(-1)S(1)$Propionamide$QQQTGG$Carbamidomethyl$Crotonaldehyde$Saligenin$Deamidated$Oxidation$Butyryl",
    "modified_positions": 16,
    "name": "Acetoacetyl-CoA reductase",
    "unique_modifications": 10
  },
  {
    "id": "A0A2S6F6D0",
    "length": 238,
    "modifications": "AFB1_Dialdehyde$Diisopropylphosphate$hexnac$Puromycin$Phosphopantetheine$Can-FP-biotin$Gluratylation$O-Et-N-diMePhospho",
    "modified_positions": 5,
    "name": "RNA polymerase sigma factor FliA",
    "unique_modifications": 8
  },
  {
    "id": "A0A378K3S1",
    "length": 230,
    "modifications": "PhosphoCytidine$Carbamidomethyl$Cytopiloyne$Deamidated$Delta:H(8)C(6)O(1)",
    "modified_positions": 5,
    "name": "Cytidylate kinase",
    "unique_modifications": 5
  },
  {
    "id": "A0A378K601",
    "length": 316,
    "modifications": "Acetyl$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "A0A378K631",
    "length": 319,
    "modifications": "Carbamyl$Carbamidomethyl$Biotin:Thermo-88310$Ammonium$Dioxidation$Oxidation$CHDH$Dimethyl$dhex(3)hex(1)hexnac(2)kdn(1)$Gly$glycosyl",
    "modified_positions": 20,
    "name": "Glutathione synthetase",
    "unique_modifications": 11
  },
  {
    "id": "A0A378K664",
    "length": 418,
    "modifications": "AEC-MAEC$benzoyl$Iodoacetanilide:13C(6)$succinyl_13c(4)$deamidated_18o(1)$Unknown:162$Didehydro$succinyl_2h(4)$Lys->MetOx$methylsulfonylethyl$O-pinacolylmethylphosphonate$SPITC:13C(6)$hex(1)hexnac(2)neuac(1)sulf(1)$Delta:H(6)C(3)O(1)$Unknown:248$Carbamidomethyl$Unknown:306$Oxidation$Cation:Li$Delta:H(8)C(6)O(2)$Thiophospho$Tyr->Dha$PhosphoUridine",
    "modified_positions": 24,
    "name": "SOS mutagenesis and repair UmuC protein",
    "unique_modifications": 23
  },
  {
    "id": "A0A378K6Y4",
    "length": 853,
    "modifications": "Diisopropylphosphate$Didehydro$Carbamidomethyl$glycidamide$dhex(1)hex(4)$DAET$Deamidated$GlycerylPE$dhex(1)hex(1)hexnac(2)sulf(1)$Phospho$Gly",
    "modified_positions": 21,
    "name": "Diaminopimelate decarboxylase",
    "unique_modifications": 11
  },
  {
    "id": "A0A378K9R2",
    "length": 260,
    "modifications": "Carbamidomethyl$icpl_13c(6)2h(4)",
    "modified_positions": 3,
    "name": "GNAT family N-acetyltransferase",
    "unique_modifications": 2
  },
  {
    "id": "A0A378KDY1",
    "length": 332,
    "modifications": "Biotin-PEO-Amine$pentose",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "A0A3A6TZD2",
    "length": 214,
    "modifications": "Ethyl+Deamidated$hex(1)hexnac(2)dhex(2)$Oxidation$Biotin:Thermo-21345$hexnac(2)",
    "modified_positions": 8,
    "name": "Alanyl-tRNA editing protein",
    "unique_modifications": 5
  },
  {
    "id": "A0A3A6UQN3",
    "length": 112,
    "modifications": "Delta:H(2)C(3)O(1)",
    "modified_positions": 1,
    "name": "Tryptophan synthase subunit beta like protein",
    "unique_modifications": 1
  },
  {
    "id": "A0A3A6UW83",
    "length": 93,
    "modifications": "Unknown:306$Carbamidomethyl$Propargylamine$Oxidation$Phospho$BHTOH$Cation:Na$BHT",
    "modified_positions": 12,
    "name": "GIY-YIG nuclease family protein",
    "unique_modifications": 8
  },
  {
    "id": "A0A3A6V549",
    "length": 216,
    "modifications": "hep$dhex(1)hex(3)hexnac(1)$hex(2)hexnac(1)pent(1)hexa(1)",
    "modified_positions": 3,
    "name": "F-box domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "A0AAN5M018",
    "length": 480,
    "modifications": "deamidated_18o(1)$Ser->LacticAcid$Carbamidomethyl$Ethanolamine$Ammonium$Methyl$Ammonia-loss$Deamidated$UgiJoullie$Oxidation$Carboxyethylpyrrole$Gly-loss+Amide$Dimethyl$hex(4)hexa(1)$Ethyl$AzidoF$Gln->pyro-Glu",
    "modified_positions": 27,
    "name": "Outer membrane protein transport protein",
    "unique_modifications": 17
  },
  {
    "id": "A0AAN5PDE6",
    "length": 149,
    "modifications": "Phosphopropargyl$Carbamidomethyl$GG$CarbamidomethylDTT$Dicarbamidomethyl",
    "modified_positions": 3,
    "name": "YbhB/YbcL family Raf kinase inhibitor-like protein",
    "unique_modifications": 5
  },
  {
    "id": "A0AAN5PF07",
    "length": 88,
    "modifications": "Delta:H(5)C(2)$AEC-MAEC$Ethanedithiol$Propargylamine$DAET$MercaptoEthanol$Formyl$dichlorination$Delta:H(4)C(2)O(-1)S(1)$Propionamide$Nitrene$Ethanolamine$neiaa_2h(5)$Ammonium$Pro->Pyrrolidinone$Carboxy$Dimethyl$Decarboxylation$Deoxyhypusine$Propionyl$neiaa$Methylamine$Methyl+Deamidated$Gly$Delta:H(4)C(2)$Carbamyl$acetyl_13c(2)$Carbamidomethyl$Methyl$Oxidation$Ethyl",
    "modified_positions": 17,
    "name": "Lipoprotein",
    "unique_modifications": 31
  },
  {
    "id": "A0AAN5PF79",
    "length": 154,
    "modifications": "Propionamide$Carbamidomethyl$GG$hexnac(1)dhex(1)$Propargylamine$Oxidation$Myristoleyl$Dicarbamidomethyl$Glu->pyro-Glu+Methyl",
    "modified_positions": 14,
    "name": "thioredoxin-dependent peroxiredoxin",
    "unique_modifications": 9
  },
  {
    "id": "A0AAN5PFI7",
    "length": 266,
    "modifications": "Carbamidomethyl$Methamidophos-O$Oxidation$Nethylmaleimide+water$LRGG+methyl$neiaa$clip_traq_4$Gly$Delta:H(4)C(3)O(2)",
    "modified_positions": 12,
    "name": "Beta-lactamase",
    "unique_modifications": 9
  },
  {
    "id": "A0AAN5PGD8",
    "length": 117,
    "modifications": "Acetyl$Lipoyl$Carbamidomethyl$Glu->pyro-Glu",
    "modified_positions": 5,
    "name": "Rieske (2Fe-2S) protein",
    "unique_modifications": 4
  },
  {
    "id": "A0AAN5PGG3",
    "length": 441,
    "modifications": "hex(2)hexnac(4)$Carbamidomethyl$Methamidophos-O$Cytopiloyne$ethylamino$Deamidated$Oxidation$Can-FP-biotin$Thiazolidine$Decarboxylation",
    "modified_positions": 20,
    "name": "Deoxyguanosinetriphosphate triphosphohydrolase-like protein",
    "unique_modifications": 10
  },
  {
    "id": "A0AAN5PGQ0",
    "length": 516,
    "modifications": "dhex(1)hexnac(3)$OxArgBiotinRed$Carbamidomethyl$Ethanedithiol$4-ONE$hexnac(4)$HNE$Oxidation$OxArgBiotin$Lysbiotinhydrazide$Formyl$BHT",
    "modified_positions": 19,
    "name": "Alpha-amylase",
    "unique_modifications": 12
  },
  {
    "id": "A0AAN5PHU8",
    "length": 721,
    "modifications": "GG$acetyl_2h(3)$Cation:Al[III]$Formyl$Delta:H(4)C(2)O(-1)S(1)$Ethylphosphate$hexnac$O-Dimethylphosphate$hex(3)hexnac(1)me(1)$dhex$spermidine$Dimethyl$Decarboxylation$Carbonyl$O-pinacolylmethylphosphonate$Methyl+Deamidated$UgiJoullieProGly$Delta:H(4)C(2)$Glu->pyro-Glu+Methyl$Carbamidomethyl$Methyl$Oxidation$Cation:Li$Ethyl$Pentylamine",
    "modified_positions": 25,
    "name": "DNA 3'-5' helicase",
    "unique_modifications": 25
  },
  {
    "id": "A0AAN5PHX7",
    "length": 161,
    "modifications": "glucuronyl",
    "modified_positions": 1,
    "name": "DUF4381 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "A0AAN5PII5",
    "length": 60,
    "modifications": "AEBS$Oxidation$pent(2)$Delta:H(2)C(3)O(1)$Malonyl",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "A0AAN5PIP9",
    "length": 293,
    "modifications": "dileu4plex$dileu4plex117$Carbamidomethyl$Ethanolamine$Dap-DSP$dileu4plex118$benzoyl$Ethanedithiol$neiaa_2h(5)$Deamidated$Oxidation$succinyl_13c(4)$dileu4plex115",
    "modified_positions": 13,
    "name": "ATP phosphoribosyltransferase",
    "unique_modifications": 13
  },
  {
    "id": "A0AAN5PJ54",
    "length": 98,
    "modifications": "hex(2)",
    "modified_positions": 5,
    "name": "Transposase",
    "unique_modifications": 1
  },
  {
    "id": "A0AAN5PJP8",
    "length": 80,
    "modifications": "Methylamine$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "A0AAN5PKB9",
    "length": 139,
    "modifications": "G-H1$Oxidation$Methyl$Cation:Cu[I]",
    "modified_positions": 7,
    "name": "Response regulator",
    "unique_modifications": 4
  },
  {
    "id": "A0AAN5PKN6",
    "length": 350,
    "modifications": "hex(1)hexnac(1)dhex(1)me(2)$Oxidation$Nethylmaleimide+water$murnac$Didehydro$Hydroxamic_acid$Unknown:234",
    "modified_positions": 11,
    "name": "Nitronate monooxygenase",
    "unique_modifications": 7
  },
  {
    "id": "A0AAN5Q4D1",
    "length": 79,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "CHASE3 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "A0AAN5RTW8",
    "length": 182,
    "modifications": "HexN$Unknown:248$dhex(1)hex(1)hexnac(3)$Menadione-HQ$Deamidated$Oxidation$Biotin$pent(1)hexnac(1)$GluGluGluGlu$Cation:Na$Ahx2+Hsl",
    "modified_positions": 17,
    "name": "Transcription termination/antitermination protein NusG",
    "unique_modifications": 11
  },
  {
    "id": "A0AAN5SZH3",
    "length": 404,
    "modifications": "bemad_st_2h(6)$icpl$15N-oxobutanoic$Carbamidomethyl$Delta:H(6)C(6)O(1)$EDT-iodoacetyl-PEO-biotin$phosphohexnac$Ammonia-loss$Oxidation$Cation:Al[III]$Unknown:216$hex(1)hexnac(2)$Gln->pyro-Glu",
    "modified_positions": 16,
    "name": "Tryptophan--tRNA ligase",
    "unique_modifications": 13
  },
  {
    "id": "A0AAN5SZW9",
    "length": 289,
    "modifications": "Carbamidomethyl$Deamidated$Carboxymethyl$Gly$hex(1)hexnac(3)$Delta:H(6)C(3)O(1)",
    "modified_positions": 4,
    "name": "Peptide methionine sulfoxide reductase MsrA",
    "unique_modifications": 6
  },
  {
    "id": "A0AAN5SZZ3",
    "length": 90,
    "modifications": "Arg->GluSA$Carbamidomethyl",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "A0AAN5T0T9",
    "length": 321,
    "modifications": "Carbamidomethyl$Ethanolamine$pentose$GEE$OxArgBiotin$benzylguanidine$Propiophenone",
    "modified_positions": 9,
    "name": "Uncharacterized protein",
    "unique_modifications": 7
  },
  {
    "id": "A0AAN5T175",
    "length": 391,
    "modifications": "Delta:H(6)C(7)O(4)$PyruvicAcidIminyl$Nitrene$Carbamidomethyl$Furan$HN3_mustard$Cresylphosphate$monomethylphosphothione$Formyl$G-H1$Delta:H(2)C(3)O(1)$BITC$cGMP+RMP-loss$Dimethyl$Gly$Carboxymethyl",
    "modified_positions": 18,
    "name": "ISL3 family transposase",
    "unique_modifications": 16
  },
  {
    "id": "A0AAN5T1Q8",
    "length": 275,
    "modifications": "phosphoRibosyl",
    "modified_positions": 1,
    "name": "sn-glycerol-3-phosphate transport system permease protein UgpE",
    "unique_modifications": 1
  },
  {
    "id": "A0AAN5T1X2",
    "length": 307,
    "modifications": "Propionamide$PEITC$Acetyl$hex(3)hexnac(1)$Methyl$dhex(1)hex(2)hexnac(1)$Tris$Oxidation$CHDH$Malonyl$Delta:H(4)C(3)O(2)",
    "modified_positions": 15,
    "name": "MCE family protein",
    "unique_modifications": 11
  },
  {
    "id": "A0AAN5T2X3",
    "length": 306,
    "modifications": "hex(1)hexnac(1)dhex(1)me(2)$hexnac(1)dhex(1)$MeMePhosphorothioate$Methamidophos-S$CHDH$Diethylphosphate$PET",
    "modified_positions": 6,
    "name": "LysR family transcriptional regulator",
    "unique_modifications": 7
  },
  {
    "id": "A0AAP3HCA8",
    "length": 227,
    "modifications": "CresylSaligeninPhosphate$Delta:H(4)C(3)$Delta:H(2)C(3)$Oxidation$propionyl_13c(3)$Glu",
    "modified_positions": 7,
    "name": "LuxR family transcriptional regulator RegK3",
    "unique_modifications": 6
  },
  {
    "id": "A0AAP3HCY0",
    "length": 437,
    "modifications": "Carbamyl$neugc$Carbamidomethyl$Biotin:Thermo-88310$Acetyl$Oxidation$PET$Dioxidation",
    "modified_positions": 15,
    "name": "Sigma-54-dependent response regulator transcription factor FleR",
    "unique_modifications": 8
  },
  {
    "id": "A0AAP3HD07",
    "length": 289,
    "modifications": "Deoxy$hex(4)hexa(1)hexnac(1)$Carbonyl$biotinAcrolein298$Carbamidomethyl$Crotonyl$Glu$hex(1)hexa(1)hexnac(2)",
    "modified_positions": 12,
    "name": "MinD/ParA family protein",
    "unique_modifications": 8
  },
  {
    "id": "A0AAP3HDX9",
    "length": 182,
    "modifications": "Oxidation$Furan",
    "modified_positions": 2,
    "name": "Yip1 domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "A0AAP3HEA5",
    "length": 212,
    "modifications": "Carbamidomethyl$azole$G-H1$Oxidation$Methylthio",
    "modified_positions": 7,
    "name": "Uridine kinase",
    "unique_modifications": 5
  },
  {
    "id": "A0AAP3HEJ3",
    "length": 124,
    "modifications": "Propiophenone$hex(3)hexnac(2)phos(1)$O-Methylphosphate$Oxidation$Diethyl$Hydroxymethyl",
    "modified_positions": 8,
    "name": "Group 1 truncated hemoglobin",
    "unique_modifications": 6
  },
  {
    "id": "A0AAP3MBM7",
    "length": 258,
    "modifications": "Carbamidomethyl$Deamidated$Oxidation$imehex(2)neuac(1)$Carboxymethyl$TAMRA-FP",
    "modified_positions": 8,
    "name": "Enoyl-CoA hydratase-related protein",
    "unique_modifications": 6
  },
  {
    "id": "A0AAP3MCD4",
    "length": 367,
    "modifications": "Myristoyl$Oxidation$O-Isopropylmethylphosphonate",
    "modified_positions": 4,
    "name": "Ribonucleoside-diphosphate reductase subunit beta",
    "unique_modifications": 3
  },
  {
    "id": "A0AAV2UVV9",
    "length": 199,
    "modifications": "Carbamyl$Formyl$ethylamino$Dioxidation$Oxidation$Trioxidation$Delta:H(8)C(6)O(2)$Ethyl",
    "modified_positions": 10,
    "name": "Tfp pilus assembly protein PilO",
    "unique_modifications": 8
  },
  {
    "id": "A0AAV2UWN8",
    "length": 357,
    "modifications": "Carbamidomethyl$Delta:H(2)C(2)$Amino$Cytopiloyne+water$Sulfo$3sulfo$Tris$HN2_mustard$probiotinhydrazide$Pro->HAVA$CAMthiopropanoyl$Hydroxamic_acid$Gln->pyro-Glu",
    "modified_positions": 22,
    "name": "Pyruvate dehydrogenase E1 component subunit alpha",
    "unique_modifications": 13
  },
  {
    "id": "A0AAV2UWY0",
    "length": 404,
    "modifications": "dhex(1)hexnac(3)$hex(1)hexa(1)$Carbamidomethyl$Glu$dhex(1)hex(1)hexnac(3)neugc(1)$Dihydroxyimidazolidine$dhex(2)hex(1)hexnac(2)neugc(1)$Oxidation$Cation:Al[III]$Myristoyl+Delta:H(-4)$CAMthiopropanoyl$hex(1)hexnac(3)$Dimethylphosphothione",
    "modified_positions": 11,
    "name": "Integral membrane protein",
    "unique_modifications": 13
  },
  {
    "id": "A0AAV2UXQ2",
    "length": 755,
    "modifications": "Diisopropylphosphate$Delta:H(2)C(2)$hex(1)hexnac(1)dhex(1)$Cation:Ni[II]$Propyl$Decarboxylation$Gln->pyro-Glu$QQQTGG$glyoxalAGE$Saligenin$Chlorination$Can-FP-biotin$Methylthio$AzidoF$ZQG$sulfanilicacid$Carbamidomethyl$Oxidation$Diethyl$hex$dhex(2)hex(3)hexnac(3)neuac(1)$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 34,
    "name": "ATPase and specificity subunit of ClpA-ClpP ATP-dependent serine protease, chaperone activity",
    "unique_modifications": 22
  },
  {
    "id": "A0AAV2UXV8",
    "length": 91,
    "modifications": "dhex(3)hex(2)hexa(1)hexnac(2)sulf(1)$Oxidation$Iminobiotin$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "A0AAX0WT96",
    "length": 163,
    "modifications": "Carbamidomethyl$benzoyl$Piperidine$succinyl_13c(4)$Nmethylmaleimide$Delta:H(6)C(3)O(1)",
    "modified_positions": 4,
    "name": "4-diphosphocytidyl-2C-methyl-D-erythritol kinase",
    "unique_modifications": 6
  },
  {
    "id": "A0AAX0WTB2",
    "length": 224,
    "modifications": "Unknown:162$SMA$Carbamidomethyl$15N-oxobutanoic$Crotonaldehyde$Lipoyl$Iodoacetanilide:13C(6)$Delta:H(2)C(5)$Oxidation$Butyryl",
    "modified_positions": 9,
    "name": "Transposase IS701-like DDE domain-containing protein",
    "unique_modifications": 10
  },
  {
    "id": "A5ICS0",
    "length": 202,
    "modifications": "HexN$Carboxyethyl$Ethanedithiol$OxLysBiotinRed$Oxidation$Dimethyl$Formyl$Thiazolidine$Nitro",
    "modified_positions": 8,
    "name": "Outer-membrane lipoprotein carrier protein",
    "unique_modifications": 9
  },
  {
    "id": "O54589",
    "length": 360,
    "modifications": "Cation:Fe[II]$Ammonia-loss$Oxidation$Cation:Ca[II]$TMPP-Ac",
    "modified_positions": 6,
    "name": "DotH",
    "unique_modifications": 5
  },
  {
    "id": "P31108",
    "length": 192,
    "modifications": "OxProBiotin$Deoxy$Unknown:162$Carbamidomethyl$Deamidated$Oxidation$LG-anhydrolactam$TAMRA-FP",
    "modified_positions": 13,
    "name": "Superoxide dismutase [Fe]",
    "unique_modifications": 8
  },
  {
    "id": "Q3V863",
    "length": 575,
    "modifications": "icpl_13c(6)$Carbamidomethyl$Methylthio$GG$Biotin:Thermo-21330$Lys->AminoadipicAcid$hexnac(1)neuac(1)$hydroxyisobutyryl$Oxidation$hex(1)hexnac(1)neuac(1)ac(1)$Nmethylmaleimide$hexnac(2)dhex(2)$Methyl+Deamidated$Dicarbamidomethyl$hex(1)hexnac(2)pent(1)",
    "modified_positions": 17,
    "name": "Siderophore biosynthetic protein, iron repressed gene FrgA",
    "unique_modifications": 15
  },
  {
    "id": "Q3V864",
    "length": 249,
    "modifications": "Propionamide$ethylamino$Oxidation$dhex(1)hex(4)hexnac(2)$hex(1)pent(2)me(1)$dhex(2)hex(3)hexnac(2)",
    "modified_positions": 10,
    "name": "Flagellar biosynthetic protein FliP",
    "unique_modifications": 6
  },
  {
    "id": "Q3V866",
    "length": 256,
    "modifications": "Quinone$Carbonyl$methyl_2h(3)+acetyl_2h(3)$Oxidation$BITC$Pro->pyro-Glu$Trp->Oxolactone$BEMAD_ST",
    "modified_positions": 11,
    "name": "Flagellar biosynthetic protein FliR",
    "unique_modifications": 8
  },
  {
    "id": "Q3V868",
    "length": 692,
    "modifications": "dhex(2)hex(1)hexnac(2)neugc(1)$Phospho$dhex(1)hex(1)hexnac(1)kdn(1)$CAMthiopropanoyl$Unknown:234$MG-H1$neiaa_2h(5)$Delta:H(2)C(3)O(1)$succinyl_2h(4)$Glu$AEBS$Methyl+Deamidated$AzidoF$RNPXL$Oxidation$MicrocinC7$dhex(2)hex(2)$hep$Thiophospho$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 27,
    "name": "Flagellar biosynthesis protein FlhA",
    "unique_modifications": 20
  },
  {
    "id": "Q3V870",
    "length": 248,
    "modifications": "Gly$Carbamidomethyl$NQIGG$Acetyl$AccQTag$spermine$Oxidation$neiaa$Carboxy$methylol$Amidino",
    "modified_positions": 15,
    "name": "Pyridoxine 5'-phosphate synthase",
    "unique_modifications": 11
  },
  {
    "id": "Q48833",
    "length": 89,
    "modifications": "Cation:Ni[II]$O-Et-N-diMePhospho$Dehydro$Carbamidomethyl$Ammonia-loss$Deamidated$BMP-piperidinol$Oxidation$DNCB_hapten$AzidoF$Gln->pyro-Glu",
    "modified_positions": 16,
    "name": "Probable monothiol glutaredoxin GrlA",
    "unique_modifications": 11
  },
  {
    "id": "Q5WSJ2",
    "length": 251,
    "modifications": "Ethanedithiol$Deamidated$Oxidation$Phospho$Thiazolidine",
    "modified_positions": 9,
    "name": "Band 7 domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5WSM8",
    "length": 229,
    "modifications": "Dehydrated$Carbamidomethyl$ISD_z+2_ion$Cytopiloyne$Ammonia-loss$Carboxy$Oxidation$succinyl_13c(4)$Biotin-tyramide",
    "modified_positions": 9,
    "name": "ABC transporter domain-containing protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5WSR7",
    "length": 180,
    "modifications": "Carbamidomethyl$2-dimethylsuccinyl$icdid_2h(6)$Oxidation$HN2_mustard",
    "modified_positions": 5,
    "name": "Cytochrome c oxidase assembly protein CtaG",
    "unique_modifications": 5
  },
  {
    "id": "Q5WSV4",
    "length": 147,
    "modifications": "hexnac(3)$BDMAPP$Oxidation",
    "modified_positions": 4,
    "name": "HEPN domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5WT12",
    "length": 88,
    "modifications": "dhex(2)hex(1)hexnac(2)kdn(1)",
    "modified_positions": 1,
    "name": "CRM domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5WT42",
    "length": 179,
    "modifications": "Carbamidomethyl$dhex(1)hex(1)hexnac(3)$Delta:H(2)C(2)$Lys->MetOx$ethylamino$Oxidation$Dimethyl$dhex(1)hexnac(4)",
    "modified_positions": 14,
    "name": "GTP cyclohydrolase 1",
    "unique_modifications": 8
  },
  {
    "id": "Q5WT83",
    "length": 178,
    "modifications": "Carbamidomethyl$glyoxalAGE$Deamidated$Oxidation$Carboxy",
    "modified_positions": 8,
    "name": "Translation initiation factor IF-3",
    "unique_modifications": 5
  },
  {
    "id": "Q5WT84",
    "length": 66,
    "modifications": "PyMIC$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Large ribosomal subunit protein bL35",
    "unique_modifications": 2
  },
  {
    "id": "Q5WT88",
    "length": 97,
    "modifications": "Label:2H(4)+GG$Cation:Fe[II]$CresylSaligeninPhosphate$Carbamidomethyl$Methylphosphonate$Formyl$Lys->AminoadipicAcid$Fluoro$Sulfide$Oxidation$Met->AspSA$LG-lactam-R$hex$Pro->Pyrrolidone$Dioxidation",
    "modified_positions": 17,
    "name": "Integration host factor subunit alpha",
    "unique_modifications": 15
  },
  {
    "id": "Q5WT92",
    "length": 205,
    "modifications": "Carbamidomethyl$Acetyl$hexnac(1)dhex(1)$Isopropylphospho$Oxidation$Unknown:216$Dansyl",
    "modified_positions": 8,
    "name": "Ubiquinol-cytochrome c reductase iron-sulfur subunit",
    "unique_modifications": 7
  },
  {
    "id": "Q5WTA2",
    "length": 64,
    "modifications": "Carbamidomethyl$bodipy$Octanoyl$Oxidation$Gly$Delta:H(6)C(3)O(1)",
    "modified_positions": 5,
    "name": "Zinc finger CHCC-type domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5WTE2",
    "length": 71,
    "modifications": "Oxidation$Succinyl",
    "modified_positions": 4,
    "name": "Transcriptional regulator HTH-type FeoC domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5WTF4",
    "length": 219,
    "modifications": "FMNH$Dehydrated$Carbamidomethyl$Methylthio$glycidamide$dhex(1)hex(2)hexnac(1)$Delta:H(2)C(5)$Oxidation$dimethyl_2h(4)$hex(1)hexnac(2)$Gly",
    "modified_positions": 17,
    "name": "Legionella transmission activator LetA",
    "unique_modifications": 11
  },
  {
    "id": "Q5WTI6",
    "length": 391,
    "modifications": "Trp->Oxolactone$ethylamino$Carbonyl",
    "modified_positions": 4,
    "name": "Probable peptidoglycan glycosyltransferase FtsW",
    "unique_modifications": 3
  },
  {
    "id": "Q5WTJ1",
    "length": 412,
    "modifications": "Carbamidomethyl$Carbonyl$Delta:H(2)C(2)$AEC-MAEC$Phosphoguanosine$Deamidated$Oxidation$hex(1)hexnac(2)$Cation:Ni[II]",
    "modified_positions": 12,
    "name": "Cell division protein FtsA",
    "unique_modifications": 9
  },
  {
    "id": "Q5WUD5",
    "length": 76,
    "modifications": "Deamidated",
    "modified_positions": 1,
    "name": "Outer membrane protein assembly factor BamC",
    "unique_modifications": 1
  },
  {
    "id": "Q5WV10",
    "length": 231,
    "modifications": "Delta:H(6)C(6)O(1)$Oxidation$DimethylpyrroleAdduct$SPITC",
    "modified_positions": 5,
    "name": "SPOR domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5WV31",
    "length": 67,
    "modifications": "Oxidation$CarbamidomethylDTT$Carbamidomethyl",
    "modified_positions": 2,
    "name": "DNA-directed RNA polymerase subunit omega",
    "unique_modifications": 3
  },
  {
    "id": "Q5WV32",
    "length": 707,
    "modifications": "Deoxyhypusine$Lys->CamCys$Carbamidomethyl$Unknown:306$Lipoyl$Fluoro$Oxidation$Unknown:216$Pro->HAVA$Acetyldeoxyhypusine$O-Isopropylmethylphosphonate$Gly$Delta:H(4)C(3)O(2)",
    "modified_positions": 22,
    "name": "guanosine-3',5'-bis(diphosphate) 3'-diphosphatase",
    "unique_modifications": 13
  },
  {
    "id": "Q5WVJ3",
    "length": 92,
    "modifications": "SMA$PS_Hapten$Delta:H(2)C(2)$Methylphosphonate$Ammonia-loss$ethylsulfonylethyl$Formyl$Thiazolidine$Carboxymethyl$Acetyl$Ammonium$Deamidated$HNE$Cation:Na$icpl_2h(4)$Deoxy$Acetylhypusine$EQIGG$Gly$Dehydrated$Carbamidomethyl$ISD_z+2_ion$dnic$15N-oxobutanoic$GluGluGlu$Oxidation$Ethyl$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 25,
    "name": "HupB DNA binding protein HU-beta",
    "unique_modifications": 28
  },
  {
    "id": "Q5WVL0",
    "length": 301,
    "modifications": "Furan$2HPG$Lipoyl$phosphohexnac$Chlorination$icpl_13c(6)2h(4)$Menadione-HQ$N-dimethylphosphate$Oxidation$Methylamine$Trioxidation$Propyl$PyruvicAcidIminyl",
    "modified_positions": 12,
    "name": "Glycine--tRNA ligase alpha subunit",
    "unique_modifications": 13
  },
  {
    "id": "Q5WVL6",
    "length": 259,
    "modifications": "Acetylhypusine$GG$Deamidated$spermine$Oxidation$Crotonyl$EDT-maleimide-PEO-biotin$N-dimethylphosphate$Cation:Ca[II]$Dicarbamidomethyl$hex(2)hexnac(2)",
    "modified_positions": 14,
    "name": "29 kDa immunogenic protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5WVX1",
    "length": 89,
    "modifications": "Succinyl$Dehydrated$Delta:H(4)C(5)O(1)$DNCB_hapten",
    "modified_positions": 4,
    "name": "Cell division topological specificity factor",
    "unique_modifications": 4
  },
  {
    "id": "Q5WWN2",
    "length": 124,
    "modifications": "glucosylgalactosyl$Carbamidomethyl$hexnac(3)$Oxidation$Bromo$dhex",
    "modified_positions": 10,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5WX44",
    "length": 225,
    "modifications": "OxArgBiotinRed$hex(1)neuac(1)pent(1)$dimethyl_2h(6)13c(2)$Cresylphosphate$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Methylthio$hex(1)hexnac(1)neuac(2)$O-Et-N-diMePhospho",
    "modified_positions": 8,
    "name": "DNA-binding response regulator",
    "unique_modifications": 8
  },
  {
    "id": "Q5WXB5",
    "length": 81,
    "modifications": "Amidated$Delta:H(4)C(3)O(1)$Diisopropylphosphate$Dehydrated$Carbamidomethyl$dileu4plex118$Amidine$Deamidated$Oxidation$Didehydro$Thiazolidine$Gly$Carboxymethyl$Glu->pyro-Glu",
    "modified_positions": 18,
    "name": "Transcription regulator AsnC/Lrp ligand binding domain-containing protein",
    "unique_modifications": 14
  },
  {
    "id": "Q5WXG2",
    "length": 108,
    "modifications": "spermidine",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5WXH8",
    "length": 90,
    "modifications": "Carbamidomethyl$Carbonyl$Ethanolamine$hexnac(3)$OxLysBiotin$Hydroxamic_acid$hex(1)hexa(1)hexnac(2)",
    "modified_positions": 13,
    "name": "KaiB domain-containing protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5WY06",
    "length": 298,
    "modifications": "gist-quat$Carboxy->Thiocarboxy$Delta:H(2)C(3)$Crotonaldehyde$betaFNA$Pyridylacetyl$Delta:H(2)C(3)O(1)$Oxidation$unknown_420$Didehydro$Phenylisocyanate$Butyryl",
    "modified_positions": 10,
    "name": "Uncharacterized protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5WYV9",
    "length": 112,
    "modifications": "Carbonyl$Carbamidomethyl$Oxidation$benzylguanidine$Propiophenone$Glu",
    "modified_positions": 9,
    "name": "Nitrogen regulatory protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5WZ42",
    "length": 98,
    "modifications": "Menadione$AccQTag",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5WZ85",
    "length": 208,
    "modifications": "Unknown:306$Carbamidomethyl$Methylphosphonate$Fluoro$Octanoyl$Oxidation$Cation:Li$Dansyl$bisANS-sulfonates$Delta:H(8)C(6)O(1)",
    "modified_positions": 12,
    "name": "HNH nuclease domain-containing protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5WZ95",
    "length": 376,
    "modifications": "Propionamide$Trimethyl$Biotin:Thermo-88310$Glu->pyro-Glu+Methyl$Oxidation$Pro->Pyrrolidinone$dhex(2)hex(4)hexnac(5)$Propyl$Dansyl$Delta:H(4)C(3)O(2)$Decarboxylation$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 13,
    "name": "DotM C-terminal cytoplasmic domain-containing protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5WZG8",
    "length": 136,
    "modifications": "Diethylphosphothione$Oxidation$Delta:H(4)C(3)O(2)$Carbonyl",
    "modified_positions": 4,
    "name": "Ferric uptake regulation protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5WZK0",
    "length": 183,
    "modifications": "deamidated_18o(1)$Ser->LacticAcid$Carbamidomethyl$Carbonyl$Methylpyrroline$Acetyl$dnic$Deamidated$Oxidation$Hydroxyheme$Gly",
    "modified_positions": 23,
    "name": "Large ribosomal subunit protein uL5",
    "unique_modifications": 11
  },
  {
    "id": "Q5WZK7",
    "length": 111,
    "modifications": "Carbamidomethyl$Propionyl$FTC$Deamidated$Oxidation",
    "modified_positions": 11,
    "name": "Large ribosomal subunit protein uL22",
    "unique_modifications": 5
  },
  {
    "id": "Q5WZK8",
    "length": 92,
    "modifications": "Delta:H(2)C(2)$Oxidation$Methyl$Deamidated",
    "modified_positions": 6,
    "name": "Small ribosomal subunit protein uS19",
    "unique_modifications": 4
  },
  {
    "id": "Q5X1H7",
    "length": 338,
    "modifications": "Biotin:Thermo-21328$Carbamidomethyl$Carbonyl$Methyl$dhex(1)hex(2)$Oxidation$AMTzHexNAc2$Pyro-carbamidomethyl$diart6plex115$Gly",
    "modified_positions": 16,
    "name": "Phenylalanine--tRNA ligase alpha subunit",
    "unique_modifications": 10
  },
  {
    "id": "Q5X4B6",
    "length": 150,
    "modifications": "PET$Isopropylphospho",
    "modified_positions": 2,
    "name": "Regulatory protein RecX",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZR97",
    "length": 156,
    "modifications": "phosphohex$Deoxy$thioacylPA$Ammonium$Delta:H(8)C(6)O(2)$Deamidated$Oxidation$methyl_2h(3)$PyridoxalPhosphate$Nmethylmaleimide$Dimethyl$Phosphoadenosine$Glu->pyro-Glu$Ethyl$Glu$Gln->pyro-Glu",
    "modified_positions": 15,
    "name": "ATP synthase subunit b",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZRA0",
    "length": 288,
    "modifications": "NDA$OxArgBiotinRed$Carbamidomethyl$Deamidated$Oxidation$Dimethyl$hex(1)hexnac(2)$Delta:H(6)C(3)O(1)",
    "modified_positions": 10,
    "name": "ATP synthase gamma chain",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZRA1",
    "length": 458,
    "modifications": "Ammonia-loss$Cys->Oxoalanine$4-ONE+Delta:H(-2)O(-1)$Unknown:216$CIGG$CresylSaligeninPhosphate$Acetyl$CarbamidomethylDTT$Deamidated$clip_traq_2$Propyl$Didehydro$Cation:Na$TAMRA-FP$Gln->pyro-Glu$Deoxy$Carbonyl$Trioxidation$Gly$Carbamyl$Dehydrated$Carbamidomethyl$GluGluGlu$Fluoro$Oxidation$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 52,
    "name": "ATP synthase subunit beta",
    "unique_modifications": 26
  },
  {
    "id": "Q5ZRA4",
    "length": 284,
    "modifications": "PropylNAGthiazoline$Deoxy$Carbamidomethyl$Crotonaldehyde$Oxidation$Biotin:Thermo-21345",
    "modified_positions": 8,
    "name": "DUF2520 domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRB7",
    "length": 201,
    "modifications": "icpl$Ser->LacticAcid$Dap-DSP$Ammonia-loss$Dioxidation$Carboxymethyl$Ammonium$CarbamidomethylDTT$Deamidated$Carbofuran$Didehydro$CarboxymethylDTT$nic$Deoxy$galactosyl$Diethylphosphothione$SulfurDioxide$Trioxidation$Methylamine$UgiJoullieProGly$Gly$Dehydrated$Carbamidomethyl$Sulfide$Oxidation$methyl_2h(3)$Delta:H(6)C(3)O(1)",
    "modified_positions": 38,
    "name": "Thioredoxin peroxidase",
    "unique_modifications": 27
  },
  {
    "id": "Q5ZRC1",
    "length": 288,
    "modifications": "SMA$Delta:H(2)C(2)$Amino$Ammonia-loss$Formyl$diart6plex116/119$Thiazolidine$Cation:Ni[II]$gist-quat$deamidated_18o(1)$Propionamide$Deamidated$Didehydro$TAMRA-FP$Carboxyethyl$Carbonyl$Crotonaldehyde$Delta:H(6)C(6)O(1)$Propionyl$Methylamine$Methyl+Deamidated$diart6plex115$Butyryl$Hydroxamic_acid$Gly$PyruvicAcidIminyl$diart6plex117$Cation:Fe[II]$Dehydrated$Carbamidomethyl$Methamidophos-O$Phe->CamCys$Delta:H(-4)O(2)$Methyl$O-Methylphosphate$Oxidation$diart6plex$Myristoyl+Delta:H(-4)$Delta:H(2)C(3)O(1)$diart6plex118",
    "modified_positions": 34,
    "name": "Major outer membrane protein",
    "unique_modifications": 40
  },
  {
    "id": "Q5ZRC2",
    "length": 323,
    "modifications": "hex(1)hexnac(2)sulf(1)$HNE$sulfanilicacid$Deamidated",
    "modified_positions": 7,
    "name": "Major outer membrane protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRC7",
    "length": 103,
    "modifications": "bemad_st_2h(6)$dhex(1)hexnac(3)$Delta:H(4)C(3)$phosphohex$Ethanedithiol$Cytopiloyne+water$Ammonia-loss$Oxidation$HN2_mustard$Delta:H(2)C(3)O(1)$PyruvicAcidIminyl",
    "modified_positions": 12,
    "name": "Integration host factor subunit beta",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZRC8",
    "length": 238,
    "modifications": "hex(1)hexnac(1)phos(1)$hex(1)hexnac(1)sulf(1)$Acetylhypusine",
    "modified_positions": 4,
    "name": "Histone-lysine N-methyltransferase, H3 lysine-79 specific",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRC9",
    "length": 241,
    "modifications": "sulfanilicacid$Carbamidomethyl$Ethanolyl$Oxidation$dimethyl_2h(4)$Gly$Pro->pyro-Glu",
    "modified_positions": 9,
    "name": "Uncharacterized protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRD1",
    "length": 316,
    "modifications": "Gly$Carbamidomethyl$Methamidophos-O$Ethanedithiol$AEC-MAEC$Ethanolamine$CarbamidomethylDTT$Trp->Hydroxykynurenin$Oxidation$Pro->Pyrrolidinone$Pyro-carbamidomethyl$hex(2)hexnac(3)$Cation:Na$DimethylpyrroleAdduct$Decarboxylation",
    "modified_positions": 15,
    "name": "Cysteine synthase B",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZRE5",
    "length": 464,
    "modifications": "hex(1)hexa(1)$GG$Delta:H(2)C(2)$Dethiomethyl$Met->Hsl$Carboxymethyl$Delta:H(4)C(6)$Lys->Allysine$OxLysBiotin$Deamidated$hex(1)hexnac(1)$Deoxy$Carboxyethyl$Acetylhypusine$Pyro-carbamidomethyl$Iminobiotin$Hydroxamic_acid$Carbamidomethyl$Dehydro$Methyl$Oxidation$Delta:H(6)C(3)O(1)",
    "modified_positions": 25,
    "name": "Fumarate hydratase class II",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZRE6",
    "length": 244,
    "modifications": "Delta:H(4)C(3)$Carbamidomethyl$Propargylamine$Deamidated$methylsulfonylethyl$hex(2)",
    "modified_positions": 7,
    "name": "Ribosomal RNA small subunit methyltransferase E",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRE7",
    "length": 108,
    "modifications": "Oxidation$AMTzHexNAc2",
    "modified_positions": 3,
    "name": "Thioredoxin",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRF3",
    "length": 133,
    "modifications": "hexnac(1)dhex(2)",
    "modified_positions": 1,
    "name": "Aspartate 1-decarboxylase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZRF4",
    "length": 256,
    "modifications": "Methyl$Delta:H(10)C(8)O(1)$Carbamidomethyl$Deamidated",
    "modified_positions": 6,
    "name": "Ribosomal RNA small subunit methyltransferase A",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRF6",
    "length": 276,
    "modifications": "Carbamidomethyl$Ethanedithiol$Sulfide$Oxidation$Trioxidation$NBS",
    "modified_positions": 10,
    "name": "Bis(5'-nucleosyl)-tetraphosphatase, symmetrical",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRF7",
    "length": 542,
    "modifications": "Trimethyl$TMPP-Ac:13C(9)$Delta:H(2)C(2)$Acetyl$hex(3)hexnac(1)hexa(1)$Tris$Arg->GluSA$Oxidation$HPG$Dioxidation$acetyl_2h(3)",
    "modified_positions": 12,
    "name": "Outer membrane efflux protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZRF8",
    "length": 381,
    "modifications": "Crotonaldehyde$phosphohex(2)$Palmitoleyl$Oxidation$hex(2)sulf(1)$Butyryl$Glu",
    "modified_positions": 9,
    "name": "Lipoprotein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRG2",
    "length": 139,
    "modifications": "Diisopropylphosphate$Cytopiloyne$Methyl$pupylation$Oxidation$methylol$Dioxidation$CIGG",
    "modified_positions": 8,
    "name": "Nucleotidyltransferase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZRG3",
    "length": 392,
    "modifications": "Deoxy$Unknown:162$Carbamidomethyl$Delta:H(6)C(3)O(1)$Acetyl$maleimide$dhex(2)hex(2)hexnac(2)kdn(1)$Carboxymethyl$bacillosamine$SPITC",
    "modified_positions": 13,
    "name": "(Serine-type) D-alanyl-D-alanine carboxypeptidase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZRG5",
    "length": 348,
    "modifications": "Delta:H(4)C(3)$Cytopiloyne+water$Carbonyl",
    "modified_positions": 5,
    "name": "FAD/NAD(P)-binding domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRG7",
    "length": 73,
    "modifications": "Oxidation$DAET",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRG8",
    "length": 96,
    "modifications": "hex(1)pent(1)$Carbamidomethyl$Crotonaldehyde$BITC$Butyryl$PyruvicAcidIminyl",
    "modified_positions": 4,
    "name": "HTH cro/C1-type domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRH1",
    "length": 423,
    "modifications": "lapachenole$Ethylphosphate$Carbamidomethyl$HydroxymethylOP$hexnac$O-Dimethylphosphate$Oxidation$Didehydro$Delta:H(2)C(3)O(1)$Methylthio$Thrbiotinhydrazide",
    "modified_positions": 10,
    "name": "Serine carboxypeptidase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZRH7",
    "length": 549,
    "modifications": "Carbamidomethyl$OxLysBiotin$Ub-fluorescein$dhex(1)hex(3)hexnac(2)$dhex(4)hex(1)hexnac(3)kdn(1)$bisANS-sulfonates$Oxidation$Deamidated$CHDH$Delta:H(2)C(3)O(1)$Delta:H(4)C(3)O(2)",
    "modified_positions": 14,
    "name": "Probable protein kinase UbiB",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZRH9",
    "length": 250,
    "modifications": "Aspartylurea$Ethylphosphate$Carbamidomethyl$Deamidated$imehex(2)neuac(1)$Oxidation$hex(3)hexnac(3)neuac(1)$Carboxymethyl$Carboxy$phosphoRibosyl$Delta:H(4)C(2)$Glu$Delta:H(6)C(3)O(1)$Nitro",
    "modified_positions": 19,
    "name": "Ubiquinone/menaquinone biosynthesis C-methyltransferase UbiE",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZRI1",
    "length": 201,
    "modifications": "Fluoro$Oxidation",
    "modified_positions": 4,
    "name": "Transporter, LysE family",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRI2",
    "length": 342,
    "modifications": "Dehydrated$Carboxy->Thiocarboxy$Carbamidomethyl$Fluoro$Oxidation$methylsulfonylethyl$Methyl+Deamidated$Nitrosyl$Glu",
    "modified_positions": 12,
    "name": "CapM protein, capsular polysaccharide biosynthesis",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZRI4",
    "length": 401,
    "modifications": "serotonylation$Trimethyl$Carbamidomethyl$NEM:2H(5)+H2O$icpl_13c(6)2h(4)$Oxidation$clip_traq_2$Propyl",
    "modified_positions": 10,
    "name": "Cytochrome c oxidase subunit 2",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZRI9",
    "length": 289,
    "modifications": "Carbamidomethyl$Arg->Orn$Oxidation$MercaptoEthanol$Gly",
    "modified_positions": 8,
    "name": "Probable chromosome-partitioning protein ParB",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRJ1",
    "length": 208,
    "modifications": "Unknown:306$Ethanedithiol$Cation:Cu[I]$Oxidation$clip_traq_4$Cation:Zn[II]$Thiazolidine",
    "modified_positions": 7,
    "name": "Ribosomal RNA small subunit methyltransferase G",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRJ2",
    "length": 624,
    "modifications": "LRGG$Carbamyl$Hydroxamic_acid$Ethylphosphate$Carbamidomethyl$pentose$Biotin:Thermo-21330$Lys->MetOx$pupylation$igbp_13c(2)$Oxidation$BDMAPP$Methamidophos-S$Met->Hse$Bromo$QEQTGG$Propyl$Gly",
    "modified_positions": 24,
    "name": "tRNA uridine 5-carboxymethylaminomethyl modification enzyme MnmG",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZRJ5",
    "length": 228,
    "modifications": "Phosphopropargyl$Carbonyl$Unknown:306$Carbamidomethyl$Delta:H(10)C(8)O(1)$Pro->pyro-Glu$Thiazolidine$Phenylisocyanate:2H(5)",
    "modified_positions": 15,
    "name": "7-cyano-7-deazaguanine synthase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZRJ7",
    "length": 245,
    "modifications": "Delta:H(4)C(3)O(1)$Ethyl+Deamidated$hexnac$Deamidated$Glu->pyro-Glu",
    "modified_positions": 6,
    "name": "Transmembrane protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRJ8",
    "length": 189,
    "modifications": "Gly$Carbamidomethyl$biotinAcrolein298$Cation:Al[III]$QAT$Malonyl",
    "modified_positions": 4,
    "name": "Flavin prenyltransferase UbiX",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRJ9",
    "length": 670,
    "modifications": "AHA-Alkyne-KDDDD$SMA$Iodoacetanilide:13C(6)$Piperidine$Ethanolamine$Deamidated$Carboxy$succinyl_2h(4)$Delta:H(6)C(7)O(4)$PEITC$Propionyl$UgiJoullieProGly$PyruvicAcidIminyl$Carbamyl$ZGB$Carbamidomethyl$Methyl$Fluoro$Oxidation$Nitrosyl",
    "modified_positions": 33,
    "name": "Methionine--tRNA ligase",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZRK1",
    "length": 211,
    "modifications": "icpl_2h(4)$Propionamide$Methylpyrroline$Carbamidomethyl$dnic$DMPO$DAET$PyridoxalPhosphateH2$Deamidated$Oxidation$Difuran$Gly",
    "modified_positions": 9,
    "name": "Endonuclease III",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZRK3",
    "length": 354,
    "modifications": "bemad_st_2h(6)$Carbamidomethyl$Lipoyl$hexnac(3)$FMNC$Amidine$Oxidation$AMTzHexNAc2$EGCG1$pent(2)$NQIGG",
    "modified_positions": 14,
    "name": "Magnesium transport protein CorA",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZRL0",
    "length": 764,
    "modifications": "Cytopiloyne$Phospho$Dioxidation$deamidated_18o(1)$Ethylphosphate$NHS-LC-Biotin$FTC$O-Dimethylphosphate$Carboxy$O-Isopropylmethylphosphonate$Delta:H(6)C(7)O(4)$Lys->AminoadipicAcid$Biotin:Thermo-88317$dhex(1)hex(1)hexnac(1)neuac(1)$PyruvicAcidIminyl$Cys->PyruvicAcid$Carbamyl$Carbamidomethyl$Unknown:306$Cytopiloyne+water$Oxidation$Cation:Li$Cation:Ca[II]",
    "modified_positions": 28,
    "name": "phosphoenolpyruvate--protein phosphotransferase",
    "unique_modifications": 23
  },
  {
    "id": "Q5ZRL1",
    "length": 268,
    "modifications": "Phosphopropargyl$Carbamidomethyl$hex(1)pent(3)",
    "modified_positions": 3,
    "name": "Probable membrane transporter protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRL3",
    "length": 264,
    "modifications": "Carbonyl$Methyl$Deamidated$Pro->pyro-Glu$Propiophenone$hexnac(2)",
    "modified_positions": 11,
    "name": "Thymidylate synthase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRL4",
    "length": 130,
    "modifications": "Pro->Pyrrolidinone$Oxidation$Decarboxylation$Met->Aha",
    "modified_positions": 5,
    "name": "Thioesterase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRL6",
    "length": 164,
    "modifications": "Pro->Pyrrolidinone$Dimethyl$Oxidation$Decarboxylation",
    "modified_positions": 5,
    "name": "6-carboxy-5,6,7,8-tetrahydropterin synthase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRL9",
    "length": 636,
    "modifications": "SulfanilicAcid:13C(6)$Delta:H(4)C(3)$QEQTGG$Carbamidomethyl$Met->Hpg$Delta:H(2)C(2)$Cytopiloyne$Oxidation$Iminobiotin$Label:13C(1)2H(3)+Oxidation$Gly-loss+Amide$Diethyl$Cation:Ca[II]$RNPXL$Cation:K",
    "modified_positions": 21,
    "name": "Coiled-coil containing protein",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZRM5",
    "length": 310,
    "modifications": "dhex(2)hex(3)hexa(1)hexnac(3)sulf(1)$bemad_st_2h(6)$Oxidation$UgiJoullieProGlyProGly",
    "modified_positions": 7,
    "name": "TPR (Repeat) domain protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRM6",
    "length": 308,
    "modifications": "Delta:H(2)C(2)$Lys->Allysine$Methyl$LG-lactam-R$AMTzHexNAc2$Propyl$Unknown:234$Thiazolidine",
    "modified_positions": 8,
    "name": "Uncharacterized protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZRN3",
    "length": 320,
    "modifications": "Biotin-PEO-Amine$deamidated_18o(1)$sulfanilicacid$dhex(1)hex(1)hexnac(3)$Delta:H(2)C(2)$LG-Hlactam-K$Dihydroxyimidazolidine$dhex(1)hex(2)$Deamidated$Oxidation$PyridoxalPhosphate$methylol$PET$TAMRA-FP",
    "modified_positions": 17,
    "name": "Putative auto-transporter adhesin head GIN domain-containing protein",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZRP6",
    "length": 789,
    "modifications": "SulfanilicAcid:13C(6)$AEC-MAEC$Ammonia-loss$Unknown:234$Carboxymethyl$Cation:Ni[II]$Propionamide$Trimethyl$hexnac(2)neugc(1)$icpl_13c(6)2h(4)$Deamidated$Propyl$succinyl_2h(4)$Glu$Delta:H(2)C(3)$Saligenin$hex(1)hexnac(1)neuac(1)$Methyl+Deamidated$hex(1)hexnac(2)dhex(1)$Hydroxamic_acid$Gly$Dehydrated$Carbamidomethyl$Lipoyl$Cation:Mg[II]$ethylamino$hexnac(3)sulf(1)$IodoU-AMP$Oxidation$Myristoyl$Ethyl$Glu->pyro-Glu",
    "modified_positions": 39,
    "name": "Transcription accessory protein",
    "unique_modifications": 32
  },
  {
    "id": "Q5ZRP7",
    "length": 126,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$ethylamino$Ethanolyl$Oxidation$Carboxy$Formyl$Nitro",
    "modified_positions": 9,
    "name": "Acyl-CoA thioester hydrolase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRQ5",
    "length": 68,
    "modifications": "Oxidation$Phe->CamCys$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 4,
    "name": "Cold shock protein CspE",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRQ6",
    "length": 555,
    "modifications": "deamidated_18o(1)$Carbamidomethyl$Methylthio$Crotonaldehyde$hexnac(1)kdn(2)$Palmitoleyl$Delta:H(2)C(5)$Oxidation$Cation:Al[III]$Methylamine$Unknown:216$hex(2)hexnac(1)me(1)$PyruvicAcidIminyl$ZQG$Delta:H(8)C(6)O(1)",
    "modified_positions": 20,
    "name": "DNA repair protein RecN",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZRQ8",
    "length": 608,
    "modifications": "Gly$Carbamidomethyl$glycidamide$Dap-DSP$Cytopiloyne+water$ethylamino$Cation:K$BMP-piperidinol$hexnac(1)neugc(2)$N-dimethylphosphate$Oxidation$Octanoyl$hex(3)hexnac(3)neuac(2)sulf(1)$dimethyl_2h(4)$Cation:Ca[II]$Cation:Na$Thiazolidine",
    "modified_positions": 23,
    "name": "Large ribosomal subunit assembly factor BipA",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZRR0",
    "length": 336,
    "modifications": "Cytopiloyne$Biotin:Thermo-21330$Unknown:216$Phenylisocyanate$Dioxidation$diart6plex116/119$Lys->CamCys$CresylSaligeninPhosphate$Carbofuran$Crotonyl$dhex(2)hex(2)hexnac(4)$Propionyl$dhex(1)hex(2)hexnac(1)$Pyridylacetyl$Menadione$diart6plex115$SPITC:13C(6)$Gly$AzidoF$diart6plex117$bemad_st_2h(6)$Carbamidomethyl$Methamidophos-O$DMPO$ethylamino$Sulfide$Oxidation$diart6plex$dhex(3)hex(2)hexnac(3)$Delta:H(6)C(3)O(1)$Nitro",
    "modified_positions": 27,
    "name": "Aldo/keto reductase",
    "unique_modifications": 31
  },
  {
    "id": "Q5ZRR2",
    "length": 165,
    "modifications": "Delta:H(4)C(3)$Carbamidomethyl$dhex(2)hex(3)hexnac(1)sulf(1)$HCysThiolactone$Chlorination$Ammonia-loss$Fluoro$Oxidation$Hydroxamic_acid$Gln->pyro-Glu",
    "modified_positions": 14,
    "name": "Uncharacterized protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZRR7",
    "length": 286,
    "modifications": "Deamidated$Oxidation$methylsulfonylethyl$Unknown:216$Diethylphosphate$Delta:H(2)C(3)O(1)",
    "modified_positions": 5,
    "name": "VipE",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRS5",
    "length": 500,
    "modifications": "Dibromo$HNE+Delta:H(2)$Oxidation$Biotin-PEO-Amine",
    "modified_positions": 5,
    "name": "Peptide transport protein, POT family",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRT0",
    "length": 658,
    "modifications": "Methylpyrroline$Decanoyl$Cys->Oxoalanine$Deamidated$Isopropylphospho$Sulfo",
    "modified_positions": 6,
    "name": "O-acetyltransferase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRT1",
    "length": 206,
    "modifications": "PyruvicAcidIminyl$Delta:H(4)C(3)O(1)$Propionyl$Oxidation$EDT-maleimide-PEO-biotin$dhex(2)hex(2)$QEQTGG$PyMIC$methylol$HN2_mustard",
    "modified_positions": 13,
    "name": "Ribosomal RNA large subunit methyltransferase E",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZRT3",
    "length": 291,
    "modifications": "Diethylphosphothione$Carbamidomethyl$ISD_z+2_ion$Ammonium$Oxidation$Carbofuran$LRGG+methyl$methylsulfonylethyl$benzylguanidine$methyl_2h(3)$Iminobiotin$Propiophenone$Dimethylphosphothione",
    "modified_positions": 17,
    "name": "Dihydropteroate synthase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZRT6",
    "length": 249,
    "modifications": "Phycoerythrobilin$Dihydroxyimidazolidine$Carbamidomethyl$Diethylphosphothione",
    "modified_positions": 7,
    "name": "Triosephosphate isomerase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRT9",
    "length": 158,
    "modifications": "Delta:H(4)C(3)$Carbamidomethyl$Delta:H(6)C(3)O(1)$Oxidation$HPG$Trp->Kynurenin$Label:13C(1)2H(3)+Oxidation$Diethyl$Carboxymethyl",
    "modified_positions": 12,
    "name": "NADH-quinone oxidoreductase subunit B",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZRU0",
    "length": 227,
    "modifications": "Dehydrated$CIGG$Carbonyl$Pro->pyro-Glu",
    "modified_positions": 6,
    "name": "NADH-quinone oxidoreductase subunit C",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRU6",
    "length": 166,
    "modifications": "sulfanilicacid$Carbamidomethyl$Phosphopropargyl$GG$Ethanolamine$pyrophospho$Ethyl$Amidine$Menadione-HQ$Oxidation$Delta:H(4)C(2)$murnac$Dimethyl$Dicarbamidomethyl$Glu->pyro-Glu+Methyl",
    "modified_positions": 21,
    "name": "NADH-quinone oxidoreductase subunit I",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZRU7",
    "length": 219,
    "modifications": "Oxidation$Methamidophos-S$Piperidine",
    "modified_positions": 4,
    "name": "NADH-quinone oxidoreductase subunit J",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRU8",
    "length": 101,
    "modifications": "Oxidation$Methamidophos-S",
    "modified_positions": 2,
    "name": "NADH-quinone oxidoreductase subunit K",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRV0",
    "length": 501,
    "modifications": "Pro->Pyrrolidinone$Carbamidomethyl",
    "modified_positions": 2,
    "name": "NADH-quinone oxidoreductase subunit M",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRV3",
    "length": 492,
    "modifications": "icpl_2h(4)$dhex(3)hexnac(3)kdn(1)$HexN$Deoxy$Carbamidomethyl$UgiJoullieProGlyProGly$Methamidophos-O$Delta:H(4)C(6)$Propionyl$PyridoxalPhosphateH2$Deamidated$DYn-2$Oxidation$Unknown:216$dhex(2)hex(2)",
    "modified_positions": 21,
    "name": "Transcription termination/antitermination protein NusA",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZRV5",
    "length": 123,
    "modifications": "Delta:H(2)C(2)$GG$Glu->pyro-Glu+Methyl",
    "modified_positions": 4,
    "name": "Ribosome-binding factor A",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRV6",
    "length": 303,
    "modifications": "Carbamidomethyl$Biotin:Thermo-88310$Delta:H(4)C(6)$Decanoyl$dhex(1)hex(1)hexnac(4)$Oxidation$Guanidinyl$Farnesyl$Delta:H(10)C(8)O(1)$hex(1)hexnac(1)neuac(1)$phosphoRibosyl",
    "modified_positions": 16,
    "name": "tRNA pseudouridine synthase B",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZRV7",
    "length": 91,
    "modifications": "hex(1)hexa(1)$Cation:Li$NHS-LC-Biotin$Ethanolamine$hexnac(1)neuac(1)$Lys->MetOx$dhex(2)hex(2)hexa(1)$hex(2)hexnac(3)$Methylthio",
    "modified_positions": 9,
    "name": "Small ribosomal subunit protein uS15",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZRV8",
    "length": 729,
    "modifications": "Propiophenone$Delta:H(4)C(3)$hex(2)pent(2)me(1)$Delta:H(4)C(5)O(1)$Carbamidomethyl$Ser->LacticAcid$GG$Arg->Npo$Amidine$Arg->Orn$hexnac(1)neugc(2)$Oxidation$Biotin$Unknown:216$hep$Dicarbamidomethyl$2-nitrobenzyl",
    "modified_positions": 25,
    "name": "Polyribonucleotide nucleotidyltransferase",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZRW1",
    "length": 113,
    "modifications": "methyl_2h(3)13c(1)$Ethyl$Oxidation$Dimethyl$Delta:H(4)C(2)$acetyl_2h(3)$Gln->pyro-Glu",
    "modified_positions": 13,
    "name": "HIT family hydrolase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRW4",
    "length": 238,
    "modifications": "GG$LG-anhyropyrrole$Ethyl$Dimethyl$PyMIC$Delta:H(2)C(3)O(1)$Dicarbamidomethyl",
    "modified_positions": 8,
    "name": "Uncharacterized protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZRW9",
    "length": 286,
    "modifications": "NHS-LC-Biotin",
    "modified_positions": 1,
    "name": "DUF547 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZRX1",
    "length": 112,
    "modifications": "Carbamyl$Deoxy$HydroxymethylOP$Oxidation$Gly-loss+Amide",
    "modified_positions": 19,
    "name": "Nucleoid-associated protein lpg2755",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZRX7",
    "length": 389,
    "modifications": "Biotin-PEO-Amine$Delta:H(6)C(7)O(4)$pentose$Ethanedithiol$Lys->MetOx$Pyridylacetyl$Oxidation$Methylamine$DNCB_hapten$Diethylphosphate$Propiophenone$Nitro$hex(1)hexnac(2)neuac(1)sulf(1)$Glycerophospho",
    "modified_positions": 15,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZRY0",
    "length": 187,
    "modifications": "Carbamidomethyl$Deamidated",
    "modified_positions": 4,
    "name": "Oligoribonuclease",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZRY7",
    "length": 429,
    "modifications": "sulfo+amino$SulfanilicAcid:13C(6)$Delta:H(4)C(3)O(1)$Carbamidomethyl$icdid$Cytopiloyne$Ammonium$Oxidation$Unknown:216$murnac$Cation:Li$hep$Gly",
    "modified_positions": 16,
    "name": "histidine kinase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZRY9",
    "length": 341,
    "modifications": "SMA$Carbamidomethyl$Delta:H(2)C(2)$Deamidated$neuac$Triton$Carbofuran$Cation:Na$Gly$Delta:H(6)C(3)O(1)$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 20,
    "name": "(Two component) response regulator",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZRZ0",
    "length": 416,
    "modifications": "Carbamidomethyl$FMNC$pupylation$Oxidation$ZQG$Delta:H(6)C(3)O(1)",
    "modified_positions": 6,
    "name": "Aminotransferase class II",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRZ4",
    "length": 164,
    "modifications": "Oxidation$dhex$Deamidated",
    "modified_positions": 3,
    "name": "Peptidyl-prolyl cis-trans isomerase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZRZ5",
    "length": 209,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Carbamidomethyl$Unknown:250$UgiJoullie$Oxidation$Biotin:Sigma-B1267",
    "modified_positions": 6,
    "name": "Inner membrane protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZRZ7",
    "length": 99,
    "modifications": "Arg->Orn$Carbamidomethyl$SMA",
    "modified_positions": 4,
    "name": "Transcriptional regulator",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZS03",
    "length": 161,
    "modifications": "Carbamidomethyl$hexnac(1)kdn(2)$hex(3)hexnac(1)me(1)$Menadione$Cation:Ca[II]",
    "modified_positions": 6,
    "name": "HTH cro/C1-type domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZS04",
    "length": 95,
    "modifications": "hexnac(1)dhex(2)$Ser->LacticAcid$Diethylphosphothione",
    "modified_positions": 4,
    "name": "UPF0235 protein lpg2716",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZS07",
    "length": 119,
    "modifications": "Carbamidomethyl$Sulfide$Oxidation$Methyl+Deamidated$Succinyl$Pentylamine",
    "modified_positions": 7,
    "name": "Large ribosomal subunit protein bL20",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZS12",
    "length": 144,
    "modifications": "Propionamide$Carboxyethyl$Dap-DSP$hexnac(1)neuac(1)$hydroxyisobutyryl$Oxidation$hex(1)hexnac(1)dhex(1)$clip_traq_3",
    "modified_positions": 10,
    "name": "Large ribosomal subunit protein uL13",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZS13",
    "length": 143,
    "modifications": "Deoxy$Dehydrated$Diethylphosphothione$Carbamidomethyl$CarbamidomethylDTT$Amidine$Deamidated$Oxidation$Biotin-phenacyl$Gly$Glu->pyro-Glu",
    "modified_positions": 9,
    "name": "Small ribosomal subunit protein uS9",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZS16",
    "length": 246,
    "modifications": "Glu->pyro-Glu+Methyl:2H(2)13C(1)$deamidated_18o(1)$Oxidation$diart6plex$diart6plex115$diart6plex118$diart6plex116/119$Amidated$diart6plex117",
    "modified_positions": 6,
    "name": "Ubiquinol-cytochrome c reductase, cytochrome c1",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZS18",
    "length": 131,
    "modifications": "Iodoacetanilide:13C(6)$hex(2)hexnac(2)neuac(1)$dhex(2)hex(2)hexnac(5)$Diisopropylphosphate",
    "modified_positions": 7,
    "name": "Stringent starvation protein B",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZS19",
    "length": 493,
    "modifications": "HexN$lapachenole$Carbamidomethyl$biotinAcrolein298$Delta:H(2)C(2)$Formyl$Dioxidation$Oxidation$Delta:H(4)C(2)$Dimethyl$Ethyl",
    "modified_positions": 14,
    "name": "Bifunctional NAD(P)H-hydrate repair enzyme",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZS20",
    "length": 160,
    "modifications": "hex(1)hexa(1)$hex(2)pent(2)me(1)$Carbamidomethyl$esp$Bromo$Gluratylation",
    "modified_positions": 6,
    "name": "tRNA threonylcarbamoyladenosine biosynthesis protein TsaE",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZS23",
    "length": 313,
    "modifications": "dileu4plex$dileu4plex117$Dehydrated$Carbamidomethyl$Carbonyl$SMA$Cytopiloyne$DAET$Oxidation$Crotonyl$Unknown:216$dileu4plex115$Tyr->Dha",
    "modified_positions": 18,
    "name": "tRNA dimethylallyltransferase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZS28",
    "length": 847,
    "modifications": "FMNH$lapachenole$Carbamidomethyl$QTGG$icpl_13c(6)2h(4)$N-dimethylphosphate$clip_traq_4$hex(1)hexnac(2)dhex(1)$RNPXL$Thrbiotinhydrazide",
    "modified_positions": 14,
    "name": "Cation transporting ATPase PacS",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZS30",
    "length": 466,
    "modifications": "Ser->LacticAcid$AEC-MAEC$Ammonia-loss$EHD-diphenylpentanone$MercaptoEthanol$Thiazolidine$Carboxymethyl$Delta:H(4)C(2)O(-1)S(1)$deamidated_18o(1)$Ethanolamine$Deamidated$dhex(1)hex(5)$Carbofuran$Pro->HAVA$Carboxy$Dimethyl$Decarboxylation$Gln->pyro-Glu$Methylamine$Label:13C(1)2H(3)+Oxidation$Gly$Carbamidomethyl$Methyl$Fluoro$Oxidation$Ethyl",
    "modified_positions": 29,
    "name": "IcmX (IcmY)",
    "unique_modifications": 26
  },
  {
    "id": "Q5ZS31",
    "length": 151,
    "modifications": "Ethyl$Formyl",
    "modified_positions": 2,
    "name": "Type 4 adapter protein IcmW",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZS32",
    "length": 151,
    "modifications": "betaFNA$Lys->MetOx$Carbamidomethyl",
    "modified_positions": 3,
    "name": "IcmV",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZS37",
    "length": 235,
    "modifications": "Iodoacetanilide$Carbamidomethyl$Methylphosphonate$pentose$Deamidated$Oxidation$HPG$Difuran",
    "modified_positions": 8,
    "name": "Hypothetical with two candidate membrane-spanning segments",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZS45",
    "length": 163,
    "modifications": "Myristoyl+Delta:H(-4)$Pyridylacetyl",
    "modified_positions": 2,
    "name": "DotD",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZS54",
    "length": 238,
    "modifications": "Dehydrated$Carbamidomethyl$15N-oxobutanoic$Methylphosphonate$O-Methylphosphate$Oxidation",
    "modified_positions": 9,
    "name": "Dienelactone hydrolase family protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZS57",
    "length": 252,
    "modifications": "hex(1)pent(1)$phosphohex$Carbamidomethyl$Biotin:Thermo-88310$Oxidation$dhex(1)hex(2)hexnac(2)pent(1)$LG-pyrrole$HN2_mustard",
    "modified_positions": 10,
    "name": "Pantothenate synthetase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZS63",
    "length": 322,
    "modifications": "Carbamidomethyl$Cation:Fe[III]$Trioxidation$dhex$Iminobiotin$Gly",
    "modified_positions": 11,
    "name": "Octaprenyl diphosphate synthase IspB",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZS64",
    "length": 371,
    "modifications": "NDA$Carbamidomethyl$QTGG$Delta:H(6)C(6)O(1)$Propargylamine$Isopropylphospho",
    "modified_positions": 6,
    "name": "Sensory box protein, EAL domain, GGDEF domain, signal transduction protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZS68",
    "length": 103,
    "modifications": "Carbamidomethyl$Deamidated$Oxidation$succinyl_2h(4)$Gly",
    "modified_positions": 7,
    "name": "Large ribosomal subunit protein bL21",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZS69",
    "length": 92,
    "modifications": "Delta:H(6)C(7)O(4)$Trioxidation$sulfanilicacid$esp_2h(10)",
    "modified_positions": 4,
    "name": "Large ribosomal subunit protein bL27",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZS71",
    "length": 365,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Carbamidomethyl$acetyl_13c(2)$Ethyl+Deamidated$Ethanolyl$hex(1)hexnac(1)neuac(1)$Carboxy$Succinyl",
    "modified_positions": 14,
    "name": "Competence damage inducible protein CinA",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZS72",
    "length": 272,
    "modifications": "Deoxy$Carbamidomethyl$Deamidated$Oxidation$Phosphoadenosine",
    "modified_positions": 8,
    "name": "Phenylalanine-4-hydroxylase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZS74",
    "length": 618,
    "modifications": "Propargylamine$pent(2)$Phospho$pent(1)hexnac(1)$GluGluGluGlu$Carboxymethyl$HydroxymethylOP$Sulfo$CAF$Carboxy$Argbiotinhydrazide$Delta:H(2)C(3)$glyoxalAGE$glycidamide$GEE$hex(2)hexnac(1)me(1)$bemad_st_2h(6)$Carbamidomethyl$azole$2HPG$Oxidation$Cation:Li$Delta:H(6)C(3)O(1)",
    "modified_positions": 32,
    "name": "UvrABC system protein C",
    "unique_modifications": 23
  },
  {
    "id": "Q5ZS76",
    "length": 219,
    "modifications": "Ethanolamine$Biotin:Thermo-21901+2H2O$propionyl_13c(3)$Oxidation",
    "modified_positions": 4,
    "name": "Outer membrane protein beta-barrel domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZS77",
    "length": 835,
    "modifications": "Biotin-PEO-Amine$Furan$Iodoacetanilide:13C(6)$Propargylamine$Cation:Ni[II]$Lys->Allysine$Deamidated$dhex$Dimethyl$Glu$hex(2)hexnac(2)$sulfo+amino$SulfurDioxide$bemad_st_2h(6)$Carbamidomethyl$15N-oxobutanoic$hexnac(1)dhex(1)$Oxidation$Nitro",
    "modified_positions": 24,
    "name": "Sensory box/GGDEF family protein",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZS78",
    "length": 240,
    "modifications": "Iodoacetanilide$Carbamidomethyl$HNE+Delta:H(2)$Cresylphosphate$neuac$Octanoyl$Oxidation$Methylamine$Label:13C(1)2H(3)+Oxidation$hex(2)$Propiophenone$Cation:Na$Thiazolidine$Nitro",
    "modified_positions": 14,
    "name": "Enhanced entry protein EnhA",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZS79",
    "length": 188,
    "modifications": "Carbamidomethyl$Delta:H(2)C(2)$Methyl$Deamidated$Oxidation",
    "modified_positions": 11,
    "name": "Enhanced entry protein EnhB",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZS82",
    "length": 403,
    "modifications": "hex(1)hexnac(1)neuac(2)ac(2)$Carbamidomethyl$QTGG$Saligenin$LRGG+dimethyl$Cy3-maleimide$Oxidation$Methyl+Deamidated$UgiJoullieProGly$Formyl$Carboxymethyl",
    "modified_positions": 17,
    "name": "Uncharacterized protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZS83",
    "length": 88,
    "modifications": "PyruvicAcidIminyl",
    "modified_positions": 1,
    "name": "Small ribosomal subunit protein bS20",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZS85",
    "length": 454,
    "modifications": "GG$Nethylmaleimide+water$LG-lactam-K$NBS:13C(6)$Dioxidation$Lys->CamCys$CresylSaligeninPhosphate$UgiJoullieProGlyProGly$Ethanolamine$Deamidated$thioacylPA$Hydroxamic_acid$Gly$Delta:H(6)C(3)O(1)$Carbamidomethyl$Methamidophos-O$Phosphoguanosine$Sulfide$Oxidation$Dicarbamidomethyl$propyl_2h(6)$hex(1)hexnac(1)neugc(2)",
    "modified_positions": 35,
    "name": "Leucine aminopeptidase",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZS86",
    "length": 105,
    "modifications": "Oxidation$Carbamidomethyl",
    "modified_positions": 3,
    "name": "DUF1840 domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZS87",
    "length": 144,
    "modifications": "maleimide$Carbamidomethyl$Biotin:Thermo-21901+H2O",
    "modified_positions": 3,
    "name": "DNA polymerase III, chi subunit",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZS92",
    "length": 393,
    "modifications": "Carbamidomethyl$pentose$Biotin:Thermo-21330$hex(1)hexnac(1)dhex(1)me(2)$Dioxidation$Oxidation$N-dimethylphosphate$LRGG+methyl$Carboxy$Propiophenone$HN2_mustard$hep$Decarboxylation",
    "modified_positions": 17,
    "name": "NAD(P)/FAD-dependent oxidoreductase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZS93",
    "length": 90,
    "modifications": "dhex(1)hex(3)hexnac(1)$hex(2)hexnac(1)pent(1)hexa(1)$Carbamidomethyl$hex(1)hexnac(3)sulf(1)$Amino$Ethanolyl$Oxidation$Trp->Kynurenin$hex(1)hexnac(2)neuac(2)$hex(4)hexnac(1)$Thiazolidine",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZS94",
    "length": 1067,
    "modifications": "biotinAcrolein298$trimethyl_13c(3)2h(9)$AEC-MAEC$Ammonia-loss$Unknown:216$clip_traq_4$Phenylisocyanate$Dioxidation$hex(1)pent(2)me(1)$HydroxymethylOP$FTC$Deamidated$Propyl$Carboxy$Dansyl$Succinyl$icpl_2h(4)$hex(1)pent(1)$Deoxy$thioacylPA$Diethylphosphothione$hex(1)neuac(1)pent(1)$AEBS$dhex(1)hex(2)hexnac(1)$Pyridylacetyl$Arg->Npo$hexnac(4)$hex(1)hexnac(2)dhex(2)$glucuronyl$Dehydrated$Carbamidomethyl$dhex(1)hex(1)hexnac(3)$Cytopiloyne+water$hex(1)hexnac(1)kdn(1)sulf(1)$NEMsulfur$Oxidation$Nmethylmaleimide$Bromo$PET$acetyl_2h(3)$Glu->pyro-Glu",
    "modified_positions": 61,
    "name": "Carbamoyl phosphate synthase large chain",
    "unique_modifications": 41
  },
  {
    "id": "Q5ZS95",
    "length": 160,
    "modifications": "Deoxy$Carbamidomethyl$Malonyl$Carboxy$O-Methylphosphate$dhex(1)hex(1)hexnac(1)neuac(1)$Gly",
    "modified_positions": 8,
    "name": "Transcription elongation factor GreA",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZS97",
    "length": 353,
    "modifications": "Lipoyl$Propargylamine$Arg->GluSA$Oxidation$methylol$glycosyl",
    "modified_positions": 6,
    "name": "Cysteine protease",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSA0",
    "length": 259,
    "modifications": "Carbamidomethyl$Methyl-PEO12-Maleimide$Decarboxylation$HCysThiolactone$Sulfide$Oxidation$Biotin$Gly$Delta:H(6)C(3)O(1)",
    "modified_positions": 12,
    "name": "Cell division protein ZipA",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZSA3",
    "length": 447,
    "modifications": "Carbamidomethyl$Methamidophos-O$Deamidated$Methylamine$Gly$Thiazolidine",
    "modified_positions": 8,
    "name": "UDP-N-acetylmuramoylalanine--D-glutamate ligase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSA5",
    "length": 469,
    "modifications": "Carbamidomethyl$Methylphosphonate$AEBS$Delta:H(4)C(6)$CarbamidomethylDTT$Arg->Npo$Fluoro$Oxidation$GEE$clip_traq_3$Unknown:234",
    "modified_positions": 14,
    "name": "UDP-N-acetylmuramate--L-alanine ligase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZSA7",
    "length": 364,
    "modifications": "Carbamidomethyl$Deamidated$Oxidation$clip_traq_3$Propiophenone$Gly",
    "modified_positions": 11,
    "name": "D-alanine--D-alanine ligase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSB0",
    "length": 398,
    "modifications": "SulfanilicAcid:13C(6)$neugc$Delta:H(2)C(2)$Maleimide-PEO2-Biotin$DAET$HNE-BAHAH$Biotin:Thermo-21901+H2O$clip_traq_4$Formyl$Biotin:Invitrogen-M1602$Acetyl$Palmitoleyl$pupylation$CAF$Deamidated$dhex$Cation:Na$Gln->pyro-Glu$Carboxyethyl$Arg->Npo$Carbamidomethyl$Sulfo-NHS-LC-LC-Biotin$ethylamino$Oxidation$methyl_2h(3)$hex",
    "modified_positions": 29,
    "name": "Cell division protein FtsZ",
    "unique_modifications": 26
  },
  {
    "id": "Q5ZSB8",
    "length": 146,
    "modifications": "PhosphoCytidine",
    "modified_positions": 1,
    "name": "YdbS-like PH domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSB9",
    "length": 657,
    "modifications": "deamidated_18o(1)$dimethyl_2h(4)13c(2)$Ethylphosphate$Carbamidomethyl$15N-oxobutanoic$NHS-LC-Biotin$HydroxymethylOP$GluGlu$MTSL$Oxidation$GPIanchor$dimethyl_2h(6)$Didehydro$Cation:Ca[II]",
    "modified_positions": 12,
    "name": "Acyltransferase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZSC5",
    "length": 314,
    "modifications": "Carbamyl$Unknown:210$Carbamidomethyl$2HPG$DimethylamineGMBS$Propargylamine$Lys->MetOx$Oxidation$Myristoyl$Phenylisocyanate:2H(5)",
    "modified_positions": 13,
    "name": "Methionyl-tRNA formyltransferase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZSD1",
    "length": 385,
    "modifications": "acetyl_13c(2)$Biotin:Thermo-88310$pentose$Ethanolyl$Propiophenone$Thiazolidine",
    "modified_positions": 4,
    "name": "Acid sphingomyelinase-like phosphodiesterase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSE1",
    "length": 84,
    "modifications": "CresylSaligeninPhosphate$4-ONE$Delta:H(2)C(5)$Oxidation$Hypusine",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZSE3",
    "length": 125,
    "modifications": "neugc$Carbamidomethyl$Phe->CamCys$HNE$Oxidation$Carboxy",
    "modified_positions": 9,
    "name": "Hypothetical, uroporphyrin-III C-methyltransferase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSF0",
    "length": 202,
    "modifications": "Iodoacetanilide$Carbamidomethyl$Phosphopropargyl$Crotonyl$GluGluGluGlu$Formyl",
    "modified_positions": 9,
    "name": "ISI400 transposase B",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSF3",
    "length": 132,
    "modifications": "Carbamidomethyl$Gln->pyro-Glu$Oxidation$diart6plex$diart6plex116/119$diart6plex117",
    "modified_positions": 3,
    "name": "LvrA",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSF4",
    "length": 68,
    "modifications": "CresylSaligeninPhosphate",
    "modified_positions": 1,
    "name": "Prophage regulatory protein-like",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSF5",
    "length": 225,
    "modifications": "gist-quat$icpl$Deoxy$Methyl$Oxidation",
    "modified_positions": 14,
    "name": "Phage repressor",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZSF7",
    "length": 195,
    "modifications": "Carbonyl$Carbamidomethyl$glycidamide$HCysThiolactone$FTC$hex(3)$CAMthiopropanoyl",
    "modified_positions": 9,
    "name": "Transcriptional regulator",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZSG6",
    "length": 281,
    "modifications": "Dihydroxyimidazolidine$Oxidation$Biotin-PEG-PRA$NEM:2H(5)",
    "modified_positions": 5,
    "name": "DUF2306 domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSH1",
    "length": 469,
    "modifications": "Deoxyhypusine$Carbamyl$Propionamide$Biotin:Thermo-21325$Dehydrated$Carbamidomethyl$glucosylgalactosyl$Oxidation$Carboxyethylpyrrole$Lysbiotinhydrazide$Cation:Li$Phosphopantetheine$SPITC$Glu->pyro-Glu",
    "modified_positions": 18,
    "name": "Dot/Icm secretion system substrate",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZSH3",
    "length": 457,
    "modifications": "Diphthamide$deamidated_18o(1)$icpl$Ethylphosphate$Carbamidomethyl$Carbonyl$FTC$dhex(1)hex(1)$Deamidated$O-Dimethylphosphate$Oxidation$hex(1)hexnac(1)neuac(1)ac(1)$Thiophospho$HN2_mustard$bisANS-sulfonates",
    "modified_positions": 20,
    "name": "peptidoglycan lytic exotransglycosylase",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZSH7",
    "length": 127,
    "modifications": "hexnac(2)neugc(1)$Oxidation$Deamidated",
    "modified_positions": 3,
    "name": "Large-conductance mechanosensitive channel",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSH8",
    "length": 135,
    "modifications": "Carbamidomethyl$Pentylamine$Methylthio$Deamidated$Formyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 8,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSI1",
    "length": 318,
    "modifications": "dhex(1)hex(2)hexa(1)hexnac(1)",
    "modified_positions": 1,
    "name": "Ferredoxin reductase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSI4",
    "length": 298,
    "modifications": "AFB1_Dialdehyde$PhosphoCytidine$ethylamino$hex(2)hexnac(1)$GluGluGluGlu",
    "modified_positions": 8,
    "name": "Tellurite resistance protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZSI6",
    "length": 194,
    "modifications": "Carbamyl$hex(3)hexnac(3)$Diisopropylphosphate$Carbamidomethyl$hexnac(2)neugc(1)$GG$hex(1)hexnac(1)dhex(1)me(1)$Dicarbamidomethyl",
    "modified_positions": 7,
    "name": "prephenate dehydratase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZSI7",
    "length": 347,
    "modifications": "Carbamidomethyl$Cytopiloyne$Propionyl$ident$Oxidation$Met->Hpg$DimethylpyrroleAdduct$SPITC",
    "modified_positions": 16,
    "name": "Phospho-2-dehydro-3-deoxyheptonate aldolase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZSJ1",
    "length": 455,
    "modifications": "Deoxy$hex(4)hexa(1)hexnac(1)$Carbamidomethyl$Phosphopropargyl$Delta:H(2)C(3)$Deamidated$Puromycin$hex(5)hexnac(1)$Oxidation$diart6plex118$diart6plex$diart6plex115$hex(1)hexnac(1)$BHT$diart6plex116/119$Delta:H(6)C(3)O(1)$diart6plex117",
    "modified_positions": 28,
    "name": "Macrodomain effector MavL domain-containing protein",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZSJ3",
    "length": 287,
    "modifications": "PyridoxalPhosphateH2$Oxidation$Can-FP-biotin$Delta:H(2)C(3)O(1)$Delta:H(8)C(6)O(2)$hep",
    "modified_positions": 7,
    "name": "Transcriptional regulator, LuxR family",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSK8",
    "length": 397,
    "modifications": "Biotin-PEO-Amine$Aspartylurea$Carbamidomethyl$hexnac$Deamidated$Phosphoguanosine$Dimethyl$BITC$Delta:H(4)C(2)$Cation:Al[III]$bemad_c_2h(6)$Oxidation$Acetyldeoxyhypusine$diart6plex115$Ethyl",
    "modified_positions": 16,
    "name": "SdeD",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZSL2",
    "length": 295,
    "modifications": "Propionamide$Carbamidomethyl$DAET$Tris$Oxidation$probiotinhydrazide$Cation:Li$pent(1)hexnac(1)",
    "modified_positions": 11,
    "name": "Ankyrin repeat protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZSL9",
    "length": 310,
    "modifications": "Oxidation$Hydroxamic_acid$Carboxy->Thiocarboxy$Delta:H(8)C(6)O(1)",
    "modified_positions": 5,
    "name": "DUF5636 domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSM4",
    "length": 164,
    "modifications": "Ammonium$Deamidated$hex(1)pent(3)$Oxidation$methyl_2h(3)$hex(2)$Hydroxymethyl$methylol",
    "modified_positions": 17,
    "name": "Small heat shock protein HspC2",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZSN1",
    "length": 462,
    "modifications": "Delta:H(4)C(3)O(1)$LG-anhydrolactam$Diethylphosphate$methyl_2h(3)13c(1)$hex(3)hexnac(3)neugc(1)sulf(1)$Delta:O(4)$Pro->Pyrrolidinone$cGMP+RMP-loss$hex(1)neuac(1)$Decarboxylation$Carboxyethyl$GGQ$Cation:K$dhex(1)hex(3)hexnac(1)$15N-oxobutanoic$Carbamidomethyl$GluGlu$Unknown:306$HN3_mustard$hex(3)$Oxidation$Oxidation+NEM$phosphoRibosyl$Propiophenone$dhex(4)hex(1)hexnac(1)kdn(2)",
    "modified_positions": 29,
    "name": "phosphomannomutase",
    "unique_modifications": 25
  },
  {
    "id": "Q5ZSP1",
    "length": 113,
    "modifications": "Cation:Fe[II]$Oxidation$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Hydrogenase maturation factor HypA",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSP2",
    "length": 252,
    "modifications": "Pyro-carbamidomethyl$gist-quat_2h(9)$Gly-loss+Amide",
    "modified_positions": 4,
    "name": "Hydrogenase maturation factor HypB",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSP5",
    "length": 368,
    "modifications": "SulfanilicAcid:13C(6)$Carbamidomethyl$Trioxidation$hex$Glu$AHA-SS",
    "modified_positions": 6,
    "name": "Hydrogenase maturation factor",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSP8",
    "length": 281,
    "modifications": "SulfanilicAcid:13C(6)$Propionamide$Carboxyethyl$Carbamidomethyl$Lys->Allysine$Oxidation$neiaa$Methamidophos-S$DNCB_hapten",
    "modified_positions": 7,
    "name": "Hydrogenase/sulfur reductase gamma subunit",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZSQ1",
    "length": 159,
    "modifications": "Oxidation$icpl$galactosyl",
    "modified_positions": 3,
    "name": "Hydrogenase expression/formation protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSQ4",
    "length": 239,
    "modifications": "His+O(2)$sulfanilicacid$PEITC$Gly-loss+Amide",
    "modified_positions": 4,
    "name": "Peptide aspartate b-dioxygenase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSQ5",
    "length": 310,
    "modifications": "Dehydrated$Carbamidomethyl$hexnac$hex(2)neuac(1)$Oxidation$clip_traq_2$Propyl",
    "modified_positions": 8,
    "name": "Exported protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZSR1",
    "length": 471,
    "modifications": "OxProBiotin$hex(1)hexa(1)$Cytopiloyne$Nethylmaleimide+water$Phospho$deamidated_18o(1)$Trimethyl$OxLysBiotin$hydroxyisobutyryl$Deamidated$Octanoyl$Propyl$Deoxy$GEE$Hydroxymethyl$Gly$Dehydrated$Carbamidomethyl$Oxidation$hex(3)$methylol$Met->Hpg$Glu->pyro-Glu",
    "modified_positions": 29,
    "name": "Ankyrin repeat-containing protein",
    "unique_modifications": 23
  },
  {
    "id": "Q5ZSR2",
    "length": 209,
    "modifications": "icpl_13c(6)$Delta:H(4)C(3)O(1)$SMA$Carbamidomethyl$FTC$Propionyl$pupylation$BITC$Oxidation$GGQ$Biotin$Nmethylmaleimide$3-phosphoglyceryl$Diethyl$glucuronyl$Pro->pyro-Glu",
    "modified_positions": 14,
    "name": "Uncharacterized protein",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZSR4",
    "length": 149,
    "modifications": "Cation:Ag$Trimethyl$Propyl",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSR7",
    "length": 242,
    "modifications": "dhex(1)hex(1)hexnac(1)neuac(1)",
    "modified_positions": 1,
    "name": "Integral membrane protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSS3",
    "length": 185,
    "modifications": "Diisopropylphosphate$Carbamidomethyl$AEC-MAEC$Isopropylphospho$Oxidation$Phenylisocyanate:2H(5)",
    "modified_positions": 6,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSS4",
    "length": 136,
    "modifications": "FP-Biotin$Carbamidomethyl$hexa(2)hexnac(3)$Pyridylacetyl$Oxidation$HMVK$Phenylisocyanate",
    "modified_positions": 9,
    "name": "PhnB protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZSS5",
    "length": 157,
    "modifications": "Dehydrated$Carbamidomethyl$Oxidation$Cation:Na$Glu->pyro-Glu$BEMAD_ST$O-Et-N-diMePhospho",
    "modified_positions": 8,
    "name": "DNA binding protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZST9",
    "length": 403,
    "modifications": "nic$icpl$GG$GluGluGlu$Methyl$Oxidation$Trioxidation$hex(3)hexnac(3)neuac(1)$Diethyl$dhex(1)hex(2)hexa(1)$Dicarbamidomethyl",
    "modified_positions": 10,
    "name": "Malonate decarboxylase acyl carrier protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZSU6",
    "length": 183,
    "modifications": "Oxidation$Sulfo$bacillosamine$Phospho",
    "modified_positions": 9,
    "name": "N-acetyltransferase domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSV0",
    "length": 368,
    "modifications": "Aspartylurea$Carbamidomethyl$phosphohex(2)$Oxidation$EDT-maleimide-PEO-biotin",
    "modified_positions": 6,
    "name": "Ankyrin repeat family protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZSV2",
    "length": 97,
    "modifications": "Carbamidomethyl$Formyl$Decarboxylation$Deamidated",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSV8",
    "length": 219,
    "modifications": "PEO-Iodoacetyl-LC-Biotin$SulfanilicAcid:13C(6)$Oxidation$Acetylhypusine",
    "modified_positions": 4,
    "name": "Transglutaminase-like domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSW1",
    "length": 133,
    "modifications": "Oxidation$Delta:H(4)C(3)",
    "modified_positions": 3,
    "name": "Mutator MutT protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSW4",
    "length": 306,
    "modifications": "CAMthiopropanoyl$Oxidation$Methyl$Deamidated",
    "modified_positions": 6,
    "name": "Regulatory protein (LysR transcriptional regulator)",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSW6",
    "length": 354,
    "modifications": "Deoxy$Carbamidomethyl$hex(5)hexnac(1)$succinyl_2h(4)$Dansyl$Delta:H(4)C(3)O(2)",
    "modified_positions": 8,
    "name": "Leucine-rich repeat-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSX0",
    "length": 356,
    "modifications": "Carbamidomethyl$biotinAcrolein298$hexnac(1)dhex(2)$DMPO$Ethanolyl$CyDye-Cy3$HNE$Oxidation$hex(1)hexnac(1)dhex(1)$O-pinacolylmethylphosphonate$dileu4plex115$hex(1)pent(2)me(1)",
    "modified_positions": 12,
    "name": "Transcriptional regulator",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZSX4",
    "length": 294,
    "modifications": "deamidated_18o(1)$Carbamidomethyl$biotinAcrolein298$hexnac(1)dhex(2)$Lipoyl$CHDH",
    "modified_positions": 6,
    "name": "Leucine-rich repeat-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSX5",
    "length": 434,
    "modifications": "Carbamidomethyl$acetyl_13c(2)$Carbonyl$Ethanolyl$Oxidation$Didehydro$hex$acetyl_2h(3)",
    "modified_positions": 14,
    "name": "SdbC",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZSX7",
    "length": 721,
    "modifications": "Cation:Al[III]$Amidine$hex(1)neuac(1)$methylol$Decarboxylation$Carbonyl$Propionyl$GGQ$Trp->Oxolactone$PyruvicAcidIminyl$Glycerophospho$Carbamyl$GluGlu$Cytopiloyne+water$DMPO$Fluoro$Oxidation$hex$acetyl_2h(3)",
    "modified_positions": 26,
    "name": "Catalase-peroxidase 1",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZSX9",
    "length": 308,
    "modifications": "hex(1)neuac(1)pent(1)$CAMthiopropanoyl",
    "modified_positions": 2,
    "name": "Plasminogen activator",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSY4",
    "length": 484,
    "modifications": "hex(5)hexa(1)$Delta:H(4)C(3)$hex(1)hexnac(1)dhex(1)me(1)$Propargylamine$Oxidation$hep$2-nitrobenzyl$Ethyl$O-Et-N-diMePhospho",
    "modified_positions": 12,
    "name": "Symporter",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZSY9",
    "length": 75,
    "modifications": "Deoxyhypusine$Lipoyl",
    "modified_positions": 3,
    "name": "HTH cro/C1-type domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSZ0",
    "length": 305,
    "modifications": "glucosylgalactosyl$Dap-DSP$Oxidation$Nethylmaleimide+water$Thiophos-S-S-biotin$CAMthiopropanoyl",
    "modified_positions": 8,
    "name": "Transcriptional regulator, LysR family",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSZ1",
    "length": 157,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Cation:Mg[II]$Oxidation$GEE$Carboxy$MercaptoEthanol",
    "modified_positions": 6,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZSZ5",
    "length": 204,
    "modifications": "Oxidation$Propargylamine$Carbamidomethyl$O-Et-N-diMePhospho",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSZ6",
    "length": 312,
    "modifications": "Aspartylurea$Carboxyethyl$Diisopropylphosphate$Lipoyl$Methyl$dhex(1)hex(2)$methyl_2h(3)$Cation:Li$pent(1)hexnac(1)$Unknown:234$Cation:K",
    "modified_positions": 13,
    "name": "HipA-like C-terminal domain-containing protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZSZ8",
    "length": 75,
    "modifications": "Lipoyl$SPITC",
    "modified_positions": 2,
    "name": "HTH cro/C1-type domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZT00",
    "length": 583,
    "modifications": "CHDH$Dehydrated$Delta:H(4)C(5)O(1)$15N-oxobutanoic$Carbamidomethyl$Ser->LacticAcid$Phe->CamCys$DNCB_hapten$Dioxidation$Oxidation$dhex(2)hex(2)$hex(2)hexnac(2)dhex(1)$Diethylphosphate$hex$O-Isopropylmethylphosphonate$Methylthio$Glu->pyro-Glu",
    "modified_positions": 30,
    "name": "Inner membrane protein",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZT02",
    "length": 121,
    "modifications": "icpl_2h(4)$dnic$Biotin$dhex$Malonyl$acetyl_2h(3)",
    "modified_positions": 6,
    "name": "BRCT domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZT06",
    "length": 147,
    "modifications": "Trimethyl$Carbamidomethyl$methyl_2h(3)13c(1)$Unknown:306$hexnac$Menadione-HQ$Oxidation$clip_traq_4$Acetyldeoxyhypusine",
    "modified_positions": 11,
    "name": "GatB/YqeY domain-containing protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZT13",
    "length": 330,
    "modifications": "Pyridylethyl$Ser->LacticAcid$hex(1)pent(3)me(1)$GG$Diethylphosphate$MercaptoEthanol$Carboxymethyl$Deamidated$Tris$Didehydro$Gln->pyro-Glu$Methyl-PEO12-Maleimide$SPITC:13C(6)$Gly$TMPP-Ac$Dehydrated$Carbamidomethyl$Oxidation$Dicarbamidomethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 30,
    "name": "Malate dehydrogenase",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZT14",
    "length": 306,
    "modifications": "Oxidation$Lys->AminoadipicAcid$dhex(2)hex(2)hexnac(1)$Pentylamine",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZT26",
    "length": 277,
    "modifications": "Myristoyl+Delta:H(-4)$Oxidation$hex(1)hexnac(2)dhex(2)",
    "modified_positions": 7,
    "name": "Alpha/beta hydrolase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZT27",
    "length": 158,
    "modifications": "Gly$OxArgBiotinRed$Ser->LacticAcid$Carbamidomethyl$ISD_z+2_ion$4-ONE$hexnac(5)$pupylation$Amidine$Acetyldeoxyhypusine$HNE$Oxidation$OxArgBiotin$murnac$MesitylOxide$UgiJoullieProGly$Dioxidation$Glu",
    "modified_positions": 22,
    "name": "RNA polymerase-binding transcription factor DksA",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZT28",
    "length": 287,
    "modifications": "serotonylation$Oxidation$dhex(2)hex(3)$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Release factor glutamine methyltransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZT30",
    "length": 424,
    "modifications": "deamidated_18o(1)$Carbamidomethyl$Furan$Ethyl+Deamidated$Sulfo$hexnac(2)dhex(1)$spermine$Oxidation$Nmethylmaleimide$Phospho$Thiazolidine$Glu->pyro-Glu+Methyl",
    "modified_positions": 18,
    "name": "Glutamyl-tRNA reductase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZT47",
    "length": 301,
    "modifications": "dhex(1)hex(2)hexnac(4)$Nmethylmaleimide$Carbamidomethyl",
    "modified_positions": 6,
    "name": "Chemotaxis (Motility protein A) transmembrane",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZT48",
    "length": 386,
    "modifications": "Propiophenone$trimethyl_13c(3)2h(9)$Oxidation$Unknown:216$benzylguanidine$MesitylOxide$Glu",
    "modified_positions": 6,
    "name": "Transmembrane protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZT49",
    "length": 260,
    "modifications": "Iodoacetanilide$Trimethyl$Diethylphosphothione$Carbamidomethyl$Cytopiloyne$CarbamidomethylDTT$ethylamino$Deamidated$SulfurDioxide$Cys->Oxoalanine$Oxidation$murnac$Delta:H(2)C(3)O(1)$Formyl$Cys->methylaminoAla",
    "modified_positions": 14,
    "name": "3-hydroxybutyrate dehydrogenase",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZT51",
    "length": 290,
    "modifications": "Carbamidomethyl$hex(1)hexnac(3)neugc(1)$Acetyl$dhex(2)hex(4)$Ammonia-loss$Amidine$Oxidation$Unknown:234$acetyl_2h(3)",
    "modified_positions": 19,
    "name": "4-hydroxy-tetrahydrodipicolinate synthase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZT53",
    "length": 100,
    "modifications": "IED-Biotin$Carbamyl$Deoxy$Carbamidomethyl$dimethyl_2h(6)13c(2)$Cresylphosphate$trimethyl_2h(9)$BITC$Oxidation$clip_traq_4$hep$Amidino",
    "modified_positions": 8,
    "name": "Secreted protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZT58",
    "length": 84,
    "modifications": "Unknown:210$Carbamidomethyl$Acetyl$dimethyl_2h(6)13c(2)$DimethylamineGMBS$DYn-2$cGMP+RMP-loss",
    "modified_positions": 6,
    "name": "Glutaredoxin",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZT59",
    "length": 139,
    "modifications": "Dap-DSP$Oxidation$Carbamidomethyl$Deamidated",
    "modified_positions": 5,
    "name": "Rhodanese domain protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZT61",
    "length": 310,
    "modifications": "Ethylphosphate$Carbamidomethyl$trimethyl_13c(3)2h(9)$O-Dimethylphosphate$Cation:Li",
    "modified_positions": 4,
    "name": "Ribosomal protein uL3 glutamine methyltransferase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZT62",
    "length": 352,
    "modifications": "Carbamidomethyl$Arg->Npo$Oxidation$3-phosphoglyceryl$hex(2)$BEMAD_ST",
    "modified_positions": 7,
    "name": "Chorismate synthase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZT63",
    "length": 340,
    "modifications": "Label:2H(4)+GG$deamidated_18o(1)$Carbamidomethyl$Oxidation$MercaptoEthanol$Malonyl",
    "modified_positions": 9,
    "name": "Aspartate-semialdehyde dehydrogenase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZT65",
    "length": 467,
    "modifications": "Carbamidomethyl$hex(1)hexnac(1)dhex(1)me(1)$Delta:H(2)C(2)$Phe->CamCys$Cation:Na$DAET$Hydroxymethyl$Oxidation$MesitylOxide$Delta:H(8)C(6)O(2)$Dioxidation",
    "modified_positions": 16,
    "name": "Ankyrin repeat domain protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZT75",
    "length": 206,
    "modifications": "dileu4plex$dileu4plex117$Delta:H(4)C(5)O(1)$dileu4plex118$phosphohexnac$hex(1)hexnac(2)$dhex(1)hexnac(4)$hex(1)pent(2)me(1)",
    "modified_positions": 6,
    "name": "FMN-dependent NADH:quinone oxidoreductase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZT83",
    "length": 332,
    "modifications": "Carbamidomethyl$SMA$AccQTag$Deamidated$Isopropylphospho$Oxidation$benzylguanidine$Propiophenone$Gly",
    "modified_positions": 26,
    "name": "Fumarylacetoacetate hydrolase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZT84",
    "length": 348,
    "modifications": "Biotin-HPDP$Carbamidomethyl$biotinAcrolein298$OxLysBiotin$Deamidated$Oxidation$Carboxymethyl",
    "modified_positions": 13,
    "name": "4-hydroxyphenylpyruvate dioxygenase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZT85",
    "length": 218,
    "modifications": "Deoxy$Carbamidomethyl$Deamidated$maleimide$Oxidation$Dimethyl$hex(2)hexnac(2)",
    "modified_positions": 8,
    "name": "O-methyltransferase, SAM-dependent",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZT86",
    "length": 357,
    "modifications": "Ser->LacticAcid$Delta:H(2)C(2)$Biotin:Thermo-21330$Ammonia-loss$Propargylamine$Phospho$Unknown:234$hex(3)hexnac(2)$Acetyl$Ammonium$Sulfo$Deamidated$methyl+acetyl_2h(3)$propionyl_13c(3)$Gln->pyro-Glu$dhex(2)hex(2)hexnac(2)neugc(1)$dhex(1)hex(1)hexnac(2)kdn(1)$Carbamidomethyl$Fluoro$Oxidation",
    "modified_positions": 22,
    "name": "Glu/Leu/Phe/Val dehydrogenase",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZT88",
    "length": 239,
    "modifications": "icpl_13c(6)$Carbamidomethyl$Dap-DSP$monomethylphosphothione$Arg2PG$Oxidation$Cation:Al[III]",
    "modified_positions": 10,
    "name": "Glycerophosphoryl diester esterase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZT89",
    "length": 437,
    "modifications": "icpl_13c(6)$Delta:H(4)C(5)O(1)$3-deoxyglucosone$Oxidation$dhex(2)hex(1)hexnac(2)kdn(1)$Nmethylmaleimide$PyruvicAcidIminyl$Delta:H(4)C(3)O(2)",
    "modified_positions": 9,
    "name": "sn-glycerol-3-phosphate-binding periplasmic protein UgpB",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZT91",
    "length": 216,
    "modifications": "Diisopropylphosphate$Carbamidomethyl$Deamidated$Octanoyl$Hydroxymethyl",
    "modified_positions": 5,
    "name": "DUF5638 domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZT92",
    "length": 280,
    "modifications": "deamidated_18o(1)$Diisopropylphosphate$Cation:Al[III]$Oxidation$maleimide3",
    "modified_positions": 5,
    "name": "Oxidoreductase (NAD-dependent epimerase/dehydratase)",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZT95",
    "length": 412,
    "modifications": "Deoxyhypusine$Delta:H(2)C(3)$Methylphosphonate$ethylamino$Arg2PG$Oxidation$LG-anhydrolactam$methylsulfonylethyl$Can-FP-biotin$Delta:H(8)C(6)O(2)$hex(7)hexnac(1)",
    "modified_positions": 13,
    "name": "Prolidase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZT97",
    "length": 187,
    "modifications": "Carbamidomethyl$hexnac(3)$Nmethylmaleimide$Delta:H(2)C(5)",
    "modified_positions": 4,
    "name": "Acyltransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTA0",
    "length": 372,
    "modifications": "FP-Biotin$Unknown:210$Carbamidomethyl$hexnac$Oxidation",
    "modified_positions": 8,
    "name": "Acetate kinase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTA1",
    "length": 468,
    "modifications": "Butyryl$Delta:H(5)C(2)$Deoxy$Carbamidomethyl$Crotonaldehyde$Amidine$Deamidated$Dimethyl$Dioxidation$Oxidation$Methamidophos-S$hep$Gly$O-Et-N-diMePhospho",
    "modified_positions": 17,
    "name": "Phosphate acetyl/butyryltransferase family protein includes: (Dehydratase mit MaoC domain",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZTA3",
    "length": 103,
    "modifications": "deamidated_18o(1)$Propionamide$Iodoacetanilide$Deamidated$Oxidation$dhex(2)hex(1)hexnac(2)kdn(1)$Argbiotinhydrazide$PyruvicAcidIminyl$Glu",
    "modified_positions": 14,
    "name": "Periplasmic, osmotically inducible protein Y-like",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZTA7",
    "length": 83,
    "modifications": "icpl_2h(4)$Carboxymethyl:13C(2)$deamidated_18o(1)$Deoxy$Methylpyrroline$Carbamidomethyl$dnic$glycidamide$Diethylphosphothione$Dethiomethyl$CarbamidomethylDTT$Met->Hsl$Oxidation$MercaptoEthanol$Gly$glucuronyl",
    "modified_positions": 17,
    "name": "Silver efflux pump",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZTB0",
    "length": 457,
    "modifications": "Delta:H(8)C(6)O(1)$Ethylphosphate$Biotin:Thermo-88310$phosphohexnac$s-glcnac$O-Dimethylphosphate$maleimide$Oxidation$Methamidophos-S$succinyl_13c(4)$AMTzHexNAc2$CAMthiopropanoyl$Glu->pyro-Glu+Methyl:2H(2)13C(1)$Tyr->Dha$Thiazolidine$Dimethylphosphothione",
    "modified_positions": 16,
    "name": "Glutamine synthetase",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZTB2",
    "length": 386,
    "modifications": "Diisopropylphosphate$PhosphoCytidine$Carbamidomethyl$Carbonyl$NHS-LC-Biotin$Methyl$Biotin:Cayman-10141$Deamidated$NO_SMX_SEMD$Oxidation$Pro->pyro-Glu$Phycocyanobilin$Hydroxamic_acid$Decarboxylation",
    "modified_positions": 29,
    "name": "Alcohol dehydrogenase, iron containing",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZTB3",
    "length": 232,
    "modifications": "neiaa$ZQG$Carbamidomethyl$PyridoxalPhosphate",
    "modified_positions": 3,
    "name": "Glutamine amidotransferase, class I",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTB6",
    "length": 169,
    "modifications": "Methyl$Carbamidomethyl$dhex",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTB7",
    "length": 430,
    "modifications": "phosphohexnac$s-glcnac$Menadione-HQ$dhex(4)hex(2)hexnac(3)$Oxidation$Carboxy$dhex(3)hex(2)hexnac(3)$dhex(2)hex(2)hexnac(2)neuac(1)",
    "modified_positions": 11,
    "name": "C4-dicarboxylate transport protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTD1",
    "length": 250,
    "modifications": "Isopropylphospho$Oxidation$Pro->Pyrrolidinone$Cation:Ca[II]$UgiJoullieProGly$Thiazolidine$Decarboxylation",
    "modified_positions": 7,
    "name": "3-oxoacyl reductase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZTD6",
    "length": 563,
    "modifications": "dhex(2)hex(2)hexnac(1)$Ser->LacticAcid$DAET$dhex(4)hex(1)hexnac(3)kdn(1)$dhex(1)hex(1)hexnac(3)sulf(1)$Trimethyl$Acetyl$Octanoyl$thioacylPA$glycidamide$2-dimethylsuccinyl$Methamidophos-S$Thiophos-S-S-biotin$Delta:H(4)C(2)$dhex(1)hex(1)hexa(1)hexnac(3)$Label:2H(4)+GG$Carbamidomethyl$HN3_mustard$Methyl$Oxidation$Cy3-maleimide$Thiophospho",
    "modified_positions": 30,
    "name": "Isovaleryl CoA dehydrogenase",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZTD9",
    "length": 407,
    "modifications": "Delta:H(6)C(7)O(4)$Delta:H(5)C(2)$Dehydro$Diethylphosphothione$Oxidation$NEMsulfurWater$hexnac(2)",
    "modified_positions": 8,
    "name": "Uncharacterized protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZTE1",
    "length": 239,
    "modifications": "Ethyl+Deamidated$Phe->CamCys$Oxidation$Methylamine$benzylguanidine$Propiophenone$Nitrosyl$dhex(1)hex(3)hexa(1)hexnac(2)",
    "modified_positions": 6,
    "name": "2,3,4,5-tetrahydropyridine-2,6-carboxylate N-succinyltransferase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTE6",
    "length": 590,
    "modifications": "maleimide5$NHS-LC-Biotin$cGMP+RMP-loss$Carboxyethylpyrrole$AMTzHexNAc2$dhex$methylol$Gluratylation$Saligenin$Lys->MetOx$methylsulfonylethyl$Methyl+Deamidated$Hydroxamic_acid$Didehydroretinylidene$sulfanilicacid$Carboxy->Thiocarboxy$Oxidation$VFQQQTGG$Delta:H(2)C(3)O(1)",
    "modified_positions": 18,
    "name": "Purine NTPase, putative",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZTE8",
    "length": 307,
    "modifications": "Deamidated$dimethyl_2h(6)13c(2)$Carbamidomethyl$Cation:Li",
    "modified_positions": 4,
    "name": "Nucleoside-diphosphate sugar epimerase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTF1",
    "length": 134,
    "modifications": "Acetyl$Chlorination$Glu$Carbamidomethyl",
    "modified_positions": 4,
    "name": "YjbQ family protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTG2",
    "length": 178,
    "modifications": "Methamidophos-O$dhex(1)hex(1)hexnac(4)$Oxidation$spermidine$hep$Formyl",
    "modified_positions": 15,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZTG6",
    "length": 323,
    "modifications": "hex(4)hexnac(2)neuac(1)$dhex(2)hex(2)hexnac(4)$Carboxy->Thiocarboxy$Ser->LacticAcid$thioacylPA$NHS-LC-Biotin$Acetyl$glycidamide$Diethylphosphothione$Oxidation$GGQ",
    "modified_positions": 22,
    "name": "Ornithine cyclodeaminase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZTG8",
    "length": 208,
    "modifications": "Deoxy$Carbamidomethyl$Phosphogluconoylation$Methyl$CarbamidomethylDTT$Oxidation$Didehydro$CarboxymethylDTT$O-Isopropylmethylphosphonate$Gly$acetyl_2h(3)",
    "modified_positions": 17,
    "name": "(Beta)-carbonic anhydrase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZTH2",
    "length": 620,
    "modifications": "cGMP$Ser->LacticAcid$Carbamidomethyl$Carbonyl$GG$a-type-ion$Cresylphosphate$phosphohex(2)$glycidamide$DAET$Deamidated$Oxidation$Carbofuran$BITC$hex(2)sulf(1)$Diethylphosphate$Formyl",
    "modified_positions": 22,
    "name": "IcmL-like",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZTH5",
    "length": 133,
    "modifications": "Deamidated",
    "modified_positions": 1,
    "name": "Acetyltransferase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTH8",
    "length": 468,
    "modifications": "Carbamidomethyl$Formyl$Ammonium$icpl_13c(6)2h(4)$Menadione-HQ$Octanoyl$Oxidation$4-ONE+Delta:H(-2)O(-1)$glucuronyl$PET$Dansyl$AzidoF",
    "modified_positions": 12,
    "name": "IS4 family transposase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZTJ0",
    "length": 336,
    "modifications": "FP-Biotin$Carbamidomethyl$HN3_mustard$hex(2)neuac(1)$Oxidation$pent(1)hexnac(1)$SPITC:13C(6)$gist-quat_2h(3)",
    "modified_positions": 11,
    "name": "N-acetyltransferase domain-containing protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTJ2",
    "length": 124,
    "modifications": "Carboxy$Delta:H(4)C(2)O(-1)S(1)$Oxidation$Unknown:306",
    "modified_positions": 6,
    "name": "VOC domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTJ3",
    "length": 257,
    "modifications": "CresylSaligeninPhosphate$PyruvicAcidIminyl$hex(1)hexnac(1)dhex(1)",
    "modified_positions": 3,
    "name": "Acetyltransferase, GNAT family",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTJ6",
    "length": 170,
    "modifications": "pupylation",
    "modified_positions": 1,
    "name": "Outer membrane protein beta-barrel domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTK1",
    "length": 482,
    "modifications": "CresylSaligeninPhosphate$Deoxy$methyl_2h(2)$Ethylphosphate$Carbamidomethyl$HydroxymethylOP$benzoyl$maleimide$O-Dimethylphosphate$Oxidation$Carbofuran$Cation:Zn[II]$clip_traq_3$methylsulfonylethyl$succinyl_13c(4)$hex$Cation:Ca[II]$Dansyl",
    "modified_positions": 22,
    "name": "Uncharacterized protein",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZTL2",
    "length": 119,
    "modifications": "Ser->LacticAcid$Carbamidomethyl$Ammonium$Deamidated$Oxidation$Unknown:216$methyl_2h(3)$Gly",
    "modified_positions": 14,
    "name": "Uncharacterized protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTM4",
    "length": 538,
    "modifications": "Deoxy$glucosylgalactosyl$Deamidated$Oxidation$MeMePhosphorothioate$Phosphoadenosine$Phosphopantetheine$Gluratylation",
    "modified_positions": 10,
    "name": "Calmodulin-dependent protein kinase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTN3",
    "length": 220,
    "modifications": "Iodoacetanilide$PEITC$azole$Oxidation$Phospho$acetyl_2h(3)",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZTN5",
    "length": 625,
    "modifications": "Ammonium$GlycerylPE$Oxidation$methyl_2h(3)$Delta:H(2)C(3)O(1)",
    "modified_positions": 4,
    "name": "Probable potassium transport system protein Kup 2",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTN6",
    "length": 153,
    "modifications": "Carbamidomethyl$Arg->Orn$hex(5)hexnac(1)$Methamidophos-S$dhex(1)hex(3)hexnac(2)pent(1)$Glu",
    "modified_positions": 8,
    "name": "Cyclic nucleotide-binding domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZTN8",
    "length": 303,
    "modifications": "Biotin:Thermo-21330$Phosphoguanosine$Oxidation$Biotin:Thermo-21345$Succinyl",
    "modified_positions": 6,
    "name": "Cobalt zinc cadmium cation transporter",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTP1",
    "length": 472,
    "modifications": "Ser->LacticAcid$PS_Hapten$Ammonia-loss$ethylsulfonylethyl$pent(2)$SPITC$icpl_13c(6)$UgiJoullieProGlyProGly$2-monomethylsuccinyl$Acetyl$dhex(2)hexnac(7)$OxLysBiotin$HNE$HCysteinyl$DimethylpyrroleAdduct$NDA$Deoxy$Methylthio$PyruvicAcidIminyl$Cation:K$Dehydrated$15N-oxobutanoic$Carbamidomethyl$Methamidophos-O$Menadione-HQ$Oxidation$Delta:H(2)C(3)O(1)$Cation:Ca[II]$Glu->pyro-Glu",
    "modified_positions": 30,
    "name": "Transposase, IS4 family, Tn5",
    "unique_modifications": 29
  },
  {
    "id": "Q5ZTP7",
    "length": 127,
    "modifications": "Delta:H(5)C(2)$Ethylphosphate$hex(1)neugc(1)$O-Dimethylphosphate$dhex(1)hex(2)hexa(1)",
    "modified_positions": 4,
    "name": "Transposase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTP9",
    "length": 184,
    "modifications": "Carbamyl$HexN$neugc$TNBS$Biotin:Thermo-33033-H$Formyl$acetyl_2h(3)$Nitro",
    "modified_positions": 7,
    "name": "24 kDa macrophage-induced major protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTQ6",
    "length": 165,
    "modifications": "glycidamide$Ethanedithiol$Phosphopropargyl",
    "modified_positions": 3,
    "name": "Transmembrane protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTQ7",
    "length": 58,
    "modifications": "Diethylphosphate$Oxidation$3-phosphoglyceryl",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTQ8",
    "length": 48,
    "modifications": "Oxidation$pent(2)",
    "modified_positions": 3,
    "name": "Core-binding (CB) domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTR6",
    "length": 294,
    "modifications": "sulfo+amino$gist-quat$methyl_2h(2)$Carbamidomethyl$Propionyl$Pyridylacetyl$DNCB_hapten$Oxidation$Crotonyl$methylsulfonylethyl$Phospho$Phenylisocyanate",
    "modified_positions": 12,
    "name": "LvrA",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZTS0",
    "length": 187,
    "modifications": "PEITC$hexnac(2)neugc(1)$GG$NHS-LC-Biotin$Oxidation$pent(2)$Biotin:Thermo-21345$Ethyl",
    "modified_positions": 12,
    "name": "Putative conjugative transfer protein TraE",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTS5",
    "length": 202,
    "modifications": "Fluoro$Cresylphosphate$deamidated_18o(1)",
    "modified_positions": 3,
    "name": "TraW",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTS6",
    "length": 331,
    "modifications": "bemad_st_2h(6)$SMA$Carbamidomethyl$AEBS$dhex(1)hex(3)hexnac(3)$Oxidation$Crotonyl$Dimethylphosphothione",
    "modified_positions": 9,
    "name": "TraU",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZTS8",
    "length": 603,
    "modifications": "Unknown:248$Carbamidomethyl$GG$Iodoacetanilide:13C(6)$Hydroxytrimethyl$hexnac(2)$DHP$Oxidation$bisANS-sulfonates$methyl+acetyl_2h(3)$GGQ$Biotin-phenacyl$Dicarbamidomethyl$propionyl_13c(3)$dichlorination$hex(1)pent(2)me(1)$Delta:H(6)C(3)O(1)$Dimethylphosphothione",
    "modified_positions": 18,
    "name": "TraN",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZTT1",
    "length": 461,
    "modifications": "Trimethyl$Phosphopropargyl$Carbamidomethyl$Dap-DSP$Crotonaldehyde$hydroxyisobutyryl$neuac$Oxidation$Cys->methylaminoAla$hex(1)hexnac(1)dhex(1)$CAMthiopropanoyl$Butyryl$MercaptoEthanol$phosphoRibosyl$NEM:2H(5)$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 19,
    "name": "TraH",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZTT3",
    "length": 630,
    "modifications": "CresylSaligeninPhosphate$QTGG$Dihydroxyimidazolidine$HCysThiolactone$EDT-iodoacetyl-PEO-biotin$ethylsulfonylethyl$clip_traq_3$murnac$O-Isopropylmethylphosphonate$Methylthio$Carboxymethyl",
    "modified_positions": 11,
    "name": "TraD",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZTT5",
    "length": 363,
    "modifications": "hexnac(2)neuac(1)$glucosylgalactosyl$Carbamidomethyl$Cation:Cu[I]$Oxidation$Phospho$hexnac(2)dhex(2)$Cation:Zn[II]$Phosphopantetheine",
    "modified_positions": 11,
    "name": "DUF4917 domain-containing protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZTT6",
    "length": 278,
    "modifications": "hex(2)neuac(1)$Oxidation$QAT$CAMthiopropanoyl$Cation:Na$gist-quat_2h(3)",
    "modified_positions": 7,
    "name": "Site-specific DNA-methyltransferase (adenine-specific)",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZTU3",
    "length": 125,
    "modifications": "Oxidation$GGQ$Methylthio$GluGlu",
    "modified_positions": 6,
    "name": "MazG (Nucleoside triphosphate pyrophosphohydrolase)",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTV4",
    "length": 334,
    "modifications": "CresylSaligeninPhosphate$Formyl$Carbamidomethyl$PyridoxalPhosphate",
    "modified_positions": 5,
    "name": "Prophage dlp12 integrase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTV5",
    "length": 292,
    "modifications": "hexnac(1)dhex(2)$Thiophospho$Carbamidomethyl$biotinAcrolein298",
    "modified_positions": 5,
    "name": "Mevalonate kinase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTV6",
    "length": 432,
    "modifications": "NDA$Deoxy$hex(3)hexnac(3)$Carbamidomethyl$Menadione-HQ$N-dimethylphosphate$Oxidation$dhex$hexnac(2)",
    "modified_positions": 12,
    "name": "3-hydroxy-3-methylglutaryl coenzyme A reductase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZTV9",
    "length": 99,
    "modifications": "3-deoxyglucosone$Fluoro$Oxidation$hex(1)hexnac(1)dhex(1)$Thiazolidine",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTW1",
    "length": 374,
    "modifications": "Lys->CamCys$hex(1)pent(1)$Carbamidomethyl$Oxidation$CHDH$Diethylphosphate$Carboxymethyl",
    "modified_positions": 10,
    "name": "ABC transporter, permease",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZTW2",
    "length": 245,
    "modifications": "LRGG$PEITC$Carbamidomethyl$Oxidation$Methylamine$hex",
    "modified_positions": 8,
    "name": "ABC transporter, ATP binding protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZTW4",
    "length": 200,
    "modifications": "PEITC$Carbamidomethyl$Ethanedithiol$dimethyl_2h(6)13c(2)$Oxidation$Cation:Na$Gly",
    "modified_positions": 12,
    "name": "Conserved domain protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZTW5",
    "length": 176,
    "modifications": "Propionamide$Carboxyethyl$Unknown:248$Carbamidomethyl$SMA$Dehydrated$Cys->Oxoalanine$Oxidation$CarboxymethylDMAP$Cation:Ca[II]$BHT$bisANS-sulfonates$Cation:K$Glu->pyro-Glu",
    "modified_positions": 13,
    "name": "Peptidoglycan-associated lipoprotein",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZTW6",
    "length": 322,
    "modifications": "Cytopiloyne+water$Methamidophos-S$Gly-loss+Amide$hep$DimethylpyrroleAdduct$Gln->pyro-Glu",
    "modified_positions": 12,
    "name": "Cell division coordinator CpoB",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZTW7",
    "length": 217,
    "modifications": "bemad_st_2h(6)$OxProBiotin$Oxidation$GPIanchor$hex(1)pent(2)me(1)",
    "modified_positions": 6,
    "name": "7-carboxy-7-deazaguanine synthase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTX2",
    "length": 200,
    "modifications": "Iodoacetanilide$Carbamidomethyl$Crotonaldehyde$Methyl$Deamidated$maleimide$Cation:Al[III]$Methyl+Deamidated$Gly$Delta:H(6)C(3)O(1)",
    "modified_positions": 17,
    "name": "Nucleoside triphosphate pyrophosphatase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZTX9",
    "length": 112,
    "modifications": "Arg->Orn$Sulfo$dhex(1)hex(1)$Phospho",
    "modified_positions": 4,
    "name": "7,8-dihydroneopterin aldolase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTY1",
    "length": 445,
    "modifications": "CresylSaligeninPhosphate$Deoxy$Carbamidomethyl$Delta:H(6)C(3)O(1)$Cytopiloyne+water$Cation:K$Deamidated$BMP-piperidinol$Pro->Pyrrolidinone$Oxidation$Phosphoadenosine$Carboxymethyl$Carboxy$Cation:Ca[II]$Gly$Decarboxylation",
    "modified_positions": 18,
    "name": "Phospho-2-dehydro-3-deoxyheptonate aldolase",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZTY6",
    "length": 382,
    "modifications": "Hydroxytrimethyl$Nethylmaleimide+water$Met->Hse$Formylasparagine$Dioxidation$UgiJoullieProGlyProGly$FTC$Deamidated$methyl+acetyl_2h(3)$Deoxyhypusine$Deoxy$pentose$neiaa$Gly$AzidoF$Carbamidomethyl$Oxidation$Propiophenone$Delta:H(6)C(3)O(1)",
    "modified_positions": 26,
    "name": "S-adenosylmethionine synthase",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZTY7",
    "length": 441,
    "modifications": "Carbamyl$Carboxy->Thiocarboxy$Carbamidomethyl$Amino$Methyl$Dioxidation$Oxidation$BITC$hex(1)neuac(1)$methyl_2h(3)$succinyl_2h(4)$Hydroxamic_acid$Carboxymethyl$Gln->pyro-Glu",
    "modified_positions": 21,
    "name": "Adenosylhomocysteinase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZTY9",
    "length": 562,
    "modifications": "15N-oxobutanoic$Carbamidomethyl$hexnac(4)$Oxidation$Cation:Li$Cation:Na$Malonyl$RNPXL$Thiazolidine",
    "modified_positions": 11,
    "name": "Serine metalloprotease",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZTZ2",
    "length": 191,
    "modifications": "Oxidation$Thiophospho",
    "modified_positions": 2,
    "name": "Hypothetical, YGGT family protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTZ4",
    "length": 231,
    "modifications": "Cation:Fe[II]$Carbamidomethyl$Oxidation$GPIanchor$Dioxidation",
    "modified_positions": 12,
    "name": "Pyridoxal phosphate homeostasis protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTZ5",
    "length": 344,
    "modifications": "Diisopropylphosphate$DYn-2$Dioxidation$Formyl$FTC$Glu$DimethylpyrroleAdduct$Delta:H(6)C(7)O(4)$AFB1_Dialdehyde$methyl_2h(2)$OxArgBiotinRed$Cresylphosphate$Lys->AminoadipicAcid$Thiophospho$Thiophos-S-S-biotin$Phosphoadenosine$sulfanilicacid$Carbamidomethyl$Biotin-PEG-PRA$GluGluGlu$hexnac(1)dhex(1)$Oxidation$Cation:Li$Bromobimane$phosphoRibosyl$HN2_mustard",
    "modified_positions": 23,
    "name": "Twitching motility protein PilT",
    "unique_modifications": 26
  },
  {
    "id": "Q5ZTZ6",
    "length": 235,
    "modifications": "Biotin-PEO-Amine$Delta:H(4)C(3)O(1)$AEC-MAEC$glucosone$clip_traq_3$icpl_13c(6)$Nmethylmaleimide+water$Dihydroxyimidazolidine$CarbamidomethylDTT$pupylation$hexnac$Deamidated$propionyl_13c(3)$Glu$Carboxyethyl$Diethylphosphothione$glycidamide$Carbamidomethyl$Unknown:306$Oxidation$imid_2h(4)$Delta:H(2)C(3)O(1)$Delta:H(6)C(3)O(1)",
    "modified_positions": 28,
    "name": "Ribonuclease PH",
    "unique_modifications": 23
  },
  {
    "id": "Q5ZTZ7",
    "length": 288,
    "modifications": "Iodoacetanilide$Carbamidomethyl$dimethyl_2h(6)13c(2)$Cytopiloyne+water$Lys->AminoadipicAcid$Oxidation$glucosone$Thiophospho$bisANS-sulfonates$Thiazolidine",
    "modified_positions": 11,
    "name": "Stress-induced protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZU00",
    "length": 128,
    "modifications": "Carbamidomethyl$dhex(1)hex(1)hexnac(3)$hex(1)pent(3)me(1)$CarbamidomethylDTT$Deamidated$Didehydro$Myristoyl$Gly",
    "modified_positions": 8,
    "name": "Endoribonuclease L-PSP",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZU01",
    "length": 163,
    "modifications": "UgiJoullieProGly",
    "modified_positions": 2,
    "name": "Aspartyl protease",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZU04",
    "length": 337,
    "modifications": "hex(1)hexa(1)$Cytopiloyne+water$Methyl$HNE$Oxidation$Dioxidation$BEMAD_ST$RNPXL$pyrophospho",
    "modified_positions": 11,
    "name": "S-adenosylmethionine:tRNA ribosyltransferase-isomerase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZU06",
    "length": 111,
    "modifications": "Argbiotinhydrazide$Thiazolidine",
    "modified_positions": 1,
    "name": "Sec translocon accessory complex subunit YajC",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZU07",
    "length": 618,
    "modifications": "SulfanilicAcid:13C(6)$Delta:H(4)C(2)O(-1)S(1)$Deoxy$deamidated_18o(1)$Dehydrated$Biotin:Thermo-88310$Lys->AminoadipicAcid$Oxidation$clip_traq_3$dhex$hep$MercaptoEthanol",
    "modified_positions": 16,
    "name": "Protein translocase subunit SecD",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZU09",
    "length": 113,
    "modifications": "Carbamidomethyl",
    "modified_positions": 2,
    "name": "Putative pterin-4-alpha-carbinolamine dehydratase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZU10",
    "length": 369,
    "modifications": "HNE-Delta:H(2)O$Carbamidomethyl$SMA$EDT-iodoacetyl-PEO-biotin$Oxidation$Nethylmaleimide+water$Lysbiotinhydrazide$clip_traq_4$Gly-loss+Amide$Hydroxymethyl",
    "modified_positions": 11,
    "name": "Histidinol-phosphate aminotransferase 2",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZU12",
    "length": 268,
    "modifications": "Carbamidomethyl$MG-H1$Oxidation$Gly-loss+Amide$Delta:H(2)C(3)O(1)$LG-lactam-K$Gly",
    "modified_positions": 6,
    "name": "Tfp pilus assembly protein PilW",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZU14",
    "length": 397,
    "modifications": "Lys->CamCys$dhex(2)hex(4)hexnac(1)$HNE-Delta:H(2)O$Unknown:162$Carbamidomethyl$Methylphosphonate$hexnac$Oxidation$Nethylmaleimide+water$GGQ$Thiazolidine",
    "modified_positions": 13,
    "name": "Membrane-bound lytic murein transglycosylase A",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZU17",
    "length": 216,
    "modifications": "unknown_420",
    "modified_positions": 1,
    "name": "Lysoplasmalogenase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZU20",
    "length": 181,
    "modifications": "Oxidation$acetyl_2h(3)",
    "modified_positions": 2,
    "name": "Dihydrofolate reductase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZU21",
    "length": 155,
    "modifications": "Carbamidomethyl$HNE$Oxidation$Phospho$ZQG$Palmitoyl",
    "modified_positions": 7,
    "name": "Phosphohistidine phosphatase SixA",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZU24",
    "length": 245,
    "modifications": "Carbamyl$Carbamidomethyl$QTGG$FTC$Oxidation$PET",
    "modified_positions": 10,
    "name": "Hydantoin racemase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZU29",
    "length": 455,
    "modifications": "FP-Biotin$Methamidophos-O$AEC-MAEC$Methyl$Oxidation$Methamidophos-S$clip_traq_4$O-pinacolylmethylphosphonate$Pro->Pyrrolidone$PyruvicAcidIminyl",
    "modified_positions": 18,
    "name": "DUF5624 domain-containing protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZU32",
    "length": 286,
    "modifications": "Carbamidomethyl$Ammonia-loss$Oxidation$Met->AspSA$Dansyl$Glu->pyro-Glu+Methyl",
    "modified_positions": 8,
    "name": "UVB-resistance protein UVR8",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZU34",
    "length": 297,
    "modifications": "SMA$Delta:H(2)C(2)$Amino$Ammonia-loss$hex(1)hexnac(2)dhex(2)sulf(1)$diart6plex116/119$gist-quat$deamidated_18o(1)$hexnac(2)sulf(1)$Deamidated$Didehydro$dhex(2)hex(4)$TAMRA-FP$glycidamide$Methylamine$Methyl+Deamidated$diart6plex115$Hydroxymethyl$Gly$hex(1)hexnac(2)neuac(1)sulf(1)$diart6plex117$Carbamidomethyl$Methyl$Oxidation$Heme$hex(3)$diart6plex$Myristoyl+Delta:H(-4)$diart6plex118",
    "modified_positions": 22,
    "name": "Major outer membrane protein",
    "unique_modifications": 29
  },
  {
    "id": "Q5ZU35",
    "length": 80,
    "modifications": "Carbamidomethyl$dhex(2)hex(2)hexnac(3)neugc(1)$OxLysBiotinRed$Oxidation$Met->AspSA$Met-loss+Acetyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 6,
    "name": "XRE family transcriptional regulator",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZU37",
    "length": 139,
    "modifications": "Delta:H(2)C(2)$Carbamidomethyl$Deamidated",
    "modified_positions": 4,
    "name": "Organic hydroperoxide resistance protein OsmC, predicted redox protein, regulator of sulfide bond formation",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZU38",
    "length": 207,
    "modifications": "Oxidation$Methyl$Carbonyl$Didehydro",
    "modified_positions": 8,
    "name": "Glutathione S-transferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZU44",
    "length": 436,
    "modifications": "Carbamidomethyl$Cation:Mg[II]$maleimide$Dioxidation$OxLysBiotinRed$unknown_420$murnac$Cation:Na$Formyl",
    "modified_positions": 12,
    "name": "Uncharacterized protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZU52",
    "length": 367,
    "modifications": "Biotin-PEO-Amine$bemad_st_2h(6)$Carbamidomethyl$Oxidation$AMTzHexNAc2$hexnac(2)dhex(2)",
    "modified_positions": 6,
    "name": "Dipeptide epimerase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZU56",
    "length": 269,
    "modifications": "icpl_2h(4)$Carbamidomethyl$dnic$HCysThiolactone$Cation:Al[III]$Oxidation$dhex(2)hex(4)hexnac(5)$Cation:Li$Thiazolidine",
    "modified_positions": 6,
    "name": "3',5'-cyclic nucleotide phosphodiesterase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZU58",
    "length": 374,
    "modifications": "Dehydrated$Nitrene$Carbonyl$Menadione-HQ$Pro->Pyrrolidinone$Oxidation$Thiazolidine",
    "modified_positions": 7,
    "name": "Guanine nucleotide exchange protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZU63",
    "length": 327,
    "modifications": "benzoyl$Cation:Mg[II]$Carboxymethyl$hex(1)hexnac(2)dhex(2)",
    "modified_positions": 4,
    "name": "3',5'-cyclic nucleotide phosphodiesterase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZU69",
    "length": 438,
    "modifications": "PyMIC$BDMAPP$Iodoacetanilide$Thrbiotinhydrazide",
    "modified_positions": 3,
    "name": "Polyketide synthase, type I",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZU75",
    "length": 204,
    "modifications": "Can-FP-biotin$clip_traq_3$Carbamidomethyl$hex(1)pent(3)me(1)",
    "modified_positions": 5,
    "name": "Leucine-rich repeat-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZU77",
    "length": 247,
    "modifications": "neugc$Unknown:248$Carbamidomethyl$Delta:H(6)C(6)O(1)$Oxidation$Biotin-tyramide",
    "modified_positions": 9,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZU78",
    "length": 383,
    "modifications": "FP-Biotin$hex(1)pent(3)$Oxidation$benzylguanidine$clip_traq_4$pent(1)hexnac(1)$Propiophenone$acetyl_2h(3)$Dimethylphosphothione",
    "modified_positions": 11,
    "name": "Serine kinase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZU82",
    "length": 881,
    "modifications": "Biotin-PEO-Amine$HexN$LG-anhydrolactam$clip_traq_3$Cation:Ni[II]$Dimethylphosphothione$Unknown:162$TMPP-Ac:13C(9)$UgiJoullieProGlyProGly$NHS-LC-Biotin$hydroxyisobutyryl$clip_traq_2$Biotin-phenacyl$Methyl+Deamidated$Carbamidomethyl$GluGlu$acetyl_13c(2)$monomethylphosphothione$Ethanolyl$Oxidation$CHDH$Met->Hpg$acetyl_2h(3)",
    "modified_positions": 27,
    "name": "Coiled-coil protein",
    "unique_modifications": 23
  },
  {
    "id": "Q5ZU84",
    "length": 111,
    "modifications": "Gly$pupylation$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Ferredoxin",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZU87",
    "length": 59,
    "modifications": "Carbamidomethyl$Acetylhypusine$Arg->GluSA$imid_2h(4)$Gly",
    "modified_positions": 6,
    "name": "Methyltransferase activator Trm112 homolog",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZU88",
    "length": 250,
    "modifications": "Unknown:210$Carbamidomethyl$Methyl$HNE$Oxidation$Cation:Al[III]$Myristoyl$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 13,
    "name": "3-deoxy-manno-octulosonate cytidylyltransferase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZU91",
    "length": 105,
    "modifications": "Oxidation$Ser->LacticAcid$Deamidated",
    "modified_positions": 3,
    "name": "Possible regulator of murein genes BolA",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZU97",
    "length": 420,
    "modifications": "Delta:H(4)C(3)$glucosylgalactosyl$Quinone$acetyl_13c(2)$propyl_2h(6)$hex(1)hexa(1)hexnac(2)",
    "modified_positions": 6,
    "name": "D-alanyl-D-alanine carboxypeptidase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZUA1",
    "length": 177,
    "modifications": "MM-diphenylpentanone$Delta:H(5)C(2)$Nitro",
    "modified_positions": 5,
    "name": "Transporting ATPase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZUB1",
    "length": 159,
    "modifications": "Oxidation$Pyridylacetyl$Carbamidomethyl",
    "modified_positions": 4,
    "name": "YchJ-like middle NTF2-like domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZUC1",
    "length": 91,
    "modifications": "Delta:H(4)C(3)$Carboxyethyl$Haloxon$Carbamidomethyl$Dihydroxyimidazolidine$AEC-MAEC$Oxidation$LRGG+methyl$SPITC:13C(6)",
    "modified_positions": 11,
    "name": "Acylphosphatase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZUC5",
    "length": 146,
    "modifications": "Andro-H2O$Carbamyl$Dehydrated$Delta:H(4)C(5)O(1)$Carbamidomethyl$Delta:H(2)C(5)$LG-lactam-K$Gly$Glu->pyro-Glu",
    "modified_positions": 12,
    "name": "Lactoylglutathione lyase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZUC8",
    "length": 177,
    "modifications": "Furan$Deamidated$MesitylOxide$Dioxidation$Delta:H(8)C(6)O(1)",
    "modified_positions": 7,
    "name": "SPOR domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUD5",
    "length": 224,
    "modifications": "dhex(1)hex(1)hexnac(1)neuac(1)$Carbamidomethyl$Oxidation$Gly-loss+Amide$Dicarbamidomethyl$hex$Dioxidation$Gln->pyro-Glu",
    "modified_positions": 12,
    "name": "Ribonuclease 3",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZUD9",
    "length": 214,
    "modifications": "Diethylphosphothione$Carbamidomethyl$acetyl_13c(2)$Cytopiloyne$hexnac(1)dhex(1)$Heme$Oxidation$N-dimethylphosphate$Carboxy",
    "modified_positions": 16,
    "name": "ATP-dependent Clp protease proteolytic subunit",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZUE0",
    "length": 424,
    "modifications": "glucosylgalactosyl$QQQTGG$Carbamidomethyl$Dehydro$Tween80$LG-Hlactam-K$2-dimethylsuccinyl$Propargylamine$Deamidated$QEQTGG$LG-pyrrole$NQIGG$Cation:K",
    "modified_positions": 13,
    "name": "ATP-dependent Clp protease ATP-binding subunit ClpX",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZUE1",
    "length": 816,
    "modifications": "Delta:H(4)C(3)O(1)$Diisopropylphosphate$GG$Cytopiloyne$Unknown:216$Carboxymethyl$Thiazolidine$Propionamide$Delta:H(4)C(6)$Lys->Allysine$Ethanolamine$icpl_13c(6)2h(4)$Deamidated$spermine$Didehydro$Argbiotinhydrazide$Propionyl$Label:13C(1)2H(3)+Oxidation$Dehydrated$Carbamidomethyl$Methamidophos-O$Ethyl+Deamidated$Methyl$Ethanolyl$Oxidation$Delta:H(6)C(3)O(1)",
    "modified_positions": 44,
    "name": "Lon protease",
    "unique_modifications": 26
  },
  {
    "id": "Q5ZUE3",
    "length": 624,
    "modifications": "Phospho$Pro->Pyrrolidone$Propionamide$Ammonium$dhex(1)hex(5)$dhex(1)hex(2)hexnac(2)sulf(1)$hex(2)$spermidine$Succinyl$Glu$AEBS$Methylamine$Delta:H(4)C(2)$Hydroxamic_acid$Cytopiloyne+water$Ethyl$O-Methylphosphate$Oxidation$Delta:H(2)C(3)O(1)$AHA-SS_CAM$gist-quat_2h(3)",
    "modified_positions": 29,
    "name": "Periplasmic chaperone PpiD",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZUE7",
    "length": 220,
    "modifications": "SulfanilicAcid:13C(6)$Fluorescein-tyramine$GG$Met->Hse$Unknown:216$Glu->pyro-Glu$Thiazolidine$Ethanolamine$Biotin-phenacyl$Decarboxylation$Gln->pyro-Glu$Gluratylation$Carbonyl$AEBS$dileu4plex$dileu4plex117$Dehydrated$Unknown:306$Dicarbamidomethyl$acetyl_2h(3)$gist-quat_2h(3)",
    "modified_positions": 23,
    "name": "Dot/Icm T4SS effector",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZUE8",
    "length": 116,
    "modifications": "Ser->LacticAcid$Acetyl$Methyl$Oxidation$Argbiotinhydrazide$Cation:K",
    "modified_positions": 6,
    "name": "Rhodanese domain protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZUF1",
    "length": 431,
    "modifications": "PhosphoCytidine$Methyl$Cation:Li$Hydroxamic_acid$TMPP-Ac",
    "modified_positions": 6,
    "name": "Glutamate-cysteine ligase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUF9",
    "length": 688,
    "modifications": "Deoxy$Ser->LacticAcid$Carbamidomethyl$Haloxon$PS_Hapten$succinyl_2h(4)$benzoyl$ethylsulfonylethyl$Tris$Deamidated$Oxidation$Cation:Al[III]$succinyl_13c(4)$Phosphoadenosine$O-Isopropylmethylphosphonate$Methylthio$Gluratylation$Dimethylphosphothione",
    "modified_positions": 21,
    "name": "Glycine--tRNA ligase beta subunit",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZUG0",
    "length": 176,
    "modifications": "Acetyl$BHT$Dipyrrolylmethanemethyl",
    "modified_positions": 3,
    "name": "D,D-heptose 1,7-bisphosphate phosphatase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZUG1",
    "length": 243,
    "modifications": "Label:2H(4)+GG$Propionamide$PEITC$Carbamidomethyl$Acetyl$Ammonium$Lys->MetOx$Isopropylphospho$clip_traq_4$methyl_2h(3)$Hydroxymethyl$LG-pyrrole$glucuronyl",
    "modified_positions": 11,
    "name": "Ribosomal RNA small subunit methyltransferase J",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZUG6",
    "length": 138,
    "modifications": "dileu4plex117$Delta:H(4)C(3)$Carbamidomethyl$glycidamide$Phe->CamCys$Methyl$Oxidation",
    "modified_positions": 7,
    "name": "VirK protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZUG8",
    "length": 302,
    "modifications": "Carbamidomethyl$hydroxyisobutyryl$Oxidation$Nethylmaleimide+water$propionyl_13c(3)",
    "modified_positions": 8,
    "name": "hydroxymethylglutaryl-CoA lyase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUH1",
    "length": 535,
    "modifications": "Deoxy$dhex(1)hex(3)hexnac(1)sulf(1)$Carbamidomethyl$Carbonyl$AEBS$hexnac(2)sulf(1)$hex(4)hexnac(4)me(2)pent(1)$Oxidation$LG-pyrrole$acetyl_2h(3)",
    "modified_positions": 11,
    "name": "Propionyl CoA carboxylase beta subunit",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUH3",
    "length": 394,
    "modifications": "Ser->LacticAcid$Dethiomethyl$Piperidine$Met->Hsl$Met->Hse$BADGE$Ethanolamine$Deamidated$Isopropylphospho$Pro->Pyrrolidinone$Carboxyethylpyrrole$spermidine$Decarboxylation$Deoxy$Cresylphosphate$TNBS$Myristoleyl$Gly$Carbamyl$bemad_st_2h(6)$Carbamidomethyl$GluGlu$ethylamino$Fluoro$Oxidation$Myristoyl+Delta:H(-4)$propyl_2h(6)",
    "modified_positions": 37,
    "name": "Acyl CoA C-acetyltransferase",
    "unique_modifications": 27
  },
  {
    "id": "Q5ZUH7",
    "length": 333,
    "modifications": "Carbamyl$Diisopropylphosphate$Unknown:248$Carbonyl$Carbamidomethyl$Unknown:306$EDT-iodoacetyl-PEO-biotin$Oxidation$hex(1)hexnac(1)neuac(1)ac(1)$Didehydro$Decarboxylation",
    "modified_positions": 16,
    "name": "Dihydroorotate dehydrogenase (quinone)",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZUH9",
    "length": 588,
    "modifications": "hex(1)hexnac(1)dhex(1)me(1)$Saligenin$Trioxidation$Dioxidation$Thiazolidine",
    "modified_positions": 6,
    "name": "ATP-dependent lipid A-core flippase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUI0",
    "length": 323,
    "modifications": "Carbamyl$galactosyl$TMPP-Ac:13C(9)$Carbamidomethyl$Methylthio$GG$Cresylphosphate$Oxidation$Gly-loss+Amide$Dicarbamidomethyl$CAMthiopropanoyl$Nitrosyl",
    "modified_positions": 14,
    "name": "Tetraacyldisaccharide 4'-kinase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZUI3",
    "length": 296,
    "modifications": "Phosphopropargyl$Carbamidomethyl$acetyl_13c(2)$hexnac(1)dhex(1)$BITC$Cation:Ag$Oxidation$pent(2)$Cation:Ca[II]$Succinyl$Cation:K",
    "modified_positions": 15,
    "name": "Hydrogen peroxide-inducible genes activator OxyR",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZUI4",
    "length": 184,
    "modifications": "hep$hex(1)hexnac(1)dhex(1)",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUI5",
    "length": 357,
    "modifications": "Gly$Hydroxamic_acid$Carbamidomethyl$AEC-MAEC$Oxidation$Delta:H(4)C(2)$Methamidophos-S$Carboxyethylpyrrole$hex(2)hexnac(1)me(1)$Ethyl$hex(6)hexnac(1)$hex(3)hexnac(3)sulf(1)",
    "modified_positions": 14,
    "name": "Iron-sulfur cluster carrier protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZUI9",
    "length": 130,
    "modifications": "hep$Oxidation$O-pinacolylmethylphosphonate",
    "modified_positions": 6,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZUJ0",
    "length": 331,
    "modifications": "Carbamidomethyl$AEBS$Lipoyl$Lys->MetOx$Oxidation$Delta:H(6)C(3)O(1)",
    "modified_positions": 9,
    "name": "Delta-aminolevulinic acid dehydratase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZUJ2",
    "length": 562,
    "modifications": "bemad_st_2h(6)$hex(2)pent(2)$phosphohex(2)$clip_traq_3$Thiazolidine$glucuronyl$Delta:H(8)C(6)O(1)",
    "modified_positions": 11,
    "name": "Translocation and assembly module subunit TamA",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZUJ4",
    "length": 164,
    "modifications": "MTSL$Cation:Fe[II]$LG-lactam-R$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Hypothetical 17.2kDa protein, CinA-related competence damage protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUJ7",
    "length": 348,
    "modifications": "Carbamyl$Carbamidomethyl$AEC-MAEC$PyridoxalPhosphateH2$Deamidated$NHS-fluorescein$dhex(3)hex(4)hexnac(4)sulf(1)$Oxidation$Propyl$Diethylphosphate",
    "modified_positions": 14,
    "name": "Protein RecA",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUK1",
    "length": 426,
    "modifications": "Acetyl$Amidine$Delta:H(2)C(5)$Oxidation$pent(2)$AzidoF$hexnac(2)",
    "modified_positions": 7,
    "name": "Coiled-coil protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZUK7",
    "length": 109,
    "modifications": "Deamidated",
    "modified_positions": 2,
    "name": "Flagellar motor switch protein FliN",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZUL2",
    "length": 257,
    "modifications": "GlycerylPE$Oxidation$Formyl",
    "modified_positions": 3,
    "name": "Flagellar motor protein MotA",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZUL7",
    "length": 161,
    "modifications": "dimethyl_2h(4)13c(2)$Unknown:162$dimethyl_2h(6)",
    "modified_positions": 3,
    "name": "Transmembrane protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZUM0",
    "length": 316,
    "modifications": "Carbamidomethyl$benzoyl$Phe->CamCys$Piperidine$Oxidation$imehex(2)neuac(1)$Dimethylaminoethyl$dileu4plex115$Gly",
    "modified_positions": 13,
    "name": "Eukaryotic small stress protein PASS1",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZUM1",
    "length": 258,
    "modifications": "Carbamidomethyl$Lysbiotinhydrazide$UgiJoullieProGlyProGly$Deamidated",
    "modified_positions": 4,
    "name": "Phosphodiester glycosidase domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUM3",
    "length": 73,
    "modifications": "Carbamyl$NHS-LC-Biotin$Oxidation$MesitylOxide$Thiazolidine",
    "modified_positions": 8,
    "name": "Translation initiation factor IF-1",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUM4",
    "length": 123,
    "modifications": "sulfo+amino$Thiadiazole$PhosphoCytidine$Carbamidomethyl$Phosphopropargyl$Deamidated$Sulfide$C8-QAT$Oxidation$BDMAPP$Cation:Ca[II]$Dioxidation",
    "modified_positions": 16,
    "name": "Rhodanese domain protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZUN0",
    "length": 343,
    "modifications": "Delta:H(4)C(3)O(1)$Carbamidomethyl$biotinAcrolein298$Cresylphosphate$Propionyl$Methyl$imid_2h(4)",
    "modified_positions": 9,
    "name": "histidine kinase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZUP0",
    "length": 455,
    "modifications": "dhex(2)hexnac(2)kdn(1)$deamidated_18o(1)$OxArgBiotinRed$Unknown:210$Carbamidomethyl$Acetylhypusine$Lys->Allysine$Deamidated$Tris$Oxidation$Carboxyethylpyrrole$Pro->Pyrrolidinone$Decarboxylation",
    "modified_positions": 16,
    "name": "UDP-N-acetylmuramate--L-alanyl-gamma-D-glutamyl-meso-2,6-diaminoheptandioate ligase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZUP2",
    "length": 436,
    "modifications": "biotinAcrolein298$clip_traq_4$CAMthiopropanoyl$Pro->Pyrrolidone$Dioxidation$Unknown:234$Dipyridyl$pupylation$Tris$hex(6)hexnac(2)$NQIGG$Dansyl$Gln->pyro-Glu$hex(3)hexnac(4)sulf(1)$maleimide$glucuronyl$Carbamidomethyl$Oxidation$hex(3)$Delta:H(10)C(8)O(1)$Propiophenone$Malonyl",
    "modified_positions": 17,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZUP5",
    "length": 261,
    "modifications": "hex(2)hexnac(1)sulf(1)$TMPP-Ac:13C(9)$glycidamide$neiaa_2h(5)$Amidine",
    "modified_positions": 6,
    "name": "Inositol-1-monophosphatase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUP6",
    "length": 257,
    "modifications": "MesitylOxide$Can-FP-biotin$Oxidation$FMN",
    "modified_positions": 6,
    "name": "tRNA (cytidine/uridine-2'-O-)-methyltransferase TrmJ",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUP8",
    "length": 127,
    "modifications": "maleimide$Arg->Orn",
    "modified_positions": 3,
    "name": "NifU family iron binding protein, [Fe-S] cluster formation/repair protein IscU, HesB",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUQ0",
    "length": 95,
    "modifications": "Carbamyl$hex(2)hexnac(2)pent(1)$Dehydrated$Carbonyl$Acetyl$Ethanedithiol$Propionyl$Dethiomethyl$Amidine$Met->Hsl$Oxidation$Met->AspSA$hex(1)hexnac(1)neuac(1)ac(1)$Met->Hse$Met-loss+Acetyl$Glu->pyro-Glu",
    "modified_positions": 9,
    "name": "Putative Fis-like DNA-binding protein",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZUQ2",
    "length": 262,
    "modifications": "phosphohex(2)$Deamidated$maleimide$Oxidation$Gluratylation",
    "modified_positions": 6,
    "name": "FecR protein domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUQ6",
    "length": 477,
    "modifications": "Carbamidomethyl$betaFNA$Propargylamine$Ethanolyl$G-H1$Oxidation$Delta:H(4)C(2)$Met->AspSA$dhex(2)hex(2)hexa(1)hexnac(1)$Met-loss+Acetyl$dhex(1)hex(1)hexnac(1)neuac(1)$Dimethyl$PET$Ethyl$hex(1)hexnac(2)dhex(1)pent(1)",
    "modified_positions": 14,
    "name": "Aspartyl/glutamyl-tRNA(Asn/Gln) amidotransferase subunit B",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZUQ7",
    "length": 483,
    "modifications": "Carbamyl$Pyridylethyl$Carbamidomethyl$2-monomethylsuccinyl$Propionyl$hex(2)hexnac(2)neuac(2)$Oxidation$Methylamine$dileu4plex115$Gly$Decarboxylation",
    "modified_positions": 17,
    "name": "Glutamyl-tRNA(Gln) amidotransferase subunit A",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZUR4",
    "length": 363,
    "modifications": "Carbamidomethyl$Delta:H(6)C(6)O(1)$pentose$Oxidation$unknown_420$Nmethylmaleimide$Propiophenone",
    "modified_positions": 8,
    "name": "sn-glycerol-3-phosphate transport, ATP binding protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZUR6",
    "length": 261,
    "modifications": "Delta:H(4)C(3)$hex(2)hexnac(1)sulf(1)$Carbamidomethyl$Delta:H(2)C(3)$glycidamide$Propionyl$Cation:Cu[I]$Oxidation$Cation:Zn[II]$Thiazolidine$Decarboxylation",
    "modified_positions": 12,
    "name": "Hydrolase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZUR8",
    "length": 276,
    "modifications": "Unknown:302$Carbamidomethyl$Methamidophos-O$dimethyl_2h(4)$Ammonia-loss$Sulfo$Deamidated$maleimide$Oxidation$OxArgBiotin$Phospho",
    "modified_positions": 15,
    "name": "Septum site-determining protein MinD",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZUR9",
    "length": 490,
    "modifications": "Carbamidomethyl$hex(1)hexnac(1)dhex(1)me(2)$benzoyl$Cation:Mg[II]$OxLysBiotin$Ethanolyl$Acetyl$Fluoro$Oxidation$murnac",
    "modified_positions": 17,
    "name": "Inosine-5'-monophosphate dehydrogenase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUS2",
    "length": 861,
    "modifications": "deamidated_18o(1)$Carbamidomethyl$hexnac(2)sulf(1)$dhex(1)hex(2)$esp$Arg->Npo$DeStreak$Oxidation$LRGG+methyl$dhex$GluGluGluGlu$acetyl_2h(3)$O-Et-N-diMePhospho",
    "modified_positions": 20,
    "name": "Bifunctional uridylyltransferase/uridylyl-removing enzyme",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZUS3",
    "length": 254,
    "modifications": "Gly$Carbamidomethyl$AEBS$Dioxidation$Oxidation$Crotonyl$BEMAD_ST$phosphoRibosyl$Formyl$Thiazolidine",
    "modified_positions": 16,
    "name": "Methionine aminopeptidase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZUS8",
    "length": 254,
    "modifications": "Delta:H(2)C(2)$Unknown:216$Thiazolidine$CresylSaligeninPhosphate$Acetyl$CarbamidomethylDTT$Deamidated$Carbofuran$Propyl$Delta:H(6)C(7)O(4)$Aspartylurea$Pyro-carbamidomethyl$MesitylOxide$Gly$BHT$NO_SMX_SIMD$Carbamyl$Carbamidomethyl$GluGlu$Oxidation$Heme$Met->Hpg$Glu->pyro-Glu",
    "modified_positions": 31,
    "name": "Small ribosomal subunit protein uS2",
    "unique_modifications": 23
  },
  {
    "id": "Q5ZUS9",
    "length": 292,
    "modifications": "LG-Hlactam-R$Diisopropylphosphate$Phosphopropargyl$Carbamidomethyl$azole$Delta:H(6)C(6)O(1)$3-deoxyglucosone$Dethiomethyl$Deamidated$G-H1$Met->Hsl$Oxidation$hex(1)hexnac(2)dhex(2)$pent(2)$PyruvicAcidIminyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 21,
    "name": "Elongation factor Ts",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZUT0",
    "length": 247,
    "modifications": "Deoxy$Trimethyl$Carbamidomethyl$Ammonium$Oxidation$dhex(1)hex(1)hexnac(2)neuac(1)$Thiophospho$acetyl_2h(3)$Cation:Ni[II]",
    "modified_positions": 16,
    "name": "Uridylate kinase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZUT1",
    "length": 185,
    "modifications": "gist-quat$bemad_st_2h(6)$Unknown:162$His+O(2)$Dihydroxyimidazolidine$Cresylphosphate$AccQTag$Ammonium$Oxidation$hex(2)hexnac(1)me(1)$Dioxidation$Dimethylphosphothione",
    "modified_positions": 17,
    "name": "Ribosome-recycling factor",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZUT4",
    "length": 448,
    "modifications": "Biotin:Thermo-21328$Carbamidomethyl$Dimethyl$GEE$hex$Ethyl$methylol",
    "modified_positions": 7,
    "name": "N-succinylarginine dihydrolase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZUT7",
    "length": 407,
    "modifications": "Carbonyl$Carbamidomethyl$QTGG$hex(3)hexnac(1)$dhex(1)hex(2)hexnac(1)$Ammonia-loss$Oxidation",
    "modified_positions": 13,
    "name": "Carboxypeptidase G2",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZUU1",
    "length": 560,
    "modifications": "PS_Hapten$clip_traq_4$Carboxymethyl$Cation:Ni[II]$gist-quat$Delta:H(4)C(2)O(-1)S(1)$Propionamide$hex(2)hexnac(3)$icpl_2h(4)$Aspartylurea$galactosyl$Cresylphosphate$Phosphoadenosine$Cation:Zn[II]$Gly$Hydroxamic_acid$Carbamidomethyl$dnic$Methyl$Cation:Mg[II]$Cation:Cu[I]$Oxidation$Biotin$Thiophospho",
    "modified_positions": 31,
    "name": "Kinectin 1 (Kinesin receptor)",
    "unique_modifications": 24
  },
  {
    "id": "Q5ZUU2",
    "length": 239,
    "modifications": "Carbamidomethyl$Methylthio$pupylation$Oxidation$Gly",
    "modified_positions": 5,
    "name": "Uracil-DNA glycosylase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUU3",
    "length": 230,
    "modifications": "FP-Biotin$Carbamidomethyl$Oxidation$exactagamine$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 8,
    "name": "Ubiquinone biosynthesis O-methyltransferase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUV5",
    "length": 400,
    "modifications": "FP-Biotin$Carbamidomethyl$Propargylamine$NHS-fluorescein$Oxidation$Diethylphosphate$RNPXL$Thiazolidine",
    "modified_positions": 11,
    "name": "Ras-GEF domain-containing protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZUW0",
    "length": 283,
    "modifications": "NDA$hex(1)pent(3)$Deamidated$Oxidation$Pro->Pyrrolidone",
    "modified_positions": 7,
    "name": "Oxidoreductase, short chain dehydrogenase/reductase family",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUW9",
    "length": 439,
    "modifications": "Biotin-HPDP$Diisopropylphosphate$Carbamidomethyl$Homocysteic_acid$Cytopiloyne+water$Fluoro$Oxidation$Trioxidation$Cys->ethylaminoAla$Argbiotinhydrazide$UgiJoullieProGly",
    "modified_positions": 18,
    "name": "Phosphoribosylamine--glycine ligase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZUX0",
    "length": 192,
    "modifications": "sulfanilicacid$Hydroxamic_acid$Oxidation$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Phosphoribosylglycinamide formyltransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUX5",
    "length": 463,
    "modifications": "hex(2)hexnac(1)sulf(1)$Phe->CamCys$hexnac(1)dhex(1)$hex(3)$Oxidation$dhex$Biotin:Thermo-21345$hep$Formyl",
    "modified_positions": 8,
    "name": "IgA Peptidase M64",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZUY0",
    "length": 198,
    "modifications": "dhex(2)hex(2)hexnac(1)$Glu->pyro-Glu+Methyl",
    "modified_positions": 2,
    "name": "Putative transport protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUY7",
    "length": 557,
    "modifications": "Delta:H(4)C(5)O(1)$QTGG$Puromycin$Oxidation$methylol$hex(1)pent(2)me(1)",
    "modified_positions": 7,
    "name": "Neutral metalloproteinase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZUZ0",
    "length": 334,
    "modifications": "G-H1$Oxidation$2HPG$Carbamidomethyl",
    "modified_positions": 6,
    "name": "Myo-inositol-2-dehydrogenase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUZ1",
    "length": 628,
    "modifications": "Ub-VME$Aspartylurea$CresylSaligeninPhosphate$Carbamidomethyl$Diethylphosphothione$ub-amide$acetyl_2h(3)$HNE$Oxidation$Cation:Fe[III]$Cation:K$Gln->pyro-Glu",
    "modified_positions": 13,
    "name": "IolC/IolB transferase kinase protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZUZ4",
    "length": 85,
    "modifications": "BMP-piperidinol$Cation:Al[III]$Carbamidomethyl$Fluoro",
    "modified_positions": 6,
    "name": "Signal peptide protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUZ7",
    "length": 191,
    "modifications": "hex(1)hexnac(2)sulf(1)$Oxidation$hex(4)$Unknown:216",
    "modified_positions": 3,
    "name": "Lipid/polyisoprenoid-binding YceI-like domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZV03",
    "length": 438,
    "modifications": "CresylSaligeninPhosphate$Carbamidomethyl$hex(1)hexnac(1)dhex(1)me(2)$hexnac$Deamidated$maleimide$Oxidation$methyl_2h(3)",
    "modified_positions": 12,
    "name": "Uncharacterized protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZV05",
    "length": 296,
    "modifications": "HNE-Delta:H(2)O$Dehydrated$15N-oxobutanoic$Carbamidomethyl$glucosone$benzylguanidine$Dimethyl$Ethyl",
    "modified_positions": 9,
    "name": "Polysaccharide deacetylase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZV06",
    "length": 282,
    "modifications": "Label:2H(4)+GG$gist-quat$Carbonyl$biotinAcrolein298$Carbamidomethyl$Methyl$Oxidation$QEQTGG$Hydroxamic_acid",
    "modified_positions": 13,
    "name": "Acetyltransferase, GNAT family",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZV07",
    "length": 179,
    "modifications": "Methylphosphonate$O-Methylphosphate$NQIGG",
    "modified_positions": 4,
    "name": "Dienelactone hydrolase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZV11",
    "length": 327,
    "modifications": "Carbamidomethyl$Myristoyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 4,
    "name": "Chalcone and stilbene synthases",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZV19",
    "length": 338,
    "modifications": "ethylamino$NHS-fluorescein$cGMP+RMP-loss$Cation:Li$O-Isopropylmethylphosphonate",
    "modified_positions": 5,
    "name": "tRNA pseudouridine synthase D",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZV21",
    "length": 439,
    "modifications": "Carbamyl$hex(2)hexnac(1)$dhex$Cation:Mg[II]",
    "modified_positions": 6,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZV30",
    "length": 250,
    "modifications": "Iminobiotin$Carbamidomethyl$maleimide",
    "modified_positions": 3,
    "name": "Transcriptional regulator SkgA, mercury resistance",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZV33",
    "length": 417,
    "modifications": "Delta:H(4)C(3)$Deoxy$Carbamidomethyl$HN3_mustard$hex(3)hexnac(1)$Propionyl$Delta:H(2)C(5)$Oxidation$Dioxidation$Thrbiotinhydrazide",
    "modified_positions": 10,
    "name": "Gamma-glutamyl phosphate reductase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZV38",
    "length": 225,
    "modifications": "phosphohex$hex(1)hexnac(1)$Carbamidomethyl",
    "modified_positions": 4,
    "name": "RES domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZV43",
    "length": 439,
    "modifications": "Ser->LacticAcid$Iodoacetanilide:13C(6)$AEC-MAEC$Ammonia-loss$3sulfo$Gly-loss+Amide$Dioxidation$Carboxymethyl$Delta:H(4)C(2)O(-1)S(1)$Trimethyl$Ethanolamine$Deamidated$Carbofuran$LG-lactam-R$hex(3)hexnac(6)$Gln->pyro-Glu$Delta:H(6)C(7)O(4)$AFB1_Dialdehyde$eqat_2h(5)$Deoxy$lapachenole$dhex(2)hex(3)hexnac(3)sulf(1)$Cresylphosphate$SulfurDioxide$Trioxidation$neiaa$Pyro-carbamidomethyl$Met-loss+Acetyl$Gly$Glycerophospho$dhex(3)hexnac(3)kdn(1)$Carbamyl$Dehydrated$Carbamidomethyl$ISD_z+2_ion$Methyl$Cation:Cu[I]$Oxidation$hex(2)hexnac(1)$hex(4)hexnac(2)pent(1)$Glu->pyro-Glu",
    "modified_positions": 68,
    "name": "Thiolase",
    "unique_modifications": 41
  },
  {
    "id": "Q5ZV47",
    "length": 65,
    "modifications": "Cation:Al[III]$Glu->pyro-Glu",
    "modified_positions": 2,
    "name": "Carbon storage regulator CsrA",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZV48",
    "length": 112,
    "modifications": "Carbamidomethyl$Delta:H(6)C(3)O(1)$Tyr->Dha$Propargylamine$Deamidated$Sulfide$Trioxidation$Oxidation$Dioxidation$Carboxymethyl",
    "modified_positions": 12,
    "name": "Small ribosomal subunit protein bS6",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZV51",
    "length": 149,
    "modifications": "AFB1_Dialdehyde$Oxidation$Iminobiotin",
    "modified_positions": 4,
    "name": "Large ribosomal subunit protein bL9",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZV53",
    "length": 185,
    "modifications": "Carbamidomethyl$Cytopiloyne$DAET$Deamidated$Gly",
    "modified_positions": 9,
    "name": "Hypothetical thiol-disulfide isomerase and thioredoxins family",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZV55",
    "length": 162,
    "modifications": "Oxidation$Carbamidomethyl$Deamidated",
    "modified_positions": 8,
    "name": "Enhanced entry protein EnhB",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZV63",
    "length": 187,
    "modifications": "Carbamidomethyl$HydroxymethylOP$OxLysBiotin$Oxidation$DNCB_hapten$Formyl",
    "modified_positions": 7,
    "name": "RNA polymerase sigma E factor RpoE",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZV80",
    "length": 370,
    "modifications": "Carbamyl$dhex(3)hexnac(3)kdn(1)$PhosphoCytidine$Carbamidomethyl$hex(1)pent(3)me(1)$Delta:H(2)C(2)$HCysThiolactone$Lipoyl$Delta:H(2)C(3)$Oxidation$hep$Succinyl",
    "modified_positions": 16,
    "name": "Dihydrolipoamide acetyltransferase component of pyruvate dehydrogenase complex",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZV81",
    "length": 324,
    "modifications": "Cation:Fe[II]$Ethylphosphate$Carbamidomethyl$MG-H1$HydroxymethylOP$Thrbiotinhydrazide$Ethyl$Deamidated$O-Dimethylphosphate$Oxidation$Can-FP-biotin$Delta:H(2)C(3)O(1)$Gly$glycosyl$Gln->pyro-Glu",
    "modified_positions": 19,
    "name": "2-oxoisovalerate dehydrogenase subunit beta",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZV91",
    "length": 294,
    "modifications": "SulfanilicAcid:13C(6)$sulfanilicacid$thioacylPA$Unknown:162$Amidine$Deamidated$Delta:H(10)C(8)O(1)$glycosyl$glucosone$hex(2)$Delta:H(2)C(3)O(1)$hep$Carboxymethyl",
    "modified_positions": 18,
    "name": "Type 4 apparatus protein DotZ",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZV92",
    "length": 141,
    "modifications": "Carbamyl$Delta:H(2)C(3)$Delta:H(2)C(2)$phosphohexnac$s-glcnac$Oxidation$UgiJoullieProGly$Thiazolidine$Glu->pyro-Glu",
    "modified_positions": 14,
    "name": "Nucleoside diphosphate kinase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZV94",
    "length": 260,
    "modifications": "deamidated_18o(1)$hex(2)hexnac(4)$Carbamidomethyl$Acetylhypusine$Lys->Allysine$Deamidated$Cation:K",
    "modified_positions": 10,
    "name": "Fimbrial biogenesis and twitching motility protein PilF",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZV97",
    "length": 224,
    "modifications": "Deoxy$Ser->LacticAcid$biotinAcrolein298$LG-anhyropyrrole$esp$DAET$Oxidation$Retinylidene",
    "modified_positions": 9,
    "name": "Ancillary SecYEG translocon subunit",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZV99",
    "length": 462,
    "modifications": "Delta:H(6)C(7)O(4)$Carbamidomethyl$Delta:H(2)C(2)$Trioxidation$Oxidation$Pro->pyro-Glu$MercaptoEthanol$Thiophospho$Dioxidation$Biotin:Sigma-B1267",
    "modified_positions": 9,
    "name": "GTPase Der",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVA6",
    "length": 429,
    "modifications": "Pro->HAVA$monomethylphosphothione$Cation:Cu[I]$Fluoro$Pro->Pyrrolidinone$Oxidation$probiotinhydrazide$dhex$CAMthiopropanoyl$Dioxidation$hexnac(2)",
    "modified_positions": 18,
    "name": "Glutamate-1-semialdehyde 2,1-aminomutase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZVB0",
    "length": 372,
    "modifications": "Carbamidomethyl$hex(3)hexnac(2)$Dihydroxyimidazolidine$Formyl$Delta:H(-4)O(2)$HNE$Oxidation$glucosone$hex(1)hexnac(1)neuac(1)$dhex(1)hex(2)hexa(1)$Gly$Thiazolidine$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 19,
    "name": "Citrate synthase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZVB2",
    "length": 271,
    "modifications": "Delta:H(4)C(3)$Didehydro$Carbamidomethyl$Delta:H(6)C(6)O(1)$Acetyl$Pro->HAVA",
    "modified_positions": 7,
    "name": "Putative phosphoenolpyruvate synthase regulatory protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVB4",
    "length": 197,
    "modifications": "phosphohex$methyl_2h(2)$Methyl$icpl_13c(6)2h(4)$Isopropylphospho$neuac$maleimide$Oxidation$murnac$Phosphoadenosine$hex(1)hexnac(2)pent(1)$Decarboxylation",
    "modified_positions": 10,
    "name": "Sel1 repeat family protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZVB7",
    "length": 406,
    "modifications": "Unknown:162$GG$Oxidation$dhex(1)hex(1)hexnac(2)neuac(1)$O-pinacolylmethylphosphonate$Dicarbamidomethyl$TAMRA-FP",
    "modified_positions": 9,
    "name": "(Type IV) pilus assembly protein PilC",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVE8",
    "length": 340,
    "modifications": "LG-lactam-K$Propionyl$Oxidation$Delta:H(8)C(6)O(1)",
    "modified_positions": 4,
    "name": "Spectinomycin phosphotransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVF6",
    "length": 269,
    "modifications": "Carbamyl$serotonylation$Carbamidomethyl$Chlorination$phosphohex(2)$OxLysBiotin$hexnac$ethylamino$Oxidation$Unknown:216$Cation:Zn[II]$Succinyl",
    "modified_positions": 17,
    "name": "LepB protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZVF7",
    "length": 529,
    "modifications": "LRGG$Lys->CamCys$Carbamidomethyl$Furan$Oxidation$Crotonyl$Unknown:216$Didehydro$Carboxy$Dimethylphosphothione",
    "modified_positions": 14,
    "name": "Serine/threonine-protein kinase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVF9",
    "length": 346,
    "modifications": "Diethyl$Ethanolamine$Tyr->Dha",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVG1",
    "length": 982,
    "modifications": "Carbamyl$Phosphopropargyl$Oxidation$MicrocinC7$Carboxy$Malonyl",
    "modified_positions": 7,
    "name": "Potassium efflux system KefA",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVG3",
    "length": 209,
    "modifications": "TMPP-Ac:13C(9)",
    "modified_positions": 1,
    "name": "Transmembrane protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVG4",
    "length": 104,
    "modifications": "Carbamidomethyl$Unknown:306$Deamidated$Oxidation$Gly",
    "modified_positions": 11,
    "name": "Putative regulatory protein FmdB zinc ribbon domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVG5",
    "length": 212,
    "modifications": "O-Methylphosphate$Nitro$Carbamidomethyl$Gln->pyro-Glu",
    "modified_positions": 4,
    "name": "ATP-dependent dethiobiotin synthetase BioD",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVG6",
    "length": 239,
    "modifications": "Delta:H(5)C(2)$Propionamide$Ethyl+Deamidated$dhex(1)hex(1)$neuac$Oxidation$Succinyl$O-Et-N-diMePhospho",
    "modified_positions": 9,
    "name": "Pimeloyl-[acyl-carrier protein] methyl ester esterase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVG7",
    "length": 381,
    "modifications": "hex(1)hexnac(2)sulf(1)$dhex(3)hexnac(3)kdn(1)$SulfanilicAcid:13C(6)$hex(1)pent(2)$hex(4)$Carbamidomethyl$Carbonyl$Propargylamine$G-H1$hex(1)neuac(1)",
    "modified_positions": 11,
    "name": "8-amino-7-oxononanoate synthase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVH3",
    "length": 201,
    "modifications": "Methylamine$Cation:Li",
    "modified_positions": 5,
    "name": "Dephospho-CoA kinase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVH9",
    "length": 579,
    "modifications": "Biotin:Thermo-21328$deamidated_18o(1)$Aspartylurea$Carbamidomethyl$PS_Hapten$Methylthio$Cytopiloyne$azole$Oxidation$cGMP+RMP-loss$Argbiotinhydrazide$BEMAD_ST$diart6plex115$hex(1)hexnac(1)$Hydroxamic_acid$Delta:H(4)C(3)O(2)$acetyl_2h(3)$Nitro",
    "modified_positions": 33,
    "name": "Single-stranded-DNA-specific exonuclease RecJ",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZVI1",
    "length": 397,
    "modifications": "Deoxy$Carbamidomethyl$Deamidated$Oxidation$Met-loss+Acetyl$Carboxy",
    "modified_positions": 16,
    "name": "Aminotransferase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVI3",
    "length": 734,
    "modifications": "Delta:H(2)C(2)$Biotin:Thermo-21330$dileu4plex118$Unknown:216$clip_traq_4$DNCB_hapten$CAMthiopropanoyl$CIGG$Delta:H(4)C(6)$Ammonium$succinyl_2h(4)$Gln->pyro-Glu$Deoxyhypusine$Carboxyethyl$Pyridylacetyl$Iminobiotin$Methamidophos-O$Ethyl+Deamidated$Oxidation$Dimethylaminoethyl$methyl_2h(3)",
    "modified_positions": 23,
    "name": "GTP pyrophosphokinase",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZVI7",
    "length": 172,
    "modifications": "Ethanolamine$monomethylphosphothione$Oxidation$Gly-loss+Amide$Delta:H(8)C(6)O(2)",
    "modified_positions": 6,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVJ3",
    "length": 248,
    "modifications": "Deoxy$Formyl$Biotin:Thermo-21330$Ethanolyl$neuac$Pro->Pyrrolidinone$Oxidation$Carboxy$Malonyl$Glu->pyro-Glu+Methyl",
    "modified_positions": 12,
    "name": "Pseudouridine synthase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVJ5",
    "length": 263,
    "modifications": "Oxidation$hexnac(1)dhex(1)$Glu->pyro-Glu",
    "modified_positions": 4,
    "name": "Segregation and condensation protein A",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVK1",
    "length": 296,
    "modifications": "Iodoacetanilide$Carbamidomethyl$UgiJoullieProGlyProGly$Acetyl$PyridoxalPhosphateH2$DNCB_hapten$OxLysBiotinRed$Oxidation$hex(1)hexnac(1)neuac(1)$Cation:Fe[III]$GluGluGluGlu$Didehydroretinylidene$Glu->pyro-Glu+Methyl$TAMRA-FP",
    "modified_positions": 15,
    "name": "Magnesium and cobalt efflux protein CorC",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZVK2",
    "length": 226,
    "modifications": "Biotin-PEO-Amine$Lys->CamCys$PEITC$Unknown:306$Carbamidomethyl$Biotin:Thermo-33033$Oxidation$Succinyl$Carboxymethyl",
    "modified_positions": 10,
    "name": "Transcriptional regulatory protein CpxR",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZVK5",
    "length": 131,
    "modifications": "NIPCAM$Carbamidomethyl$Oxidation$HNE+Delta:H(2)$HN2_mustard$Palmitoyl$BHT",
    "modified_positions": 6,
    "name": "Cytidine deaminase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVK7",
    "length": 254,
    "modifications": "Carbonyl$Carbamyl$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Deoxyribose-phosphate aldolase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVK9",
    "length": 132,
    "modifications": "Oxidation$Ammonia-loss$Carboxy->Thiocarboxy$Gln->pyro-Glu",
    "modified_positions": 6,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVL5",
    "length": 229,
    "modifications": "Oxidation$Cation:Mg[II]$Cation:Na$hexnac(1)dhex(1)",
    "modified_positions": 3,
    "name": "Orotidine 5'-phosphate decarboxylase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVL6",
    "length": 371,
    "modifications": "Delta:H(4)C(3)O(2)$Carbamidomethyl$ethylamino$Delta:H(2)C(3)",
    "modified_positions": 4,
    "name": "Aminotransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVL8",
    "length": 96,
    "modifications": "Delta:H(8)C(6)O(2)$Carbamidomethyl",
    "modified_positions": 2,
    "name": "Hypothetical membrane protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVM1",
    "length": 433,
    "modifications": "Phenylisocyanate$dhex(1)hexnac(3)$hex(2)hexnac(1)pent(1)hexa(1)$hex(3)hexnac(2)$hexnac$Tris$HNE-Delta:H(2)O$Pyridylacetyl$dimethyl_2h(6)$Gly$dimethyl_2h(4)13c(2)$dhex(1)hex(3)hexnac(1)$Carbamidomethyl$Cysteinyl$Ethyl+Deamidated$Delta:H(2)C(5)$Phosphoguanosine$Oxidation$HMVK",
    "modified_positions": 14,
    "name": "3-phosphoshikimate 1-carboxyvinyltransferase",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZVM4",
    "length": 293,
    "modifications": "Unknown:210$Carbamidomethyl$Methamidophos-O$hexnac(1)dhex(1)$Isopropylphospho$clip_traq_2$Oxidation$Cation:Na$Phenylisocyanate:2H(5)",
    "modified_positions": 13,
    "name": "Purine nucleoside phosphorylase II",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZVM5",
    "length": 423,
    "modifications": "icpl_2h(4)$Trimethyl$OxArgBiotinRed$Carbamidomethyl$dnic$Methamidophos-O$Crotonaldehyde$GluGluGlu$Propionyl$Deamidated$Oxidation$4-ONE+Delta:H(-2)O(-1)$Methylamine$Phosphoadenosine$Biotin-tyramide$Butyryl",
    "modified_positions": 19,
    "name": "Citrate synthase",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZVN7",
    "length": 366,
    "modifications": "Carbamidomethyl$Acetylhypusine$Cresylphosphate$Oxidation$Cation:Li$Diethylphosphate$bisANS-sulfonates",
    "modified_positions": 12,
    "name": "Anhydro-N-acetylmuramic acid kinase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVN9",
    "length": 113,
    "modifications": "Diisopropylphosphate$Lipoyl$Oxidation$diart6plex$diart6plex115$diart6plex118$diart6plex116/119$diart6plex117",
    "modified_positions": 4,
    "name": "Type 4 fimbrial biogenesis protein PilZ",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVP1",
    "length": 212,
    "modifications": "O-Et-N-diMePhospho$Carbamidomethyl$Methylphosphonate$Octanoyl$Oxidation$Methamidophos-S$Cation:Ni[II]",
    "modified_positions": 6,
    "name": "Thymidylate kinase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVP3",
    "length": 412,
    "modifications": "hex(2)hexnac(4)$galactosyl$Carbamidomethyl$QTGG$GluGlu$Menadione-HQ$Deamidated$HNE$Oxidation$QAT$Formyl",
    "modified_positions": 17,
    "name": "3-oxoacyl-[acyl-carrier-protein] synthase 2",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZVP6",
    "length": 315,
    "modifications": "Carbamidomethyl$Ethyl$Oxidation$BDMAPP$Biotin:Thermo-21345$Dimethyl$Gly$Unknown:234",
    "modified_positions": 16,
    "name": "Malonyl CoA-acyl carrier protein transacylase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVP8",
    "length": 342,
    "modifications": "Ethyl$hex(1)hexnac(2)$Delta:H(4)C(2)$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Phosphate acyltransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVQ2",
    "length": 130,
    "modifications": "Methyl",
    "modified_positions": 2,
    "name": "Iron-sulfur cluster insertion protein ErpA",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVQ8",
    "length": 269,
    "modifications": "hex(1)pent(1)$Dehydrated$ZGB$Diethylphosphothione$Carbamidomethyl$Methamidophos-O$Ethyl+Deamidated$Methyl$Pyridylacetyl$Deamidated$hex(2)neuac(1)$Oxidation$Trioxidation$Diethylphosphate$Gluratylation",
    "modified_positions": 22,
    "name": "Dehydrogenase, short chain (Dhs-6C)",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZVR3",
    "length": 112,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Ribosomal silencing factor RsfS",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVR4",
    "length": 156,
    "modifications": "LRGG$Carbamidomethyl$DimethylamineGMBS$Methylamine$Hypusine",
    "modified_positions": 6,
    "name": "Ribosomal RNA large subunit methyltransferase H",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVR6",
    "length": 372,
    "modifications": "Amino$hexnac(1)dhex(1)$Oxidation$Phosphopantetheine$Propiophenone",
    "modified_positions": 13,
    "name": "Peptidoglycan glycosyltransferase MrdB",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZVR7",
    "length": 191,
    "modifications": "nic$icpl$Carbonyl$DMPO$O-Methylphosphate$Oxidation$Delta:S(-1)Se(1)$Cation:Li$Cation:Na",
    "modified_positions": 10,
    "name": "Ribonuclease HII",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZVR8",
    "length": 320,
    "modifications": "hex(1)pent(2)$Propionamide$Carbamidomethyl$Carbonyl$NHS-LC-Biotin$hex(1)hexnac(1)$Methyl$Ammonia-loss$Lys->MetOx$hexnac$phenylsulfonylethyl$Unknown:234",
    "modified_positions": 12,
    "name": "Oxidoreductase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZVR9",
    "length": 384,
    "modifications": "Carbonyl$Carbamidomethyl$glycidamide$Lys->Allysine$Cys->Oxoalanine$Oxidation$Biotin$PyMIC$Cation:Na$hex(4)hexnac(1)",
    "modified_positions": 11,
    "name": "Lipid-A-disaccharide synthase 1",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZVS0",
    "length": 98,
    "modifications": "Delta:H(4)C(3)$Deoxy$Unknown:210$Carboxy->Thiocarboxy$Carbamidomethyl$Ammonium$Cation:Mg[II]$Cation:Na$Cation:Cu[I]$C8-QAT$Deamidated$neuac$Oxidation$Methyl+Deamidated$Myristoyl$Cation:Zn[II]$Gly$Gln->pyro-Glu",
    "modified_positions": 23,
    "name": "Putative Fis-like DNA-binding protein",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZVS1",
    "length": 623,
    "modifications": "Propiophenone$deamidated_18o(1)$methyl_2h(2)$Carbamidomethyl$Delta:H(2)C(3)$Deamidated$Octanoyl$Trioxidation$Oxidation$Dioxidation$pent(2)$methylol$Nitro$Delta:H(8)C(6)O(1)$Gly$Thiazolidine$Gln->pyro-Glu",
    "modified_positions": 26,
    "name": "Chaperone protein HtpG",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZVS4",
    "length": 257,
    "modifications": "dhex(1)hex(2)hexnac(4)sulf(2)$Hydroxytrimethyl$neuac$Oxidation$methyl+acetyl_2h(3)$propionyl_13c(3)$Dioxidation$Thiazolidine$Dimethylphosphothione",
    "modified_positions": 15,
    "name": "UPF0246 protein lpg1366",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZVS7",
    "length": 399,
    "modifications": "bemad_st_2h(6)$Propionamide$Biotin:Thermo-21330$hex(1)hexnac(1)neugc(1)$hex$dhex(1)hex(2)hexnac(3)$hex(1)hexnac(1)$pyrophospho",
    "modified_positions": 9,
    "name": "General secretion pathway protein F",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVT3",
    "length": 792,
    "modifications": "bemad_st_2h(6)$galactosyl$Diisopropylphosphate$Carbamidomethyl$icdid$dimethyl_2h(6)13c(2)$monomethylphosphothione$Ethyl$hexnac$Amidine$Ethanolyl$Fluoro$Hydroxymethyl$Oxidation$cGMP+RMP-loss$Dimethyl$Delta:H(4)C(2)",
    "modified_positions": 15,
    "name": "Inner membrane protein PLUS sensory box protein LssE",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZVT4",
    "length": 376,
    "modifications": "Acetyl$Chlorination$Phosphogluconoylation$Phenylisocyanate:2H(5)",
    "modified_positions": 6,
    "name": "TPR repeat protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVT6",
    "length": 391,
    "modifications": "Diisopropylphosphate$Acetylhypusine$Saligenin$hexnac(1)dhex(1)$Arg->Orn$methylsulfonylethyl$Carboxy$bacillosamine",
    "modified_positions": 8,
    "name": "SGNH/GDSL hydrolase family protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVT7",
    "length": 394,
    "modifications": "Unknown:210$Carbamidomethyl$Phosphogluconoylation$Phosphopropargyl$AEBS$Biotin:Thermo-21330$Gln->pyro-Glu$Oxidation$Argbiotinhydrazide$methylol$Amidated$Nitro",
    "modified_positions": 15,
    "name": "acetyl-CoA C-acyltransferase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZVU2",
    "length": 823,
    "modifications": "SMA$DAET$clip_traq_4$DNCB_hapten$Gly-loss+Amide$Carboxymethyl$hex(2)hexnac(1)pent(1)hexa(1)$Ethylphosphate$NHS-LC-Biotin$Deamidated$O-Dimethylphosphate$Crotonyl$Cresylphosphate$hexnac(3)$Methamidophos-S$O-pinacolylmethylphosphonate$Menadione$MesitylOxide$Gly$Delta:H(4)C(3)O(2)$dhex(1)hex(3)hexnac(1)$Unknown:248$Carbamidomethyl$Oxidation$MeMePhosphorothioate",
    "modified_positions": 27,
    "name": "Leucine--tRNA ligase",
    "unique_modifications": 25
  },
  {
    "id": "Q5ZVU5",
    "length": 211,
    "modifications": "hex(1)pent(1)$QTGG$GG$Oxidation$dhex$O-Isopropylmethylphosphonate$Dicarbamidomethyl",
    "modified_positions": 8,
    "name": "Probable nicotinate-nucleotide adenylyltransferase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVU9",
    "length": 294,
    "modifications": "Dehydrated$QQQTGG$Carbamidomethyl$Glu->pyro-Glu+Methyl$Deamidated$Oxidation$AMTzHexNAc2$Biotin:Thermo-33033-H$hex$Gly$bisANS-sulfonates$Delta:H(6)C(3)O(1)",
    "modified_positions": 21,
    "name": "Acetyl-coenzyme A carboxylase carboxyl transferase subunit beta",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZVV0",
    "length": 475,
    "modifications": "Ser->LacticAcid$Nethylmaleimide+water$Phenylisocyanate$Nitrene$Deamidated$Didehydro$Cation:Na$Deoxy$Pyridylacetyl$UgiJoullieProGly$Gly$Propiophenone$FMN$Carbamidomethyl$ISD_z+2_ion$azole$Cation:Mg[II]$Oxidation$Delta:H(2)C(3)O(1)$Delta:H(8)C(6)O(2)$O-Et-N-diMePhospho",
    "modified_positions": 25,
    "name": "Flagellin",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZVV1",
    "length": 93,
    "modifications": "Biotin:Thermo-21360",
    "modified_positions": 1,
    "name": "FlaG protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVV2",
    "length": 541,
    "modifications": "FMN$Hydroxamic_acid$Dap-DSP$Ethyl+Deamidated$Malonyl$Menadione-HQ$Carboxyethylpyrrole$Methyl+Deamidated$Cation:Na",
    "modified_positions": 11,
    "name": "Flagellar hook-associated protein 2",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZVV4",
    "length": 248,
    "modifications": "Carbamidomethyl$BisANS$N-dimethylphosphate$Oxidation$glucosone$Pro->HAVA$LG-lactam-K$Palmitoyl",
    "modified_positions": 11,
    "name": "Enhanced entry protein EnhA",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVV5",
    "length": 432,
    "modifications": "bemad_st_2h(6)$Carbamidomethyl$Crotonaldehyde$HCysThiolactone$HNE+Delta:H(2)$AHA-SS",
    "modified_positions": 7,
    "name": "Lysosomal dipeptide transporter MFSD1",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVV7",
    "length": 321,
    "modifications": "Gly$Carbamidomethyl$Methylphosphonate$DNCB_hapten$Oxidation$dhex$pent(1)hexnac(1)$Delta:H(2)C(3)O(1)$Formyl$hep$Met->Aha",
    "modified_positions": 11,
    "name": "Pseudouridine synthase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZVV8",
    "length": 241,
    "modifications": "Diisopropylphosphate$Carbamidomethyl$Methyl$Deamidated$Oxidation$Gly$Biotin:Sigma-B1267",
    "modified_positions": 11,
    "name": "Purine nucleoside phosphorylase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVW2",
    "length": 104,
    "modifications": "Carbamidomethyl$EQIGG$Maleimide-PEO2-Biotin$dhex(1)hex(2)$NHS-fluorescein$Oxidation$O-pinacolylmethylphosphonate$hex",
    "modified_positions": 8,
    "name": "DUF4286 domain-containing protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVW3",
    "length": 361,
    "modifications": "HNE$Diphthamide$Crotonyl$Propyl",
    "modified_positions": 3,
    "name": "LbtU family siderophore porin",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVW5",
    "length": 386,
    "modifications": "Carbamidomethyl$Delta:H(2)C(2)$Pyridylacetyl$hex(1)hexnac(1)phos(1)$Oxidation$Phenylisocyanate$hex(1)hexnac(1)sulf(1)",
    "modified_positions": 10,
    "name": "Drug resistance transporter, Bcr/CflA",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVW9",
    "length": 494,
    "modifications": "O-Isopropylmethylphosphonate$Iodoacetanilide$galactosyl$Carbamidomethyl$Methylthio$Crotonaldehyde$Acetyl$GlycerylPE$hex$Oxidation$cGMP+RMP-loss$O-pinacolylmethylphosphonate$pent(1)hexnac(1)$Butyryl$PET$CHDH$PyruvicAcidIminyl$glucuronyl",
    "modified_positions": 14,
    "name": "Type II secretion system protein E",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZVX1",
    "length": 295,
    "modifications": "Acetylhypusine$Puromycin$Oxidation$Cation:Ag$GGQ$hex(1)neuac(1)$dimethyl_2h(6)$3-phosphoglyceryl$Cys->ethylaminoAla",
    "modified_positions": 10,
    "name": "Uncharacterized protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZVX2",
    "length": 340,
    "modifications": "hex(2)hexnac(4)$Delta:H(4)C(3)$Delta:H(4)C(2)O(-1)S(1)$Carbamidomethyl$acetyl_13c(2)$Ethanolyl$Methylamine$Myristoleyl$Cation:Ca[II]$Cys->PyruvicAcid$Cation:K",
    "modified_positions": 11,
    "name": "Uncharacterized protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZVX3",
    "length": 249,
    "modifications": "GG$Dimethyl$Oxidation$GEE$Dicarbamidomethyl$Methyl+Deamidated$Ethyl",
    "modified_positions": 9,
    "name": "Transposase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZVY2",
    "length": 551,
    "modifications": "AEC-MAEC$Propargylamine$MG-H1$hexnac$Carbofuran$Didehydro$FormylMet$icpl_2h(4)$thioacylPA$Delta:H(2)C(3)$gist-quat_2h(6)$Chlorination$Biotin:Thermo-88317$Gly$Iodoacetanilide$Carbamidomethyl$dnic$hex(1)hexnac(1)neugc(1)$Oxidation$methyl_2h(3)$Delta:H(2)C(3)O(1)$Nitro",
    "modified_positions": 29,
    "name": "Glutamine--tRNA ligase",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZVY3",
    "length": 272,
    "modifications": "Delta:H(4)C(3)O(1)$Deoxy$Carbamidomethyl$Propionyl$Oxidation$Met->Hse$Cys->Dha$Propiophenone$Formyl",
    "modified_positions": 12,
    "name": "Tryptophan synthase alpha chain",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZVY4",
    "length": 399,
    "modifications": "icpl_2h(4)$Methylpyrroline$Carbamidomethyl$dnic$Deamidated$Nethylmaleimide+water$Methamidophos-S$Decarboxylation",
    "modified_positions": 11,
    "name": "Tryptophan synthase beta chain",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVY7",
    "length": 432,
    "modifications": "Ser->LacticAcid$Nitrene$Delta:H(2)C(2)$Deamidated$Sulfide$Carbofuran$clip_traq_2$methylsulfonylethyl",
    "modified_positions": 7,
    "name": "Oxidoreductase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZVZ1",
    "length": 284,
    "modifications": "galactosyl$Carbamidomethyl$Deamidated$Oxidation$hex(2)$Decarboxylation",
    "modified_positions": 9,
    "name": "Bifunctional protein FolD",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZVZ3",
    "length": 254,
    "modifications": "Carbamidomethyl$OxProBiotinRed",
    "modified_positions": 2,
    "name": "Hydroxyacylglutathione hydrolase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVZ4",
    "length": 479,
    "modifications": "Hydroxamic_acid$Dicarbamidomethyl$GG$Methyl$hex(3)hexnac(2)phos(1)$dhex(2)hex(3)hexnac(2)sulf(1)$Iminobiotin$Pro->Pyrrolidone$Succinyl",
    "modified_positions": 11,
    "name": "Membrane bound lytic murein transglycosylase D",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZVZ8",
    "length": 528,
    "modifications": "Pyridylethyl$lapachenole$Carbamidomethyl$Unknown:306$AEBS$esp$OxLysBiotin$neuac$G-H1$Oxidation$dhex(1)hex(1)hexnac(2)neuac(1)sulf(1)$Lysbiotinhydrazide$Label:13C(1)2H(3)+Oxidation$Dimethyl$Cation:Ca[II]$Ethyl$Thiazolidine$Nitro",
    "modified_positions": 20,
    "name": "Peptidase C58 YopT-type domain-containing protein",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZW00",
    "length": 199,
    "modifications": "gist-quat$Delta:H(2)C(3)$Carbamidomethyl$Ethanolamine$Oxidation",
    "modified_positions": 5,
    "name": "Holliday junction branch migration complex subunit RuvA",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZW07",
    "length": 127,
    "modifications": "Carbamidomethyl$Methyl$Oxidation$Carbofuran$Carboxymethyl$Hydroxymethyl$Delta:H(6)C(3)O(1)$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 7,
    "name": "Secreted endonuclease",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZW09",
    "length": 123,
    "modifications": "Iodoacetanilide:13C(6)$Cresylphosphate$Carboxyethyl",
    "modified_positions": 2,
    "name": "Proteinase inhibitor I42 chagasin domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZW14",
    "length": 151,
    "modifications": "Ethanolyl",
    "modified_positions": 2,
    "name": "YHS domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZW60",
    "length": 598,
    "modifications": "GG$4-ONE+Delta:H(-2)O(-1)$Dioxidation$bacillosamine$Thiazolidine$NEM:2H(5)$Acetyl$icpl_13c(6)2h(4)$Carboxyethylpyrrole$glucosylgalactosyl$hex(1)neuac(1)pent(1)$Methamidophos-S$Carbamidomethyl$Hydroxycinnamyl$Unknown:250$Oxidation$Biotin$Delta:H(10)C(8)O(1)$hex$Dicarbamidomethyl$acetyl_2h(3)",
    "modified_positions": 31,
    "name": "PNPLA domain-containing protein",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZW66",
    "length": 261,
    "modifications": "Biotin-PEO-Amine$Deoxy$SMA$Oxidation$Biotin:Thermo-21345$AzidoF",
    "modified_positions": 6,
    "name": "Flagellar basal-body rod protein FlgG",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZW67",
    "length": 248,
    "modifications": "Delta:H(6)C(7)O(4)$Ethanolamine$dimethyl_2h(6)13c(2)$Oxidation$Phosphoadenosine$CIGG",
    "modified_positions": 9,
    "name": "Flagellar basal-body rod protein FlgF",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZW71",
    "length": 130,
    "modifications": "acetyl_13c(2)$Delta:H(2)C(2)$AzidoF$Oxidation$Delta:H(4)C(2)$Guanidinyl$Propyl$hex(1)hexnac(1)$Ethyl$glucuronyl",
    "modified_positions": 8,
    "name": "Flagellar basal body rod protein FlgB",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZW72",
    "length": 311,
    "modifications": "phosphoRibosyl$15N-oxobutanoic$Dehydrated$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Oxygen-dependent coproporphyrinogen-III oxidase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZW81",
    "length": 190,
    "modifications": "Carbamidomethyl$GG$Ethanolamine$hex(2)hexnac(1)me(1)$hexnac(1)dhex(1)$Sulfo$Phospho$Thiophospho",
    "modified_positions": 9,
    "name": "Sigma 54 modulation protein YhbH",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZW83",
    "length": 210,
    "modifications": "Carbamidomethyl$Ammonium$Methyl$Deamidated$methyl_2h(3)",
    "modified_positions": 7,
    "name": "Orotate phosphoribosyltransferase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZW91",
    "length": 239,
    "modifications": "Oxidation$N-dimethylphosphate$ISD_z+2_ion",
    "modified_positions": 3,
    "name": "1-(5-phosphoribosyl)-5-[(5-phosphoribosylamino)methylideneamino] imidazole-4-carboxamide isomerase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZW93",
    "length": 207,
    "modifications": "Deoxy$Quinone$Carbamidomethyl$Ser->LacticAcid$Piperidine$Deamidated$Oxidation$Carboxymethyl$methylol$Delta:H(6)C(3)O(1)",
    "modified_positions": 9,
    "name": "Histidine biosynthesis bifunctional protein HisIE",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZWA1",
    "length": 795,
    "modifications": "Carbamidomethyl$gist-quat_2h(6)$Cytopiloyne$hexnac(1)dhex(1)$UgiJoullie$bisANS-sulfonates$Oxidation$Cation:Fe[III]$hex(1)hexnac(2)dhex(1)$Cation:Ca[II]$LG-pyrrole$Dioxidation$hex(1)hexnac(3)$Cation:K",
    "modified_positions": 19,
    "name": "Outer membrane protein RomA",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZWA5",
    "length": 155,
    "modifications": "Carboxyethyl$Carbamidomethyl$Palmitoleyl$Ammonia-loss$Oxidation",
    "modified_positions": 6,
    "name": "6,7-dimethyl-8-ribityllumazine synthase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZWA7",
    "length": 204,
    "modifications": "thioacylPA$hex(2)pent(2)me(1)$Cytopiloyne$GluGluGlu$Biotin:Thermo-21330$Oxidation",
    "modified_positions": 11,
    "name": "Riboflavin synthase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZWA8",
    "length": 357,
    "modifications": "Nitrene$Carbamidomethyl$15N-oxobutanoic$LG-Hlactam-K$Acetyl$LG-anhyropyrrole$hex(1)hexnac(1)dhex(1)me(1)$Arg->GluSA$Oxidation$3-phosphoglyceryl$MesitylOxide$Met->Hpg$phosphoRibosyl$PyruvicAcidIminyl$Unknown:234",
    "modified_positions": 20,
    "name": "Riboflavin biosynthesis protein RibD",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZWB1",
    "length": 442,
    "modifications": "FP-Biotin$Propionamide$thioacylPA$Cys->SecNEM$Carbonyl$Carbamidomethyl$2HPG$Nitrene$Didehydro$Lys->MetOx$Arg2PG$G-H1$Oxidation$HPG$Biotin$hex(2)$bisANS-sulfonates$Cation:Ni[II]",
    "modified_positions": 17,
    "name": "Two component response regulator PilR",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZWB4",
    "length": 139,
    "modifications": "BHTOH$Oxidation$Ethanolyl",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWB8",
    "length": 161,
    "modifications": "Deoxyhypusine$hex(2)pent(2)me(1)$hexnac(4)$Gln->pyro-Glu$Oxidation$BDMAPP$pent(2)$PyruvicAcidIminyl$Cation:K$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 14,
    "name": "Nucleotide-binding protein lpg1167",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZWC1",
    "length": 384,
    "modifications": "Carbamyl$CresylSaligeninPhosphate$Carbamidomethyl$ub-amide$dimethyl_2h(6)13c(2)$Oxidation$clip_traq_3$Gly$Amidated",
    "modified_positions": 10,
    "name": "Acetylornithine deacetylase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZWC3",
    "length": 243,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Carbonyl$Methyl$Sulfide$Dioxidation$Oxidation$hex(2)hexnac(3)sulf(1)$probiotinhydrazide$Hydroxymethyl$Hydroxamic_acid",
    "modified_positions": 14,
    "name": "OmpA-like transmembrane domain protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZWC5",
    "length": 81,
    "modifications": "Gly$Carbamidomethyl$Deamidated",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWC7",
    "length": 256,
    "modifications": "Propionamide$Delta:H(4)C(6)$Cytopiloyne$Deamidated$Oxidation$Pro->Pyrrolidinone$Carboxymethyl$Diethylphosphate$hex(4)hexnac(2)pent(1)$O-Isopropylmethylphosphonate$Decarboxylation",
    "modified_positions": 10,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZWC9",
    "length": 398,
    "modifications": "Gly$Carbamidomethyl$AEC-MAEC$Acetyldeoxyhypusine$Oxidation$Methamidophos-S$O-pinacolylmethylphosphonate$Diethyl$hex$Malonyl$hex(2)$PhosphoUridine",
    "modified_positions": 14,
    "name": "Aminopeptidase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZWD3",
    "length": 318,
    "modifications": "glyoxalAGE$AEBS$dileu4plex118$Tyr->Dha$Carbofuran$Oxidation$Biotin$Lysbiotinhydrazide$Cation:Na$Carboxymethyl",
    "modified_positions": 10,
    "name": "Uncharacterized protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZWE4",
    "length": 364,
    "modifications": "Carbamidomethyl$ISD_z+2_ion$phosphohexnac$hexnac(1)dhex(1)$s-glcnac$hexnac(2)dhex(1)$Pro->Pyrrolidinone$Delta:H(8)C(6)O(2)",
    "modified_positions": 9,
    "name": "Spermidine/putrescine import ATP-binding protein PotA",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZWE5",
    "length": 274,
    "modifications": "Diethylphosphate$HydroxymethylOP$Ethylphosphate",
    "modified_positions": 3,
    "name": "Spermidine/putrescine ABC transporter permease protein PotB",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWE7",
    "length": 340,
    "modifications": "pent(1)hexnac(1)$serotonylation$Nitrene$Deamidated",
    "modified_positions": 5,
    "name": "Putrescine-binding periplasmic protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZWE9",
    "length": 300,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$hex(1)hexnac(1)neuac(2)ac(2)$acetyl_13c(2)$biotinAcrolein298$SMA$hexnac(5)$Deamidated$Oxidation$clip_traq_2$Carboxy$Cation:K",
    "modified_positions": 15,
    "name": "DUF4349 domain-containing protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZWF0",
    "length": 203,
    "modifications": "Carbamidomethyl$QTGG$betaFNA$Chlorination$ethylamino$hex(2)hexnac(1)$Cation:Li",
    "modified_positions": 8,
    "name": "Bacterial regulatory proteins, TetR family",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZWF5",
    "length": 483,
    "modifications": "Dehydrated$Carbamidomethyl$Ammonium$monomethylphosphothione$phosphohexnac$s-glcnac$Cys->Oxoalanine$Oxidation$HPG$methylsulfonylethyl$methyl_2h(3)$Cation:Ca[II]$hex(1)hexnac(2)$Thiazolidine",
    "modified_positions": 17,
    "name": "Adenylate cyclase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZWG3",
    "length": 442,
    "modifications": "icpl_2h(4)$Delta:H(4)C(3)$Methylpyrroline$dnic$Ethanedithiol$HydroxymethylOP$hexnac(1)neuac(1)$Delta:H(2)C(3)O(1)$Oxidation$AMTzHexNAc2$methylol",
    "modified_positions": 11,
    "name": "Membrane bound lytic murein transglycosylase D",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZWG7",
    "length": 371,
    "modifications": "hex(1)pent(3)",
    "modified_positions": 2,
    "name": "Serine-type D-Ala-D-Ala carboxypeptidase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWH4",
    "length": 212,
    "modifications": "NDA$AEC-MAEC$Ethyl$Deamidated",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZWH5",
    "length": 231,
    "modifications": "Pyridylacetyl$DNCB_hapten$Oxidation$O-pinacolylmethylphosphonate$NBS",
    "modified_positions": 6,
    "name": "Transglutaminase-like domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZWH6",
    "length": 686,
    "modifications": "FP-Biotin$AFB1_Dialdehyde$phosphohex$neugc$thioacylPA$Carbamidomethyl$PS_Hapten$dhex(1)hex(2)hexnac(2)neugc(1)$icpl_13c(6)2h(4)$Isopropylphospho$ethylsulfonylethyl$Oxidation$Biotin$AMTzHexNAc2$O-Isopropylmethylphosphonate$Glu",
    "modified_positions": 21,
    "name": "Uncharacterized protein",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZWI1",
    "length": 330,
    "modifications": "Unknown:162$Carbamidomethyl$methyl_2h(3)13c(1)$Delta:H(4)C(6)$Ethyl$Oxidation$O-pinacolylmethylphosphonate$Cation:Na",
    "modified_positions": 11,
    "name": "Aminoglycoside phosphotransferase domain-containing protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZWI5",
    "length": 200,
    "modifications": "CresylSaligeninPhosphate$HexN",
    "modified_positions": 3,
    "name": "Proton transporter",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWJ4",
    "length": 147,
    "modifications": "Oxidation$Glu->pyro-Glu+Methyl",
    "modified_positions": 2,
    "name": "N-acetyltransferase domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWJ8",
    "length": 535,
    "modifications": "Carbamidomethyl$Carbonyl$Propionyl$Deamidated$Arg->GluSA$Oxidation$Thiazolidine",
    "modified_positions": 9,
    "name": "Probable lipid II flippase MurJ",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZWK1",
    "length": 343,
    "modifications": "Carbamidomethyl$Nitrosyl$glycidamide$Lys->Allysine$Formyl$Ethyl+Deamidated$neiaa_2h(5)$Pyridylacetyl$Sulfide$EHD-diphenylpentanone$Oxidation$Trioxidation$Phenylisocyanate$diart6plex118$Dioxidation",
    "modified_positions": 23,
    "name": "DUF1016 domain-containing protein",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZWK2",
    "length": 227,
    "modifications": "AEBS$Delta:H(4)C(6)$Sulfo$neuac$Oxidation$hex(5)phos(1)$Biotin:Thermo-21345$hex(1)hexnac(1)",
    "modified_positions": 11,
    "name": "Uncharacterized protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZWL1",
    "length": 394,
    "modifications": "Carbamidomethyl$Phosphopropargyl$Deamidated$clip_traq_2$hex(3)$BITC$Oxidation$PyruvicAcidIminyl",
    "modified_positions": 12,
    "name": "GIY-YIG nuclease family protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZWL8",
    "length": 85,
    "modifications": "Argbiotinhydrazide$hexnac(2)dhex(1)$Oxidation$PhosphoCytidine",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZWM9",
    "length": 180,
    "modifications": "Carbamidomethyl$maleimide$Oxidation$BHTOH$Pro->Pyrrolidone",
    "modified_positions": 8,
    "name": "Guanylate cyclase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZWN8",
    "length": 289,
    "modifications": "PET",
    "modified_positions": 2,
    "name": "ATP synthase gamma subunit C-terminus",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWQ5",
    "length": 150,
    "modifications": "AEBS$O-Methylphosphate",
    "modified_positions": 6,
    "name": "Transporter",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWQ6",
    "length": 1071,
    "modifications": "dhex(1)hex(3)hexnac(1)sulf(1)$Delta:H(2)C(3)$Methylphosphonate$Decanoyl$esp$Ammonia-loss$Fluoro$Oxidation$Glu->pyro-Glu$glucuronyl$Nitro",
    "modified_positions": 15,
    "name": "Chemiosmotic efflux system protein A-like protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZWQ7",
    "length": 322,
    "modifications": "Methylphosphonate$Methylamine$Ammonia-loss",
    "modified_positions": 3,
    "name": "Chemiosmotic efflux system C protein B",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWQ9",
    "length": 124,
    "modifications": "dileu4plex117$HexN$Carbamidomethyl$Lipoyl$Delta:H(2)C(5)$Fluoro$Arg->GluSA$Arg->Orn$Oxidation$dileu4plex115$acetyl_2h(3)$hexnac(2)",
    "modified_positions": 8,
    "name": "Putative outer membrane lipoprotein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZWR1",
    "length": 736,
    "modifications": "PyruvicAcidIminyl$PEITC$Carboxy->Thiocarboxy$Delta:H(4)C(5)O(1)$trimethyl_2h(9)$HNE$Oxidation$EHD-diphenylpentanone$clip_traq_2$Cation:Al[III]$murnac$Gly-loss+Amide$Delta:H(10)C(8)O(1)$BEMAD_ST$UgiJoullieProGly$HN2_mustard",
    "modified_positions": 21,
    "name": "Copper-exporting P-type ATPase",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZWR2",
    "length": 303,
    "modifications": "OxLysBiotinRed$Oxidation$acetyl_2h(3)$biotinAcrolein298",
    "modified_positions": 5,
    "name": "Ribose-phosphate pyrophosphokinase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZWR6",
    "length": 377,
    "modifications": "Biotin-PEG-PRA$Lys->Allysine$dimethyl_2h(6)13c(2)$Ammonia-loss$Amidine$Oxidation$Met->Hse$Argbiotinhydrazide$Dibromo$AHA-SS_CAM",
    "modified_positions": 10,
    "name": "Chemiosmotic efflux system B protein B",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZWU4",
    "length": 419,
    "modifications": "hexnac(2)neuac(1)$Aspartylurea$Ethylphosphate$Carbamidomethyl$Unknown:306$Tyr->Dha$Acetyl$Formyl$PyridoxalPhosphateH2$O-Dimethylphosphate$Oxidation$MeMePhosphorothioate$EQAT$Dioxidation",
    "modified_positions": 18,
    "name": "Exported membrane protein",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZWU7",
    "length": 324,
    "modifications": "phosphohex$Ethyl",
    "modified_positions": 2,
    "name": "TIGR03756 family integrating conjugative element protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWU8",
    "length": 455,
    "modifications": "Met->Hse$clip_traq_4$HCysteinyl$LRGG+methyl$Didehydro$hexnac(1)neugc(1)$Decarboxylation$Carbonyl$GGQ$Gly$Methylthio$Carbamyl$Dehydrated$15N-oxobutanoic$Carbamidomethyl$azole$Ethyl+Deamidated$Biotin:Thermo-33033$Oxidation$Malonyl$Glu->pyro-Glu",
    "modified_positions": 24,
    "name": "Membrane protein, Tfp pilus assembly, pilus retraction ATPase PilT",
    "unique_modifications": 21
  },
  {
    "id": "Q5ZWV8",
    "length": 140,
    "modifications": "hex(1)hexnac(1)",
    "modified_positions": 1,
    "name": "Single-stranded DNA-binding protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWW3",
    "length": 381,
    "modifications": "Carboxy$Succinyl$Nitrosyl$hex(1)hexnac(2)pent(1)",
    "modified_positions": 6,
    "name": "Ecto-ATP diphosphohydrolase II",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZWW5",
    "length": 246,
    "modifications": "Diethylphosphate$Oxidation$CresylSaligeninPhosphate",
    "modified_positions": 12,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWX9",
    "length": 420,
    "modifications": "MesitylOxide$methylol$Quinone$Cation:Li",
    "modified_positions": 4,
    "name": "Transmembrane protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZWY1",
    "length": 555,
    "modifications": "Deoxy$Carbamidomethyl$PS_Hapten$15N-oxobutanoic$dhex(1)hex(1)$ethylsulfonylethyl$Arg->GluSA$O-Methylphosphate$Oxidation$dimethyl_2h(4)$O-Isopropylmethylphosphonate$Malonyl",
    "modified_positions": 15,
    "name": "AMP-binding protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZWY3",
    "length": 480,
    "modifications": "Carbamyl$dhex(2)hex(3)hexnac(4)$galactosyl$dhex(1)hex(2)hexnac(2)neugc(1)$Carbamidomethyl$biotinAcrolein298$Decarboxylation$MercaptoEthanol$4-ONE$acetyl_2h(3)$Oxidation$hex(3)$Carbofuran$UgiJoullieProGly$Thiazolidine$Formyl$bacillosamine$Carboxymethyl",
    "modified_positions": 28,
    "name": "TldD protein",
    "unique_modifications": 18
  },
  {
    "id": "Q5ZWY4",
    "length": 268,
    "modifications": "hex(1)pent(2)$Cation:Fe[II]$Unknown:248$Furan$dhex(2)hex(2)hexnac(2)$Carbamidomethyl$Propargylamine$CarboxymethylDMAP$Oxidation$hex$dileu4plex115$BEMAD_ST$Carboxymethyl",
    "modified_positions": 18,
    "name": "Nitrilase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZWY7",
    "length": 605,
    "modifications": "dhex(1)hex(6)hexnac(2)$deamidated_18o(1)$Gly$neugc$Phosphopropargyl$Carbamidomethyl$hexnac(1)kdn(2)$Biotin:Thermo-21330$dhex(1)hex(3)hexnac(4)sulf(1)$neuac$Trioxidation$Cation:Al[III]$Oxidation$Pro->Pyrrolidinone$hep$Dioxidation",
    "modified_positions": 25,
    "name": "2-oxoglutarate ferredoxin oxidoreductase alpha subunit",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZWZ0",
    "length": 229,
    "modifications": "NDA$PropylNAGthiazoline$Aspartylurea$Carbamidomethyl$Carbonyl$Malonyl$maleimide$GGQ$Pro->pyro-Glu$Trp->Oxolactone$hex(1)hexnac(1)$Dioxidation$acetyl_2h(3)",
    "modified_positions": 14,
    "name": "DNA repair protein RecO",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZWZ4",
    "length": 187,
    "modifications": "probiotinhydrazide$Carbamidomethyl$Gln->pyro-Glu",
    "modified_positions": 3,
    "name": "2-dehydro-3-deoxy-phosphogluconate aldolase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWZ7",
    "length": 328,
    "modifications": "Carbamidomethyl$Cysteinyl$glycidamide$hex(2)hexnac(3)neugc(1)$Myristoyl+Delta:H(-4)$diart6plex115$LG-pyrrole$Succinyl",
    "modified_positions": 10,
    "name": "Riboflavin biosynthesis protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZWZ8",
    "length": 143,
    "modifications": "dileu4plex$dileu4plex117$HNE-Delta:H(2)O$Carbamidomethyl$Delta:H(2)C(2)$Iodoacetanilide:13C(6)$HN3_mustard$4-ONE$dileu4plex118$Oxidation$O-pinacolylmethylphosphonate$CAMthiopropanoyl$dileu4plex115$Decarboxylation",
    "modified_positions": 12,
    "name": "Universal stress protein",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZWZ9",
    "length": 483,
    "modifications": "galactosyl$Unknown:210$Carbamidomethyl$Carbonyl$Oxidation$Carbofuran$Biotin-phenacyl$hex$O-Isopropylmethylphosphonate$Delta:H(6)C(3)O(1)",
    "modified_positions": 12,
    "name": "DamX-related protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZX00",
    "length": 369,
    "modifications": "thioacylPA$Unknown:306$Carbamidomethyl$Methylphosphonate$Ethanolamine$Ammonia-loss$OxProBiotinRed$Oxidation$BITC$Heme$Pyro-carbamidomethyl$O-Isopropylmethylphosphonate$Decarboxylation",
    "modified_positions": 19,
    "name": "3-dehydroquinate synthase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZX01",
    "length": 175,
    "modifications": "SMA$Dap-DSP$Cytopiloyne+water$Oxidation$Phosphoadenosine$PyridoxalPhosphate",
    "modified_positions": 8,
    "name": "Shikimate kinase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZX05",
    "length": 182,
    "modifications": "Oxidation$neugc$Phospho",
    "modified_positions": 6,
    "name": "Type IV pilus biogenesis protein PilN",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZX06",
    "length": 354,
    "modifications": "Carbamidomethyl$Lys->AminoadipicAcid$Oxidation$4-ONE+Delta:H(-2)O(-1)$Methamidophos-S$Didehydroretinylidene",
    "modified_positions": 9,
    "name": "Type IV pilus biogenesis protein PilM",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZX07",
    "length": 336,
    "modifications": "Biotin-PEO-Amine$Delta:H(4)C(2)O(-1)S(1)$Carbamidomethyl$Methylthio$Phosphogluconoylation$Acetylhypusine$Deamidated$hexnac(1)neugc(2)$Oxidation$Methamidophos-S$Carboxy$Gly$Thiazolidine",
    "modified_positions": 22,
    "name": "Uncharacterized protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZX08",
    "length": 794,
    "modifications": "Carbamidomethyl$dimethyl_2h(4)$Acetyl$PyridoxalPhosphateH2$Deamidated$methylol$Oxidation$Pro->Pyrrolidinone$Menadione$PyridoxalPhosphate$glucuronyl$Hydroxymethyl$PyruvicAcidIminyl$ZQG$Decarboxylation",
    "modified_positions": 23,
    "name": "Penicillin-binding protein 1A",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZX10",
    "length": 312,
    "modifications": "bemad_st_2h(6)$neugc$Carbamidomethyl$Carbonyl$GG$hex(1)neugc(1)$Oxidation$Dicarbamidomethyl$Gln->pyro-Glu",
    "modified_positions": 9,
    "name": "Electron transfer flavoprotein subunit alpha",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZX11",
    "length": 249,
    "modifications": "bemad_st_2h(6)$neugc$Propionyl$Ammonia-loss$HNE$Oxidation$Glu->pyro-Glu",
    "modified_positions": 9,
    "name": "Electron transfer flavoprotein subunit beta",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZX12",
    "length": 414,
    "modifications": "Delta:H(4)C(3)O(1)$Decarboxylation$GG$ethylamino$hex(1)hexnac(2)dhex(2)$Deamidated$Oxidation$PET$Glu->pyro-Glu+Methyl",
    "modified_positions": 7,
    "name": "J domain-containing protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZX15",
    "length": 350,
    "modifications": "NA-OA-NO2$Pyridylethyl$Dehydrated$PhosphoCytidine$Carbamidomethyl$Propionyl$icpl_13c(6)2h(4)$hexnac(4)$Oxidation$NA-LNO2$methyl_2h(3)$Methylthio$propyl_2h(6)$Cation:Ni[II]",
    "modified_positions": 19,
    "name": "Erythronate-4-phosphate dehydrogenase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZX16",
    "length": 483,
    "modifications": "Carbamidomethyl$15N-oxobutanoic$Methamidophos-O$Deamidated$maleimide$OxLysBiotinRed$NA-LNO2$GlycerylPE$Oxidation$propionyl_13c(3)$dimethyl_2h(4)$UgiJoullieProGly$BEMAD_ST$Carboxymethyl",
    "modified_positions": 21,
    "name": "UDP-N-acetylmuramoyl-L-alanyl-D-glutamate--2,6-diaminopimelate ligase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZX20",
    "length": 152,
    "modifications": "Carbamidomethyl$AEBS$hex(1)hexnac(1)kdn(1)sulf(1)$Deamidated$Oxidation$Trp->Kynurenin$hex",
    "modified_positions": 10,
    "name": "Transcriptional regulator MraZ",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZX22",
    "length": 256,
    "modifications": "NDA$CresylSaligeninPhosphate$Carbamidomethyl$hexnac(1)dhex(1)$Gly$Unknown:234$Delta:H(8)C(6)O(1)",
    "modified_positions": 9,
    "name": "Type III pantothenate kinase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZX24",
    "length": 135,
    "modifications": "Decarboxylation",
    "modified_positions": 1,
    "name": "Cytochrome c5",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZX25",
    "length": 233,
    "modifications": "icpl_2h(4)$Carbamyl$acetyl_13c(2)$hex(1)pent(3)me(1)$Ethanolyl$Cation:Na$TMPP-Ac",
    "modified_positions": 6,
    "name": "Flagella basal body P-ring formation protein FlgA",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZX26",
    "length": 106,
    "modifications": "icpl$Oxidation$glucosone$Methyl+Deamidated$phosphoRibosyl$Hydroxamic_acid",
    "modified_positions": 7,
    "name": "Negative regulator of flagellin synthesis",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZX27",
    "length": 165,
    "modifications": "Succinyl$Malonyl",
    "modified_positions": 2,
    "name": "Flagellar biosynthesis/type III secretory pathway chaperone",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZX32",
    "length": 218,
    "modifications": "Deoxy$Carbamidomethyl$hex(1)neugc(1)$CarbamidomethylDTT$Ammonia-loss$Deamidated$neuac$Oxidation$Gln->pyro-Glu",
    "modified_positions": 12,
    "name": "Uncharacterized protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZX37",
    "length": 125,
    "modifications": "Carbamidomethyl$Tyr->Dha$methyl_2h(3)",
    "modified_positions": 3,
    "name": "Sel-1 protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZX48",
    "length": 358,
    "modifications": "HexN$Dehydrated$Deoxy$Carbamidomethyl$Delta:H(6)C(6)O(1)$Deamidated$hex(1)pent(3)$3sulfo$Oxidation$glucosone$Pro->Pyrrolidone$Glu->pyro-Glu",
    "modified_positions": 15,
    "name": "beta-N-acetylhexosaminidase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZX56",
    "length": 377,
    "modifications": "Carbamidomethyl$PS_Hapten$hex(3)hexnac(2)$2-dimethylsuccinyl$BEMAD_C$ethylsulfonylethyl$Deamidated$Fluoro$Gly",
    "modified_positions": 8,
    "name": "NAD(P) transhydrogenase subunit alpha part 1",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZX60",
    "length": 526,
    "modifications": "Dehydrated$Iodoacetanilide$Carbamidomethyl$15N-oxobutanoic$hex(1)neugc(1)$Propargylamine$maleimide$Oxidation$HPG$Methylamine$EDT-maleimide-PEO-biotin$Propiophenone$UgiJoullieProGly",
    "modified_positions": 16,
    "name": "Peptide chain release factor 3",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZX61",
    "length": 288,
    "modifications": "GluGlu$Acetyl$FTC$Trioxidation$Oxidation$UgiJoullieProGly",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZX66",
    "length": 183,
    "modifications": "hex(3)hexnac(2)$Biotin",
    "modified_positions": 2,
    "name": "Putative 3-methyladenine DNA glycosylase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZX70",
    "length": 177,
    "modifications": "Formylasparagine$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Thiol:disulfide interchange protein DsbE",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZX71",
    "length": 650,
    "modifications": "Delta:H(6)C(7)O(4)$Carbonyl$Carbamidomethyl$Cytopiloyne$Oxidation$Nethylmaleimide+water$Biotin-tyramide$Met->Hpg$acetyl_2h(3)",
    "modified_positions": 13,
    "name": "Cytochrome c-type biogenesis protein CcmF",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZX75",
    "length": 226,
    "modifications": "Oxidation$propyl_2h(6)",
    "modified_positions": 1,
    "name": "Heme exporter protein B",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZX78",
    "length": 93,
    "modifications": "QTGG$Oxidation$imid_2h(4)$Hydroxamic_acid$CIGG",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZX79",
    "length": 471,
    "modifications": "Hypusine$Carbamyl$Delta:H(4)C(3)O(1)$thioacylPA$Pro->HAVA$Carbamidomethyl$Acetyl$hex(3)hexnac(1)$ethylamino$hep$Oxidation$Carboxymethyl$Myristoyl+Delta:H(-4)$Delta:H(2)C(3)O(1)$Dioxidation$hex(2)$Delta:H(6)C(3)O(1)",
    "modified_positions": 30,
    "name": "Transcriptional regulator FleQ",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZX81",
    "length": 338,
    "modifications": "Delta:H(6)C(7)O(4)$hex(1)hexa(1)$Diethylphosphothione$Glu$Cytopiloyne+water$Oxidation$O-Isopropylmethylphosphonate$ZQG$hex(2)hexa(1)hexnac(1)sulf(1)",
    "modified_positions": 10,
    "name": "Membrane fusion protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZX83",
    "length": 225,
    "modifications": "FP-Biotin$OxProBiotin$PEITC$hex(1)hexnac(1)dhex(1)me(2)$Arg->Npo$HNE-BAHAH$Oxidation$dimethyl_2h(4)$hex(2)hexnac(1)me(1)$Formyl",
    "modified_positions": 15,
    "name": "ABC transporter, ATP binding protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZX84",
    "length": 252,
    "modifications": "GG$Oxidation$Dicarbamidomethyl$Gluratylation",
    "modified_positions": 3,
    "name": "GTP cyclohydrolase 1 type 2 homolog",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZX86",
    "length": 81,
    "modifications": "Oxidation$4-ONE+Delta:H(-2)O(-1)$GPIanchor",
    "modified_positions": 3,
    "name": "Hypothetical BolA like protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZX87",
    "length": 93,
    "modifications": "Carbamidomethyl$Deamidated$Oxidation$methylsulfonylethyl$Gly",
    "modified_positions": 6,
    "name": "STAS domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZX91",
    "length": 265,
    "modifications": "deamidated_18o(1)$neugc$Carbamidomethyl$QTGG$Oxidation$PET$Palmitoyl",
    "modified_positions": 10,
    "name": "Toluene tolerance ABC transporter, ATP binding protein Ttg2A",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZX92",
    "length": 320,
    "modifications": "bemad_st_2h(6)$Carbamyl$Delta:H(4)C(3)O(1)$Carbamidomethyl$SMA$betaFNA$Deamidated$hex(1)hexnac(2)neugc(1)$Oxidation$hex(1)hexnac(2)dhex(1)$Cation:Ni[II]",
    "modified_positions": 18,
    "name": "Arabinose 5-phosphate isomerase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZX97",
    "length": 192,
    "modifications": "Oxidation$esp$O-Et-N-diMePhospho",
    "modified_positions": 5,
    "name": "Anthranilate synthase component II",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXA2",
    "length": 241,
    "modifications": "icpl_13c(6)$Deoxy$Cresylphosphate$esp$Pyridylacetyl$Oxidation$Label:13C(1)2H(3)+Oxidation$Nmethylmaleimide$Gln->pyro-Glu",
    "modified_positions": 15,
    "name": "Thioesterase domain-containing protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZXB0",
    "length": 416,
    "modifications": "benzoyl$qat_2h(3)",
    "modified_positions": 2,
    "name": "O-antigen biosynthesis protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXB1",
    "length": 259,
    "modifications": "CresylSaligeninPhosphate$Propionamide$Quinone$Oxidation$methylol$Delta:H(4)C(3)O(2)",
    "modified_positions": 6,
    "name": "Lipopolysaccharide biosynthesis glycosyltransferase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXB7",
    "length": 232,
    "modifications": "Cytopiloyne+water$Deamidated$Oxidation$methyl_2h(3)$MercaptoEthanol",
    "modified_positions": 13,
    "name": "Protein tyrosine phosphatase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXC2",
    "length": 105,
    "modifications": "dhex",
    "modified_positions": 2,
    "name": "Competence protein ComEA",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXC3",
    "length": 471,
    "modifications": "NEM:2H(5)+H2O$Cation:Al[III]$Pro->Pyrrolidone$Carboxymethyl$Delta:H(2)C(3)O(1)$Didehydro$Gln->pyro-Glu$FP-Biotin$hex(1)pent(1)$Deoxy$galactosyl$Methylthio$Gly$glycosyl$Carbamidomethyl$Oxidation$HMVK$hep$Cation:Ca[II]$acetyl_2h(3)",
    "modified_positions": 31,
    "name": "Succinyl-diaminopimelate desuccinylase",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZXC5",
    "length": 280,
    "modifications": "Delta:H(4)C(3)O(1)$Carbamidomethyl$Unknown:306$phosphohexnac$s-glcnac$Oxidation",
    "modified_positions": 5,
    "name": "Probable nicotinate-nucleotide pyrophosphorylase [carboxylating]",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXC7",
    "length": 795,
    "modifications": "GG$HPG$pent(1)hexnac(1)$Unknown:234$bacillosamine$Thrbiotinhydrazide$Phenylisocyanate:2H(5)$Lys->CamCys$Ethanolamine$Octanoyl$Pro->Pyrrolidinone$Gly$ZQG$Carbamidomethyl$GluGlu$Fluoro$Oxidation$Propiophenone$Dicarbamidomethyl$O-Et-N-diMePhospho",
    "modified_positions": 29,
    "name": "Phosphoenolpyruvate synthase",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZXC8",
    "length": 332,
    "modifications": "FP-Biotin$sulfanilicacid$Delta:H(5)C(2)$hex(2)pent(2)me(1)$Carbamidomethyl$Menadione-HQ$Oxidation$Can-FP-biotin$Tyr->Dha$Cation:K",
    "modified_positions": 9,
    "name": "Choloylglycine hydrolase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZXD1",
    "length": 456,
    "modifications": "Deoxy$FMN$Pro->HAVA$Carbonyl$Homocysteic_acid$AccQTag$EDT-iodoacetyl-PEO-biotin$esp$Deamidated$Fluoro$Oxidation$Pro->pyro-Glu$hexnac(2)dhex(2)$Ethyl$Gln->pyro-Glu",
    "modified_positions": 24,
    "name": "Adenylosuccinate lyase",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZXD2",
    "length": 549,
    "modifications": "galactosyl$Carbamidomethyl$Unknown:234$Cresylphosphate$dhex(1)hex(2)hexnac(1)$dhex(1)hex(5)$Oxidation$CarboxymethylDTT$Biotin-phenacyl$Carboxy$MercaptoEthanol$dhex(1)hex(1)hexa(1)hexnac(3)$hex(1)hexnac(3)",
    "modified_positions": 18,
    "name": "L-aspartate oxidase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZXE4",
    "length": 178,
    "modifications": "Deoxy$Carbamidomethyl$Thrbiotinhydrazide",
    "modified_positions": 3,
    "name": "Transposase IS200-like domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXE6",
    "length": 317,
    "modifications": "Phosphopropargyl$Carbamidomethyl$Acetyl$hex(2)hexnac(2)neugc(1)$Oxidation$Biotin-phenacyl$Dioxidation$Nitro",
    "modified_positions": 12,
    "name": "Acetyl-coenzyme A carboxylase carboxyl transferase subunit alpha",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZXE7",
    "length": 245,
    "modifications": "Carbamyl$Deoxy$Dehydrated$glucosylgalactosyl$Carbamidomethyl$Deamidated$Oxidation$Biotin$OxArgBiotin$Delta:H(6)C(3)O(1)$Thrbiotinhydrazide",
    "modified_positions": 10,
    "name": "Phosphopantetheine-protein transferase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZXF2",
    "length": 339,
    "modifications": "Carbamidomethyl$Delta:H(2)C(3)",
    "modified_positions": 2,
    "name": "Glycosyltransferase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXG2",
    "length": 239,
    "modifications": "Carbamidomethyl$LRGG+dimethyl$Deamidated$Crotonyl$Didehydro",
    "modified_positions": 7,
    "name": "Methyltransferase type 12 domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXG7",
    "length": 174,
    "modifications": "icpl_13c(6)$Arg->Orn$hex(3)$Nmethylmaleimide$Thiazolidine",
    "modified_positions": 4,
    "name": "Right handed beta helix domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXG8",
    "length": 80,
    "modifications": "Dehydrated",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXG9",
    "length": 334,
    "modifications": "Cytopiloyne$NQIGG",
    "modified_positions": 2,
    "name": "O-antigen initiating glycosyl transferase group 4-UDP-N-acetylmuramyl pentapeptide phosphotransferase/(N-acetylgalactosaminyl transferase TrsF)",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXH0",
    "length": 318,
    "modifications": "Unknown:162$Ethylphosphate$O-Dimethylphosphate$Oxidation$hex(1)hexnac(1)neuac(1)ac(1)$Cation:Li$Diethyl",
    "modified_positions": 7,
    "name": "NAD dependent epimerase/dehydratase, UDP-glucose-4-epimerase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXH3",
    "length": 359,
    "modifications": "Propionamide$thioacylPA$AEC-MAEC$dhex(1)hex(2)$Amidine$Deamidated$BITC$Oxidation$Carboxymethyl$NQIGG$Palmitoyl",
    "modified_positions": 12,
    "name": "dTDP-glucose 4,6-dehydratase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZXH4",
    "length": 294,
    "modifications": "Biotin:Thermo-21328$dimethyl_2h(4)13c(2)$Diisopropylphosphate$Carbamidomethyl$Acetyl$Methyl$3-deoxyglucosone$4-ONE+Delta:H(-2)O(-1)$hex(1)hexnac(1)dhex(1)$dimethyl_2h(6)$glucosone$Cation:Fe[III]$hex(1)hexnac(2)$diart6plex118$PyruvicAcidIminyl$diart6plex116/119$hexnac(2)",
    "modified_positions": 15,
    "name": "dTDP-4-dehydrorhamnose reductase",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZXI0",
    "length": 232,
    "modifications": "Carbamidomethyl$Deamidated",
    "modified_positions": 2,
    "name": "CMP-N,N'-diacetyllegionaminic acid synthase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXI1",
    "length": 213,
    "modifications": "dimethyl_2h(4)13c(2)$Carbamidomethyl$icdid$hexnac(3)$ethylamino$Oxidation$BDMAPP$dimethyl_2h(6)$Methyl+Deamidated$Delta:H(6)C(3)O(1)",
    "modified_positions": 12,
    "name": "Imidazole glycerol phosphate synthase subunit HisH 1",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZXJ1",
    "length": 149,
    "modifications": "Dehydrated$Carboxy->Thiocarboxy$Carbamidomethyl$AEBS$CarbamidomethylDTT$Oxidation$Glu->pyro-Glu",
    "modified_positions": 17,
    "name": "17kDa common antigen",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXJ2",
    "length": 357,
    "modifications": "hex(1)hexa(1)$Nmethylmaleimide+water$Ser->LacticAcid$Carbamidomethyl$Methyl$Deamidated$Isopropylphospho$Oxidation$4-ONE+Delta:H(-2)O(-1)$Cation:K",
    "modified_positions": 11,
    "name": "Alanine racemase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZXJ7",
    "length": 536,
    "modifications": "Biotin:Cayman-10013$Carbamidomethyl$Saligenin$4-ONE$Biotin:Thermo-88317$Amidine$Deamidated$Delta:O(4)$Oxidation$Triton$Cation:Ag$Cys->ethylaminoAla$Biotin$Didehydro$hex(1)hexnac(3)$Glycerophospho",
    "modified_positions": 22,
    "name": "Glutamine-dependent NAD(+) synthetase",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZXK6",
    "length": 417,
    "modifications": "Carbamyl$Deoxyhypusine$Delta:H(4)C(5)O(1)$Carbamidomethyl$hex(2)pent(2)me(1)$Cation:Cu[I]$PET$Oxidation$propionyl_13c(3)$Cation:Zn[II]$Glycerophospho",
    "modified_positions": 16,
    "name": "Serine hydroxymethyltransferase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZXK7",
    "length": 103,
    "modifications": "betaFNA$Oxidation$Methamidophos-S$Met->Hse$dichlorination$Decarboxylation",
    "modified_positions": 6,
    "name": "Hypothetical periplasmic or secreted lipoprotein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXL0",
    "length": 420,
    "modifications": "Carbamidomethyl$HydroxymethylOP$Ammonium$Deamidated$Oxidation$LG-pyrrole$ZQG",
    "modified_positions": 10,
    "name": "RND efflux membrane fusion protein, acriflavin resistance protein E",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXL5",
    "length": 337,
    "modifications": "PyruvicAcidIminyl$Carbamidomethyl$glyoxalAGE$Acetyl$AEC-MAEC$Cytopiloyne+water$Cation:Mg[II]$Cation:K$hexnac(1)dhex(1)$DAET$Deamidated$Oxidation$Argbiotinhydrazide$Succinyl$Cation:Na$acetyl_2h(3)$hex(1)hexnac(2)dhex(1)pent(1)",
    "modified_positions": 16,
    "name": "Uncharacterized protein",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZXL6",
    "length": 223,
    "modifications": "OxArgBiotinRed$hex(1)pent(2)me(1)$Unknown:306",
    "modified_positions": 3,
    "name": "Two component response regulator",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXL9",
    "length": 231,
    "modifications": "Ethanedithiol$Methyl$Deamidated$Oxidation$Delta:H(8)C(6)O(2)$Decarboxylation",
    "modified_positions": 7,
    "name": "Endo-1,4-beta-xylanase-like",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXM1",
    "length": 269,
    "modifications": "hex(1)pent(2)$Carbamidomethyl$Oxidation$hex(1)hexnac(2)neuac(2)$CHDH",
    "modified_positions": 5,
    "name": "Sepiapterin reductase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXM3",
    "length": 320,
    "modifications": "deamidated_18o(1)$Deoxy$hex(5)hexa(1)$Carbamidomethyl$HNE+Delta:H(2)$Deamidated$hexnac(2)neuac(1)sulf(1)$Oxidation$Methylamine$Carboxymethyl$Methyl+Deamidated$Dioxidation$Delta:H(6)C(3)O(1)$gist-quat_2h(3)",
    "modified_positions": 21,
    "name": "IcmL-like",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZXM6",
    "length": 145,
    "modifications": "Carbamidomethyl$Cytopiloyne$Delta:O(4)$Oxidation$SulfoGMBS",
    "modified_positions": 6,
    "name": "Predicted transporter component",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXM7",
    "length": 203,
    "modifications": "serotonylation$Carbamidomethyl$Delta:H(2)C(2)$Deamidated$clip_traq_2$Oxidation$Trioxidation$Myristoleyl$Hydroxyheme$Phospho$Diethyl$LG-lactam-K$Cyano$Thiazolidine",
    "modified_positions": 20,
    "name": "Enhanced entry protein EnhA",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZXM8",
    "length": 557,
    "modifications": "Carbamidomethyl$hexnac$hex(1)hexnac(1)kdn(1)sulf(1)$hydroxyisobutyryl$Deamidated$Phosphoguanosine$hex(2)hexnac(2)neugc(1)$Oxidation$GEE$O-pinacolylmethylphosphonate$dhex(1)hex(2)hexnac(1)sulf(1)$EHD-diphenylpentanone$DNCB_hapten$Diethylphosphate$MesitylOxide$DAET$Dimethylphosphothione",
    "modified_positions": 20,
    "name": "Energy-dependent translational throttle protein EttA",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZXM9",
    "length": 340,
    "modifications": "NDA$Propionamide$Carbamidomethyl$azole$Deamidated$Cys->methylaminoAla",
    "modified_positions": 7,
    "name": "L-threonine 3-dehydrogenase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXN2",
    "length": 455,
    "modifications": "OxLysBiotinRed$Oxidation$dhex(1)hex(2)$clip_traq_3",
    "modified_positions": 7,
    "name": "Outer membrane protein TolC",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXN3",
    "length": 283,
    "modifications": "galactosyl$Carbamidomethyl$UgiJoullieProGlyProGly$Amino$Oxidation$hex(2)hexnac(1)$HMVK$BHTOH$Nitrosyl$AHA-SS",
    "modified_positions": 14,
    "name": "tRNA-cytidine(32) 2-sulfurtransferase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZXP4",
    "length": 96,
    "modifications": "Delta:H(2)C(2)$Ammonia-loss$Dethiomethyl$Met->Hsl$Diethylphosphate$Ammonium$Amidine$Deamidated$Carbofuran$Didehydro$dimethyl_2h(4)$TAMRA-FP$Deoxy$Carbonyl$Gly$Carbamyl$Dehydrated$Carboxy->Thiocarboxy$Carbamidomethyl$Methyl$Oxidation$Delta:H(6)C(3)O(1)$Glu->pyro-Glu",
    "modified_positions": 26,
    "name": "Co-chaperonin GroES",
    "unique_modifications": 23
  },
  {
    "id": "Q5ZXQ0",
    "length": 190,
    "modifications": "PEITC$Carbonyl$Carbamidomethyl$ethylamino$Oxidation$Nethylmaleimide+water$LG-lactam-R$clip_traq_3$Diethyl$PyruvicAcidIminyl$Diethylphosphate",
    "modified_positions": 14,
    "name": "Lipoprotein, putative",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZXQ4",
    "length": 88,
    "modifications": "phosphohex$hex(4)hexnac(4)neuac(1)sulf(2)$Quinone$Diethylphosphothione$Oxidation$pent(2)",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXQ9",
    "length": 254,
    "modifications": "Carbamyl$Carbamidomethyl$ethylamino$Deamidated$Oxidation$Formyl$Thiazolidine$Glu->pyro-Glu",
    "modified_positions": 9,
    "name": "Acetoacetate decarboxylase ADC",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZXR4",
    "length": 289,
    "modifications": "Cation:Al[III]$Carbamidomethyl",
    "modified_positions": 2,
    "name": "DUF692 domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXR5",
    "length": 259,
    "modifications": "Unknown:250",
    "modified_positions": 1,
    "name": "Putative DNA-binding domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXR7",
    "length": 217,
    "modifications": "Iodoacetanilide$Carbamidomethyl$esp$Oxidation$hex(1)hexnac(2)",
    "modified_positions": 8,
    "name": "Ribulose-phosphate 3-epimerase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXR9",
    "length": 479,
    "modifications": "Methylthio$Methylphosphonate$Delta:H(6)C(6)O(1)$Crotonaldehyde$Methyl$Dimethyl$Oxidation$cGMP+RMP-loss$methylsulfonylethyl$O-pinacolylmethylphosphonate$Dicarbamidomethyl$Butyryl$Ethyl$hep",
    "modified_positions": 14,
    "name": "Multidrug efflux MFS outer membrane protein (RND family)",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZXS9",
    "length": 430,
    "modifications": "Propiophenone$propionyl_13c(3)$Oxidation$Carbamidomethyl",
    "modified_positions": 8,
    "name": "Lysosomal dipeptide transporter MFSD1",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXT0",
    "length": 411,
    "modifications": "Phosphopropargyl$Carbamidomethyl$Deamidated$Oxidation$Trioxidation$Phosphoadenosine$2-succinyl",
    "modified_positions": 10,
    "name": "NADP-dependent malic enzyme",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXT1",
    "length": 75,
    "modifications": "Dehydrated$Carbamidomethyl$15N-oxobutanoic$Decanoyl$Oxidation$Didehydro$PET$O-Isopropylmethylphosphonate$Glu->pyro-Glu",
    "modified_positions": 10,
    "name": "Large ribosomal subunit protein bL31",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZXU0",
    "length": 441,
    "modifications": "Biotin-PEO-Amine$Deoxy$Diisopropylphosphate$dhex(1)hex(2)hexnac(1)$pupylation$Deamidated$O-Methylphosphate$Oxidation$hex(3)$methyl+acetyl_2h(3)$clip_traq_4$CAMthiopropanoyl$propionyl_13c(3)$AzidoF$Carboxymethyl$Dimethylphosphothione",
    "modified_positions": 19,
    "name": "ATP-dependent protease ATPase subunit HslU",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZXU1",
    "length": 182,
    "modifications": "Diethylphosphate$dhex(2)hex(5)hexnac(2)me(1)$Oxidation$clip_traq_3",
    "modified_positions": 4,
    "name": "ATP-dependent protease subunit HslV",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXU3",
    "length": 427,
    "modifications": "Carbamidomethyl$Cytopiloyne$monomethylphosphothione$Cytopiloyne+water$Unknown:216$Decarboxylation",
    "modified_positions": 13,
    "name": "Lysosomal dipeptide transporter MFSD1",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXU5",
    "length": 209,
    "modifications": "Oxidation$ethylamino$Carbamidomethyl$Delta:H(4)C(5)O(1)",
    "modified_positions": 4,
    "name": "Thymidine kinase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXU6",
    "length": 493,
    "modifications": "SulfanilicAcid:13C(6)$neiaa$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Melitin resistance protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXV1",
    "length": 355,
    "modifications": "serotonylation$Carbamidomethyl$hexnac(4)$Pro->Pyrrolidinone$Oxidation$Unknown:216$Pro->Pyrrolidone",
    "modified_positions": 9,
    "name": "Type IV fimbrial biogenesis PilW related protein, transmembrane",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXV2",
    "length": 170,
    "modifications": "Carboxy$Oxidation$Met->Hpg",
    "modified_positions": 2,
    "name": "Tfp pilus assembly protein PilX",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXV4",
    "length": 149,
    "modifications": "HNE-BAHAH$Oxidation$Methyl$Carbamidomethyl",
    "modified_positions": 7,
    "name": "Type IV pilin",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXW2",
    "length": 126,
    "modifications": "Carboxy$Oxidation$Tween20",
    "modified_positions": 3,
    "name": "Glyoxylase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXW3",
    "length": 190,
    "modifications": "AEBS$hexnac$icpl_13c(6)2h(4)$Oxidation$Argbiotinhydrazide",
    "modified_positions": 8,
    "name": "3-methyladenine DNA glycosylase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXX5",
    "length": 149,
    "modifications": "icpl_2h(4)$Carbamidomethyl$dnic$Ammonia-loss$Oxidation$Pyro-carbamidomethyl$Cys->PyruvicAcid$Cyano",
    "modified_positions": 6,
    "name": "Nitrogen fixation protein (Fe-S cluster formation) NifU",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZXX6",
    "length": 414,
    "modifications": "Deoxy$Carbamidomethyl$hex(2)pent(2)$hex(1)hexnac(1)dhex(1)me(2)$Oxidation$cGMP+RMP-loss$PyMIC$dhex(1)hex(2)hexnac(3)",
    "modified_positions": 10,
    "name": "Cysteine desulfurase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZXX7",
    "length": 428,
    "modifications": "ethylamino$Propargylamine$dhex(1)hex(1)$Oxidation$Myristoyl",
    "modified_positions": 10,
    "name": "ABC transporter, permease component",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXX8",
    "length": 250,
    "modifications": "Carbamyl$neugc$Carbamidomethyl$Methyl$Malonyl$Deamidated$Isopropylphospho$OxLysBiotinRed$Oxidation$hex(1)hexnac(1)dhex(1)$clip_traq_3$Hydroxamic_acid$hex(1)hexnac(3)",
    "modified_positions": 16,
    "name": "ATP transporter, ABC binding component, ATP-binding protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZXY0",
    "length": 153,
    "modifications": "neugc$Carbonyl$Delta:H(4)C(6)$Oxidation$hexnac(1)neugc(1)",
    "modified_positions": 7,
    "name": "Rrf2 family protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXY2",
    "length": 139,
    "modifications": "Carbamidomethyl$Dap-DSP$FTC$Oxidation$methylsulfonylethyl$Thiazolidine",
    "modified_positions": 5,
    "name": "DUF1499 domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZXY5",
    "length": 271,
    "modifications": "nic$hex(1)hexa(1)$hex(4)hexnac(2)$icpl$Carbamidomethyl$Crotonaldehyde$dhex(2)hex(1)hexnac(3)$Oxidation$Methamidophos-S$hex(2)hexnac(2)dhex(1)$Diethylphosphate$Butyryl$Methylthio$Thiazolidine",
    "modified_positions": 14,
    "name": "Aminodeoxychorismate lyase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZXZ1",
    "length": 128,
    "modifications": "Delta:H(4)C(3)$glucosylgalactosyl",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXZ2",
    "length": 297,
    "modifications": "Biotin-PEO-Amine$Carbamidomethyl$Acetyl$Deamidated$Propyl$Carboxymethyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 8,
    "name": "Aspartate carbamoyltransferase catalytic subunit",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZXZ8",
    "length": 159,
    "modifications": "Carbamidomethyl$Delta:H(2)C(2)$betaFNA$Lipoyl$Oxidation$dhex(2)hex(2)$Phospho",
    "modified_positions": 6,
    "name": "Swiss Army Knife 2H phosphoesterase domain-containing protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZY00",
    "length": 326,
    "modifications": "Biotin-PEO-Amine$Carbamidomethyl$Methyl$Oxidation$CHDH$hex$Formyl",
    "modified_positions": 10,
    "name": "Adenosine deaminase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZY03",
    "length": 178,
    "modifications": "Amidine$CresylSaligeninPhosphate$Carbamidomethyl$Deamidated",
    "modified_positions": 5,
    "name": "Transferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZY11",
    "length": 356,
    "modifications": "SulfanilicAcid:13C(6)$Ethylphosphate$Carbamidomethyl$IodoU-AMP$O-Dimethylphosphate$Oxidation$hex(2)hexnac(1)$dichlorination$bacillosamine",
    "modified_positions": 12,
    "name": "DUF1460 domain-containing protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZY13",
    "length": 132,
    "modifications": "Ethyl+Deamidated$Ethyl$Met->Hse$Gln->pyro-Glu",
    "modified_positions": 4,
    "name": "PHA accumulation regulator DNA-binding N-terminal domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZY14",
    "length": 248,
    "modifications": "icpl_2h(4)$NDA$OxProBiotin$Propionamide$dhex(2)hex(2)hexnac(2)sulf(1)$dnic$Oxidation$dhex$bacillosamine",
    "modified_positions": 11,
    "name": "Acetyoacetyl CoA reductase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZY16",
    "length": 132,
    "modifications": "Carbamyl$Biotin-phenacyl",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZY17",
    "length": 395,
    "modifications": "Lys->CamCys$Methylpyrroline$GG$Oxidation$Propyl$CAMthiopropanoyl$MercaptoEthanol$O-Isopropylmethylphosphonate$Dicarbamidomethyl$dichlorination",
    "modified_positions": 12,
    "name": "Stearoyl-CoA-9-desaturase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZY18",
    "length": 274,
    "modifications": "Carbamidomethyl$propionamide_2h(3)$methyl_2h(3)$hex(1)hexnac(2)dhex(1)$hex(1)hexnac(1)",
    "modified_positions": 6,
    "name": "Formamidopyrimidine-DNA glycosylase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZY19",
    "length": 206,
    "modifications": "Carbamidomethyl$Carbonyl$Oxidation$4-ONE+Delta:H(-2)O(-1)$Delta:H(8)C(6)O(2)$CIGG$Delta:H(8)C(6)O(1)",
    "modified_positions": 10,
    "name": "Uncharacterized protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZY20",
    "length": 355,
    "modifications": "dileu4plex118$dhex(2)hex(2)hexa(1)$HNE-BAHAH$Unknown:216$dileu4plex115$Propionamide$TMPP-Ac:13C(9)$Phosphopropargyl$HCysThiolactone$Cation:Fe[III]$Didehydro$AEBS$GEE$dileu4plex$dileu4plex117$Thiadiazole$Carbamidomethyl$Methyl$Oxidation$Diethyl$hex$PET",
    "modified_positions": 23,
    "name": "DNA polymerase IV",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZY27",
    "length": 199,
    "modifications": "Carbamidomethyl$Ethyl$Deamidated$Oxidation$Delta:H(4)C(2)$Dimethyl$Hydroxamic_acid",
    "modified_positions": 8,
    "name": "Outer-membrane lipoprotein LolB",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZY30",
    "length": 315,
    "modifications": "bemad_st_2h(6)$dileu4plex117$Carbamidomethyl$Amidine$Oxidation$Propiophenone$dileu4plex115$Gly",
    "modified_positions": 12,
    "name": "Ribose-phosphate pyrophosphokinase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZY33",
    "length": 427,
    "modifications": "hex(1)pent(1)$Cytopiloyne+water$hex(1)hexa(1)hexnac(1)$O-Methylphosphate$Oxidation$Delta:H(4)C(2)$Dimethyl$Ethyl",
    "modified_positions": 6,
    "name": "Lysosomal dipeptide transporter MFSD1",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZY34",
    "length": 129,
    "modifications": "hexnac(3)sulf(1)$Lys->Allysine$Iodoacetanilide$Hydroxamic_acid",
    "modified_positions": 6,
    "name": "SseB protein N-terminal domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZY40",
    "length": 409,
    "modifications": "hex(2)hexnac(5)$Delta:H(2)C(2)$dhex(1)hex(2)hexa(1)hexnac(2)$dhex(1)hex(2)hexnac(3)neuac(1)$LG-anhydrolactam$SPITC$His+O(2)$hex(1)hexnac(1)dhex(1)me(2)$hexnac$pupylation$hex(1)hexa(1)hexnac(1)$G-H1$HNE$LRGG+methyl$Decarboxylation$Deoxy$dhex(1)hex(2)hexnac(3)$Gly$Carbamidomethyl$Methamidophos-O$Oxidation$dhex(3)hex(2)hexnac(3)",
    "modified_positions": 26,
    "name": "Dihydrolipoyllysine-residue succinyltransferase component of 2-oxoglutarate dehydrogenase complex",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZY42",
    "length": 240,
    "modifications": "dimethyl_2h(4)13c(2)$Deoxy$Carbamidomethyl$AEC-MAEC$EDT-iodoacetyl-PEO-biotin$Deamidated$Oxidation$dimethyl_2h(6)$CarboxymethylDTT$Gly",
    "modified_positions": 22,
    "name": "Succinate dehydrogenase iron-sulfur subunit",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZY43",
    "length": 589,
    "modifications": "Delta:H(4)C(3)O(1)$neugc$Unknown:210$Dethiomethyl$Met->Hsl$clip_traq_4$Phospho$Deamidated$Sulfo$Pro->HAVA$Cation:Na$sulfo+amino$NA-OA-NO2$Deoxy$EDT-iodoacetyl-PEO-biotin$Iminobiotin$MesitylOxide$Gly$RNPXL$Carbamidomethyl$ISD_z+2_ion$Cation:Mg[II]$Biotin:Thermo-33033$Fluoro$Oxidation$Biotin:Thermo-33033-H$Myristoyl+Delta:H(-4)$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 52,
    "name": "Succinate dehydrogenase flavoprotein subunit",
    "unique_modifications": 28
  },
  {
    "id": "Q5ZY44",
    "length": 115,
    "modifications": "Deamidated",
    "modified_positions": 1,
    "name": "Succinate dehydrogenase hydrophobic membrane anchor subunit",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZY48",
    "length": 208,
    "modifications": "Trimethyl$Carbamidomethyl$AEBS$hexnac(3)$Oxidation$EDT-maleimide-PEO-biotin$Propyl$Gly",
    "modified_positions": 13,
    "name": "Type 4 adapter protein LvgA",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZY49",
    "length": 187,
    "modifications": "Dehydrated$Phosphopropargyl$HCysThiolactone$ethylamino$Oxidation$Delta:H(4)C(2)$Carboxy$Dimethyl$Ethyl$Glu->pyro-Glu",
    "modified_positions": 10,
    "name": "Aminoglycoside N (6')-acetyltransferase",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZY50",
    "length": 155,
    "modifications": "glucosylgalactosyl$Ethylphosphate$Carbamidomethyl$Cresylphosphate$O-Dimethylphosphate$Oxidation$hex(1)neuac(1)$Phosphoadenosine$hex(2)$CAMthiopropanoyl$Dioxidation$RNPXL",
    "modified_positions": 10,
    "name": "Acetyltransferase, GNAT family",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZY51",
    "length": 202,
    "modifications": "Unknown:210$Carbamidomethyl$EHD-diphenylpentanone$Cation:Fe[III]$Cys->Dha",
    "modified_positions": 7,
    "name": "Uridine kinase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZY54",
    "length": 282,
    "modifications": "Ammonium$hex(1)hexnac(2)dhex(2)$Oxidation$methyl_2h(3)$Glycerophospho",
    "modified_positions": 6,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZY61",
    "length": 256,
    "modifications": "Iodoacetanilide$Carbamidomethyl$Decanoyl$CarbamidomethylDTT$hexnac$Carbofuran$BITC$Oxidation$clip_traq_3$propionyl_13c(3)$Gly$Carboxymethyl",
    "modified_positions": 10,
    "name": "Acyl-[acyl-carrier-protein]--UDP-N-acetylglucosamine O-acyltransferase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZY62",
    "length": 150,
    "modifications": "Delta:H(2)C(2)$Oxidation$dhex(1)hex(3)$hex(4)",
    "modified_positions": 7,
    "name": "3-hydroxyacyl-[acyl-carrier-protein] dehydratase FabZ",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZY64",
    "length": 339,
    "modifications": "Carbamidomethyl$NHS-LC-Biotin$maleimide3$dichlorination$glucuronyl",
    "modified_positions": 6,
    "name": "UDP-3-O-(3-hydroxymyristoyl) glucosamine N-acyltransferase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZY65",
    "length": 166,
    "modifications": "Delta:H(4)C(5)O(1)$Delta:H(2)C(2)$clip_traq_3$Phospho$Carboxymethyl$Trimethyl$Deamidated$Propyl$Deoxy$Carbonyl$Delta:H(2)C(3)$Arg->Npo$EDT-maleimide-PEO-biotin$Dehydrated$Carbamidomethyl$Methyl$ethylamino$Oxidation$Delta:H(6)C(3)O(1)",
    "modified_positions": 22,
    "name": "Outer membrane protein OmpH",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZY70",
    "length": 423,
    "modifications": "Carbamyl$Pentylamine$Carbamidomethyl$hexnac$Deamidated$Gly-loss+Amide$acetyl_2h(3)$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 9,
    "name": "Phosphatidylcholine hydrolyzing phospholipase",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZY77",
    "length": 411,
    "modifications": "AFB1_Dialdehyde$Carbamidomethyl$Oxidation$neiaa$dhex(3)hex(1)hexnac(2)kdn(1)$Delta:H(6)C(3)O(1)",
    "modified_positions": 7,
    "name": "Argininosuccinate lyase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZY85",
    "length": 191,
    "modifications": "PEITC$Gly$Carbamidomethyl$Crotonyl",
    "modified_positions": 2,
    "name": "Cupin",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZY86",
    "length": 431,
    "modifications": "AEC-MAEC$Carboxymethyl$Cation:Ni[II]$Ethylphosphate$O-Dimethylphosphate$dhex(2)hex(3)$dhex$Delta:H(6)C(7)O(4)$galactosyl$Acetylhypusine$Propionyl$maleimide$Pyro-carbamidomethyl$Carboxy->Thiocarboxy$Carbamidomethyl$Unknown:306$Ethyl+Deamidated$dhex(1)hex(4)$hex$Oxidation$methyl_2h(3)$Delta:H(2)C(3)O(1)",
    "modified_positions": 24,
    "name": "Adenylosuccinate synthetase",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZY89",
    "length": 495,
    "modifications": "Nmethylmaleimide+water$methyl_2h(3)13c(1)$Dihydroxyimidazolidine$icpl_13c(6)2h(4)$Carbofuran$Carboxy$Glu$galactosyl$pentose$hex(1)hexnac(1)neuac(1)$benzylguanidine$hex(2)hexnac(1)me(1)$Carbamidomethyl$HN3_mustard$Hydroxycinnamyl$DMPO$GluGluGlu$Oxidation$Propiophenone$Dicarbamidomethyl",
    "modified_positions": 16,
    "name": "Ankyrin repeat-containing protein",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZY97",
    "length": 89,
    "modifications": "NHS-LC-Biotin$Oxidation",
    "modified_positions": 6,
    "name": "Sugar transport PTS system phosphocarrier HPr protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYA2",
    "length": 336,
    "modifications": "Delta:H(5)C(2)$Quinone$Carbamidomethyl$Diethylphosphothione$Biotin:Thermo-88310$LG-anhyropyrrole$FTC$ethylamino$Oxidation$clip_traq_4$methylol$Thiazolidine",
    "modified_positions": 18,
    "name": "Probable fructose-bisphosphate aldolase class 1",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZYA8",
    "length": 145,
    "modifications": "Carbamyl$Delta:H(4)C(2)O(-1)S(1)$Carbamidomethyl$Methylthio$Dioxidation$Nitro",
    "modified_positions": 6,
    "name": "3-dehydroquinate dehydratase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYA9",
    "length": 160,
    "modifications": "Carbamidomethyl$Cation:Li$Propionyl$DimethylamineGMBS$Oxidation$Biotin$pent(2)$Diethyl$Hydroxamic_acid",
    "modified_positions": 9,
    "name": "Biotin carboxyl carrier protein of acetyl-CoA carboxylase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYB1",
    "length": 289,
    "modifications": "Carbamidomethyl$O-Methylphosphate$Bromo$Gly$glucuronyl",
    "modified_positions": 7,
    "name": "Ribosomal protein L11 methyltransferase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYB2",
    "length": 529,
    "modifications": "MesitylOxide$Oxidation$hex(2)pent(2)me(1)$Carbamidomethyl",
    "modified_positions": 10,
    "name": "Bifunctional purine biosynthesis protein PurH",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZYB3",
    "length": 261,
    "modifications": "hex(6)phos(1)$Carbamidomethyl$Cresylphosphate$Diethylphosphate$hep",
    "modified_positions": 9,
    "name": "IcmH (DotU)",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYB5",
    "length": 418,
    "modifications": "O-Dimethylphosphate$Ethylphosphate$maleimide",
    "modified_positions": 3,
    "name": "TphA (ProP)",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYB9",
    "length": 194,
    "modifications": "Carbamidomethyl$phosphohexnac$Propionyl$Phosphopantetheine$BADGE",
    "modified_positions": 8,
    "name": "IcmC (DotE)",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYC0",
    "length": 269,
    "modifications": "Deoxy$Propionamide$Ser->LacticAcid$Ammonia-loss$DAET$Deamidated$Octanoyl$Oxidation$CAMthiopropanoyl$Decarboxylation$Gln->pyro-Glu",
    "modified_positions": 15,
    "name": "IcmG (DotF)",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZYC1",
    "length": 1048,
    "modifications": "hex(2)pent(2)$GG$AEC-MAEC$dhex(2)hex(1)hexnac(2)neugc(1)$Cation:Al[III]$BDMAPP$CAMthiopropanoyl$Unknown:234$Thiazolidine$Carboxymethyl$Trimethyl$HCysThiolactone$dimethyl_2h(6)13c(2)$FTC$CarbamidomethylDTT$hexnac$hex(3)hexnac(3)neugc(1)sulf(1)$Didehydro$Glu$Decarboxylation$Biotin:Thermo-21328$Deoxy$PEITC$thioacylPA$Carbonyl$Thiophospho$dhex(1)hex(1)hexnac(2)kdn(1)$GEE$Methylamine$NA-LNO2$Can-FP-biotin$Gly$Dehydrated$Carboxy->Thiocarboxy$Carbamidomethyl$acetyl_13c(2)$15N-oxobutanoic$Ethyl+Deamidated$Biotin:Thermo-88310$monomethylphosphothione$Methyl$dhex(1)hex(1)$icdid_2h(6)$Oxidation$dhex(1)hex(2)hexnac(1)neuac(2)$hex(4)hexnac(3)$hex$phosphoRibosyl$propyl_2h(6)$Glu->pyro-Glu",
    "modified_positions": 76,
    "name": "IcmE (DotG)",
    "unique_modifications": 50
  },
  {
    "id": "Q5ZYC3",
    "length": 212,
    "modifications": "Methyl$Deamidated$Oxidation$Delta:H(4)C(2)$clip_traq_4$Ethyl",
    "modified_positions": 9,
    "name": "IcmL (DotI)",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYC5",
    "length": 189,
    "modifications": "trimethyl_13c(3)2h(9)$Carbamidomethyl$LG-lactam-R$Arg->Npo",
    "modified_positions": 6,
    "name": "LphA (DotK)",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZYD0",
    "length": 114,
    "modifications": "gist-quat$Deoxy$Carbamidomethyl$Malonyl$Oxidation$Lysbiotinhydrazide$Delta:H(2)C(3)O(1)$PyruvicAcidIminyl",
    "modified_positions": 16,
    "name": "Type 4 adapter protein IcmS",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYD1",
    "length": 86,
    "modifications": "Methylamine$AzidoF$O-Et-N-diMePhospho",
    "modified_positions": 3,
    "name": "IcmT",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYD7",
    "length": 203,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$acetyl_13c(2)$Carbamidomethyl$hexnac(1)dhex(2)$Dethiomethyl$Met->Hsl$hexnac(2)dhex(1)$Oxidation$cGMP+RMP-loss$Unknown:216$Carboxy$Delta:H(2)C(3)O(1)",
    "modified_positions": 8,
    "name": "SAM-dependent methyltransferase",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZYD9",
    "length": 126,
    "modifications": "HN3_mustard$Oxidation$phosphohexnac$dhex(1)hex(1)hexnac(1)neugc(1)",
    "modified_positions": 4,
    "name": "HTH hxlR-type domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZYE3",
    "length": 450,
    "modifications": "dimethyl_2h(4)13c(2)$Unknown:248$Lys->MetOx$Methylamine$dimethyl_2h(6)$dhex(2)hex(1)hexnac(2)kdn(1)$Dimethyl",
    "modified_positions": 8,
    "name": "Outer membrane efflux protein",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZYE6",
    "length": 77,
    "modifications": "Ammonia-loss$Deamidated",
    "modified_positions": 1,
    "name": "Cold shock protein CspD",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYF3",
    "length": 335,
    "modifications": "Carbamidomethyl$MeMePhosphorothioate$Thiazolidine",
    "modified_positions": 4,
    "name": "Glucokinase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYF8",
    "length": 302,
    "modifications": "sulfo+amino$Iodoacetanilide$Carbamidomethyl$GG$HydroxymethylOP$Saligenin$Deamidated$Oxidation$QAT$MicrocinC7$Unknown:216$Menadione$pent(1)hexnac(1)$Dicarbamidomethyl$Delta:H(4)C(3)O(2)$Gluratylation",
    "modified_positions": 14,
    "name": "Probable alpha-L-glutamate ligase",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZYG3",
    "length": 242,
    "modifications": "Methamidophos-O$Oxidation$Delta:H(8)C(6)O(1)$DNCB_hapten",
    "modified_positions": 6,
    "name": "SURF1-like protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZYG5",
    "length": 147,
    "modifications": "Oxidation$Carbamidomethyl$SPITC",
    "modified_positions": 3,
    "name": "Phosphatase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYG6",
    "length": 113,
    "modifications": "Didehydro$Carbamidomethyl$Pro->HAVA$Delta:H(2)C(2)$hex(4)hexa(1)$CarbamidomethylDTT$Ammonia-loss$hexnac(1)neuac(1)$Oxidation$Pyro-carbamidomethyl$Biotin:Thermo-33033-H$hep$hexnac(1)neugc(1)$Glu->pyro-Glu$AzidoF$Gln->pyro-Glu",
    "modified_positions": 18,
    "name": "Carboxymuconolactone decarboxylase-like domain-containing protein",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZYG7",
    "length": 196,
    "modifications": "SulfanilicAcid:13C(6)$Carbamidomethyl$hydroxyisobutyryl$Oxidation$Met->Hpg$Thiophospho$Malonyl$Thiazolidine",
    "modified_positions": 7,
    "name": "Coiled-coil protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYH0",
    "length": 567,
    "modifications": "icpl$Methylphosphonate$Cytopiloyne$LG-anhydrolactam$Nethylmaleimide+water$Formyl$Dioxidation$hexnac(2)$HCysThiolactone$Tris$LRGG+methyl$Cation:Na$Arg->Npo$dhex(1)hex(1)hexnac(2)kdn(1)$hex(1)hexnac(1)neuac(1)neugc(1)$cGMP$Carbamidomethyl$Cation:Mg[II]$Ethanolyl$Oxidation$PET$hex(1)hexnac(1)neugc(2)",
    "modified_positions": 22,
    "name": "Putative ankyrin-repeat containing protein",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZYH2",
    "length": 458,
    "modifications": "EHD-diphenylpentanone$Nethylmaleimide+water$3-phosphoglyceryl$Phenylisocyanate$Thiazolidine$Delta:H(8)C(6)O(1)$deamidated_18o(1)$FTC$Deamidated$G-H1$murnac$tmab_2h(9)$Dimethyl$succinyl_2h(4)$Decarboxylation$TAMRA-FP$Deoxy$hex(2)pent(2)me(1)$Diethylphosphothione$gist-quat_2h(6)$Pyridylacetyl$Delta:H(4)C(2)$Carbamyl$Carboxy->Thiocarboxy$Methyl$Oxidation$Cation:Li$Thiophospho$Ethyl$Glu->pyro-Glu",
    "modified_positions": 37,
    "name": "Signal recognition particle protein",
    "unique_modifications": 30
  },
  {
    "id": "Q5ZYH3",
    "length": 86,
    "modifications": "Diethylphosphothione$Delta:H(2)C(2)$Triton$Oxidation$Crotonyl$Dansyl",
    "modified_positions": 6,
    "name": "Small ribosomal subunit protein bS16",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYH5",
    "length": 169,
    "modifications": "Oxidation$hexnac(1)neuac(1)",
    "modified_positions": 3,
    "name": "Ribosome maturation factor RimM",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYH6",
    "length": 250,
    "modifications": "clip_traq_3$Phosphoadenosine",
    "modified_positions": 2,
    "name": "tRNA (guanine-N(1)-)-methyltransferase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYH7",
    "length": 121,
    "modifications": "Dehydrated$15N-oxobutanoic$Carbamidomethyl$Oxidation$Gly",
    "modified_positions": 8,
    "name": "Large ribosomal subunit protein bL19",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYH8",
    "length": 151,
    "modifications": "hex(1)hexnac(2)sulf(1)$hex(4)$galactosyl$Carbamidomethyl$Quinone$pupylation$Oxidation$PET$BHT",
    "modified_positions": 10,
    "name": "Methylated DNA protein cysteine S-methyltransferase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYI0",
    "length": 235,
    "modifications": "Biotin:Thermo-21328$Carbamidomethyl$Oxidation$Cation:Li$Malonyl",
    "modified_positions": 6,
    "name": "Zinc metalloprotease",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYI4",
    "length": 304,
    "modifications": "dhex(1)hexnac(3)$Carbamidomethyl$Dap-DSP$Deamidated$Oxidation$benzylguanidine$UgiJoullieProGly$Gly$Thiazolidine",
    "modified_positions": 10,
    "name": "ABC transporter, ATP binding component",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYI6",
    "length": 339,
    "modifications": "serotonylation$Carbamidomethyl$Biotin:Thermo-21330$TNBS$Oxidation$acetyl_2h(3)",
    "modified_positions": 9,
    "name": "Heat shock protein HtpX",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYI7",
    "length": 193,
    "modifications": "Crotonaldehyde$gist-quat_2h(9)$Deamidated$BITC$4-ONE+Delta:H(-2)O(-1)$Oxidation$Butyryl$PyruvicAcidIminyl$2-nitrobenzyl",
    "modified_positions": 8,
    "name": "LemA protein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYJ1",
    "length": 157,
    "modifications": "hex(5)hexnac(2)phos(1)$icpl$Phosphoadenosine$Carbamidomethyl",
    "modified_positions": 5,
    "name": "DUF4442 domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZYJ3",
    "length": 484,
    "modifications": "bemad_st_2h(6)$Phosphopropargyl$Carbamidomethyl$Delta:H(2)C(2)$GG$Methyl$Oxidation$succinyl_2h(4)$Dicarbamidomethyl$TAMRA-FP",
    "modified_positions": 13,
    "name": "Ribosomal protein S6 modification protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZYJ7",
    "length": 199,
    "modifications": "HN3_mustard$UgiJoullieProGly$icpl_13c(6)2h(4)$Oxidation$Iminobiotin$dhex(1)hex(2)hexnac(3)",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYK0",
    "length": 114,
    "modifications": "Oxidation$Methylthio",
    "modified_positions": 2,
    "name": "Small protein A, tmRNA-binding",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYK2",
    "length": 144,
    "modifications": "glucosylgalactosyl$Carbamidomethyl$Unknown:306$Ethanolamine$Iodoacetanilide:13C(6)$GG$Deamidated$hex(1)hexnac(2)dhex(2)$Carbofuran$Oxidation$Carboxymethyl$Dicarbamidomethyl$Nitro$Gly$hex(2)$Delta:H(6)C(3)O(1)$Thrbiotinhydrazide",
    "modified_positions": 19,
    "name": "Oligoketide cyclase/lipid transporter protein",
    "unique_modifications": 17
  },
  {
    "id": "Q5ZYK6",
    "length": 277,
    "modifications": "Carbamidomethyl$dhex(1)hex(2)$Deamidated$EDT-maleimide-PEO-biotin$Nmethylmaleimide$UgiJoullieProGly$Succinyl",
    "modified_positions": 12,
    "name": "Diaminopimelate epimerase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZYL0",
    "length": 425,
    "modifications": "Sulfo$HNE$tmab_2h(9)$Cation:Fe[III]$icpl_2h(4)$EQIGG$neuac$GGQ$Met-loss+Acetyl$probiotinhydrazide$UgiJoullieProGly$Carbamidomethyl$dnic$Ethyl+Deamidated$ethylamino$O-Methylphosphate$Oxidation$Delta:H(10)C(8)O(1)$Malonyl",
    "modified_positions": 17,
    "name": "3-oxoacyl-(Acyl carrier protein) synthase II, N-terminal",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZYL1",
    "length": 430,
    "modifications": "deamidated_18o(1)$methyl_2h(2)$Biotin:Thermo-21360$Carbamidomethyl$15N-oxobutanoic$Delta:H(2)C(2)$Phosphopropargyl$Fluoro$Oxidation$Crotonyl$probiotinhydrazide$pent(1)hexnac(1)$MercaptoEthanol$RNPXL",
    "modified_positions": 17,
    "name": "3-oxoacyl-[acyl-carrier-protein] synthase 2",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZYL3",
    "length": 137,
    "modifications": "neugc$Diethylphosphothione$Carbamidomethyl$Lipoyl$CarbamidomethylDTT$Pyridylacetyl$Trioxidation$Oxidation$Biotin$GGQ$Gly",
    "modified_positions": 8,
    "name": "Acyl carrier protein",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZYL4",
    "length": 252,
    "modifications": "Carbamidomethyl$Cysteinyl$GG$MercaptoEthanol$Methamidophos-O$AccQTag$Menadione-HQ$methyl_2h(3)+acetyl_2h(3)$hex(1)hexnac(1)phos(1)$Oxidation$Menadione$UgiJoullieProGly$Carboxymethyl",
    "modified_positions": 18,
    "name": "Glucose-1-dehydrogenase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZYL7",
    "length": 127,
    "modifications": "Delta:H(4)C(3)O(1)$Gly$Carbamidomethyl$Biotin-PEG-PRA$exactagthiol$Propionyl$Amidine$SulfurDioxide$Sulfide$Oxidation$Trioxidation$Methylamine$Methyl+Deamidated$Dioxidation",
    "modified_positions": 10,
    "name": "Large ribosomal subunit protein bL17",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZYL8",
    "length": 330,
    "modifications": "Biotin-HPDP$phosphohex$Carbamyl$thioacylPA$Carbamidomethyl$Tris$gist-quat_2h(9)$Oxidation$Biotin$Unknown:216$clip_traq_4",
    "modified_positions": 15,
    "name": "DNA-directed RNA polymerase subunit alpha",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZYL9",
    "length": 206,
    "modifications": "Furan$Phospho$CarbamidomethylDTT$Sulfo$Arg->Orn$Deamidated$BITC$CarboxymethylDTT$Dansyl$FMNC$N-dimethylphosphate$hex(1)hexnac(1)neuac(2)$bemad_st_2h(6)$FMN$Carbamidomethyl$DimethylamineGMBS$3-deoxyglucosone$Oxidation$Biotin$acetyl_2h(3)",
    "modified_positions": 21,
    "name": "Small ribosomal subunit protein uS4",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZYM0",
    "length": 132,
    "modifications": "icpl_13c(6)$Carbamidomethyl$EQIGG$AEC-MAEC$Delta:H(2)C(5)$Deamidated$Delta:H(2)C(3)O(1)$Nitro$Carboxymethyl$Dimethylphosphothione",
    "modified_positions": 11,
    "name": "Small ribosomal subunit protein uS11",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZYM5",
    "length": 61,
    "modifications": "O-Methylphosphate$Deamidated",
    "modified_positions": 2,
    "name": "Large ribosomal subunit protein uL30",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYM8",
    "length": 179,
    "modifications": "Cytopiloyne$Lys->AminoadipicAcid$dhex(1)hex(2)hexnac(1)$Deamidated$3sulfo$Oxidation$dhex$dhex(1)hex(1)hexnac(1)neuac(1)$Gln->pyro-Glu",
    "modified_positions": 13,
    "name": "Large ribosomal subunit protein uL6",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYM9",
    "length": 131,
    "modifications": "Deoxy$dhex(2)hex(2)hexnac(2)neugc(1)$Carbamidomethyl$Deamidated$Oxidation$dhex(3)hex(3)hexnac(2)$Thiazolidine$Gln->pyro-Glu",
    "modified_positions": 11,
    "name": "Small ribosomal subunit protein uS8",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYN0",
    "length": 100,
    "modifications": "Carbamidomethyl$trimethyl_2h(9)$Dethiomethyl$Cys->Oxoalanine$Met->Hsl$Oxidation$Pro->Pyrrolidinone$GGQ$Biotin:Thermo-21345$Delta:H(2)C(3)O(1)$hexnac(2)",
    "modified_positions": 13,
    "name": "Small ribosomal subunit protein uS14",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZYN3",
    "length": 121,
    "modifications": "Delta:H(2)C(2)$PyridoxalPhosphateH2$icpl_13c(6)2h(4)$Oxidation$hex(2)hexnac(3)$hex(1)hexnac(2)",
    "modified_positions": 8,
    "name": "Large ribosomal subunit protein uL14",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYN4",
    "length": 84,
    "modifications": "bemad_st_2h(6)$Carbamidomethyl$Cys->Oxoalanine$SulfurDioxide$maleimide$Dioxidation",
    "modified_positions": 5,
    "name": "Small ribosomal subunit protein uS17",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYN5",
    "length": 64,
    "modifications": "SMA$Phosphopropargyl$Delta:H(2)C(2)$HCysThiolactone$FTC$3-deoxyglucosone$pupylation$Sulfo$DNCB_hapten$Oxidation$clip_traq_4$hex(2)",
    "modified_positions": 13,
    "name": "Large ribosomal subunit protein uL29",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZYN6",
    "length": 137,
    "modifications": "Carbamyl$Delta:H(2)C(2)$Trp->Hydroxykynurenin$Cresylphosphate$Oxidation$Malonyl$bisANS-sulfonates$Glu->pyro-Glu",
    "modified_positions": 17,
    "name": "Large ribosomal subunit protein uL16",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYP0",
    "length": 275,
    "modifications": "icpl$AEC-MAEC$Cys->Oxoalanine$Carboxymethyl$Thiazolidine$Ethanolamine$Deamidated$BITC$Carboxy$PEITC$hex(1)neuac(1)pent(1)$AEBS$AHA-Alkyne$PyridoxalPhosphate$Dehydrated$Carbamidomethyl$15N-oxobutanoic$Methamidophos-O$azole$Methyl$O-Methylphosphate$Oxidation",
    "modified_positions": 26,
    "name": "Large ribosomal subunit protein uL2",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZYP5",
    "length": 396,
    "modifications": "Ser->LacticAcid$Ammonia-loss$dhex(1)hex(1)hexnac(4)$hex(1)hexnac(2)$Formyl$Phenylisocyanate:2H(5)$gist-quat$Trimethyl$Methylpyrroline$UgiJoullieProGlyProGly$Ethanolamine$Ammonium$hexnac(2)sulf(1)$CarbamidomethylDTT$esp$Deamidated$Propyl$Pro->HAVA$CarboxymethylDTT$Carboxy$Cation:Na$Palmitoyl$Gln->pyro-Glu$Deoxy$methyl_2h(2)$dhex(2)hex(1)hexnac(3)$Trioxidation$N-dimethylphosphate$Methamidophos-S$Methylamine$Hydroxamic_acid$Gly$Cation:K$ZQG$Carbamyl$dimethyl_2h(4)13c(2)$Dehydrated$Carboxy->Thiocarboxy$acetyl_13c(2)$dnic$Carbamidomethyl$Methyl$Cation:Mg[II]$ethylamino$PET$Fluoro$Oxidation$Biotin$Cation:Li$Cation:Ca[II]$Glu->pyro-Glu",
    "modified_positions": 81,
    "name": "Elongation factor Tu",
    "unique_modifications": 51
  },
  {
    "id": "Q5ZYP7",
    "length": 175,
    "modifications": "SulfanilicAcid:13C(6)$Cation:Al[III]$Diethylphosphate$Formyl$Thiazolidine$Phosphopropargyl$Deamidated$Cation:Fe[III]$Cation:Na$PEITC$Carbonyl$Gly$Hydroxamic_acid$Cation:K$Dehydrated$Carbamidomethyl$Cation:Mg[II]$Fluoro$Oxidation$hep$Cation:Ca[II]$Glu->pyro-Glu",
    "modified_positions": 23,
    "name": "Small ribosomal subunit protein uS7",
    "unique_modifications": 22
  },
  {
    "id": "Q5ZYQ1",
    "length": 126,
    "modifications": "thioacylPA$Dehydrated$PEITC$HNE$hex(3)hexnac(6)$Glu->pyro-Glu",
    "modified_positions": 8,
    "name": "Large ribosomal subunit protein bL12",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYQ2",
    "length": 177,
    "modifications": "Oxidation$Methylthio$Deamidated",
    "modified_positions": 3,
    "name": "Large ribosomal subunit protein uL10",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYQ4",
    "length": 144,
    "modifications": "dhex(1)hexnac(3)$Carbamidomethyl$icpl_13c(6)2h(4)$LG-anhydrolactam$Oxidation$Delta:H(6)C(3)O(1)",
    "modified_positions": 6,
    "name": "Large ribosomal subunit protein uL11",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYR2",
    "length": 163,
    "modifications": "Carbamyl$Carbamidomethyl$C8-QAT$Oxidation$AHA-Alkyne$Crotonyl$Lysbiotinhydrazide$maleimide3$Thrbiotinhydrazide",
    "modified_positions": 12,
    "name": "Dihydrofolate reductase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYR3",
    "length": 429,
    "modifications": "TAMRA-FP$Quinone$Carbamidomethyl$Delta:H(2)C(3)$Iodoacetanilide:13C(6)$Propargylamine$hexnac$Deamidated$Tris$Oxidation$diart6plex$Delta:H(2)C(3)O(1)$diart6plex115$Hydroxamic_acid$diart6plex117",
    "modified_positions": 16,
    "name": "Chaperone SurA",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZYR4",
    "length": 839,
    "modifications": "bemad_st_2h(6)$HNE-Delta:H(2)O$Carbamidomethyl$Cytopiloyne$Deamidated$O-Methylphosphate$Oxidation$BDMAPP$BEMAD_ST$AzidoF",
    "modified_positions": 14,
    "name": "LPS-assembly protein LptD",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZYR6",
    "length": 220,
    "modifications": "LG-Hlactam-R$HNE+Delta:H(2)$Delta:H(2)C(2)$Oxidation$hex$CIGG",
    "modified_positions": 6,
    "name": "Mannose-1-phosphate guanyltransferase",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYR7",
    "length": 230,
    "modifications": "Deoxy$Phenylisocyanate:2H(5)$Carbamidomethyl$Delta:H(4)C(6)$CarbamidomethylDTT$hydroxyisobutyryl$Oxidation$BDMAPP$Methamidophos-S$hex(1)pent(2)me(1)$Malonyl$bisANS-sulfonates$Nitro",
    "modified_positions": 14,
    "name": "Type 4 apparatus protein DotY",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZYS1",
    "length": 401,
    "modifications": "NDA$LG-Hlactam-R$Dehydrated$Saligenin$monomethylphosphothione$esp$Arg->Npo$Oxidation$hex(1)hexnac(2)dhex(1)",
    "modified_positions": 10,
    "name": "Lipoprotein",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZYS4",
    "length": 189,
    "modifications": "Carbamidomethyl$GluGlu$Deamidated$Oxidation$dhex(1)hex(1)hexnac(1)kdn(1)",
    "modified_positions": 9,
    "name": "Elongation factor P",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYS8",
    "length": 403,
    "modifications": "Carbamidomethyl$Cytopiloyne$Chlorination$Trioxidation$GEE$Oxidation$pent(2)$MesitylOxide$BHTOH$Malonyl$propyl_2h(6)",
    "modified_positions": 21,
    "name": "Formate dehydrogenase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZYS9",
    "length": 258,
    "modifications": "Carboxyethyl$Carbamidomethyl$HCysThiolactone$Acetyl$Methyl$hex(3)hexnac(1)me(1)$Formyl$Cys->PyruvicAcid",
    "modified_positions": 9,
    "name": "Methyltransferase domain-containing protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYT4",
    "length": 740,
    "modifications": "biotinAcrolein298$LG-lactam-K$hex(1)pent(2)me(1)$CresylSaligeninPhosphate$methyl_2h(3)13c(1)$MG-H1$esp$pupylation$LG-lactam-R$Pro->HAVA$Cys->Dha$Cation:Na$Delta:H(4)C(3)$Deoxy$dhex(2)hex(3)hexnac(1)sulf(1)$pentose$Carbamidomethyl$Oxidation$Biotin$Delta:H(2)C(3)O(1)",
    "modified_positions": 26,
    "name": "Sensory box protein, GGDEF family protein, LssE",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZYT5",
    "length": 499,
    "modifications": "bemad_st_2h(6)$Carbamidomethyl$Saligenin$DAET$hexnac$Oxidation$N-dimethylphosphate$Delta:H(10)C(8)O(1)$Carboxyethylpyrrole$dhex$Menadione",
    "modified_positions": 12,
    "name": "Ras GEF",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZYT7",
    "length": 287,
    "modifications": "Cation:Fe[II]$Trimethyl$Carbamidomethyl$AccQTag$Deamidated$Oxidation$Menadione$Methyl+Deamidated$Cation:Ca[II]$AzidoF$Cation:K",
    "modified_positions": 10,
    "name": "Transcriptional regulator, LysR family",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZYU3",
    "length": 198,
    "modifications": "Diethylphosphothione$Carbamidomethyl$maleimide$Heme$Glu->pyro-Glu",
    "modified_positions": 4,
    "name": "5'-deoxynucleotidase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYU9",
    "length": 212,
    "modifications": "Carbamidomethyl$GG$Chlorination$Oxidation$neiaa$Phosphoadenosine$Dicarbamidomethyl",
    "modified_positions": 11,
    "name": "Type-4 uracil-DNA glycosylase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZYV3",
    "length": 647,
    "modifications": "Diisopropylphosphate$Carbamidomethyl$Pentylamine$Dethiomethyl$Met->Hsl$Oxidation$Nethylmaleimide+water$Unknown:216$Myristoyl+Delta:H(-4)$acetyl_2h(3)",
    "modified_positions": 10,
    "name": "Uncharacterized protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZYV4",
    "length": 330,
    "modifications": "dimethyl_2h(4)13c(2)$HNE-Delta:H(2)O$cGMP$PEITC$Carbonyl$PS_Hapten$Delta:H(2)C(2)$dhex(2)hex(1)hexnac(1)kdn(1)$Ammonia-loss$ethylsulfonylethyl$BMP-piperidinol$Oxidation$Delta:H(10)C(8)O(1)$dimethyl_2h(6)$Thiazolidine",
    "modified_positions": 14,
    "name": "Multidrug resistance secretion protein",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZYV6",
    "length": 448,
    "modifications": "Phosphopropargyl$Carbamidomethyl$azole$dhex(3)hex(2)hexnac(2)$AEC-MAEC$Oxidation$hex(1)neuac(1)$spermidine",
    "modified_positions": 8,
    "name": "Outer membrane channel protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZYW1",
    "length": 414,
    "modifications": "Deoxy$acetyl_13c(2)$Carbamidomethyl$Carbonyl$Ethanedithiol$NHS-LC-Biotin$Methyl$hex(3)hexnac(1)me(1)$Oxidation$Didehydro$Cation:Na$Gly",
    "modified_positions": 19,
    "name": "DEAD-box ATP-dependent RNA helicase RhpA",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZYW3",
    "length": 113,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Arsenate reductase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYW4",
    "length": 317,
    "modifications": "PEITC$Diisopropylphosphate$Carbamidomethyl$Unknown:210$Methylphosphonate$HCysThiolactone$Ethyl$Ethanolyl$Oxidation$clip_traq_3$Didehydro$Dimethyl$Delta:H(4)C(2)",
    "modified_positions": 12,
    "name": "Uncharacterized protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZYW8",
    "length": 199,
    "modifications": "Carbamidomethyl$dhex(1)hex(1)hexnac(3)neugc(1)$hex(2)hexnac(3)neugc(1)$Ammonia-loss$Deamidated$Oxidation$DNCB_hapten",
    "modified_positions": 9,
    "name": "Short chain dehydrogenase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZYW9",
    "length": 295,
    "modifications": "hex(1)hexa(1)$Carbonyl$Carbamidomethyl$Cresylphosphate$Methyl$Hydroxycinnamyl$GlycerylPE$Oxidation$Nethylmaleimide+water$dhex(1)hex(1)hexnac(2)neuac(1)$Didehydro",
    "modified_positions": 12,
    "name": "D-3-phosphoglycerate dehydrogenase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZYX4",
    "length": 264,
    "modifications": "CresylSaligeninPhosphate$dhex(1)hex(1)hexnac(1)neugc(1)$Ammonia-loss$Lys->MetOx$NBS:13C(6)$Gln->pyro-Glu",
    "modified_positions": 7,
    "name": "Lipolytic enzyme",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYY4",
    "length": 368,
    "modifications": "Dehydrated$Trimethyl$Deamidated$Oxidation$Methylamine$Propyl$hex(2)hexnac(2)",
    "modified_positions": 10,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZYY6",
    "length": 328,
    "modifications": "ZGB$Delta:H(-4)O(3)$hexnac$Oxidation$hex",
    "modified_positions": 8,
    "name": "RND efflux membrane fusion protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZYY9",
    "length": 506,
    "modifications": "pyrophospho$Isopropylphospho",
    "modified_positions": 3,
    "name": "NADH dehydrogenase subunit 5",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYZ3",
    "length": 166,
    "modifications": "Biotin-PEO-Amine$Oxidation$Pro->Pyrrolidone",
    "modified_positions": 4,
    "name": "N5-carboxyaminoimidazole ribonucleotide mutase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYZ4",
    "length": 359,
    "modifications": "Ethanolyl$Deamidated",
    "modified_positions": 2,
    "name": "N5-carboxyaminoimidazole ribonucleotide synthase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYZ6",
    "length": 294,
    "modifications": "NIPCAM$Carbamidomethyl$Ethanolamine$Acetyl$Ammonia-loss$Isopropylphospho$IodoU-AMP$Oxidation$Propyl$phosphoRibosyl$HN2_mustard$Decarboxylation",
    "modified_positions": 14,
    "name": "Transcriptional regulator, LysR family",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZZ05",
    "length": 137,
    "modifications": "Oxidation",
    "modified_positions": 2,
    "name": "Membrane protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZ06",
    "length": 512,
    "modifications": "Label:2H(4)+GG$NDA$Carbamidomethyl$dhex(1)hex(2)$Oxidation$hex(3)$Methamidophos-S$hep$PyruvicAcidIminyl$Decarboxylation",
    "modified_positions": 12,
    "name": "Cryptochrome/photolyase family protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZZ07",
    "length": 232,
    "modifications": "Deamidated$Pro->Pyrrolidinone$Carbamidomethyl$Isopropylphospho",
    "modified_positions": 6,
    "name": "2-deoxy-D-gluconate-3-dehydrogenase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZ08",
    "length": 595,
    "modifications": "Carbamidomethyl$Acetylhypusine$Methylphosphonate$Cation:Mg[II]$Oxidation$Nmethylmaleimide$Bromo$CAMthiopropanoyl",
    "modified_positions": 10,
    "name": "DhaL domain-containing protein",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZZ11",
    "length": 329,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Cytochrome D ubiquinol oxidase subunit II, cyanide insensitive",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZ15",
    "length": 424,
    "modifications": "CresylSaligeninPhosphate$glucosylgalactosyl$Quinone$TMPP-Ac:13C(9)$ISD_z+2_ion$Carbamidomethyl$dhex(2)hex(4)hexnac(3)neuac(1)sulf(1)$Oxidation$O-pinacolylmethylphosphonate$Met->Aha$hex$Unknown:234$hexnac(2)",
    "modified_positions": 14,
    "name": "Coiled-coil protein",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZZ17",
    "length": 749,
    "modifications": "Biotin-PEO-Amine$Delta:H(4)C(3)O(1)$Unknown:210$hex(1)pent(3)me(1)$Pro->Pyrrolidone$Carboxymethyl$Lys->CamCys$Trimethyl$Dihydroxyimidazolidine$Deamidated$Propyl$hex(2)$Carboxyethyl$Met->AspSA$Hydroxymethyl$hep$hex$Oxidation$methylol",
    "modified_positions": 27,
    "name": "Catalase-peroxidase 2",
    "unique_modifications": 19
  },
  {
    "id": "Q5ZZ26",
    "length": 246,
    "modifications": "IED-Biotin$Dehydrated$Diethylphosphothione$Carbamidomethyl$Ethanolamine$betaFNA$hex(1)hexnac(1)dhex(1)me(1)$Glu->pyro-Glu+Methyl$NO_SMX_SEMD$maleimide$Oxidation$Methylamine$Met-loss+Acetyl$DNCB_hapten$no_smx_smct$Thiazolidine",
    "modified_positions": 14,
    "name": "ABC sugar transporter, ATP binding protein",
    "unique_modifications": 16
  },
  {
    "id": "Q5ZZ27",
    "length": 294,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$TMPP-Ac:13C(9)$Delta:H(2)C(3)$Carbamidomethyl$HCysThiolactone$Carboxy$neuac$Methamidophos-S$Biotin:Thermo-21345$Dansyl",
    "modified_positions": 12,
    "name": "ABC sugar transporter, periplasmic sugar binding protein",
    "unique_modifications": 10
  },
  {
    "id": "Q5ZZ29",
    "length": 150,
    "modifications": "Oxidation$thioacylPA$Methylamine",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZ30",
    "length": 303,
    "modifications": "Oxidation$Carbamidomethyl",
    "modified_positions": 4,
    "name": "NAD(+)--arginine ADP-ribosyltransferase Lart1",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZ31",
    "length": 280,
    "modifications": "Phosphopropargyl$Cytopiloyne$Delta:H(-4)O(3)$HN3_mustard$Trioxidation$Oxidation$Dioxidation",
    "modified_positions": 10,
    "name": "Protease HtpX",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZZ35",
    "length": 480,
    "modifications": "Carbamidomethyl$DMPO$Oxidation$hex(1)hexnac(1)dhex(1)$LG-lactam-K$dileu4plex115$Decarboxylation",
    "modified_positions": 8,
    "name": "FAD monooxygenase, PheA/TfdB family",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZZ38",
    "length": 286,
    "modifications": "Carbamidomethyl$Methamidophos-O$neiaa_2h(5)$NHS-fluorescein$N-dimethylphosphate",
    "modified_positions": 4,
    "name": "Transcriptional regulator, LysR",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZZ39",
    "length": 241,
    "modifications": "AFB1_Dialdehyde$Oxidation$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZ44",
    "length": 136,
    "modifications": "Carbamidomethyl$GG$icdid_2h(6)$Oxidation$BITC$spermidine$Dicarbamidomethyl",
    "modified_positions": 6,
    "name": "Peptide chain release factor",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZZ45",
    "length": 294,
    "modifications": "TMPP-Ac",
    "modified_positions": 1,
    "name": "DUF808 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZ50",
    "length": 153,
    "modifications": "HexN$Carbamidomethyl$hexnac$Oxidation$tmab_2h(9)$Phospho",
    "modified_positions": 10,
    "name": "Secondary thiamine-phosphate synthase enzyme",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZZ51",
    "length": 325,
    "modifications": "NDA$CresylSaligeninPhosphate$Diphthamide$Unknown:162$neugc$Carbamidomethyl$Unknown:306$UgiJoullieProGlyProGly$HN3_mustard$2-dimethylsuccinyl$Fluoro$Oxidation$MesitylOxide$BHT$Decarboxylation",
    "modified_positions": 15,
    "name": "Uncharacterized protein",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZZ53",
    "length": 70,
    "modifications": "Carbamyl$diart6plex117$Cytopiloyne+water$Carbofuran$Oxidation$Met-loss+Acetyl$diart6plex$diart6plex115$diart6plex118$diart6plex116/119$hexnac(2)",
    "modified_positions": 10,
    "name": "ParD-like antitoxin of type II toxin-antitoxin system",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZZ59",
    "length": 171,
    "modifications": "Ethanolamine$Amino$methylol",
    "modified_positions": 3,
    "name": "N-acetyltransferase domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZ62",
    "length": 446,
    "modifications": "LG-Hlactam-R$Carbamyl$bemad_st_2h(6)$Carbamidomethyl$Methylthio$Cresylphosphate$hexnac$Oxidation$hex(3)$AMTzHexNAc2$dhex$Formyl$hex(2)$Delta:Hg(1)",
    "modified_positions": 15,
    "name": "Uncharacterized protein",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZZ74",
    "length": 396,
    "modifications": "hex(1)hexa(1)$Methylphosphonate$Unknown:216$Trimethyl$Phosphopropargyl$Ammonium$Carbofuran$Propyl$Decarboxylation$Deoxy$Iminobiotin$Phosphopantetheine$hep$Carbamidomethyl$monomethylphosphothione$Cation:Cu[I]$O-Methylphosphate$Oxidation$methyl_2h(3)$hex",
    "modified_positions": 27,
    "name": "Phosphoglycerate kinase",
    "unique_modifications": 20
  },
  {
    "id": "Q5ZZ75",
    "length": 474,
    "modifications": "Propionamide$Carbamidomethyl$Propionyl$Carboxy$Oxidation$Met->Hse$Didehydro$Diethyl$Cation:Ni[II]",
    "modified_positions": 9,
    "name": "Pyruvate kinase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZZ78",
    "length": 230,
    "modifications": "Carbamidomethyl$Saligenin$Oxidation$Carboxyethylpyrrole$RNPXL",
    "modified_positions": 4,
    "name": "Activator of ProP osmoprotectant transporter",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZZ80",
    "length": 243,
    "modifications": "hex(3)hexnac(1)pent(1)$deamidated_18o(1)$Deoxy$Ser->LacticAcid$Carbamidomethyl$Cresylphosphate$Ethyl$Dimethyl$Oxidation$Delta:H(4)C(2)$pent(1)hexnac(1)$hep$Unknown:234",
    "modified_positions": 15,
    "name": "4-hydroxy-tetrahydrodipicolinate reductase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZZ87",
    "length": 200,
    "modifications": "Dehydrated$Carbamidomethyl$Diethylphosphothione$DTT$Fluoro$Oxidation$Met->Hse$qat_2h(3)$Decarboxylation",
    "modified_positions": 15,
    "name": "Cytochrome c4",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZZ89",
    "length": 432,
    "modifications": "Carbamyl$hex(1)hexnac(1)dhex(1)me(1)$Dap-DSP$Cation:Mg[II]$Propargylamine$Deamidated$Biotin:Thermo-33033-H$Oxidation$Methylamine$QEQTGG$O-Isopropylmethylphosphonate$AHA-SS_CAM",
    "modified_positions": 16,
    "name": "ABC transporter, ATP binding protein",
    "unique_modifications": 12
  },
  {
    "id": "Q5ZZ91",
    "length": 176,
    "modifications": "Hydroxamic_acid$Methyl$Gly$Carbamidomethyl",
    "modified_positions": 5,
    "name": "IcmL-like",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZ93",
    "length": 360,
    "modifications": "Dehydrated$Carbamidomethyl$His+O(2)$GG$DMPO$Cation:Mg[II]$Deamidated$maleimide$Oxidation$Met->AspSA$Glu->pyro-Glu",
    "modified_positions": 18,
    "name": "Aminomethyltransferase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZZ96",
    "length": 102,
    "modifications": "Delta:H(2)C(3)O(1)$Oxidation$dileu4plex115$Haloxon",
    "modified_positions": 4,
    "name": "YCII-related domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZ97",
    "length": 484,
    "modifications": "Biotin-PEO-Amine$Ub-VME$Methylphosphonate$phenylsulfonylethyl$Formyl$Carboxymethyl$UgiJoullieProGlyProGly$NHS-LC-Biotin$Deamidated$hex(1)hexnac(1)neuac(2)ac(2)$Deoxy$Acetylhypusine$AEBS$hex(1)neuac(1)pent(1)$AccQTag$Menadione$Gly$BHT$Carbamidomethyl$3-deoxyglucosone$Oxidation$QAT$gist-quat_2h(3)",
    "modified_positions": 30,
    "name": "Probable glycine dehydrogenase (decarboxylating) subunit 2",
    "unique_modifications": 23
  },
  {
    "id": "Q5ZZ98",
    "length": 414,
    "modifications": "Carbamyl$Oxidation",
    "modified_positions": 4,
    "name": "HDOD domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZA1",
    "length": 600,
    "modifications": "icpl_13c(6)$Hydroxamic_acid$Unknown:210$Carbamidomethyl$trimethyl_13c(3)2h(9)$Amino$dhex(1)hex(2)hexa(1)hexnac(2)$Oxidation$Methyl+Deamidated$glycosyl$Carboxymethyl$Acetyldeoxyhypusine$diart6plex118$NBS:13C(6)$Pentylamine",
    "modified_positions": 19,
    "name": "2-oxoacid dehydrogenase acyltransferase catalytic domain-containing protein",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZZA2",
    "length": 89,
    "modifications": "Carbamidomethyl$Didehydro",
    "modified_positions": 2,
    "name": "Transcriptional regulator",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZA6",
    "length": 198,
    "modifications": "Carbamidomethyl$hexnac(1)kdn(2)$Oxidation$hex(3)hexnac(1)me(1)$Cation:K",
    "modified_positions": 5,
    "name": "Cytochrome oxidase-like",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZZA7",
    "length": 191,
    "modifications": "Decanoyl$HexN",
    "modified_positions": 2,
    "name": "Peptide methionine sulfoxide reductase MsrA",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZB0",
    "length": 260,
    "modifications": "Deamidated$Oxidation$imid_2h(4)$Iminobiotin$Methyl+Deamidated$Biotin:Thermo-21345",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZZC4",
    "length": 196,
    "modifications": "Delta:H(4)C(3)O(1)$Trimethyl$Carbamidomethyl$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 3,
    "name": "DUF4254 domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZC7",
    "length": 507,
    "modifications": "Deoxyhypusine$Delta:H(2)C(2)$Methyl$Ammonia-loss$Deamidated$Pro->Pyrrolidinone$Gln->pyro-Glu",
    "modified_positions": 7,
    "name": "Membrane-associated HD superfamily hydrolase",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZZD1",
    "length": 255,
    "modifications": "Myristoyl+Delta:H(-4)$GGQ$Unknown:306",
    "modified_positions": 6,
    "name": "Dot/Icm T4SS effector",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZD3",
    "length": 400,
    "modifications": "NDA$Carbamidomethyl$GG$Ethyl+Deamidated$Methamidophos-O$Cytopiloyne$DAET$Arg->Npo$PyridoxalPhosphateH2$neuac$Oxidation$Dicarbamidomethyl$PET$hex(1)hexnac(2)pent(1)",
    "modified_positions": 20,
    "name": "2-octaprenyl-6-methoxyphenol hydroxylase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZZD5",
    "length": 193,
    "modifications": "Arg->GluSA$Octanoyl$Oxidation$Label:13C(1)2H(3)+Oxidation",
    "modified_positions": 6,
    "name": "YecA family protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZD7",
    "length": 523,
    "modifications": "Trimethyl$Carbamidomethyl$Dehydro$Trp->Hydroxykynurenin$Ammonia-loss$hexnac(1)dhex(1)$Deamidated$Puromycin$Oxidation$cGMP+RMP-loss$Guanidinyl$Pyro-carbamidomethyl$hexnac(1)neugc(1)$Gln->pyro-Glu",
    "modified_positions": 21,
    "name": "Glutamate synthase",
    "unique_modifications": 14
  },
  {
    "id": "Q5ZZE1",
    "length": 392,
    "modifications": "Carbamidomethyl$azole$Methyl$Deamidated$neuac$Sulfide$Oxidation$Trioxidation$murnac$Methyl+Deamidated$Dioxidation",
    "modified_positions": 13,
    "name": "Aminotransferase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZZE7",
    "length": 395,
    "modifications": "Ser->LacticAcid$Carbamidomethyl$dileu4plex118$Oxidation$Tween20$Menadione$Dimethyl$dileu4plex115$Ethyl",
    "modified_positions": 9,
    "name": "Phospho-2-dehydro-3-deoxyheptonate aldolase",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZZE9",
    "length": 392,
    "modifications": "O-Dimethylphosphate$dhex(2)hex(3)hexnac(1)sulf(1)$Ethylphosphate$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Multidrug resistance protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZF2",
    "length": 247,
    "modifications": "GluGlu",
    "modified_positions": 1,
    "name": "Methylamine utilization protein MauE",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZF7",
    "length": 244,
    "modifications": "Ethylphosphate$Acetyl$O-Dimethylphosphate$Oxidation$MicrocinC7$methyl_2h(3)$Methylthio",
    "modified_positions": 8,
    "name": "Transferase enzyme",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZZF8",
    "length": 297,
    "modifications": "Diisopropylphosphate$Methylpyrroline$Carbamidomethyl$hex(1)pent(3)me(1)$Palmitoleyl$Ethanolyl$Delta:H(2)C(5)$Oxidation$Biotin-phenacyl$Formylasparagine$murnac$neiaa$Ethyl",
    "modified_positions": 17,
    "name": "2-methylisocitrate lyase",
    "unique_modifications": 13
  },
  {
    "id": "Q5ZZG2",
    "length": 292,
    "modifications": "phosphohex$Trimethyl$Ammonia-loss$Oxidation$Gln->pyro-Glu",
    "modified_positions": 7,
    "name": "Acetyltransferase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZZG8",
    "length": 233,
    "modifications": "Carbonyl$Cation:Ca[II]$Amidine",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZH4",
    "length": 240,
    "modifications": "serotonylation$Oxidation$Cation:Ca[II]$propionyl_13c(3)$Cation:K",
    "modified_positions": 6,
    "name": "DUF2490 domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZZH5",
    "length": 118,
    "modifications": "dimethyl_2h(4)13c(2)$Ammonia-loss$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZH8",
    "length": 397,
    "modifications": "Trimethyl$Carbamidomethyl$neiaa_2h(5)$Ammonium$hexnac(1)dhex(1)$Oxidation$hex(2)hexnac(1)$BITC$dimethyl_2h(6)$hex(2)$Ahx2+Hsl",
    "modified_positions": 15,
    "name": "Leucine aminopeptidase",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZZI4",
    "length": 463,
    "modifications": "clip_traq_2$Thrbiotinhydrazide",
    "modified_positions": 2,
    "name": "Amino acid permease",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZI5",
    "length": 190,
    "modifications": "Decarboxylation$Crotonyl$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Lipid A acyltransferase PagP",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZI6",
    "length": 141,
    "modifications": "deamidated_18o(1)$Deoxy$Carbamidomethyl$Delta:H(4)C(6)$Oxidation$Met->Hse$acetyl_2h(3)",
    "modified_positions": 9,
    "name": "Hemin binding protein Hbp",
    "unique_modifications": 7
  },
  {
    "id": "Q5ZZJ2",
    "length": 461,
    "modifications": "Ethanolyl$BisANS$Oxidation$Biotin$Glu",
    "modified_positions": 8,
    "name": "Outer membrane efflux protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZZK1",
    "length": 85,
    "modifications": "Fluoro$Triton$Oxidation$Deamidated",
    "modified_positions": 6,
    "name": "RNA-binding protein Hfq",
    "unique_modifications": 4
  },
  {
    "id": "Q6BBR7",
    "length": 160,
    "modifications": "Oxidation$Methylthio$propyl_2h(6)$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Uncharacterized protein orf 160",
    "unique_modifications": 4
  },
  {
    "id": "Q7WTV4",
    "length": 455,
    "modifications": "icpl$Phosphopropargyl$pupylation$Amidine$hex(1)hexnac(2)neugc(1)$BITC$hex(2)hexnac(2)dhex(1)$icpl_2h(4)$nic$thioacylPA$Saligenin$Cresylphosphate$Pyridylacetyl$OxProBiotinRed$methylsulfonylethyl$Iminobiotin$hex(1)hexnac(2)sulf(1)$Iodoacetanilide$Carbamidomethyl$Haloxon$dnic$Oxidation$hep",
    "modified_positions": 23,
    "name": "histidine kinase",
    "unique_modifications": 23
  },
  {
    "id": "Q8RNM5",
    "length": 469,
    "modifications": "Lys->CamCys$Unknown:306$Acetylhypusine$Carbamidomethyl$Chlorination$Sulfide$Pro->Pyrrolidinone$Oxidation$Myristoleyl$methyl_2h(3)$Pro->Pyrrolidone$hex(1)hexnac(1)$Methylthio",
    "modified_positions": 21,
    "name": "Zn metalloprotein",
    "unique_modifications": 13
  },
  {
    "id": "Q9S4T0",
    "length": 416,
    "modifications": "Carbamidomethyl$Sulfo-NHS-LC-LC-Biotin$clip_traq_3$LG-pyrrole$Decarboxylation",
    "modified_positions": 6,
    "name": "Homogentisate 1,2-dioxygenase",
    "unique_modifications": 5
  },
  {
    "id": "Q9S4T1",
    "length": 341,
    "modifications": "SulfanilicAcid:13C(6)$CresylSaligeninPhosphate$methyl_2h(2)$galactosyl$hex(1)hexa(1)$QQQTGG$Dap-DSP$Methyl$G-H1$Oxidation$Methylamine$glucuronyl$hex$Thiazolidine$Glu$Decarboxylation",
    "modified_positions": 25,
    "name": "RNA polymerase sigma factor RpoS",
    "unique_modifications": 16
  },
  {
    "id": "A0A128R885",
    "length": 94,
    "modifications": "Oxidation$hex(3)hexnac(3)$Methylamine$Carbamidomethyl",
    "modified_positions": 4,
    "name": "DUF3579 domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "A0A222P2Y9",
    "length": 67,
    "modifications": "Dioxidation",
    "modified_positions": 1,
    "name": "Prophage CP4-57 regulatory protein (AlpA)",
    "unique_modifications": 1
  },
  {
    "id": "A0A222P2Z3",
    "length": 136,
    "modifications": "GG$Gly$Dicarbamidomethyl$Carbamidomethyl",
    "modified_positions": 2,
    "name": "F0F1 ATP synthase subunit epsilon",
    "unique_modifications": 4
  },
  {
    "id": "A0A2S6F0M8",
    "length": 63,
    "modifications": "Phenylisocyanate$Crotonaldehyde$Pyridylacetyl",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "A0AAN5PF74",
    "length": 89,
    "modifications": "Oxidation$HN2_mustard",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "A0AAN5PFZ7",
    "length": 164,
    "modifications": "MercaptoEthanol$Oxidation",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "A0AAN5PH17",
    "length": 305,
    "modifications": "AEBS$HCysThiolactone$Nitrene$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Class II glutamine amidotransferase",
    "unique_modifications": 4
  },
  {
    "id": "A0AAN5T2B5",
    "length": 65,
    "modifications": "sulfanilicacid",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "A0AAX2IXW3",
    "length": 56,
    "modifications": "Oxidation$Carbamidomethyl",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5WSQ5",
    "length": 61,
    "modifications": "CAMthiopropanoyl$Oxidation",
    "modified_positions": 2,
    "name": "Sec-independent protein translocase protein TatA",
    "unique_modifications": 2
  },
  {
    "id": "Q5WVL4",
    "length": 55,
    "modifications": "Oxidation",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5WYX7",
    "length": 201,
    "modifications": "Phosphopropargyl",
    "modified_positions": 2,
    "name": "Nucleoside transporter/FeoB GTPase Gate domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5WZ86",
    "length": 132,
    "modifications": "Oxidation$Deamidated",
    "modified_positions": 2,
    "name": "Type IV secretion protein IcmD",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZR80",
    "length": 81,
    "modifications": "Oxidation$Sulfo$Phospho",
    "modified_positions": 2,
    "name": "Putative membrane protein insertion efficiency factor",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZR81",
    "length": 556,
    "modifications": "SulfanilicAcid:13C(6)$HexN$ethylamino$Oxidation$3-phosphoglyceryl$MesitylOxide$PET$Thiophospho$DimethylpyrroleAdduct",
    "modified_positions": 10,
    "name": "Membrane protein insertase YidC",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZR89",
    "length": 118,
    "modifications": "Methamidophos-O$ethylamino$Oxidation$hexnac",
    "modified_positions": 4,
    "name": "UPF0102 protein lpg2994",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZRL2",
    "length": 256,
    "modifications": "Nitrosyl",
    "modified_positions": 1,
    "name": "Phosphatidylglycerol--prolipoprotein diacylglyceryl transferase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZRN0",
    "length": 71,
    "modifications": "Unknown:162$Deamidated",
    "modified_positions": 3,
    "name": "Cold shock transcriptional regulator CspA",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZS59",
    "length": 220,
    "modifications": "Carbamyl",
    "modified_positions": 1,
    "name": "Transmembrane protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZS61",
    "length": 75,
    "modifications": "CarboxymethylDTT$Propiophenone$Oxidation$Carbamidomethyl",
    "modified_positions": 6,
    "name": "Ferrous iron transporter A",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSB7",
    "length": 140,
    "modifications": "Cation:Fe[II]$Dioxidation",
    "modified_positions": 2,
    "name": "Conserved domain protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSE0",
    "length": 137,
    "modifications": "dhex(1)hex(3)hexnac(2)$Oxidation$Carbamidomethyl$Cys->SecNEM:2H(5)",
    "modified_positions": 7,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZSE7",
    "length": 186,
    "modifications": "Dehydrated",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSJ6",
    "length": 59,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "UPF0391 membrane protein lpg2521",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZSL0",
    "length": 231,
    "modifications": "icpl$Crotonyl$Carbamidomethyl",
    "modified_positions": 3,
    "name": "Pyrroloquinoline quinone (Coenzyme PQQ) biosynthesis protein C",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZSL4",
    "length": 106,
    "modifications": "AROD$Carbamidomethyl",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSN7",
    "length": 270,
    "modifications": "CAMthiopropanoyl$Ethylphosphate",
    "modified_positions": 2,
    "name": "Cellobiose phosphorylase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZSP9",
    "length": 261,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Sulfhydrogenase delta subunit",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZST4",
    "length": 219,
    "modifications": "Piperidine$Tris",
    "modified_positions": 2,
    "name": "Alkaline phosphatase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZT11",
    "length": 375,
    "modifications": "Carbamidomethyl$Phosphopropargyl$AEC-MAEC$Oxidation$Bromo$hex(2)$Methyl+Deamidated$Unknown:234$Cation:Ni[II]",
    "modified_positions": 12,
    "name": "Heme chaperone HemW",
    "unique_modifications": 9
  },
  {
    "id": "Q5ZT31",
    "length": 92,
    "modifications": "Methyl$Deoxy$Dimethylphosphothione",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZT36",
    "length": 76,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Exodeoxyribonuclease 7 small subunit",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTA9",
    "length": 262,
    "modifications": "GG$Cytopiloyne+water$Difuran$Dicarbamidomethyl$Gluratylation",
    "modified_positions": 3,
    "name": "Putative DNA-binding domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTC4",
    "length": 128,
    "modifications": "Delta:H(6)C(7)O(4)$Carbamidomethyl$hex(2)hexnac(2)neugc(1)$Oxidation$Dioxidation",
    "modified_positions": 6,
    "name": "Transmembrane protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZTD4",
    "length": 353,
    "modifications": "Cresylphosphate$Delta:H(2)C(3)$dhex",
    "modified_positions": 4,
    "name": "3-oxoacyl-(Acyl carrier protein) synthase III",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZTQ3",
    "length": 97,
    "modifications": "BITC$Diisopropylphosphate$Carbamidomethyl$Nitro",
    "modified_positions": 4,
    "name": "DUF2282 domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZTZ0",
    "length": 93,
    "modifications": "Oxidation$dhex(1)hex(4)hexnac(3)",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUA3",
    "length": 300,
    "modifications": "Oxidation$neugc",
    "modified_positions": 5,
    "name": "Integral membrane protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZUA5",
    "length": 108,
    "modifications": "Carbonyl$Oxidation$Myristoleyl$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUC0",
    "length": 117,
    "modifications": "hex(3)hexnac(1)",
    "modified_positions": 1,
    "name": "Apolipoprotein A1/A4/E domain",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZUF4",
    "length": 145,
    "modifications": "Carbamyl$Oxidation$Methamidophos-S$PhosphoCytidine",
    "modified_positions": 5,
    "name": "D-aminoacyl-tRNA deacylase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZUR2",
    "length": 292,
    "modifications": "hex(1)hexa(1)hexnac(2)",
    "modified_positions": 1,
    "name": "sn-glycerol-3-phosphate transport system permease protein UgpA",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZUR5",
    "length": 305,
    "modifications": "Menadione",
    "modified_positions": 2,
    "name": "DUF1189 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZUT2",
    "length": 121,
    "modifications": "Dehydro$Carbamidomethyl$ub-amide$Iodoacetanilide:13C(6)$Glu->pyro-Glu+Methyl:2H(2)13C(1)",
    "modified_positions": 6,
    "name": "Cytochrome c domain-containing protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUV6",
    "length": 105,
    "modifications": "Carbamidomethyl$azole$Chlorination$LG-anhydrolactam$propyl_2h(6)",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZUX2",
    "length": 296,
    "modifications": "Butyryl$Crotonaldehyde$Carbamidomethyl",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZUY1",
    "length": 372,
    "modifications": "Ethyl$Dimethyl$Delta:H(4)C(2)",
    "modified_positions": 3,
    "name": "Heparan-alpha-glucosaminide N-acetyltransferase catalytic domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZV56",
    "length": 255,
    "modifications": "hex$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Phosphatidylcholine synthase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZV88",
    "length": 242,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "UDP-2,3-diacylglucosamine hydrolase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVB3",
    "length": 151,
    "modifications": "Oxidation$Dioxidation$Deamidated",
    "modified_positions": 3,
    "name": "Transmembrane protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZVL3",
    "length": 259,
    "modifications": "Cation:Ca[II]$Phospho",
    "modified_positions": 2,
    "name": "Short chain dehydrogenase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVP2",
    "length": 332,
    "modifications": "Arg->GluSA$Ethanedithiol$hex(2)hexnac(1)$methylsulfonylethyl",
    "modified_positions": 5,
    "name": "Endolytic murein transglycosylase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZVQ0",
    "length": 142,
    "modifications": "Tyr->Dha$Carbamidomethyl",
    "modified_positions": 2,
    "name": "Metal-binding protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVS8",
    "length": 140,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Type II secretion system core protein G",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVT1",
    "length": 205,
    "modifications": "DMPO$Dehydrated",
    "modified_positions": 2,
    "name": "Type II secretion system protein J",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZVX9",
    "length": 104,
    "modifications": "Phosphopropargyl$HN3_mustard$Methyl+Deamidated$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZW78",
    "length": 262,
    "modifications": "Carboxy->Thiocarboxy$Oxidation$hex(4)hexnac(3)$Tyr->Dha$Cyano",
    "modified_positions": 9,
    "name": "PhzF family phenazine biosynthesis protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZW80",
    "length": 151,
    "modifications": "Ethyl$Dimethyl$Delta:H(4)C(2)",
    "modified_positions": 2,
    "name": "YbaK/aminoacyl-tRNA synthetase-associated domain-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWE8",
    "length": 322,
    "modifications": "Oxidation$Diisopropylphosphate",
    "modified_positions": 3,
    "name": "Serine protease Lpg1137",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWF7",
    "length": 154,
    "modifications": "ethylamino",
    "modified_positions": 3,
    "name": "Cytidine/deoxycytidylate deaminase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWI8",
    "length": 595,
    "modifications": "Propionamide$Unknown:248$Carbamidomethyl$hex(1)pent(3)me(1)$glycidamide$GG$dimethyl_2h(6)13c(2)$Delta:H(4)C(5)O(1)$neuac$Gluratylation$Oxidation$Met-loss+Acetyl$CAMthiopropanoyl$Dicarbamidomethyl$Glu->pyro-Glu+Methyl",
    "modified_positions": 17,
    "name": "Polyhydroxyalkanoic synthase",
    "unique_modifications": 15
  },
  {
    "id": "Q5ZWK6",
    "length": 56,
    "modifications": "Carboxy",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWN0",
    "length": 146,
    "modifications": "Ethyl",
    "modified_positions": 1,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWT9",
    "length": 88,
    "modifications": "Lysbiotinhydrazide",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZX44",
    "length": 297,
    "modifications": "Oxidation$galactosyl$clip_traq_3$Bromo",
    "modified_positions": 6,
    "name": "1-acyl-sn-glycerol-3-phosphate acyltransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZX47",
    "length": 426,
    "modifications": "hex$sulfanilicacid$Unknown:248",
    "modified_positions": 2,
    "name": "Sodium:dicarboxylate symporter",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZX50",
    "length": 148,
    "modifications": "Delta:H(2)C(3)O(1)$Carbamidomethyl",
    "modified_positions": 2,
    "name": "Periplasmic protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZX69",
    "length": 133,
    "modifications": "Carbamidomethyl$Deamidated",
    "modified_positions": 4,
    "name": "Cytochrome c-type biogenesis protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZX90",
    "length": 260,
    "modifications": "maleimide$Oxidation$Tris",
    "modified_positions": 4,
    "name": "Intermembrane phospholipid transport system permease protein MlaE",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXB2",
    "length": 97,
    "modifications": "SPITC",
    "modified_positions": 1,
    "name": "Endonuclease",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXB5",
    "length": 111,
    "modifications": "Carbamidomethyl$Ammonium$Isopropylphospho$methyl_2h(3)$hex(1)hexnac(1)",
    "modified_positions": 4,
    "name": "ATP-dependent Clp protease adapter protein ClpS",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZXE8",
    "length": 331,
    "modifications": "dimethyl_2h(4)13c(2)$Delta:H(4)C(3)$Carbamidomethyl$methyl_2h(3)13c(1)$Ethanolamine$Ammonia-loss$ethylamino$Octanoyl$Oxidation$Pyro-carbamidomethyl$Didehydro",
    "modified_positions": 13,
    "name": "Bifunctional ligase/repressor BirA",
    "unique_modifications": 11
  },
  {
    "id": "Q5ZXG5",
    "length": 372,
    "modifications": "MercaptoEthanol$FNEM$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXI8",
    "length": 98,
    "modifications": "Piperidine$Carbamidomethyl",
    "modified_positions": 2,
    "name": "Glutamate synthetase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZXS1",
    "length": 373,
    "modifications": "Dihydroxyimidazolidine$dhex(1)hex(1)$UgiJoullieProGlyProGly",
    "modified_positions": 5,
    "name": "ABC transporter permease protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZXT8",
    "length": 412,
    "modifications": "hex(4)phos(1)$Ammonium$Tyr->Dha$Cation:Li",
    "modified_positions": 4,
    "name": "UPF0761 membrane protein lpg0643",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZXW7",
    "length": 134,
    "modifications": "Lys->CamCys$Oxidation$Hydroxamic_acid$Carbamidomethyl",
    "modified_positions": 4,
    "name": "DUF4332 domain-containing protein",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZY26",
    "length": 170,
    "modifications": "CAMthiopropanoyl$EDT-maleimide-PEO-biotin$Glu->pyro-Glu$Deamidated",
    "modified_positions": 4,
    "name": "Phosphopantetheine adenylyltransferase",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZY37",
    "length": 215,
    "modifications": "Oxidation$Deamidated",
    "modified_positions": 3,
    "name": "Pyridoxine/pyridoxamine 5'-phosphate oxidase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZY57",
    "length": 310,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Phytanoyl-CoA dioxygenase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZY60",
    "length": 134,
    "modifications": "PhosphoCytidine",
    "modified_positions": 1,
    "name": "Fluoride-specific ion channel FluC",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYE8",
    "length": 179,
    "modifications": "Methamidophos-O",
    "modified_positions": 1,
    "name": "DUF2975 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYF2",
    "length": 220,
    "modifications": "Carbamidomethyl$probiotinhydrazide",
    "modified_positions": 3,
    "name": "2-dehydro-3-deoxy-phosphogluconate aldolase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYF7",
    "length": 81,
    "modifications": "deamidated_18o(1)$Carbonyl$hex$Pro->pyro-Glu$methylol$Cation:Ni[II]",
    "modified_positions": 9,
    "name": "HTH cro/C1-type domain-containing protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZYG0",
    "length": 294,
    "modifications": "Cation:Fe[II]$hex(2)hexnac(2)$Carbamidomethyl",
    "modified_positions": 4,
    "name": "Protoheme IX farnesyltransferase",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYG4",
    "length": 182,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Inner (Transmembrane) protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYN2",
    "length": 109,
    "modifications": "QQQTGG",
    "modified_positions": 1,
    "name": "Large ribosomal subunit protein uL24",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYX1",
    "length": 259,
    "modifications": "Oxidation$Retinylidene$Unknown:306",
    "modified_positions": 3,
    "name": "DNA repair protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYY5",
    "length": 465,
    "modifications": "Carbamidomethyl$Haloxon$Oxidation$AMTzHexNAc2$Thiazolidine$Delta:H(8)C(6)O(1)",
    "modified_positions": 6,
    "name": "Multidrug efflux protein, outer membrane component",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZZ16",
    "length": 334,
    "modifications": "Delta:H(4)C(3)$Carbamidomethyl$OxLysBiotinRed$Oxidation$methyl_2h(3)",
    "modified_positions": 5,
    "name": "Uncharacterized protein",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZZ36",
    "length": 278,
    "modifications": "hex(1)hexnac(2)sulf(1)$Carbamidomethyl",
    "modified_positions": 2,
    "name": "Pyoverdine biosynthesis protein PvcB",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZ40",
    "length": 188,
    "modifications": "Arg->GluSA$Oxidation$Cytopiloyne+water",
    "modified_positions": 5,
    "name": "FBOX-containing protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZ41",
    "length": 251,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Probable ABC transport system permease protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZ52",
    "length": 159,
    "modifications": "Phospho",
    "modified_positions": 3,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZ86",
    "length": 200,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)$Delta:H(4)C(3)O(1)$Carbamidomethyl$acetyl_13c(2)$AEBS$Ethanolyl$neuac$methylsulfonylethyl",
    "modified_positions": 5,
    "name": "Probable GTP-binding protein EngB",
    "unique_modifications": 8
  },
  {
    "id": "Q5ZZB3",
    "length": 150,
    "modifications": "Argbiotinhydrazide$diart6plex115$Phosphopropargyl$Carbamidomethyl",
    "modified_positions": 5,
    "name": "Two component sensor and regulator, histidine kinase response regulator",
    "unique_modifications": 4
  },
  {
    "id": "Q5ZZC8",
    "length": 315,
    "modifications": "G-H1$Phe->CamCys$Thiazolidine",
    "modified_positions": 3,
    "name": "Glutathione synthase/ribosomal protein S6 modification enzyme",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZG5",
    "length": 70,
    "modifications": "DMPO$Phosphoadenosine",
    "modified_positions": 2,
    "name": "Dot/Icm secretion system substrate",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZH0",
    "length": 331,
    "modifications": "icpl_2h(4)$Carbamidomethyl$dnic$Oxidation$dhex(1)hex(6)$Gly",
    "modified_positions": 6,
    "name": "Integral membrane protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZZH6",
    "length": 253,
    "modifications": "Ammonium$Dansyl$Oxidation$Delta:H(4)C(2)$Dimethyl$Ethyl",
    "modified_positions": 6,
    "name": "Uncharacterized protein",
    "unique_modifications": 6
  },
  {
    "id": "Q5ZZI2",
    "length": 213,
    "modifications": "Carbamidomethyl$Carbonyl$Deamidated$Dansyl$Delta:H(6)C(3)O(1)",
    "modified_positions": 8,
    "name": "3-demethoxyubiquinol 3-hydroxylase",
    "unique_modifications": 5
  },
  {
    "id": "Q5ZZI7",
    "length": 180,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Transmembrane protein",
    "unique_modifications": 1
  },
  {
    "id": "Q9XD70",
    "length": 161,
    "modifications": "icpl_2h(4)$Carbamyl$Methylpyrroline$dnic$Oxidation",
    "modified_positions": 3,
    "name": "Type II secretion system protein H",
    "unique_modifications": 5
  },
  {
    "id": "A0A098G5B0",
    "length": 72,
    "modifications": "MesitylOxide",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "A0A128XE11",
    "length": 104,
    "modifications": "Ethanedithiol$Oxidation$MercaptoEthanol",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 3
  },
  {
    "id": "A0A222P310",
    "length": 430,
    "modifications": "Carbamidomethyl$Oxidation$PET",
    "modified_positions": 4,
    "name": "Proline/betaine transporter",
    "unique_modifications": 3
  },
  {
    "id": "A0A378K985",
    "length": 200,
    "modifications": "cGMP+RMP-loss",
    "modified_positions": 1,
    "name": "DUF2845 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "A0A3A6UNU7",
    "length": 98,
    "modifications": "neiaa_2h(5)",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "A0AAN2RRN1",
    "length": 107,
    "modifications": "maleimide$Oxidation$Deamidated",
    "modified_positions": 5,
    "name": "Protein-export membrane protein SecG",
    "unique_modifications": 3
  },
  {
    "id": "A0AAN5PHP6",
    "length": 77,
    "modifications": "hex(1)hexnac(1)",
    "modified_positions": 1,
    "name": "Acyl carrier protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5WUN0",
    "length": 138,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "DUF4949 domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5WWD8",
    "length": 87,
    "modifications": "Oxidation$Carbamidomethyl$hex(1)pent(3)me(1)",
    "modified_positions": 3,
    "name": "UPF0250 protein lpl1515",
    "unique_modifications": 3
  },
  {
    "id": "Q5WXZ3",
    "length": 112,
    "modifications": "Oxidation",
    "modified_positions": 2,
    "name": "Cell division protein FtsL",
    "unique_modifications": 1
  },
  {
    "id": "Q5WYY5",
    "length": 76,
    "modifications": "GGQ",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZRK0",
    "length": 204,
    "modifications": "Carbamidomethyl",
    "modified_positions": 2,
    "name": "Iron-sulfur cluster binding protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZRQ9",
    "length": 270,
    "modifications": "Oxidation$Gly-loss+Amide",
    "modified_positions": 4,
    "name": "NAD(P)H-hydrate epimerase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZT23",
    "length": 257,
    "modifications": "Delta:H(2)C(3)O(1)",
    "modified_positions": 1,
    "name": "ATPases involved in biogenesis of archaeal flagella",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZT99",
    "length": 296,
    "modifications": "Delta:H(2)C(2)$Oxidation",
    "modified_positions": 2,
    "name": "Curved DNA binding protein DnaJ",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTL0",
    "length": 288,
    "modifications": "Oxidation$MercaptoEthanol",
    "modified_positions": 3,
    "name": "Aminoglycoside 6-adenylyltransferase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTN0",
    "length": 180,
    "modifications": "Delta:H(4)C(2)O(-1)S(1)",
    "modified_positions": 2,
    "name": "Ankyrin 3",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTP0",
    "length": 69,
    "modifications": "Formyl",
    "modified_positions": 4,
    "name": "Cold shock DNA binding domain protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZTS3",
    "length": 116,
    "modifications": "Oxidation$dimethyl_2h(4)",
    "modified_positions": 2,
    "name": "Conjugative transfer: assembly",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZTU6",
    "length": 280,
    "modifications": "Phospho$Phosphopropargyl$Sulfo",
    "modified_positions": 2,
    "name": "D-xylose reductase III",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZU33",
    "length": 216,
    "modifications": "O-Isopropylmethylphosphonate",
    "modified_positions": 1,
    "name": "F-box domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZU36",
    "length": 125,
    "modifications": "Ethylphosphate$Carbamidomethyl",
    "modified_positions": 2,
    "name": "Type IV secretion protein Dot",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZU65",
    "length": 85,
    "modifications": "diart6plex115$O-Isopropylmethylphosphonate",
    "modified_positions": 2,
    "name": "Carrier domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZV13",
    "length": 278,
    "modifications": "NHS-fluorescein",
    "modified_positions": 1,
    "name": "Zn-dependent hydrolase GumP",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVA0",
    "length": 140,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Universal stress protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVC1",
    "length": 189,
    "modifications": "Carbamidomethyl",
    "modified_positions": 1,
    "name": "Purine/pyrimidine phosphoribosyltransferase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVF5",
    "length": 133,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Integral membrane protein (PIN domain superfamily)",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVI0",
    "length": 269,
    "modifications": "CAMthiopropanoyl",
    "modified_positions": 2,
    "name": "Cofactor-independent phosphoglycerate mutase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZVK0",
    "length": 158,
    "modifications": "Butyryl$Crotonaldehyde$Pyridylacetyl",
    "modified_positions": 2,
    "name": "Endoribonuclease YbeY",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZWH3",
    "length": 127,
    "modifications": "Oxidation$Thrbiotinhydrazide",
    "modified_positions": 2,
    "name": "Uncharacterized protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZWI2",
    "length": 403,
    "modifications": "AMTzHexNAc2",
    "modified_positions": 1,
    "name": "Alpha/beta hydrolase",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWI6",
    "length": 152,
    "modifications": "NQIGG",
    "modified_positions": 1,
    "name": "Transmembrane protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWP7",
    "length": 105,
    "modifications": "Delta:H(2)C(2)",
    "modified_positions": 1,
    "name": "VrrB",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZWT7",
    "length": 210,
    "modifications": "hex$Oxidation$AccQTag",
    "modified_positions": 7,
    "name": "TIGR03747 family integrating conjugative element membrane protein",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZX95",
    "length": 169,
    "modifications": "Lys->MetOx",
    "modified_positions": 1,
    "name": "Organic solvent tolerance-like N-terminal domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXT6",
    "length": 681,
    "modifications": "Oxidation",
    "modified_positions": 1,
    "name": "Type I secretion C-terminal target domain-containing protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZXV8",
    "length": 130,
    "modifications": "Dimethyl$Oxidation$Ethyl",
    "modified_positions": 4,
    "name": "Integral membrane protein (PIN domain superfamily)",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZY55",
    "length": 276,
    "modifications": "Myristoyl+Delta:H(-4)",
    "modified_positions": 2,
    "name": "Aldo/keto reductases",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZY82",
    "length": 104,
    "modifications": "Lys->CamCys$Oxidation$hexnac(1)dhex(1)",
    "modified_positions": 4,
    "name": "Arginine repressor",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZYC9",
    "length": 120,
    "modifications": "Deamidated",
    "modified_positions": 1,
    "name": "IcmR",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZYS3",
    "length": 326,
    "modifications": "Carbamidomethyl$Cys->Oxoalanine",
    "modified_positions": 2,
    "name": "L-lysine 2,3-aminomutase",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZYV1",
    "length": 132,
    "modifications": "Unknown:210",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  },
  {
    "id": "Q5ZZ09",
    "length": 178,
    "modifications": "hex(1)hexnac(1)neugc(1)$Oxidation",
    "modified_positions": 3,
    "name": "DUF2878 domain-containing protein",
    "unique_modifications": 2
  },
  {
    "id": "Q5ZZ49",
    "length": 93,
    "modifications": "methylol$Oxidation$Lys->MetOx",
    "modified_positions": 3,
    "name": "SapA-like",
    "unique_modifications": 3
  },
  {
    "id": "Q5ZZD6",
    "length": 104,
    "modifications": "Lipoyl",
    "modified_positions": 1,
    "name": "Uncharacterized protein",
    "unique_modifications": 1
  }
];