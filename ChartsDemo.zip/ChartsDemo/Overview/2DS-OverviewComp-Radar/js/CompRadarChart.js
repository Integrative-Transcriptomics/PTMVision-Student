// colors: 
var colorSet1 = "#435c9c";
var colorSet2 = "#E9625A";
var colorComp = "#558b60";


var compClassCountChart = echarts.init(document.getElementById("RadarChartClassCount"));

// define chart options
var compClassCountChartOpt = {
    color: [colorSet1, colorSet2],
    tooltip: {},
    legend: {
        data: ["Data 1", "Data 2"]
    },
    radar: {
        indicator: combinedJsonData,
        axisName: {
            color: '#000000'
        },
    },
    series: [
        {
            type: "radar",
            data: [
                {
                    // data1:
                    value: combinedData[1],
                    name: "Data 1",
                    areaStyle: {
                        color: colorSet1
                    }
                },
                {
                    value: combinedData[2],
                    name: "Data 2",
                    areaStyle: {
                        color: colorSet2
                    }
                }
            ]
        }
    ]
};

compClassCountChart.setOption(compClassCountChartOpt);