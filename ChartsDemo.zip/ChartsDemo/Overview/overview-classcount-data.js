// script for data preparation/preprocessing

/**
 * Function which combines the modification class data of
 * 2 json files
 * @param jsonData1
 * @param jsonData2
 * @returns classCombined object:
 * [0] -> array of class names (keys)
 * [1] -> array of values of data 1
 * [2] -> array of values of data 2
 */
function combineclassData(jsonData1, jsonData2) {

    /**
     * classOnly1/2:
     * [0] -> keys
     * [1] -> values
     */
    let classOnly1 = [];
    let classOnly2 = [];

    classOnly1.push(Object.keys(jsonData1[3]));
    classOnly1.push(Object.values(jsonData1[3]));

    classOnly2.push(Object.keys(jsonData2[3]));
    classOnly2.push(Object.values(jsonData2[3]));

    /**
     * classCombined:
     * [0] -> keys
     * [1] -> values of 1
     * [2] -> values of 2
     */
    let classCombined = [[],[],[]];

    // fill classCombined
    for(let i = 0; i < classOnly1[0].length; i++){
        classCombined[0].push(classOnly1[0][i]);
        classCombined[1].push(classOnly1[1][i]);
        // this will be filled with class 2 if contained
        classCombined[2].push(0);
    }

    for(let i = 0; i < classOnly2[0].length; i++){
        if(classCombined[0].includes(classOnly2[0][i])){
            // case: this type of unimod class is already in classCombined
            let idx = classCombined[0].indexOf(classOnly2[0][i]);
            classCombined[2][idx] = classOnly2[1][i];
        } else{
            // case: this type  is not contained already
            classCombined[0].push(classOnly2[0][i]);
            classCombined[1].push(0);
            classCombined[2].push(classOnly2[1][i]);
        }
    };

    return classCombined;
}

/**
 * Function which makes a Json Object from the combinedArray array
 * @param {[String],[Int],[Int]} inputArray (combinedData Array as input)
 * length should be the same for all 3Dimensions
 * @returns {Object} combinedJson Object (with name: , value: , value:)
 */
function makeJsonObj(inputArray){

    let combinedJson = [];

    for(let i = 0; i < inputArray[0].length; i++){
        combinedJson.push(
            {
                "name": inputArray[0][i],
                "value1": inputArray[0][i],
                "value2": inputArray[0][i],
            }
        )
    };

    return combinedJson;
}

/**
 * function to get the max value out of data
 * @param {Array} combinedData array
 * @param {number} skaleFaktor number (should be >= 1)
 * @returns {number} maxModsC maximum of modifications in all classes + scale faktor
 */
function getMaxMods(combinedData, skaleFaktor){

    let maxModsC = Math.max(Math.max(...combinedData[1]), Math.max(...combinedData[2])) * skaleFaktor;
    return Math.ceil(maxModsC);
}


/**
 * function to get the min (negative max) value out of data
 * @param {Array} combinedData array
 * @param {number} skaleFaktor number (should be >= 1)
 * @returns {number} minModsC minimum value for left side (negativ max)
 */
function getMinMods(combinedData, skaleFaktor){

    let minModsC = getMaxMods(combinedData, skaleFaktor) * -1;
    return minModsC;
}

let combinedData = combineclassData(overviewData1, overviewData2);

let combinedJsonData = makeJsonObj(combinedData);