// dom element to bin this to:
var domID = document.getElementById("SharedSitesChordChart");


// try data_fragger/ data_ionbot, adjust data and links in chartOpt
let sharedSitesRaw = data_fragger[2];

let modificationsSet = new Set();
Object.keys(sharedSitesRaw).forEach(pair => {
    const [mod1, mod2] = pair.split("@");
    modificationsSet.add(mod1);
    modificationsSet.add(mod2);
});

let modNames = Array.from(modificationsSet).map(name => ({ name }));

const sharedSitesLinks = Object.entries(sharedSitesRaw).map(([key, value]) => {
  const [target, source] = key.split("@");
  return { target, source, value };
});

// init echarts elem:
var sharedSitesChordChart = echarts.init(domID);




var chartOpt = {

    tooltip:{

    },
    series: [
        {
            type: "chord",
            label: {
                show: true,
                color: "black",
                fontWeight: "bold",
            },
            lineStyle: {color: "target"},
            // data_names_prep_fragger/ modNames
            data: data_names_prep_fragger,
            // try: data_links_prep_fragger/ sharedSitesLinks
            links: data_links_prep_fragger,
        }

    ]
};

sharedSitesChordChart.setOption(chartOpt);

