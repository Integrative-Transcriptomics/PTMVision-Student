// colors: 
var colorSet1 = "#435c9c";
var colorSet2 = "#E9625A";
var colorComp = "#558b60";


var compClassCountChart = echarts.init(document.getElementById("testcanvas"));

// define chart options
var compClassCountChartOpt = {
    tooltip: {
        trigger: "axis",
        axisPointer: {            
            type: "shadow", // dont use cross... negativ values need extra treetment... again!
            label: {
                backgroundColor: "#FF821C"
            }        
        },
        valueFormatter: (value) => Math.abs(value)
    },
    legend: {
        data: ["Dataset1", "Dataset2"]
    },
          dataZoom: [
        {
          type: "inside",
          xAxisIndex: [0, 1],
        },
      ],
    grid: {
        right: "2%",
        left: "2%",
        bottom: "3%",
        containLabel: true
    },
    xAxis: [
        {
            type: "value",
            max: getMaxMods(combinedData, 1.2),
            min: getMinMods(combinedData, 1.2),
            show: true,
            axisLabel: {
              formatter: (value, index) => Math.abs(value)
          }
        }
    ],
    yAxis: [
        {
            type: "category",
            data: combinedData[0]
        }
    ],
    series: [
        {
            name: "Dataset 2",
            type: "bar",
            color: colorSet2,
            stack: "quantity",
            label: {
                show: true,
                position: "right"
            },
            emphasis: {
                focus: "series"
            },
            data: combinedData[2]
        },
        {
            name: "Dataset 1",
            type: "bar",
            color: colorSet1,
            stack: "quantity",
            label: {
                show: true,
                position: "left",
                formatter: function (params) {
                    return Math.abs(params.data);
                }               
            },
            emphasis: {
                focus: "series"
            },
            data: combinedData[1].map(x => x * -1)
        }
    ]
};


compClassCountChart.setOption(compClassCountChartOpt);