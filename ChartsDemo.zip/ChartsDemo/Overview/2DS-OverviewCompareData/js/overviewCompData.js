var domElemLeft = document.getElementById("FirstChartContainer");
var domElemMiddle = document.getElementById("SecondChartContainer");
var domElemRight = document.getElementById("ThirdChartContainer");

// jsonData1:


// Data counts of ptms found in dataset:
var numberPTMin1 = proteinData1.length;
var numberPTMin2 = proteinData2.length;

// max value
var maxValue = Math.round(Math.max(numberPTMin1, numberPTMin2) * 1.25);


// Difference in % between the number of modifications in Dataset1 and Dataset2
var diffData = Math.round((numberPTMin2 - numberPTMin1) / ((numberPTMin2 + numberPTMin1) / 2) * 100);

/**
 * Function for getting the maximum value for the chart borders of the difference in % chart
 * @returns number (adjusted max value)
 */
function getDiffDataMax() {
    diffDataMax = 0;
    // scaleFaktor = factor by which the limits should be adjusted
    scaleFaktor = 1.2

    if (diffData <= 0) {
        diffDataMax = (diffData * scaleFaktor) * -1;
    } else {
        diffDataMax = diffData * scaleFaktor;
    }

    return Math.round(diffDataMax);
}



// init charts
var leftCChart = echarts.init(domElemLeft);
var middleChart = echarts.init(domElemMiddle);
var rightCChart = echarts.init(domElemRight);


/**
 * Options left chart:
 */
var leftOption = {
    tooltip: {
        trigger: "axis",
        axisPointer: {
            type: "shadow",
            label: {
                show: true,
                fontSize: 18,
                backgroundColor: "#435c9c"
            }
        }
    },
    xAxis: {
        type: "category",
        data: ["Number of PTMs in Dataset 1"],
        axisLabel: {
            fontSize: 16
        }
    },
    yAxis: {
        type: "value",
        max: maxValue,
    },
    series: [
        {
            data: [numberPTMin1],
            type: "bar",
            color: "#435c9c" // TODO: use global color var
        }]
}


//#E9625A


var rightOption = {
    tooltip: {
        trigger: "axis",
        axisPointer: {
            type: "shadow",
            label: {
                show: true,
                fontSize: 18,
                backgroundColor: "#E9625A"
            }
        }
    },
    xAxis: {
        type: "category",
        data: ["Number of PTMs in Dataset 2"],
        axisLabel: {
            fontSize: 16
        }
    },
    yAxis: {
        type: "value",
        max: maxValue,
    },
    series: [
        {
            data: [numberPTMin2],
            type: "bar",
            color: "#E9625A", // following the color scheme
        }
    ]
}


var middleOption = {
    title: {
        text: "Difference in %",
        textVerticalAlign: "bottom"
    },
    tooltip: {
        trigger: "axis",
        axisPointer: {
            type: "shadow", // dont use cross... negativ values need extra treetment... again!
            label: {
                show: true,
                fontSize: 18,
                backgroundColor: "#000000"
            }
        },
        valueFormatter: (value) => Math.abs(value)
    },
    grid: {

    },
    legend: {
        data: ["diff"]
    },
    xAxis: {
        beginnAtZero: true,
        // for showing both sides:
        min: -1 * getDiffDataMax(),
        max: getDiffDataMax(),
        axisLabel: {
            showMinLabel: false,
            showMaxLabel: false,
            formatter: (value, index) => Math.abs(value),
            fontSize: 16
        },
    },
    yAxis: {
        // essential for showing data on x-axis, not on y with % label
        data: ['%']
    },
    series: [
        {
            name: "Difference",
            type: "bar",
            data: [diffData],
            itemStyle: {
                color: "#558b60",
                opacity: 0.95
            }
        }
    ]
}

rightCChart.setOption(rightOption);
leftCChart.setOption(leftOption);
middleChart.setOption(middleOption);