// colors:
var colorSet1 = "#435c9c";
var colorSet2 = "#E9625A";
var dataName1 = "Data1";
var dataName2 = "Data2";

/**
 * This opens a pop up for the selected molecule
 * @param {String} modName 
 */
function displayMod(modName){

  // settings for the window to open:
  let windowSettings = "popup, width=500px, height=500px";

  switch(modName) {
    case "Acetyl":
      window.open("../molecules/molviewAcetyl.html", null, windowSettings);
      break;
    case "Octanoyl":
      window.open("../molecules/molviewOctanoyl.html", null, windowSettings);
      break;
    default:
      break;
  }
}


// data prep:
function joinOverviewJson(json1, json2){
  let joined = {};

  Object.entries(json1[0]).forEach(([modificationKey, modificationData]) => {
    joined[modificationKey] = {
      display_name: modificationData.display_name,
      count1: modificationData.count,
      count2: 0
    };
  })


  Object.entries(json2[0]).forEach(([modificationKey, modificationData]) => {
    if(joined[modificationKey]){
      // case: both modifications in both sets, modification data added by json1 already
      joined[modificationKey].count2 = modificationData.count
    } else {
      // case: only json2
      joined[modificationKey] = {
        display_name: modificationData.display_name,
        count1: 0,
        count2: modificationData.count
      };

    }
  });

  return joined;
}

let combinedData = joinOverviewJson(overviewData1, overviewData2);


// declare chart
let domElem = document.getElementById("CompPTMsCounter-ZoomProt");

let compPTMCounter = echarts.init(domElem);

option = {
  dataZoom: [
    {
      type: "slider",     // inside to scroll with mouse wheel, slider for adjustable slider...
      // slider chosen because better for different scales of data
      yAxisIndex: [0, 1, 2],
      brushSelect: false,
      throttle: 0,
    },
  ],
  title: {
    text: "Comparative PTMs Count"
  },
  tooltip: {
    trigger: "axis",
    axisPointer: {
      type: "shadow"
    }
  },
  legend: {},
  xAxis: {
    type: "value",
    boundaryGap: [0, 0.01]
  },
  yAxis: {
    type: "category",
    data: Object.values(combinedData).map(name => name.display_name).sort() // sorts alphabetical, with Big letters first, then small A-Z,then a-z
  },
  series: [
    {
      name: dataName1,
      type: "bar",
      color: colorSet1,
      data: Object.values(combinedData).map(data => data.count1)//echartsData1Values,
    },
    {
      name: dataName2,
      type: "bar",
      color: colorSet2,
      data: Object.values(combinedData).map(data => data.count2)//echartsData1Values,
    },
  ]
};

compPTMCounter.setOption(option);
// on click behavior (open Pop up):
compPTMCounter.on("click", function(params){

  console.log(params.name)
  // opens kekule pop up
  openWindow(params.name);
})
