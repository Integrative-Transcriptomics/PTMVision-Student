
function openWindow(params) {
    let molName = params;
    let cmlOut = moleculesLib[molName];

    // put input data together:
    let data = new URLSearchParams({
        molname: molName,
        cml: cmlOut,
    })

    window.open(`./molDisplay.html?${data.toString()}`, "_blank", "popup,width=800,height=800");
};