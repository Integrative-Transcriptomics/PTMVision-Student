// colors:
var colorSet1 = "#435c9c";
var colorSet2 = "#E9625A";
var colorComp = "#558b60";


/**
 * ------------------------------
 * Data Preparation
 * ------------------------------
 */
let uniprotID = "Q5ZYC1";
// Q5ZYP5 - Elongation Factor Tu -> 86 modification sites max
// Q5ZUY0 - Putative transport protein -> no shared mods
// Q5ZV63 - RNA polymerase sigma E factor RpoE -> mods in both


/**
 * Function: getProteinName
 * Returns the name of the Protein for a given
 * uniprot ID
 * Note: protData can be from 1/2 because this chart
 * displays only if both contain the protein
 * @param {String} id           UniProtID
 * @param {Object} protData     Object with id + name
 * @returns {String} protName   name of the protein 
 */
function getProteinName(id, protData){

    let protName = "";

    for(let i = 0; i < protData.length; i++){

        if(protData[i].id == id){
            // case: IDs match
            protName = protData[i].name;
            break;
        }
    };

    return protName;
}

/**
 * Function: getModNames
 * Searches in protein data json object for the
 * names of occuring modifications of the selected
 * protein (UniProt ID). Returns array of modification
 * names.
 * @param {String} id           UniProtID
 * @param Json                  Json protein data object
 * @returns Array[String] Array of modification names
 */
function getModNames(id, protData) {

    // composedProtNames
    let namesEntry = "";

    // loop through protein data object
    for (let i = 0; i < protData.length; i++) {

        //check if protein at index id = given id
        if (protData[i].id == id) {
            namesEntry = protData[i].modifications;
            break;
        }
    };

    // splits the string into modification names
    let modNames = namesEntry.split("$");

    return modNames;
}

/**
 * Function: countModOccurrence
 * Counts the Occurrence of a given modification (name)
 * for a given protein (UniProtID), needs overview data json
 * @param {String} id               UniProtID
 * @param {String} name             Modification Name
 * @param Json Json overview data   (overviewData)
 * @returns {number} (count of occurring at given protein)
 */
function countModOccurrence(id, name, overviewData) {

    let occurrenceCount = 0;

    // get the array with occurrences of uniprot ids
    let occurrenceData = overviewData[0][name].occurrence;

    // search in the occurrence data of occurrences for given id
    for (let i = 0; i < occurrenceData.length; i++) {
        if (occurrenceData[i] == id) {
            occurrenceCount++;
        }
    }
    return occurrenceCount;
}


/**
 * Function: compareModNames
 * Checks which names of modifications occurr in both 
 * input data sets
 * @param {String[]} modNames1
 * @param {String[]} modNames2
 * @returns {String[]} modNamesBoth
 */
function compareModNames(modNames1, modNames2) {

    let modNamesBoth = [];

    // TODO works but meh -> refactor
    for (let i = 0; i < modNames1.length; i++) {

        for (let j = 0; j < modNames2.length; j++) {

            if (modNames1[i] == modNames2[j]) {
                // case: Mod name is in both arrays
                modNamesBoth.push(modNames2[j]);
            };
        };
    };

    return modNamesBoth;
}


/**
 * Function: getModInfo
 * Aligns the Counts and Names of given Mod Data
 * - Mod Name
 * - Mod Count
 * @param {String} id                   UniProtID
 * @param {String[]} modNames           Names of the Modifications
 * @param {Object} overviewData         overviewData Object
 * @param {String} color                hexcolor as String                        
 * @returns Json formatted Javascript Object
 */
function getModInfo(id, modNames, overviewData, color) {

    let modData = [];

    for (let i = 0; i < modNames.length; i++) {

        let currentModCount = countModOccurrence(id, modNames[i], overviewData);

        let currentEntry = {
            name: modNames[i],
            value: currentModCount,
            itemStyle: {
                color: color,
            },
        };

        modData.push(currentEntry);
    };

    return modData;
}

/**
 * Function: calcGroupSize
 * Returns the size of a group of Mofications based on
 * the number of occuring modifications in the given data
 * @param modData       Object containing modification data
 * @returns {number}    count of modifications
 */
function calcGroupSize(modData){

    let size = 0;

    for(let i = 0; i < modData.length; i++){
        size = size + modData[i].value;
    };

    return size;
}

/**
 * Function: getProcessedModData
 * Returns the processed modification data containing:
 * - Dataset of Modification
 * - Mod Name
 * - Mod Counts
 * @param String UniProtID                  (id)
 * @param Json Json protein data set 1      (protData1)
 * @param Json Json protein data set 2      (protData2)
 * @param Json Json overview data set 1     (ovData1)
 * @param Json Json overview data set 2     (ovData2)
 * @returns Json formatted Javascript Object for read in as
 *          data in the chart option
 */
function getProcessedModData(id, protData1, protData2, ovData1, ovData2) {

    // output data -> contains 3 sub arrays:
    // -> mods only in 1
    // -> mods only in 2
    // -> mods in both -> with childs if count is different
    let outputData = []

    let modNames1 = getModNames(id, protData1);
    let modNames2 = getModNames(id, protData2);
    let modNamesBoth = compareModNames(modNames1, modNames2);

    // make objects with elements only in one of dataset 1/2:
    // names which dont occur in both
    let filteredModNames1 = [];
    let filteredModNames2 = [];

    for (let i = 0; i < modNames1.length; i++) {

        if (!modNamesBoth.includes(modNames1[i])) {
            // case: modname occurrs only in modNames1
            filteredModNames1.push(modNames1[i]);
        }
    };

    for (let i = 0; i < modNames2.length; i++) {

        if (!modNamesBoth.includes(modNames2[i])) {
            // case: modname occurrs only in modNames2
            filteredModNames2.push(modNames2[i]);
        }
    };

    // get modification data as structured object:    
    let modDataOnly1 = getModInfo(id, filteredModNames1, ovData1, colorSet1);
    let modDataOnly2 = getModInfo(id, filteredModNames2, ovData2, colorSet2);
    
    // Both 1 -> with occurrence value set 1
    // Both 2 ->  with occurrence value set 2
    let modDataBoth1 = getModInfo(id, modNamesBoth, ovData1, colorComp);
    let modDataBoth2 = getModInfo(id, modNamesBoth, ovData2, colorComp);

    // calculate part sizes:
    // -> number of contained Modifications
    let sizeMods1 = calcGroupSize(modDataOnly1);
    let sizeMods2 = calcGroupSize(modDataOnly2);
    let sizeModsBoth1 = calcGroupSize(modDataBoth1);
    let sizeModsBoth2 = calcGroupSize(modDataBoth2);
    let sizeModsBoth = sizeModsBoth1 + sizeModsBoth2;

    let sharedMods = [
        {
            name: "Occurence in Set 1",
            value: sizeModsBoth1,
            children: modDataBoth1,
            itemStyle: {
                color: colorComp,
            },
        },
        {
            name: "Occurence in Set 2",
            value: sizeModsBoth2,
            children: modDataBoth2,
            itemStyle: {
                color: colorComp,
            },
        },
    ];

    // define outputData
    outputData = [
        {
            name: "Modifications only in Set 1",
            value: sizeMods1,
            children: modDataOnly1,
            itemStyle: {
                color: colorSet1,
                fontWeight: "bolder",
            },
        },
        {
            name: "Modifications only in Set 2",
            value: sizeMods2,
            children: modDataOnly2,
            itemStyle: {
                color: colorSet2,
                fontWeight: "bolder",
            },
        },
        {
            name: "Mod shared",
            value: sizeModsBoth,
            children: sharedMods,
            itemStyle: {
                color: colorComp,
                fontWeight: "bolder",
            },
        }
    ];

    return outputData;
}

// Definitions for Chart
let proteinName = getProteinName(uniprotID, proteinData1);
let modData = getProcessedModData(uniprotID, proteinData1, proteinData2, overviewData1, overviewData2);


/**
 * ------------------------------
 * Chart Definition
 * ------------------------------
 */
let domID = document.getElementById("ChartContainer");

// control = 1
// copper = 2
// this protein has
let compDashChart = echarts.init(domID);

let compDashChartOpt = {
    title: {
        text: proteinName,
        textStyle: {
            fontWeight: "bold",
            fontSize: 20,
            align: "center",
        }
    },
    tooltip: {
        show: true
    },
    series: {
        type: "sunburst",
        data: modData,
        radius: [55, "85%"],
        itemStyle: {
            borderRadius: 5,
            borderWidth: 2,
        },
        label: {
            show: true,
        }
    },
};

compDashChart.setOption(compDashChartOpt);