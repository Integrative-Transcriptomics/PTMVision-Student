/**
 * Script to prepare data for the chart
 */

// make array with uniprot ids of proteins, that are in 1/2/both

/**
 * function: checkOccurence()
 * checks if an Uniprot ID occurs in Both input data jsons
 * @param {Object} json1            (json object)
 * @param {Object}json2             (json object)
 * @returns {[String]} idBoth       array of Uniprot IDs (in both data inputs)
 */
function checkOccurence(json1, json2){
    
    // define return array
    let idBoth = [];
    
    for(let i = 0; i < json1.length; i++){
        // i index of loop on json1 array

        let currentID1 = json1[i].id;


        for(let j = 0; j < json2.length; j++){
            // j index of loop on json1 array
            let currentID2 = json2[j].id;

            if(currentID1 == currentID2){
                idBoth.push(currentID1);
            }


        }
    }

    return idBoth;
}

let commonProtIDs = checkOccurence(data1, data2);


// define the final data containers:
/**
 * Should have the form: 
 * {
        name: "Proteiname",
        (id: "Protein ID")
        value: "Number Modifications"/"Unique Modifications"/"Protein length"
    },
 */
let only1Prot = [];
let only2Prot = [];
let bothProt = [];



/**
 * Filters the json data to only the necessary elements
 * - name = Proteinname
 * - value = modified_positions (max)
 * - (id = protein uniprot id)
 * 
 * @param {Object} commonIDList = list (array of type: ["id1". "id2" ,...]) 
 * with common Uniprot IDs in Both data sets
 * @param {Number} set = which set should be created, one of: 
 * - "1" (protiens only in 1)
 * - "2" (proteins only in 2)
 * - "B" (proteins in Both)
 * @param {Object} json1 (json array)
 * @param {Object} json2 (json array)
 */
function prepareData(commonIDList, set, json1, json2){

    let output = [];

    switch(set) {
        case "1":
            for(let i = 0; i < json1.length; i++){
                // loop over all elements in 1
                // add only with id != in commonIDList
                if(!commonIDList.includes(json1[i].id) ){
                    // if id is not in commonIDList -> add to output
                    output.push(
                        {
                            name: json1[i].name,
                            value: json1[i].modified_positions,
                            id: json1[i].id
                        }
                    )
                }
            }

            return output;
            break;
        case "2":
            for(let i = 0; i < json2.length; i++){
                // loop over all elements in 2
                // add only with id != in commonIDList
                if(!commonIDList.includes(json2[i].id)){
                    // if id is not in commonIDList -> add to output
                    output.push(
                        {
                            name: json2[i].name,
                            value: json2[i].modified_positions,
                            id: json2[i].id
                        }
                    )
                }
            }

            return output;
            break;
        case "B":
            // need 2 Loops for max amount of modifications
            for(let i = 0; i < json1.length; i++){
                // loop over all elements in 1 $ 2

                for(let j = 0; j < json2.length; j++){
                    if(json1[i].id == json2[j].id){
                        // id in both elements the same
                        output.push({
                            name: json1[i].name,
                            value: Math.max(json1[i].modified_positions, json2[j].modified_positions),
                            id: json1[i].id
                        });

                    }
                }
            }

            return output;
            break;
        default:
            console.error("Default Case Entered!!! This should not happen!!!");
            return output;
    }
}


// Fill input data
only1Prot = prepareData(commonProtIDs, "1", data1, data2);
only2Prot = prepareData(commonProtIDs, "2", data1, data2);
bothProt = prepareData(commonProtIDs, "B", data1, data2);
