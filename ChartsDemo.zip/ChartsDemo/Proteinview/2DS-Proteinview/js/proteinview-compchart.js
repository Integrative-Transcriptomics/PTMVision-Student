var colorSet1 = "#435c9c";
var colorSet2 = "#E9625A";
var colorComp = "#558b60";

var setName1 = "Data 1";
var setName2 = "Data 2";

var _uniprotID = "";


// dom element to bind chart to:
var domElem = document.getElementById("Charthere");

// init echarts chart (Protein Comp Chart):
var pvCompChart = echarts.init(domElem);

// definition of options + data
var pvCompChartOpt = {
    tooltip: {
        show: true,
        formatter: function(params){
            // Array which contains the name of non child elements:
            let topCategories = ["Modified proteins", setName1, setName2, "Contained in both datasets"];
            if(topCategories.includes(params.name)){
                return "Contains " + params.value + " Proteins";
            }else{
                return "Modifications: " + params.data.value + "<br>" +
                "ID: " + params.data.id;
            }
        },
    },
    series: [
        {
            name: "Modified proteins",
            type: "treemap",
            label: {
                show: true,
                fontSize: 16,
                formatter: "{b}",

            },
            upperLabel: {
                // name of Category
                fontSize: 24,
                show: true,
                height: 30,
                color: "#FFFFFF",
                backgroundColor: "#343434",
            },
            squareRatio: 1, // looks better (positioning of sets)
            data: [
                {
                    name: setName1,
                    itemStyle: {
                        color: colorSet1,
                    },
                    upperLabel: {
                        // name of Category
                        show: true,
                        fontSize: 18,
                        color: "#ffffff",
                        backgroundColor: "#435c9cbe",
                    },
                    value: only1Prot.length, // how much space this category will get
                    children: only1Prot             // proteinsSet1 here
                },
                {
                    name: "Contained in both datasets",
                    itemStyle: {
                        color: colorComp,
                    },
                    upperLabel: {
                        // name of Category
                        show: true,
                        fontSize: 18,
                        color: "#ffffff",
                        backgroundColor: "#558b60db",
                    },
                    value: bothProt.length,     // how much space this category will get
                    children: bothProt             // proteinsBoth here

                },
                {
                    name: setName2,
                    itemStyle: {
                        color: colorSet2,
                    },
                    upperLabel: {
                        // name of Category
                        show: true,
                        fontSize: 18,
                        color: "#ffffff",
                        backgroundColor: "#e9615ade",
                    },
                    value: only2Prot.length,    // how much space this category will get
                    children: only2Prot             // proteinsSet2 here

                }
            ]
        }
    ]
}

// set options to chart
pvCompChart.setOption(pvCompChartOpt);


// selecting elements
pvCompChart.on("click", function (params) {
    // Console log Name + ID
    console.log("Uniprot ID of " + params.data.name + " is: " + params.data.id);

    let text2Show = "<p> Selected: " + params.data.name + "</p>" + "<p>Modified positions: " + params.data.value + "</p>" + "<p>Uniprot ID: " + params.data.id + "</p>";
    document.getElementById("SelectTextHere").innerHTML = text2Show;

    // updates uniprot id for dashboard
    _uniprotID = params.data.id;
});